Attribute VB_Name = "SheetReferencesToIndirect"
Option Explicit
' SHEET REFERENCE ACTION AND ITS PRIVATE HELPERS - version 2.0.1.
' Used by frmSheetReferences only. The separate IFS module has no dependency
' on this module or form. No workbook events or keyboard bindings are added.
Private Const TITLE As String = "Change worksheet references"
Private Const BACKUP_TAG As String = "sheet_references"
Private currentDialog As Object

Public Sub MakeSheetReferencesIndirect()
    ' The only exposed sheet-reference launcher. Keep this existing name so
    ' assigned shortcuts/buttons continue to work; choose either replacement
    ' behaviour INSIDE the popup instead of exposing a second launch macro.
    IR_Open False
End Sub

Private Sub IR_Open(ByVal direct As Boolean)
    Dim picked As Range, stage As String
    On Error GoTo Failed
    stage = "capturing the selected target cells"
    If TypeName(Application.Selection) <> "Range" Then Err.Raise vbObjectError + 720, , "Select a worksheet cell or range first."
    Set picked = Application.Selection
    If ActiveWindow.SelectedSheets.Count > 1 Then Err.Raise vbObjectError + 721, , "Ungroup the selected worksheet tabs first. Only one target worksheet is supported."
    stage = "opening frmSheetReferences"
    Set currentDialog = VBA.UserForms.Add("frmSheetReferences")
    currentDialog.Prepare picked, direct
    currentDialog.Show vbModeless
    Exit Sub
Failed:
    MsgBox IR_Error("IR_Open", stage, Err.Number, Err.Description) & vbCrLf & vbCrLf & _
        "If the popup is not installed, import frmSheetReferences.frm with its matching .frx file. The guide also provides copy/paste setup.", vbExclamation, TITLE
End Sub

Public Function IR_Error(ByVal routine As String, ByVal context As String, ByVal number As Long, ByVal description As String) As String
    ' One diagnostic format for form, resolver, planning, applying and rollback.
    IR_Error = "SheetReferencesToIndirect." & routine & vbCrLf & "Stage: " & context & vbCrLf & "Error " & CStr(number) & ": " & description
End Function

Private Function IR_Sheet(ByVal wb As Workbook, ByVal name As String) As Worksheet
    ' A checked lookup avoids error 9 from Worksheets(unvalidated user text).
    Dim ws As Worksheet
    For Each ws In wb.Worksheets
        If StrComp(ws.Name, name, vbTextCompare) = 0 Then Set IR_Sheet = ws: Exit Function
    Next ws
End Function

Public Function IR_NormalSheet(ByVal raw As Variant, ByVal wb As Workbook, ByRef why As String) As String
    ' Used by both live fields and final preflight. Exact existing names win,
    ' including names with punctuation; optional reference syntax is removed.
    Dim s As String, ws As Worksheet, i As Long, bang As Long, quoted As Boolean, ch As String, p As Long
    why = vbNullString
    If IsError(raw) Or IsArray(raw) Or IsObject(raw) Then why = "The value is an Excel error or more than one value.": Exit Function
    s = CStr(raw): Set ws = IR_Sheet(wb, s)
    If Not ws Is Nothing Then IR_NormalSheet = ws.Name: Exit Function
    s = Trim$(s)
    If Left$(s, 1) = "=" Then s = Trim$(Mid$(s, 2))
    If Left$(s, 1) = Chr$(34) And Right$(s, 1) = Chr$(34) And Len(s) > 1 Then s = Replace(Mid$(s, 2, Len(s) - 2), Chr$(34) & Chr$(34), Chr$(34))
    Set ws = IR_Sheet(wb, s)
    If Not ws Is Nothing Then IR_NormalSheet = ws.Name: Exit Function
    ' Locate the qualifier separator outside apostrophe-quoted sheet names.
    i = 1
    Do While i <= Len(s)
        ch = Mid$(s, i, 1)
        If ch = "'" Then
            If quoted And Mid$(s, i + 1, 1) = "'" Then i = i + 1 Else quoted = Not quoted
        ElseIf ch = "!" And Not quoted Then
            bang = i
        End If
        i = i + 1
    Loop
    ' Excel consumes a leading apostrophe when text is typed into a cell.
    ' A displayed 'Sheet'!A1 can therefore arrive as Sheet'!A1 in Value2.
    If bang = 0 And Left$(s, 1) <> "'" Then
        p = InStrRev(s, "!")
        If p > 1 Then
            If Mid$(s, p - 1, 1) = "'" Then bang = p
        End If
    End If
    If bang > 0 Then s = Trim$(Left$(s, bang - 1))
    If Left$(s, 1) = "'" And Right$(s, 1) = "'" And Len(s) > 1 Then s = Replace(Mid$(s, 2, Len(s) - 2), "''", "'")
    If Left$(s, 1) <> "'" And Right$(s, 1) = "'" Then s = Replace(Left$(s, Len(s) - 1), "''", "'")
    If Left$(s, 1) = "[" Then
        p = InStr(1, s, "]", vbBinaryCompare)
        If p > 0 Then
            If StrComp(Mid$(s, 2, p - 2), wb.Name, vbTextCompare) <> 0 Then why = "That reference names a different workbook. Use " & wb.Name & ".": Exit Function
            s = Mid$(s, p + 1)
        End If
    End If
    Set ws = IR_Sheet(wb, s)
    If ws Is Nothing Then
        why = "No worksheet named " & Chr$(34) & s & Chr$(34) & " was found in " & wb.Name & ". Check the spelling and the target workbook."
    Else
        IR_NormalSheet = ws.Name
    End If
End Function

Public Function IR_Resolve(ByVal inputText As String, ByVal referenceMode As Boolean, ByVal ws As Worksheet, Optional ByVal picked As Range = Nothing) As Object
    ' Returns one checked destination and its formula expression. A picked
    ' formula cell is accepted through Value2, not its displayed formatting.
    Dim d As Object, r As Range, nm As Name, v As Variant, text As String, why As String, dest As String, expression As String
    Set d = CreateObject("Scripting.Dictionary")
    d.Add "OK", False: d.Add "Message", "Enter a replacement worksheet or choose a cell."
    d.Add "Sheet", "": d.Add "Expression", "": d.Add "Rule expression", "": d.Add "Cell", Nothing
    Set IR_Resolve = d
    On Error GoTo Invalid
    text = Trim$(inputText)
    If Len(text) = 0 And picked Is Nothing Then Exit Function
    If referenceMode Then
        If Not picked Is Nothing Then
            Set r = picked
        Else
            If Left$(text, 1) = "=" Then text = Mid$(text, 2)
            ' A typed named cell, table column or INDEX reference must resolve
            ' to one cell. A column with several rows is deliberately ambiguous.
            On Error Resume Next
            Set r = ws.Range(text)
            If r Is Nothing Then Set r = ws.Evaluate(text)
            On Error GoTo Invalid
            If r Is Nothing Then
                ' A defined name may itself be a formula returning sheet text.
                For Each nm In ws.Parent.Names
                    If StrComp(nm.Name, text, vbTextCompare) = 0 Or StrComp(nm.Name, ws.Name & "!" & text, vbTextCompare) = 0 Or StrComp(nm.Name, "'" & Replace(ws.Name, "'", "''") & "'!" & text, vbTextCompare) = 0 Then
                        v = ws.Evaluate(text): expression = text: Exit For
                    End If
                Next nm
                If Len(expression) = 0 Then Err.Raise vbObjectError + 722, , "This is not a single-cell reference or defined name. Choose Worksheet name for a literal sheet name."
            End If
        End If
        If Not r Is Nothing Then
            If r.CountLarge <> 1 Then Err.Raise vbObjectError + 723, , "The reference resolves to " & Format$(r.CountLarge, "0") & " cells. Pick one data cell or enter INDEX(TableName[Column],row_number)."
            If Not r.Parent.Parent Is ws.Parent Then Err.Raise vbObjectError + 724, , "Choose a selector cell in " & ws.Parent.Name & "."
            r.Calculate: v = r.Value2
            expression = IR_SelectorReference(r, ws)
            Set d("Cell") = r
            ' Native DV/CF cannot accept every structured reference. A real
            ' selected cell has an equivalent absolute address for those rules.
            d("Rule expression") = "'" & Replace(r.Parent.Name, "'", "''") & "'!" & r.Address(True, True)
        Else
            d("Rule expression") = expression
        End If
    Else
        v = inputText
    End If
    dest = IR_NormalSheet(v, ws.Parent, why)
    If Len(why) > 0 Then Err.Raise vbObjectError + 725, , why
    If referenceMode Then
        expression = IR_CleanExpression(expression, CStr(v), dest)
        d("Rule expression") = IR_CleanExpression(CStr(d("Rule expression")), CStr(v), dest)
    Else
        expression = IR_Quote(dest): d("Rule expression") = expression
    End If
    d("OK") = True: d("Sheet") = dest: d("Expression") = expression
    d("Message") = "Resolved: worksheet " & Chr$(34) & dest & Chr$(34) & " in " & ws.Parent.Name & "."
    If referenceMode Then d("Message") = d("Message") & vbCrLf & "Linked source: " & IIf(Len(expression) > 150, "selected reference (text cleaned automatically)", expression)
    Exit Function
Invalid:
    d("Message") = Err.Description
End Function

Private Function IR_CleanExpression(ByVal expression As String, ByVal raw As String, ByVal clean As String) As String
    ' Ordinary sheet-name cells stay short. If the current cell value includes
    ' quotes / !address syntax, a built-in LET expression normalizes that text
    ' too, without introducing a VBA worksheet function or a hidden helper cell.
    If StrComp(raw, clean, vbTextCompare) = 0 Then IR_CleanExpression = expression: Exit Function
    If StrComp(Trim$(raw), clean, vbTextCompare) = 0 Then IR_CleanExpression = "TRIM(" & expression & ")": Exit Function
    IR_CleanExpression = "LET(_ir,TRIM(" & expression & "),_it,IF(LEFT(_ir,1)=" & IR_Quote("=") & ",TRIM(MID(_ir,2,999)),_ir),_id,IF(AND(LEFT(_it,1)=CHAR(34),RIGHT(_it,1)=CHAR(34)),SUBSTITUTE(MID(_it,2,LEN(_it)-2),CHAR(34)&CHAR(34),CHAR(34)),_it),_iq,LEFT(_id,1)=" & IR_Quote("'") & ",_ie,SUBSTITUTE(_id," & IR_Quote("''") & ",CHAR(1)),_is,IF(_iq,IFERROR(LEFT(MID(_ie,2,999),FIND(" & IR_Quote("'") & ",MID(_ie,2,999))-1),MID(_ie,2,999)),IFERROR(LEFT(_id,FIND(" & IR_Quote("!") & ",_id)-1),_id)),_ix,IF(AND(NOT(_iq),RIGHT(_is,1)=" & IR_Quote("'") & "),SUBSTITUTE(LEFT(_is,LEN(_is)-1)," & IR_Quote("''") & "," & IR_Quote("'") & "),_is),IF(_iq,SUBSTITUTE(_ix,CHAR(1)," & IR_Quote("'") & "),_ix))"
End Function

Private Function IR_Transform(ByVal s As String, ByVal source As String, ByVal selector As String, ByVal ws As Worksheet, ByRef hits As Long, ByRef why As String, ByVal contextCell As Range, Optional ByVal direct As Boolean = False, Optional ByVal destination As String = "", Optional ByVal ruleContext As Boolean = False) As String
    ' Token-aware replacement; string literals, external books and structured
    ' reference headers are not a global text-replace target. ADDRESS/ROW/
    ' COLUMN preserve mixed $/relative fill behaviour in INDIRECT's A1 text.
    ' Keeping A1 mode also preserves compatibility with the separate IFS tool.
    Dim i As Long, j As Long, e As Long, ch As String, name As String, prev As String, out As String, address As String, matched As Boolean, arguments As String
    On Error GoTo Failed
    i = 1
    Do While i <= Len(s)
        ch = Mid$(s, i, 1)
        If ch = Chr$(34) Then
            j = IR_QuotedEnd(s, i): out = out & Mid$(s, i, j - i + 1): i = j + 1
        ElseIf ch = "[" Then
            j = IR_BracketEnd(s, i): out = out & Mid$(s, i, j - i + 1): i = j + 1
        ElseIf ch = "'" Or IR_NameChar(ch) Then
            If ch = "'" Then
                j = IR_QuotedEnd(s, i) + 1: name = Replace(Mid$(s, i + 1, j - i - 2), "''", "'")
            Else
                j = i + 1
                Do While IR_NameChar(Mid$(s, j, 1)): j = j + 1: Loop
                name = Mid$(s, i, j - i)
            End If
            prev = vbNullString: If i > 1 Then prev = Mid$(s, i - 1, 1)
            matched = (StrComp(name, source, vbTextCompare) = 0 And Mid$(s, j, 1) = "!")
            If prev = "]" Or prev = ":" Or prev = "!" Then matched = False
            If matched Then
                hits = hits + 1
                If direct Then
                    out = out & "'" & Replace(destination, "'", "''") & "'!": i = j + 1
                Else
                    address = IR_Address(s, j + 1, e)
                    If Len(address) = 0 Then why = "Unsupported named/spilled/constructed reference; kept unchanged.": IR_Transform = s: Exit Function
                    If ruleContext Then
                        ' Native CF/DV engines evaluate relative references in
                        ' their rule context. R1C1 text preserves that offset;
                        ' ADDRESS(ROW(A1)) is not equivalent in every CF engine.
                        arguments = Mid$(CStr(Application.ConvertFormula("=" & address, xlA1, xlR1C1, , contextCell)), 2)
                        out = out & "INDIRECT(CONCAT(" & IR_Quote("'") & ",SUBSTITUTE(" & selector & "," & IR_Quote("'") & "," & IR_Quote("''") & ")," & IR_Quote("'!") & "," & IR_Quote(arguments) & "),FALSE)"
                    Else
                        out = out & "INDIRECT(CONCAT(" & IR_Quote("'") & ",SUBSTITUTE(" & selector & "," & IR_Quote("'") & "," & IR_Quote("''") & ")," & IR_Quote("'!") & "," & IR_AddressArguments(address) & "))"
                    End If
                    i = e + 1
                End If
            Else
                out = out & Mid$(s, i, j - i): i = j
            End If
        Else
            out = out & ch: i = i + 1
        End If
    Loop
    IR_Transform = out
    Exit Function
Failed:
    why = "Formula needs review: " & Err.Description: IR_Transform = s
End Function

Private Function IR_AddressArguments(ByVal address As String) As String
    ' Fully absolute references remain short quoted A1 text. Relative pieces
    ' are native reference tokens inside ROW/COLUMN, so Excel adjusts them on
    ' fill/copy rather than freezing the original address inside a string.
    Dim p As Long
    p = InStr(1, address, ":", vbBinaryCompare)
    If p = 0 Then
        IR_AddressArguments = IR_AddressPiece(address)
    Else
        IR_AddressArguments = IR_AddressPiece(Left$(address, p - 1)) & "," & IR_Quote(":") & "," & IR_AddressPiece(Mid$(address, p + 1))
    End If
End Function

Private Function IR_AddressPiece(ByVal part As String) As String
    Dim p As Long, kind As Long, dollars As Long
    p = 1: kind = IR_AddressPart(part, p)
    dollars = Len(part) - Len(Replace(part, "$", ""))
    Select Case kind
        Case 3
            If dollars = 2 Then IR_AddressPiece = IR_Quote(part) Else IR_AddressPiece = "ADDRESS(ROW(" & part & "),COLUMN(" & part & "),1)"
        Case 1
            If dollars = 1 Then IR_AddressPiece = IR_Quote(part) Else IR_AddressPiece = "SUBSTITUTE(ADDRESS(1,COLUMN(" & part & "$1),4)," & IR_Quote("1") & "," & IR_Quote("") & ")"
        Case 2
            If dollars = 1 Then IR_AddressPiece = IR_Quote(part) Else IR_AddressPiece = "ROW($A" & part & ")"
        Case Else
            Err.Raise vbObjectError + 739, , "Unsupported address token: " & part
    End Select
End Function

Private Function IR_Read(ByVal c As Range, ByVal useF2 As Boolean) As String
    If useF2 Then
        IR_Read = CStr(CallByName(c, "Formula2", VbGet))
    Else
        IR_Read = CStr(c.Formula)
    End If
End Function

Private Sub IR_Write(ByVal c As Range, ByVal formula As String, ByVal useF2 As Boolean)
    If useF2 Then
        CallByName c, "Formula2", VbLet, formula
    Else
        c.Formula = formula
    End If
End Sub

Private Function IR_HasFormula2(ByVal c As Range) As Boolean
    Dim v As Variant
    On Error Resume Next
    v = CallByName(c, "Formula2", VbGet)
    IR_HasFormula2 = (Err.Number = 0)
    Err.Clear
    On Error GoTo 0
End Function

Private Function IR_CellRestriction(ByVal c As Range) As String
    Dim v As Variant
    If c.HasArray Then
        IR_CellRestriction = "Legacy array formula: edit the array as a unit manually."
        Exit Function
    End If
    On Error Resume Next
    v = CallByName(c, "HasSpill", VbGet)
    If Err.Number = 0 Then
        If Not IsNull(v) Then
            If CBool(v) Then IR_CellRestriction = "Spilled array: review the spill formula manually."
        End If
    End If
    Err.Clear
    On Error GoTo 0
End Function

Private Function IR_QuotedEnd(ByVal s As String, ByVal start As Long) As Long
    Dim i As Long, q As String
    q = Mid$(s, start, 1)
    i = start + 1
    Do While i <= Len(s)
        If Mid$(s, i, 1) = q Then
            If Mid$(s, i + 1, 1) = q Then
                i = i + 2
            Else
                IR_QuotedEnd = i
                Exit Function
            End If
        Else
            i = i + 1
        End If
    Loop
    Err.Raise vbObjectError + 710, TITLE, "Unclosed quotation in formula."
End Function

Private Function IR_BracketEnd(ByVal s As String, ByVal start As Long) As Long
    Dim i As Long, depth As Long, ch As String
    i = start
    Do While i <= Len(s)
        ch = Mid$(s, i, 1)
        If ch = "'" And i < Len(s) Then
            ' Apostrophe escapes special characters in structured references.
            i = i + 2
        Else
            If ch = "[" Then depth = depth + 1
            If ch = "]" Then
                depth = depth - 1
                If depth = 0 Then
                    IR_BracketEnd = i
                    Exit Function
                End If
            End If
            i = i + 1
        End If
    Loop
    Err.Raise vbObjectError + 711, TITLE, "Unclosed bracket in formula."
End Function

Private Function IR_NameChar(ByVal ch As String) As Boolean
    If Len(ch) = 0 Then Exit Function
    IR_NameChar = (ch Like "[A-Za-z0-9_.$\]")
    If AscW(ch) < 0 Or AscW(ch) > 127 Then IR_NameChar = True
End Function

Private Function IR_Quote(ByVal s As String) As String
    IR_Quote = Chr$(34) & Replace(s, Chr$(34), Chr$(34) & Chr$(34)) & Chr$(34)
End Function


Private Function IR_SelectorReference(ByVal selectedCell As Range, ByVal targetSheet As Worksheet) As String
    Dim table As ListObject, column As ListColumn, data As Range
    Dim expression As String, rowNumber As Long, candidate As String
    Dim definedName As Name, bestName As String, rank As Long, bestRank As Long
    If selectedCell.CountLarge <> 1 Then Err.Raise 5, TITLE, "Select exactly one selector cell."
    If Not (selectedCell.Parent.Parent Is targetSheet.Parent) Then _
        Err.Raise 5, TITLE, "The selector cell must be in the target workbook."

    ' First preference: a structured reference to the selected table column.
    On Error Resume Next
    Set table = selectedCell.ListObject
    On Error GoTo 0
    If Not table Is Nothing Then
        Set column = table.ListColumns(selectedCell.Column - table.Range.Column + 1)
        Set data = column.DataBodyRange
        If data Is Nothing Then Err.Raise 5, TITLE, "Select a table data cell, not its header or totals row."
        If Application.Intersect(selectedCell, data) Is Nothing Then _
            Err.Raise 5, TITLE, "Select a table data cell, not its header or totals row."
        expression = table.Name & IR_ColumnSpecifier(column.Name)
        If data.Rows.Count > 1 Then
            rowNumber = selectedCell.Row - data.Row + 1
            expression = "INDEX(" & expression & "," & CStr(rowNumber) & ")"
        End If
        IR_SelectorReference = expression
        Exit Function
    End If

    ' Second preference: a visible, non-relative name resolving to this cell.
    ' Workbook names rank ahead of worksheet names; ties use alphabetical order.
    bestRank = 999
    For Each definedName In selectedCell.Parent.Parent.Names
        candidate = IR_UsableCellName(definedName, selectedCell, targetSheet, rank)
        If Len(candidate) > 0 Then
            If rank < bestRank Or (rank = bestRank And StrComp(candidate, bestName, vbTextCompare) < 0) Then
                bestName = candidate
                bestRank = rank
            End If
        End If
    Next definedName
    If Len(bestName) > 0 Then
        IR_SelectorReference = bestName
        Exit Function
    End If

    ' Final preference: a sheet-qualified absolute cell address.
    IR_SelectorReference = "'" & Replace(selectedCell.Worksheet.Name, "'", "''") & "'!" & _
                           selectedCell.Address(True, True, xlA1)
End Function

Private Function IR_ColumnSpecifier(ByVal header As String) As String
    Dim i As Long, ch As String, escaped As String, special As Boolean
    Dim specialChars As String
    specialChars = vbTab & vbCr & vbLf & ",:.[]#'" & Chr$(34) & "{}$^&*+=-<>/@\!()%?`;~_"
    For i = 1 To Len(header)
        ch = Mid$(header, i, 1)
        If InStr(1, specialChars, ch, vbBinaryCompare) > 0 Then special = True
        If InStr(1, "[]#'@", ch, vbBinaryCompare) > 0 Then escaped = escaped & "'"
        escaped = escaped & ch
    Next i
    If special Then
        IR_ColumnSpecifier = "[[" & escaped & "]]"
    Else
        IR_ColumnSpecifier = "[" & escaped & "]"
    End If
End Function

Private Function IR_UsableCellName(ByVal definedName As Name, ByVal selectedCell As Range, _
                                  ByVal targetSheet As Worksheet, ByRef rank As Long) As String
    Dim referredCell As Range, localName As Name, fullName As String, leafName As String
    Dim absoluteDefinition As String, canonicalDefinition As String, candidate As String, bang As Long
    On Error GoTo Unusable
    If Not definedName.Visible Then Exit Function
    fullName = definedName.Name
    bang = InStrRev(fullName, "!")
    leafName = Mid$(fullName, bang + 1)
    Select Case LCase$(leafName)
        Case "print_area", "print_titles", "_filterdatabase": Exit Function
    End Select
    If LCase$(Left$(leafName, 6)) = "_xlnm." Then Exit Function
    Set referredCell = definedName.RefersToRange
    If Not IR_SameCell(referredCell, selectedCell) Then Exit Function
    ' A relative name can point somewhere else in each rewritten formula.
    ' Do not silently turn it into the fixed selector chosen by the user.
    absoluteDefinition = Application.ConvertFormula(definedName.RefersTo, xlA1, xlA1, xlAbsolute, selectedCell)
    canonicalDefinition = Application.ConvertFormula(definedName.RefersTo, xlA1, xlA1, , selectedCell)
    If StrComp(absoluteDefinition, canonicalDefinition, vbTextCompare) <> 0 Then Exit Function
    If bang = 0 Then
        rank = 1
        candidate = fullName
        For Each localName In targetSheet.Names
            If StrComp(Mid$(localName.Name, InStrRev(localName.Name, "!") + 1), fullName, vbTextCompare) = 0 Then
                ' A local name wins over a bare workbook name on this sheet.
                candidate = "'" & Replace(selectedCell.Parent.Parent.Name, "'", "''") & "'!" & fullName
                Exit For
            End If
        Next localName
    Else
        rank = 2
        candidate = fullName
    End If
    IR_UsableCellName = candidate
Unusable:
End Function

Private Function IR_SameCell(ByVal first As Range, ByVal second As Range) As Boolean
    If first Is Nothing Or second Is Nothing Then Exit Function
    If first.CountLarge <> 1 Or second.CountLarge <> 1 Then Exit Function
    If Not (first.Parent Is second.Parent) Then Exit Function
    IR_SameCell = (first.Address = second.Address)
End Function


Private Function IR_Address(ByVal s As String, ByVal start As Long, ByRef finish As Long) As String
    Dim p As Long, firstKind As Long, secondKind As Long, ch As String, nextNonSpace As Long
    p = start
    firstKind = IR_AddressPart(s, p)
    If firstKind = 0 Then Exit Function
    If Mid$(s, p, 1) = ":" Then
        p = p + 1
        secondKind = IR_AddressPart(s, p)
        If firstKind <> secondKind Or secondKind = 0 Then Exit Function
    ElseIf firstKind <> 3 Then
        Exit Function
    End If
    ch = Mid$(s, p, 1)
    If IR_NameChar(ch) Or ch = "#" Or ch = "[" Or ch = "!" Or ch = ":" Or ch = "(" Then Exit Function
    nextNonSpace = p
    Do While Mid$(s, nextNonSpace, 1) = " "
        nextNonSpace = nextNonSpace + 1
    Loop
    If Mid$(s, nextNonSpace, 1) = ":" Then Exit Function
    finish = p - 1
    IR_Address = Mid$(s, start, p - start)
End Function

Private Function IR_AddressPart(ByVal s As String, ByRef p As Long) As Long
    ' 1 = column, 2 = row, 3 = cell; zero = unsupported.
    Dim col As Long, row As Double, letters As Long, digits As Long, ch As String
    If Mid$(s, p, 1) = "$" Then p = p + 1
    Do
        ch = UCase$(Mid$(s, p, 1))
        If Len(ch) = 0 Then Exit Do
        If ch < "A" Or ch > "Z" Then Exit Do
        letters = letters + 1
        If letters > 3 Then Exit Function
        col = col * 26 + Asc(ch) - 64
        p = p + 1
    Loop
    If col > 16384 Then Exit Function
    If letters > 0 And Mid$(s, p, 1) = "$" Then p = p + 1
    If Mid$(s, p, 1) = "0" Then Exit Function
    Do
        ch = Mid$(s, p, 1)
        If Len(ch) = 0 Then Exit Do
        If ch < "0" Or ch > "9" Then Exit Do
        digits = digits + 1
        row = row * 10 + CLng(ch)
        If row > 1048576 Then Exit Function
        p = p + 1
    Loop
    If letters > 0 Then
        If digits > 0 Then IR_AddressPart = 3 Else IR_AddressPart = 1
    ElseIf digits > 0 Then
        IR_AddressPart = 2
    End If
End Function

Public Function IR_Plan(ByVal scope As Range, ByVal source As String, ByVal resolved As Object, ByVal direct As Boolean, ByVal includeCF As Boolean, ByVal includeDV As Boolean) As Collection
    ' A plan holds object references and before/after text, never changes the
    ' target. The form's Preview action is the only caller outside native tests.
    Dim plan As New Collection, ws As Worksheet, cells As Range, c As Range, rule As Object, seen As Object, rules As FormatConditions, ruleIndex As Long
    Dim before1 As String, before2 As String, after1 As String, after2 As String, why As String, hits As Long, hits2 As Long, kind As Long, op As Long, rec As Object, hit As Range
    Set ws = scope.Parent
    If ws.ProtectContents Then Err.Raise vbObjectError + 726, , "Unprotect " & ws.Name & " before changing its formulas or rules."
    Set seen = CreateObject("Scripting.Dictionary")
    On Error Resume Next
    Set cells = Intersect(scope, ws.UsedRange).SpecialCells(xlCellTypeFormulas)
    On Error GoTo Failed
    If Not cells Is Nothing Then
        ' Intersect again: Excel SpecialCells on a single cell can expand its
        ' search to UsedRange. A one-cell explicit scope must remain one cell.
        Set cells = Intersect(cells, scope)
        If cells Is Nothing Then GoTo NoFormulaCells
        For Each c In cells.Cells
            before1 = IR_Read(c, IR_HasFormula2(c)): hits = 0: why = vbNullString
            after1 = IR_Transform(before1, source, CStr(resolved("Expression")), ws, hits, why, c, direct, CStr(resolved("Sheet")))
            If hits > 0 Then
                If Len(why) = 0 Then why = IR_CellRestriction(c)
                If Not direct And Not resolved("Cell") Is Nothing Then
                    If IR_SameCell(c, resolved("Cell")) Then why = "Selector cell kept unchanged: rewriting it would introduce a self-reference."
                End If
                If Len(after1) > 8192 Then why = "The proposed formula is longer than Excel's 8,192-character limit."
                Set rec = IR_Record("Formula", c, c.Address(False, False), before1, after1, "", "", why)
                rec.Add "Formula2", IR_HasFormula2(c): plan.Add rec
            End If
        Next c
    End If
NoFormulaCells:
    If includeCF Then
        Set rules = ws.Cells.FormatConditions
        For ruleIndex = 1 To rules.Count
            Set rule = rules(ruleIndex)
            ' Priorities identify native rules uniquely on this worksheet.
            If Not seen.Exists(CStr(rule.Priority)) Then
                seen.Add CStr(rule.Priority), True
                Set hit = Nothing: Set hit = Intersect(scope, rule.AppliesTo)
                If Not hit Is Nothing Then
                    kind = rule.Type
                    If kind = xlExpression Or kind = xlCellValue Then
                        before1 = CStr(rule.Formula1): before2 = vbNullString: op = 0
                        If kind = xlCellValue Then op = rule.Operator
                        If kind = xlCellValue And (op = xlBetween Or op = xlNotBetween) Then before2 = CStr(rule.Formula2)
                        hits = 0: hits2 = 0: why = vbNullString
                        after1 = IR_Transform(before1, source, CStr(resolved("Rule expression")), ws, hits, why, rule.AppliesTo.Cells(1, 1), direct, CStr(resolved("Sheet")), True)
                        after2 = IR_Transform(before2, source, CStr(resolved("Rule expression")), ws, hits2, why, rule.AppliesTo.Cells(1, 1), direct, CStr(resolved("Sheet")), True)
                        If hits + hits2 > 0 Then
                            ' A native CF rule can cover cells outside scope.
                            ' Modifying it would change those cells as well.
                            If hit.CountLarge <> rule.AppliesTo.CountLarge Then why = "Shared conditional-formatting rule extends outside the selected range. Kept unchanged; select its whole Applies to range or choose Whole worksheet."
                            Set rec = IR_Record("Conditional formatting", rule, rule.AppliesTo.Address(False, False), before1, after1, before2, after2, why)
                            rec.Add "Type", kind: rec.Add "Operator", op: rec.Add "Priority", rule.Priority
                            rec.Add "Rank", ruleIndex
                            rec.Add "Worksheet", ws
                            rec.Add "Applies to", rule.AppliesTo.Address: plan.Add rec
                        End If
                    End If
                End If
            End If
        Next ruleIndex
    End If
    If includeDV Then
        Set cells = Nothing
        On Error Resume Next
        Set cells = scope.SpecialCells(xlCellTypeAllValidation)
        On Error GoTo Failed
        If Not cells Is Nothing Then
            Set cells = Intersect(cells, scope)
            If Not cells Is Nothing Then
                If cells.CountLarge > 200000 Then Err.Raise vbObjectError + 727, , "More than 200,000 validated cells are in scope. Select a smaller range for validation processing; no target changes have been made."
                For Each c In cells.Cells
                    kind = c.Validation.Type: op = c.Validation.Operator
                    before1 = CStr(c.Validation.Formula1): before2 = CStr(c.Validation.Formula2)
                    hits = 0: hits2 = 0: why = vbNullString
                    after1 = before1: after2 = before2
                    If Left$(before1, 1) = "=" Then after1 = IR_Transform(before1, source, CStr(resolved("Rule expression")), ws, hits, why, c, direct, CStr(resolved("Sheet")), True)
                    If Left$(before2, 1) = "=" Then after2 = IR_Transform(before2, source, CStr(resolved("Rule expression")), ws, hits2, why, c, direct, CStr(resolved("Sheet")), True)
                    If hits + hits2 > 0 Then
                        If Len(after1) > 255 Or Len(after2) > 255 Then why = "The replacement exceeds the native 255-character data-validation formula limit. Use a shorter named selector or straight replacement."
                        Set rec = IR_Record("Data validation", c, c.Address(False, False), before1, after1, before2, after2, why)
                        rec.Add "Type", kind: rec.Add "Operator", op: rec.Add "Alert", c.Validation.AlertStyle: plan.Add rec
                    End If
                Next c
            End If
        End If
    End If
    Set IR_Plan = plan
    Exit Function
Failed:
    Err.Raise Err.Number, "SheetReferencesToIndirect.IR_Plan", "Worksheet " & ws.Name & ": " & Err.Description
End Function

Private Function IR_Record(ByVal kind As String, ByVal target As Object, ByVal address As String, ByVal before1 As String, ByVal after1 As String, ByVal before2 As String, ByVal after2 As String, ByVal why As String) As Object
    ' One record shape lets planning, review, apply and rollback share exact
    ' evidence, while native rule objects preserve formatting and messages.
    Dim d As Object: Set d = CreateObject("Scripting.Dictionary")
    d.Add "Kind", kind: d.Add "Target", target: d.Add "Address", address
    d.Add "Before", before1: d.Add "After", after1: d.Add "Before2", before2: d.Add "After2", after2
    d.Add "State", IIf(Len(why) = 0, "Proposed", "Skipped"): d.Add "Details", why
    Set IR_Record = d
End Function

Public Function IR_Proposed(ByVal plan As Collection) As Long
    Dim d As Object
    For Each d In plan: If d("State") = "Proposed" Then IR_Proposed = IR_Proposed + 1
    Next d
End Function

Public Function IR_ShowPlan(ByVal plan As Collection, ByVal ws As Worksheet, ByVal scope As Range, ByVal destination As String, ByVal direct As Boolean) As Worksheet
    ' The report is a new UNSAVED workbook. Strings are stored as text so
    ' reviewing an old/new formula never executes that formula in the report.
    Dim sh As Worksheet, data() As Variant, d As Object, i As Long, key As Variant, j As Long
    Set sh = Workbooks.Add(xlWBATWorksheet).Worksheets(1): sh.Name = "Reference changes"
    sh.Range("A1:G6").NumberFormat = "@": sh.Range("A1:G1").Merge
    sh.Range("A1").Value2 = TITLE & " - preview"
    sh.Range("A2").Value2 = "Target": sh.Range("B2").Value2 = ws.Parent.FullName & " / " & ws.Name
    sh.Range("A3").Value2 = "Scope": sh.Range("B3").Value2 = scope.Address(False, False)
    sh.Range("A4").Value2 = "Replacement": sh.Range("B4").Value2 = destination & IIf(direct, " (straight replacement)", " (INDIRECT)")
    sh.Range("A5").Value2 = "State": sh.Range("B5").Value2 = "Preview only. The target is unchanged."
    sh.Range("A7:G7").Value2 = Array("Kind", "Cells / rule range", "Status", "Original", "Replacement", "Second bound: old -> new", "Explanation")
    If plan.Count > sh.Rows.Count - 7 Then Err.Raise vbObjectError + 728, , "The plan is too large for one report worksheet."
    If plan.Count > 0 Then
        ReDim data(1 To plan.Count, 1 To 7)
        For i = 1 To plan.Count
            Set d = plan(i): data(i, 1) = d("Kind"): data(i, 2) = d("Address"): data(i, 3) = d("State")
            data(i, 4) = d("Before"): data(i, 5) = d("After"): data(i, 6) = d("Before2") & IIf(Len(d("Before2")) > 0, " -> ", "") & d("After2"): data(i, 7) = d("Details")
        Next i
        With sh.Range("A8").Resize(plan.Count, 7)
            .NumberFormat = "@": .Value2 = data: .WrapText = True: .VerticalAlignment = xlTop: .Rows.RowHeight = 62
        End With
    Else
        sh.Range("A8").Value2 = "No matching references were found in the enabled categories and scope."
    End If
    sh.Range("A1:G" & CStr(Application.Max(8, plan.Count + 7))).Font.Name = "Tahoma"
    sh.Range("A1:G" & CStr(Application.Max(8, plan.Count + 7))).Font.Size = 12
    sh.Range("A1").Font.Size = 18: sh.Range("A1").Font.Bold = True
    sh.Range("A7:G7").Interior.Color = RGB(191, 234, 250): sh.Range("A7:G7").Font.Bold = True
    sh.Columns("A:B").ColumnWidth = 24: sh.Columns("C").ColumnWidth = 17: sh.Columns("D:F").ColumnWidth = 53: sh.Columns("G").ColumnWidth = 65
    sh.Range("A7:G" & CStr(Application.Max(8, plan.Count + 7))).AutoFilter
    sh.Activate: sh.Range("D8").Select: ActiveWindow.FreezePanes = True
    Set IR_ShowPlan = sh
End Function

Public Function IR_ApplyPlan(ByVal plan As Collection, ByVal wb As Workbook, ByVal makeBackup As Boolean, ByRef backupPath As String, Optional ByVal injectFailureAt As Long = 0) As Long
    ' All proposed objects are checked BEFORE the first write. On a failure,
    ' reverse only this transaction. Source workbooks are never auto-saved.
    ' injectFailureAt is a parameterised native-test hook, never a UI setting.
    Dim d As Object, i As Long, count As Long, changed As Long, target As Object, c As Range
    Dim events As Boolean, screen As Boolean, fill As Boolean, calculation As XlCalculation
    Dim captured As Boolean, stage As String, number As Long, description As String, rollback As String, previousSelection As Range
    On Error GoTo Failed
    stage = "checking the preview is still current"
    If wb.ReadOnly Then Err.Raise vbObjectError + 729, , "The target workbook is read-only."
    For Each d In plan
        If d("State") = "Proposed" Then
            Set target = d("Target")
            If d("Kind") = "Formula" Then
                Set c = target
                If c.Parent.ProtectContents Then Err.Raise vbObjectError + 730, , "The target worksheet is now protected."
                If IR_Read(c, CBool(d("Formula2"))) <> d("Before") Then Err.Raise vbObjectError + 731, , "Formula changed after preview: " & c.Parent.Name & "!" & d("Address")
            ElseIf d("Kind") = "Conditional formatting" Then
                If target.AppliesTo.Parent.ProtectContents Then Err.Raise vbObjectError + 730, , "The rule worksheet is now protected."
                If target.AppliesTo.Address <> d("Applies to") Or target.Priority <> d("Priority") Or CStr(target.Formula1) <> d("Before") Then Err.Raise vbObjectError + 732, , "Conditional-formatting rule changed after preview: " & d("Address")
                If Len(d("Before2")) > 0 Then
                    If CStr(target.Formula2) <> d("Before2") Then Err.Raise vbObjectError + 732, , "Second conditional-formatting bound changed after preview."
                End If
            Else
                Set c = target
                If c.Parent.ProtectContents Then Err.Raise vbObjectError + 730, , "The validation worksheet is now protected."
                If c.Validation.Type <> d("Type") Or CStr(c.Validation.Formula1) <> d("Before") Or CStr(c.Validation.Formula2) <> d("Before2") Then Err.Raise vbObjectError + 733, , "Data validation changed after preview: " & d("Address")
            End If
        End If
    Next d
    stage = "capturing Excel settings and the optional recovery copy"
    events = Application.EnableEvents: screen = Application.ScreenUpdating
    calculation = Application.Calculation: fill = Application.AutoCorrect.AutoFillFormulasInLists: captured = True
    If TypeName(Application.Selection) = "Range" Then Set previousSelection = Application.Selection
    Application.EnableEvents = False: Application.ScreenUpdating = False
    Application.Calculation = xlCalculationManual: Application.AutoCorrect.AutoFillFormulasInLists = False
    If makeBackup Then backupPath = IR_Backup(wb)
    For i = 1 To plan.Count
        Set d = plan(i)
        If d("State") = "Proposed" Then
            stage = "writing " & d("Kind") & " at " & d("Address")
            d("State") = "Writing": changed = changed + 1
            If injectFailureAt > 0 And changed = injectFailureAt Then Err.Raise vbObjectError + 734, , "Injected native-test write failure."
            IR_WriteRecord d, False
            d("State") = "Applied": count = count + 1
        End If
    Next i
    IR_ApplyPlan = count
Clean:
    If captured Then
        On Error Resume Next
        If Not previousSelection Is Nothing Then Application.Goto previousSelection, False
        On Error GoTo 0
        Application.AutoCorrect.AutoFillFormulasInLists = fill
        Application.Calculation = calculation: Application.EnableEvents = events: Application.ScreenUpdating = screen
    End If
    If number <> 0 Then Err.Raise number, "SheetReferencesToIndirect.IR_ApplyPlan", stage & vbCrLf & description & rollback
    Exit Function
Failed:
    number = Err.Number: description = Err.Description
    On Error Resume Next
    For i = plan.Count To 1 Step -1
        Set d = plan(i)
        If d("State") = "Applied" Or d("State") = "Writing" Then
            Err.Clear: IR_WriteRecord d, True
            If Err.Number = 0 Then
                d("State") = "Restored": d("Details") = "Run stopped; original restored."
            Else
                d("State") = "Restore failed": d("Details") = Err.Description
                rollback = rollback & vbCrLf & "RESTORE FAILED: " & d("Kind") & " " & d("Address") & ". " & Err.Description
            End If
        End If
    Next i
    On Error GoTo 0
    Resume Clean
End Function

Private Sub IR_WriteRecord(ByVal d As Object, ByVal restore As Boolean)
    ' Modify native rules in place: preserve fill, font, border, order,
    ' StopIfTrue, validation prompts, error messages and dropdown settings.
    Dim first As String, second As String, target As Object, c As Range, condition As FormatCondition
    first = CStr(d(IIf(restore, "Before", "After"))): second = CStr(d(IIf(restore, "Before2", "After2")))
    Set target = d("Target")
    Select Case d("Kind")
        Case "Formula"
            Set c = target: IR_Write c, first, CBool(d("Formula2"))
        Case "Conditional formatting"
            ' Anchor rule operations to their first cell. More importantly,
            ' IR_ConditionAt returns an AppliesTo-scoped native wrapper:
            ' a whole-sheet wrapper can shift relative references on Modify.
            Application.Goto d("Worksheet").Range(CStr(d("Applies to"))).Cells(1, 1), False
            ' A previous rule write/reorder may invalidate cached wrappers
            ' for OTHER rules too. Resolve by the restored order + scope
            ' immediately before each write, including rollback writes.
            Set condition = IR_ConditionAt(d("Worksheet"), CStr(d("Applies to")), CLng(d("Rank")))
            If d("Type") = xlExpression Then
                condition.Modify Type:=xlExpression, Formula1:=first
            Else
                condition.Modify Type:=xlCellValue, Operator:=d("Operator"), Formula1:=first, Formula2:=second
            End If
            ' Modify replaces the native rule wrapper on some Excel builds.
            ' Reacquire its newly appended rule before restoring priority;
            ' retaining the old COM wrapper can read stale order or fail.
            Set condition = IR_FreshCondition(d("Worksheet"), CStr(d("Applies to")), CLng(d("Type")))
            ' Excel can change a rule's priority even when its type is the
            ' same. Put it back explicitly, retaining the relative rule order.
            condition.Priority = CLng(d("Rank"))
            Set d("Target") = condition
        Case "Data validation"
            Set c = target
            c.Validation.Modify Type:=d("Type"), AlertStyle:=d("Alert"), Operator:=d("Operator"), Formula1:=first, Formula2:=second
    End Select
End Sub

Private Function IR_ConditionAt(ByVal ws As Worksheet, ByVal applies As String, ByVal rank As Long) As FormatCondition
    ' Used immediately before a CF write or rollback. Use whole-sheet order
    ' only to identify the rule, then acquire it THROUGH its exact AppliesTo
    ' range. Excel associates relative-formula context with the parent range
    ' of the rule wrapper; modifying a ws.Cells wrapper can shift A1 to T1.
    Dim rules As FormatConditions, candidate As Object, i As Long, priority As Long
    Set rules = ws.Cells.FormatConditions
    If rank <= rules.Count Then
        Set candidate = rules(rank)
        If candidate.AppliesTo.Address = applies Then
            priority = candidate.Priority
            Set rules = ws.Range(applies).FormatConditions
            For i = 1 To rules.Count
                Set candidate = rules(i)
                If candidate.Priority = priority And candidate.AppliesTo.Address = applies Then
                    Set IR_ConditionAt = candidate: Exit Function
                End If
            Next i
        End If
    End If
    Err.Raise vbObjectError + 738, , "Conditional-formatting rule no longer matches order " & CStr(rank) & " at " & applies & ". Build a fresh preview."
End Function

Private Function IR_FreshCondition(ByVal ws As Worksheet, ByVal applies As String, ByVal kind As Long) As FormatCondition
    ' Excel appends the replacement rule last. Other rules have not changed
    ' during this transaction (events are suspended), so the greatest priority
    ' for this exact AppliesTo/type identifies the freshly modified rule.
    Dim candidate As Object, greatest As Long, rules As FormatConditions, i As Long
    Set rules = ws.Range(applies).FormatConditions
    For i = 1 To rules.Count
        Set candidate = rules(i)
        If candidate.Type = kind Then
            If candidate.AppliesTo.Address = applies And candidate.Priority > greatest Then
                greatest = candidate.Priority: Set IR_FreshCondition = candidate
            End If
        End If
    Next i
    If IR_FreshCondition Is Nothing Then Err.Raise vbObjectError + 737, , "Could not reacquire the modified conditional-formatting rule for " & applies
End Function

Private Function IR_Backup(ByVal wb As Workbook) As String
    ' Only a user-selected Apply option creates a separate recovery copy.
    ' SaveCopyAs does not save the original workbook or mark its edits saved.
    Dim p As Long, base As String, ext As String, path As String, i As Long
    If Len(wb.Path) = 0 Or InStr(wb.Path, "://") > 0 Then Err.Raise vbObjectError + 735, , "For a recovery copy, save the target to a local/synced folder first, or turn off Make recovery copy."
    p = InStrRev(wb.Name, ".")
    If p = 0 Then Err.Raise vbObjectError + 736, , "The target needs an Excel filename before a recovery copy can be made."
    base = wb.Path & Application.PathSeparator & Left$(wb.Name, p - 1) & "_before_" & BACKUP_TAG & "_" & Format$(Now, "yyyymmdd_hhnnss")
    ext = Mid$(wb.Name, p): path = base & ext
    Do While Len(Dir$(path)) > 0: i = i + 1: path = base & "_" & CStr(i) & ext: Loop
    wb.SaveCopyAs path: IR_Backup = path
End Function
