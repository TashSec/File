VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmSheetReferences 
   Caption         =   "UserForm1"
   ClientHeight    =   3015
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   4560
   OleObjectBlob   =   "frmSheetReferences.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmSheetReferences"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
' frmSheetReferences - native runtime-built popup, version 2.0.
' This form owns interaction and event handlers only. The matching standard
' module resolves references and plans/applies transactions. No VBProject
' access, workbook events, helper executables or automatic saves are used.
Private targetSheet As Worksheet
Private initialRange As Range
Private selectedNameCell As Range
Private planned As Collection
Private report As Worksheet
Private previewDestination As String, previewSource As String, previewExpression As String
Private busy As Boolean, updating As Boolean
Private WithEvents txtSource As MSForms.TextBox
Attribute txtSource.VB_VarHelpID = -1
Private WithEvents txtTarget As MSForms.TextBox
Attribute txtTarget.VB_VarHelpID = -1
Private WithEvents optWhole As MSForms.OptionButton
Attribute optWhole.VB_VarHelpID = -1
Private WithEvents optSelected As MSForms.OptionButton
Attribute optSelected.VB_VarHelpID = -1
Private WithEvents optReference As MSForms.OptionButton
Attribute optReference.VB_VarHelpID = -1
Private WithEvents optLiteral As MSForms.OptionButton
Attribute optLiteral.VB_VarHelpID = -1
Private WithEvents optIndirect As MSForms.OptionButton
Attribute optIndirect.VB_VarHelpID = -1
Private WithEvents optDirect As MSForms.OptionButton
Attribute optDirect.VB_VarHelpID = -1
Private WithEvents chkCF As MSForms.ToggleButton
Attribute chkCF.VB_VarHelpID = -1
Private WithEvents chkDV As MSForms.ToggleButton
Attribute chkDV.VB_VarHelpID = -1
Private WithEvents chkBackup As MSForms.ToggleButton
Attribute chkBackup.VB_VarHelpID = -1
Private WithEvents cmdPick As MSForms.CommandButton
Attribute cmdPick.VB_VarHelpID = -1
Private WithEvents cmdPreview As MSForms.CommandButton
Attribute cmdPreview.VB_VarHelpID = -1
Private WithEvents cmdApply As MSForms.CommandButton
Attribute cmdApply.VB_VarHelpID = -1
Private WithEvents cmdCancel As MSForms.CommandButton
Attribute cmdCancel.VB_VarHelpID = -1
Private lblContext As MSForms.Label, lblSource As MSForms.Label, lblTarget As MSForms.Label, lblSummary As MSForms.Label

Private Sub UserForm_Initialize()
    ' All controls are created here so copying this code into one BLANK form
    ' is equivalent to importing the delivered native FRM/FRX pair.
    Dim frame As MSForms.frame
    Me.caption = "Change worksheet references": Me.width = 710: Me.height = 660
    Me.BackColor = RGB(255, 252, 250): Me.StartUpPosition = 1
    Label "lblTitle", "Change worksheet references", 18, 12, 660, 28, 18, True
    Set lblContext = Label("lblContext", "", 18, 49, 660, 30, 11)
    Set frame = Me.Controls.Add("Forms.Frame.1", "fraScope", True)
    frame.caption = "What should change?": frame.Left = 18: frame.Top = 84: frame.width = 660: frame.height = 59: frame.BackColor = Me.BackColor
    Set optWhole = OptionControl(frame, "optWhole", "Whole worksheet", 12, 22, 250, "Use every formula on the target worksheet. Enabled rule options also consider rules across that worksheet.")
    Set optSelected = OptionControl(frame, "optSelected", "Only the original selection", 300, 22, 335, "Keep the range selected before this popup opened. Choosing a replacement-name cell does not change this scope.")
    Label "lblOldTitle", "Worksheet name to remove from references", 18, 156, 660, 20, 12, True
    Set txtSource = TextControl("txtSource", 18, 179, 660, "Enter the source sheet. Sheet1, 'Sheet 1', or 'Sheet 1'!$A$1 are normalized automatically.")
    Set lblSource = Label("lblSource", "", 18, 211, 660, 30, 11)
    Label "lblNewTitle", "Replacement worksheet - choose how to supply it", 18, 250, 660, 20, 12, True
    Set cmdPick = Button("cmdPick", "Pick a name cell...", 18, 275, 161, "Click a single cell containing the replacement sheet name. A formula returning the name is allowed. Table data cells and named cells are recognised.")
    Set optReference = OptionControl(Me, "optReference", "Cell / name / table reference", 194, 275, 290, "Type a named cell, sheet-qualified cell, single-row table column, or INDEX(Table[Column],row). The resolved cell may contain a formula.")
    Set optLiteral = OptionControl(Me, "optLiteral", "Worksheet name", 502, 275, 180, "Type the replacement worksheet itself. Quotes, an equals sign, ! and a reference suffix are cleaned for you.")
    Set txtTarget = TextControl("txtTarget", 18, 314, 660, "Enter the reference or worksheet selected above. Read the resolved result immediately underneath before previewing.")
    Set lblTarget = Label("lblTarget", "", 18, 347, 660, 44, 11)
    Set frame = Me.Controls.Add("Forms.Frame.1", "fraMode", True)
    frame.caption = "Replacement behaviour": frame.Left = 18: frame.Top = 399: frame.width = 660: frame.height = 55: frame.BackColor = Me.BackColor
    Set optIndirect = OptionControl(frame, "optIndirect", "Use INDIRECT - follow the name", 12, 20, 325, "Link formulas to the selected name cell/reference. Changing that value later changes the destination. A typed worksheet name becomes a fixed text input to INDIRECT.")
    Set optDirect = OptionControl(frame, "optDirect", "Straight sheet replacement", 350, 20, 290, "Replace the sheet qualifier with the currently resolved worksheet name. Later changes to the selector will not redirect these formulas.")
    Set chkCF = Toggle("chkCF", "Conditional formatting", 18, 467, 310, "Also update formula and cell-value conditional-formatting rules. A rule covering cells outside a limited selection is reported and skipped.")
    Set chkDV = Toggle("chkDV", "Data validation", 349, 467, 329, "Also update formula-based validation sources/bounds in scope. Prompts and dropdown/error settings are retained. Literal comma-separated lists are not rewritten.")
    Set chkBackup = Toggle("chkBackup", "Make a recovery copy", 18, 507, 285, "Optional: before Apply, create a separate timestamped copy beside a saved local/synced workbook. The original workbook is never automatically saved.")
    Label "lblSaveHint", "Changes remain unsaved. Excel Undo is unavailable after a macro.", 319, 508, 359, 35, 11
    Set lblSummary = Label("lblSummary", "Preview first to inspect the exact changes.", 18, 548, 660, 22, 11)
    Set cmdPreview = Button("cmdPreview", "Preview changes", 18, 582, 190, "Build an unsaved before/after report. This does not change any target formulas or rules.")
    Set cmdApply = Button("cmdApply", "Apply previewed changes", 235, 582, 227, "Apply only the current reviewed plan. The macro checks for intervening edits and rolls back this run if a write fails.")
    Set cmdCancel = Button("cmdCancel", "Close", 488, 582, 190, "Close this popup. A preview alone changes nothing. Existing preview reports are left open for your review.")
    cmdCancel.Cancel = True: cmdApply.Enabled = False
    updating = True: optReference.Value = True: optIndirect.Value = True: updating = False
End Sub

Private Function Label(ByVal name As String, ByVal caption As String, ByVal x As Double, ByVal y As Double, ByVal width As Double, ByVal height As Double, ByVal size As Double, Optional ByVal bold As Boolean = False) As MSForms.Label
    Dim c As MSForms.Label: Set c = Me.Controls.Add("Forms.Label.1", name, True)
    c.caption = caption: c.Left = x: c.Top = y: c.width = width: c.height = height: c.BackStyle = 0: c.WordWrap = True
    c.Font.name = "Tahoma": c.Font.size = size: c.Font.bold = bold: c.ForeColor = RGB(77, 94, 106)
    If bold Then c.ForeColor = RGB(32, 38, 53)
    Set Label = c
End Function

Private Function TextControl(ByVal name As String, ByVal x As Double, ByVal y As Double, ByVal width As Double, ByVal tip As String) As MSForms.TextBox
    Dim c As MSForms.TextBox: Set c = Me.Controls.Add("Forms.TextBox.1", name, True)
    c.Left = x: c.Top = y: c.width = width: c.height = 27: c.Font.name = "Tahoma": c.Font.size = 13
    c.BackColor = RGB(255, 241, 247): c.ForeColor = RGB(32, 38, 53): c.ControlTipText = tip
    Set TextControl = c
End Function

Private Function Button(ByVal name As String, ByVal caption As String, ByVal x As Double, ByVal y As Double, ByVal width As Double, ByVal tip As String) As MSForms.CommandButton
    Dim c As MSForms.CommandButton: Set c = Me.Controls.Add("Forms.CommandButton.1", name, True)
    c.caption = caption: c.Left = x: c.Top = y: c.width = width: c.height = 31
    c.Font.name = "Tahoma": c.Font.size = 12: c.Font.bold = True: c.ForeColor = RGB(32, 38, 53)
    c.BackColor = RGB(191, 234, 250): c.ControlTipText = tip
    Set Button = c
End Function

Private Function OptionControl(ByVal parent As Object, ByVal name As String, ByVal caption As String, ByVal x As Double, ByVal y As Double, ByVal width As Double, ByVal tip As String) As MSForms.OptionButton
    Dim c As MSForms.OptionButton: Set c = parent.Controls.Add("Forms.OptionButton.1", name, True)
    c.caption = caption: c.Left = x: c.Top = y: c.width = width: c.height = 27
    c.Font.name = "Tahoma": c.Font.size = 11: c.ForeColor = RGB(32, 38, 53): c.BackColor = Me.BackColor: c.ControlTipText = tip
    Set OptionControl = c
End Function

Private Function Toggle(ByVal name As String, ByVal caption As String, ByVal x As Double, ByVal y As Double, ByVal width As Double, ByVal tip As String) As MSForms.ToggleButton
    Dim c As MSForms.ToggleButton: Set c = Me.Controls.Add("Forms.ToggleButton.1", name, True)
    c.caption = caption: c.Left = x: c.Top = y: c.width = width: c.height = 31
    c.Font.name = "Tahoma": c.Font.size = 12: c.BackColor = RGB(255, 241, 247): c.ForeColor = RGB(32, 38, 53): c.ControlTipText = tip
    Set Toggle = c
End Function

Public Sub Prepare(ByVal picked As Range, ByVal direct As Boolean)
    ' Capture scope once: a later range-picker click cannot replace it.
    Set initialRange = picked: Set targetSheet = picked.parent
    updating = True
    optWhole.Value = (picked.CountLarge = 1): optSelected.Value = Not optWhole.Value
    optDirect.Value = direct: optIndirect.Value = Not direct
    lblContext.caption = "Target: " & targetSheet.parent.name & " / " & targetSheet.name & vbCrLf & "Original selection: " & picked.address(False, False)
    updating = False: RefreshInput
End Sub

Private Function scope() As Range
    If optWhole.Value Then Set scope = targetSheet.cells Else Set scope = initialRange
End Function

Private Sub RefreshInput()
    Dim why As String, source As String, d As Object
    If updating Or targetSheet Is Nothing Then Exit Sub
    Set planned = Nothing: cmdApply.Enabled = False
    source = IR_NormalSheet(txtSource.Value, targetSheet.parent, why)
    lblSource.ForeColor = RGB(77, 94, 106)
    If Len(source) > 0 Then
        lblSource.caption = "Found source worksheet " & Chr$(34) & source & Chr$(34) & ". Only matching sheet references will change."
    ElseIf Len(txtSource.Value) = 0 Then
        lblSource.caption = "Enter the source worksheet name; no quotes or ! are required."
    Else
        lblSource.caption = why: lblSource.ForeColor = RGB(109, 25, 49)
    End If
    Set d = IR_Resolve(txtTarget.Value, CBool(optReference.Value), targetSheet, selectedNameCell)
    lblTarget.caption = d("Message"): lblTarget.ForeColor = RGB(77, 94, 106)
    If d("OK") Then
        lblTarget.ForeColor = RGB(33, 92, 119)
        If optDirect.Value And optReference.Value Then lblTarget.caption = "Resolved: worksheet " & Chr$(34) & d("Sheet") & Chr$(34) & ". Straight replacement uses this name now; it will not follow later selector changes."
    ElseIf Len(txtTarget.Value) > 0 Then
        lblTarget.ForeColor = RGB(109, 25, 49)
    End If
    cmdPreview.Enabled = (Len(source) > 0 And CBool(d("OK")))
    lblSummary.caption = "Preview first. Formulas" & IIf(chkCF.Value, " + conditional formatting", "") & IIf(chkDV.Value, " + data validation", "") & "."
End Sub

Private Sub cmdPick_Click()
    Dim r As Range
    If busy Then Exit Sub
    Me.Hide
    On Error Resume Next
    Set r = Application.InputBox("Select ONE data cell containing the replacement worksheet name, in " & targetSheet.parent.name & ". A formula result is allowed.", "Replacement worksheet name cell", Type:=8)
    On Error GoTo Failed
    If Not r Is Nothing Then
        updating = True: Set selectedNameCell = r
        optReference.Value = True
        txtTarget.Value = "'" & Replace(r.parent.name, "'", "''") & "'!" & r.address(True, True)
        updating = False
    End If
    Me.Show vbModeless: RefreshInput
    Exit Sub
Failed:
    updating = False: Me.Show vbModeless
    MsgBox IR_Error("frmSheetReferences.cmdPick_Click", "choosing the name cell", Err.number, Err.description), vbExclamation, Me.caption
End Sub

Private Sub cmdPreview_Click()
    Dim source As String, why As String, d As Object
    If busy Then Exit Sub
    On Error GoTo Failed
    busy = True: lblSummary.caption = "Building the preview...": Me.Repaint
    source = IR_NormalSheet(txtSource.Value, targetSheet.parent, why)
    If Len(source) = 0 Then Err.Raise vbObjectError + 740, , why
    Set d = IR_Resolve(txtTarget.Value, CBool(optReference.Value), targetSheet, selectedNameCell)
    If Not d("OK") Then Err.Raise vbObjectError + 741, , d("Message")
    Set planned = IR_Plan(scope, source, d, CBool(optDirect.Value), CBool(chkCF.Value), CBool(chkDV.Value))
    previewSource = source: previewDestination = d("Sheet"): previewExpression = d("Expression")
    Set report = IR_ShowPlan(planned, targetSheet, scope, previewDestination, CBool(optDirect.Value))
    cmdApply.Enabled = (IR_Proposed(planned) > 0)
    lblSummary.caption = CStr(IR_Proposed(planned)) & " proposed change(s); " & CStr(planned.count - IR_Proposed(planned)) & " skipped. Review the report before Apply."
Clean:
    busy = False: Exit Sub
Failed:
    lblSummary.caption = "Preview could not finish. No target changes were made."
    MsgBox IR_Error("frmSheetReferences.cmdPreview_Click", "building the before/after plan", Err.number, Err.description), vbExclamation, Me.caption
    Resume Clean
End Sub

Private Sub cmdApply_Click()
    Dim d As Object, count As Long, backup As String, result As String, errorNumber As Long, errorDescription As String
    If busy Or planned Is Nothing Then Exit Sub
    On Error GoTo Failed
    Set d = IR_Resolve(txtTarget.Value, CBool(optReference.Value), targetSheet, selectedNameCell)
    If Not d("OK") Then Err.Raise vbObjectError + 742, , d("Message")
    If d("Sheet") <> previewDestination Or d("Expression") <> previewExpression Then Err.Raise vbObjectError + 743, , "The selector changed after preview. Build a fresh preview before applying."
    If MsgBox("Apply " & CStr(IR_Proposed(planned)) & " previewed change(s) to " & targetSheet.parent.name & " / " & targetSheet.name & "?" & vbCrLf & "The original workbook will remain unsaved. Normal Excel Undo is unavailable.", vbYesNo + vbQuestion + vbDefaultButton2, Me.caption) <> vbYes Then Exit Sub
    busy = True: cmdApply.Enabled = False: lblSummary.caption = "Applying the reviewed plan...": Me.Repaint
    count = IR_ApplyPlan(planned, targetSheet.parent, CBool(chkBackup.Value), backup)
    result = CStr(count) & " change(s) applied. Review and save the workbook yourself."
    If Len(backup) > 0 Then result = result & vbCrLf & "Recovery copy: " & backup
    UpdateReport result
    lblSummary.caption = CStr(count) & " applied; target workbook remains unsaved."
    MsgBox result, vbInformation, Me.caption
Clean:
    busy = False: Exit Sub
Failed:
    ' Presentation helpers deliberately suppress report-only errors. Capture
    ' the actual failure first so the diagnostic retains its precise cause.
    errorNumber = Err.number: errorDescription = Err.description
    UpdateReport "The run stopped. Inspect statuses and the detailed error."
    MsgBox IR_Error("frmSheetReferences.cmdApply_Click", "applying references to " & targetSheet.name, errorNumber, errorDescription), vbExclamation, Me.caption
    lblSummary.caption = "Run stopped. Review the report and detailed error."
    Resume Clean
End Sub

Private Sub UpdateReport(ByVal status As String)
    ' Closing an optional report must not turn a successful target transaction
    ' into a misleading failed action. Its update is presentation only.
    Dim d As Object, i As Long
    On Error Resume Next
    report.Range("B5").Value2 = status
    For i = 1 To planned.count
        Set d = planned(i): report.cells(i + 7, 3).Value2 = d("State"): report.cells(i + 7, 7).Value2 = d("Details")
    Next i
    On Error GoTo 0
End Sub

Private Sub cmdCancel_Click()
    If Not busy Then Unload Me
End Sub
Private Sub UserForm_QueryClose(Cancel As Integer, CloseMode As Integer)
    If busy Then Cancel = 1
End Sub
Private Sub txtSource_Change()
    RefreshInput
End Sub
Private Sub txtTarget_Change()
    If Not updating Then Set selectedNameCell = Nothing
    RefreshInput
End Sub
Private Sub optWhole_Click()
    RefreshInput
End Sub
Private Sub optSelected_Click()
    RefreshInput
End Sub
Private Sub optReference_Click()
    RefreshInput
End Sub
Private Sub optLiteral_Click()
    Set selectedNameCell = Nothing: RefreshInput
End Sub
Private Sub optIndirect_Click()
    RefreshInput
End Sub
Private Sub optDirect_Click()
    RefreshInput
End Sub
Private Sub chkCF_Click()
    StyleToggle chkCF: RefreshInput
End Sub
Private Sub chkDV_Click()
    StyleToggle chkDV: RefreshInput
End Sub
Private Sub chkBackup_Click()
    StyleToggle chkBackup
End Sub
Private Sub StyleToggle(ByVal c As Object)
    c.BackColor = IIf(CBool(c.Value), RGB(191, 234, 250), RGB(255, 241, 247)): c.Font.bold = CBool(c.Value)
End Sub

