VERSION 1.0 CLASS
BEGIN
  MultiUse = -1
END
Attribute VB_Name = "clsPersonalFolderWatcher"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
' Insert a CLASS MODULE named clsPersonalFolderWatcher; paste all this code.
Option Explicit
Private WithEvents watchedItems As Outlook.Items
Private WithEvents watchedChildren As Outlook.Folders
Private WithEvents watchedSync As Outlook.SyncObject

' Retain item-add events and optionally child-folder events for this folder.
Public Sub WatchFolder(ByVal folder As Outlook.Folder, ByVal includeChildren As Boolean)
    If folder.DefaultItemType = olMailItem Then Set watchedItems = folder.Items
    If includeChildren Then Set watchedChildren = folder.Folders
End Sub
' Extend an existing watcher to observe newly added subfolders.
Public Sub WatchChildren(ByVal folder As Outlook.Folder)
    Set watchedChildren = folder.Folders
End Sub
' Retain a Send/Receive event source so bulk arrivals can be checked afterwards.
Public Sub WatchSync(ByVal sync As Outlook.SyncObject)
    Set watchedSync = sync
End Sub
' Pass a newly added item through the configured receive-time and notification filters.
Private Sub watchedItems_ItemAdd(ByVal Item As Object)
    PT_AlertArrived Item
End Sub
' Attach a new child folder under a selected recursive notification scope.
Private Sub watchedChildren_FolderAdd(ByVal Folder As Outlook.Folder)
    PT_AlertNewFolder Folder
End Sub
' Trigger catch-up scanning after Send/Receive finishes.
Private Sub watchedSync_SyncEnd()
    PT_AlertsCatchUp "Send/Receive completed"
End Sub
