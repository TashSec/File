Attribute VB_Name = "modPersonalFollowUp"
' Standard module modPersonalFollowUp. Linked mail carries a random identity which
' normally survives a move. EntryID plus StoreID is the fast path. A moved email
' is accepted only when its own marker can be resolved to one accessible message.
Option Explicit
Option Private Module
Private Const SCHEMA As String = "http://schemas.microsoft.com/mapi/string/{00020329-0000-0000-C000-000000000046}/"
Private Const MAIL_KEY As String = "PersonalOfficeMailLink"
Private Const TASK_XML As String = "PersonalOfficeLinkedMail"
Private Const PENDING As String = "PersonalOfficeCompletionPending"
Private Const HIDE_FLAG As String = "PersonalOfficeNoDateFlag"
Private Const VIEW_NAME As String = "Tasks without linked email flags"
Private taskEvents As clsPersonalTaskEvents
Private handling As Boolean

Public Sub WatchTasks(ByVal app As Outlook.Application)
    If taskEvents Is Nothing Then Set taskEvents = New clsPersonalTaskEvents
    taskEvents.Connect app
End Sub

Public Sub ReleaseTaskWatch(ByVal shutdown As Boolean)
    Set taskEvents = Nothing
End Sub

Private Function ReadField(ByVal item As Object, ByVal name As String) As String
    Dim number As Long, detail As String
    On Error GoTo Failed
    ReadField = CStr(item.PropertyAccessor.GetProperty(SCHEMA & name))
    Exit Function
Failed:
    number = Err.Number: detail = Err.Description
    ' Only MAPI_E_NOT_FOUND means this item has no saved field. A disconnected
    ' or read-only store must never be mistaken for a task with an empty table.
    If number <> &H8004010F Then Err.Raise number, "Read linked email information", detail
End Function

Private Function LinkDocument(ByVal task As Outlook.TaskItem, Optional ByVal loaded As Variant) As Object
    Dim xml As Object, root As Object, raw As String
    Set xml = CreateObject("MSXML2.DOMDocument.6.0")
    If IsMissing(loaded) Then raw = ReadField(task, TASK_XML) Else raw = CStr(loaded)
    If Len(raw) Then
        If Not xml.LoadXML(raw) Then Err.Raise 5, , "The task's saved mail list could not be read. Its body has been kept."
    Else
        Set root = xml.createElement("emails"): xml.appendChild root
    End If
    If xml.documentElement.nodeName <> "emails" Then Err.Raise 5, , "The linked-email list is unrecognised."
    Dim node As Object, keys As Object, key As String, field As Variant
    Set keys = CreateObject("Scripting.Dictionary"): keys.CompareMode = vbTextCompare
    For Each node In xml.documentElement.childNodes
        If node.nodeName <> "mail" Then Err.Raise 5, , "The saved task contains an unexpected row. Existing links have been kept."
        For Each field In Array("key", "entry", "store", "stamp", "date", "sender", "files", "note", "subject", "body")
            If node.getAttributeNode(CStr(field)) Is Nothing Then Err.Raise 5, , "The saved email row is incomplete. Existing links have been kept."
        Next field
        key = UCase$(CStr(node.getAttribute("key")))
        node.setAttribute "key", key
        If Not ValidLinkKey(key) Or keys.Exists(key) Then Err.Raise 5, , "The saved mail list contains an invalid or repeated identity."
        keys.Add key, True
    Next node
    Set LinkDocument = xml
End Function

Public Function OpenTaskChoices(ByVal folder As Outlook.Folder) As Collection
    Dim result As New Collection, items As Outlook.Items, task As Object, due As Date
    Set items = folder.Items.Restrict("[Complete] = False")
    items.Sort "[Subject]"
    For Each task In items
        If TypeOf task Is Outlook.TaskItem Then
            due = DateAdd("d", 7, Date) + TimeSerial(10, 0, 0)
            If Year(task.DueDate) < 4000 Then due = DateValue(task.DueDate) + TimeSerial(10, 0, 0)
            If task.ReminderSet Then due = DateValue(due) + TimeValue(task.ReminderTime)
            result.Add Array(task.Subject, task.EntryID, folder.StoreID, due, Format$(task.CreationTime, "dd/mm/yyyy hh:nn"))
        End If
    Next task
    Set OpenTaskChoices = result
End Function

Private Function TwoBodyLines(ByVal body As String) As String
    Dim part As Variant, n As Long, value As String
    For Each part In Split(Replace(Replace(body, vbCrLf, vbLf), vbCr, vbLf), vbLf)
        value = Trim$(CStr(part))
        If Len(value) Then
            If n Then TwoBodyLines = TwoBodyLines & vbCrLf
            TwoBodyLines = TwoBodyLines & value: n = n + 1
            If n = 2 Then Exit For
        End If
    Next part
End Function

Private Function LinkMail(ByVal xml As Object, ByVal original As Outlook.MailItem, ByVal note As String) As Object
    Dim mail As Outlook.MailItem, node As Object, nextNode As Object, id As String, stamp As Date, sortKey As String
    Dim oldNode As Object, anchor As Object
    Set mail = EditableItem(original)
    If Not mail.Sent Or Len(mail.EntryID) = 0 Then Err.Raise 5, , "Save or send the draft before linking it."
    id = UCase$(ReadField(mail, MAIL_KEY))
    If Not ValidLinkKey(id) Then
        id = WorkflowID()
        mail.PropertyAccessor.SetProperty SCHEMA & MAIL_KEY, id: mail.Save
    End If
    Set node = xml.documentElement.selectSingleNode("mail[@key='" & id & "']")
    If node Is Nothing Then
        Set node = xml.createElement("mail")
        node.setAttribute "key", id: node.setAttribute "note", note
    Else
        ' A copied message may inherit the marker. Never overwrite an existing
        ' link to a still-accessible different message with the copy's IDs.
        Dim prior As Object, why As String, moved As Boolean
        Set oldNode = node: Set node = oldNode.cloneNode(True)
        If CStr(node.getAttribute("entry")) <> mail.EntryID Or CStr(node.getAttribute("store")) <> mail.Parent.StoreID Then
            Set prior = ResolveLink(node, why, moved)
            If prior Is Nothing Then Err.Raise 5, , "The earlier link could not be verified. " & why
            If prior.EntryID <> mail.EntryID Or prior.Parent.StoreID <> mail.Parent.StoreID Then _
                Err.Raise 5, , "A different stored email already uses this link. The existing row was kept."
        End If
        If Len(note) Then node.setAttribute "note", note
    End If
    stamp = mail.ReceivedTime
    If Year(stamp) >= 4000 Or Year(stamp) < 1900 Then stamp = mail.SentOn
    sortKey = Format$(stamp, "yyyymmddhhnnss")
    node.setAttribute "entry", mail.EntryID: node.setAttribute "store", mail.Parent.StoreID
    node.setAttribute "stamp", sortKey: node.setAttribute "date", Format$(stamp, "dd/mm/yyyy hh:nn")
    node.setAttribute "sender", mail.SenderName: node.setAttribute "subject", mail.Subject
    node.setAttribute "files", IIf(PT_HasFileAttachments(mail), "Yes", "No")
    node.setAttribute "body", TwoBodyLines(mail.Body)
    ' Construct the complete detached row before touching the task document.
    ' Replacing one row avoids cloning and parsing the whole XML per selection.
    For Each nextNode In xml.documentElement.childNodes
        If Not (nextNode Is oldNode) Then
            If CStr(nextNode.getAttribute("stamp")) < sortKey Then Set anchor = nextNode: Exit For
        End If
    Next nextNode
    If anchor Is Nothing Then xml.documentElement.appendChild node Else xml.documentElement.insertBefore node, anchor
    If Not oldNode Is Nothing Then xml.documentElement.removeChild oldNode
    Set LinkMail = mail
End Function

Private Function IsDeletedMail(ByVal mail As Outlook.MailItem) As Boolean
    Dim current As Outlook.Folder, trash As Outlook.Folder
    Set current = mail.Parent
    Set trash = current.Store.GetDefaultFolder(olFolderDeletedItems)
    Do
        If current.EntryID = trash.EntryID Then IsDeletedMail = True: Exit Function
        If Not TypeOf current.Parent Is Outlook.Folder Then Exit Do
        Set current = current.Parent
    Loop
End Function



Private Function ValidLinkKey(ByVal key As String) As Boolean
    ValidLinkKey = (Len(key) = 32 And Not key Like "*[!A-Fa-f0-9]*")
End Function

Private Function StoredLink(ByVal node As Object, ByRef reason As String) As Outlook.MailItem
    Dim item As Object, code As Long, detail As String, key As String
    key = CStr(node.getAttribute("key"))
    On Error Resume Next
    Err.Clear
    Set item = Application.Session.GetItemFromID(CStr(node.getAttribute("entry")), CStr(node.getAttribute("store")))
    code = Err.Number: detail = Err.Description
    On Error GoTo Failed
    If item Is Nothing Then
        If code <> 0 And code <> &H8004010F And code <> &H80040107 Then reason = "The saved mailbox could not be checked. " & detail
        Exit Function
    End If
    If TypeOf item Is Outlook.MailItem Then
        If StrComp(ReadField(item, MAIL_KEY), key, vbTextCompare) = 0 Then
            If IsDeletedMail(item) Then reason = "Original is in Deleted Items.": Exit Function
            Set StoredLink = item
        End If
    End If
    Exit Function
Failed:
    reason = "The stored email could not be checked. " & Err.Description
End Function

Private Function MarkerQueries(ByVal keys As Object) As Collection
    Dim queries As New Collection, key As Variant, terms As String, count As Long, field As String
    field = Chr$(34) & SCHEMA & MAIL_KEY & Chr$(34)
    ' Limit restriction size per store provider. Validated keys contain hex only.
    For Each key In keys.Keys
        If Len(terms) Then terms = terms & " OR "
        terms = terms & field & " = '" & CStr(key) & "'": count = count + 1
        If count = 24 Then queries.Add "@SQL=(" & terms & ")": count = 0: terms = ""
    Next key
    If count Then queries.Add "@SQL=(" & terms & ")"
    Set MarkerQueries = queries
End Function

Private Sub ReadMarkedGroup(ByVal folder As Outlook.Folder, ByVal filter As String, ByVal missing As Object, ByVal found As Object, ByVal duplicates As Object, ByRef incomplete As Boolean)
    Dim table As Outlook.Table, row As Outlook.Row, item As Object, first As Outlook.MailItem, key As String
    On Error GoTo QueryFailed
    Set table = folder.GetTable(filter, olUserItems)
    On Error GoTo RowFailed
    Do Until table.EndOfTable
        Set row = table.GetNextRow
        Set item = Application.Session.GetItemFromID(CStr(row("EntryID")), folder.StoreID)
        If TypeOf item Is Outlook.MailItem Then
            key = ReadField(item, MAIL_KEY)
            If missing.Exists(key) Then
                If found.Exists(key) Then
                    Set first = found(key)
                    If first.EntryID <> item.EntryID Or first.Parent.StoreID <> item.Parent.StoreID Then duplicates(key) = True
                Else
                    found.Add key, item
                End If
            End If
        End If
    Loop
    Exit Sub
QueryFailed:
    ' A folder which has never held this named property may reject its column.
    If Err.Number <> &H8004010F Then incomplete = True
    Exit Sub
RowFailed:
    incomplete = True
End Sub

Private Sub FindMarkedMail(ByVal folder As Outlook.Folder, ByVal queries As Collection, ByVal missing As Object, ByVal found As Object, ByVal duplicates As Object, ByRef incomplete As Boolean)
    Dim child As Outlook.Folder, kind As Long, filter As Variant
    On Error GoTo FolderFailed
    kind = PT_FolderKind(folder): If kind = 2 Then Exit Sub
    If kind = 1 And folder.DefaultItemType = olMailItem Then
        ' Include Deleted Items in the uniqueness check. A live copy must not
        ' stand in for a deleted original which carries the same marker.
        For Each filter In queries
            ReadMarkedGroup folder, CStr(filter), missing, found, duplicates, incomplete
        Next filter
    End If
    For Each child In folder.Folders
        FindMarkedMail child, queries, missing, found, duplicates, incomplete
    Next child
    Exit Sub
FolderFailed:
    incomplete = True
End Sub

Private Sub SearchMarkerStores(ByVal queries As Collection, ByVal missing As Object, ByVal found As Object, ByVal duplicates As Object, ByRef incomplete As Boolean)
    Dim store As Outlook.Store, root As Outlook.Folder, problem As Long
    On Error GoTo Failed
    For Each store In Application.Session.Stores
        Set root = Nothing
        On Error Resume Next
        Err.Clear: Set root = store.GetRootFolder: problem = Err.Number
        On Error GoTo Failed
        If problem <> 0 Or root Is Nothing Then
            incomplete = True
        Else
            FindMarkedMail root, queries, missing, found, duplicates, incomplete
        End If
    Next store
    Exit Sub
Failed:
    incomplete = True
End Sub

Private Sub AcceptRecoveredLink(ByVal node As Object, ByVal item As Outlook.MailItem, ByVal key As String, ByVal resolved As Object, ByVal issues As Object, ByRef moved As Boolean)
    On Error GoTo Failed
    If IsDeletedMail(item) Then issues(key) = "Original is in Deleted Items.": Exit Sub
    node.setAttribute "entry", item.EntryID: node.setAttribute "store", item.Parent.StoreID
    resolved.Add key, item: moved = True
    Exit Sub
Failed:
    issues(key) = "Could not verify the recovered email. " & Err.Description
End Sub

Private Sub ResolveTaskRows(ByVal nodes As Object, ByVal resolved As Object, ByVal issues As Object, ByRef moved As Boolean)
    Dim missing As Object, found As Object, duplicates As Object, queries As Collection, node As Object, item As Outlook.MailItem
    Dim key As String, id As Variant, detail As String, incomplete As Boolean
    Set missing = CreateObject("Scripting.Dictionary"): missing.CompareMode = vbTextCompare
    For Each node In nodes
        key = CStr(node.getAttribute("key")): detail = ""
        If ValidLinkKey(key) Then
            Set item = StoredLink(node, detail)
            If Not item Is Nothing Then
                resolved.Add key, item
            ElseIf Len(detail) Then
                issues(key) = detail
            Else
                missing.Add key, node
            End If
        Else
            issues(key) = "Invalid saved identity."
        End If
    Next node
    If missing.Count = 0 Then Exit Sub
    Set found = CreateObject("Scripting.Dictionary"): found.CompareMode = vbTextCompare
    Set duplicates = CreateObject("Scripting.Dictionary"): duplicates.CompareMode = vbTextCompare
    Set queries = MarkerQueries(missing)
    ' Resolve every missing original in one traversal of the mounted folder trees.
    SearchMarkerStores queries, missing, found, duplicates, incomplete
    For Each id In missing.Keys
        If duplicates.Exists(id) Then
            issues(id) = "More than one copy has this identity."
        ElseIf incomplete Then
            issues(id) = "Some folders could not be searched. Open the mailboxes and retry."
        ElseIf Not found.Exists(id) Then
            issues(id) = "Deleted, unavailable, or the mailbox did not preserve its link."
        Else
            Set node = missing(id): Set item = found(id)
            AcceptRecoveredLink node, item, CStr(id), resolved, issues, moved
        End If
    Next id
End Sub

Private Function ResolveLink(ByVal node As Object, ByRef reason As String, ByRef moved As Boolean) As Outlook.MailItem
    Dim nodes As New Collection, resolved As Object, issues As Object, key As String
    nodes.Add node: key = CStr(node.getAttribute("key"))
    Set resolved = CreateObject("Scripting.Dictionary"): Set issues = CreateObject("Scripting.Dictionary")
    ResolveTaskRows nodes, resolved, issues, moved
    If resolved.Exists(key) Then Set ResolveLink = resolved(key) Else reason = CStr(issues(key))
End Function

Private Function TaskHeaders() As Variant
    TaskHeaders = Array("Date", "From", "Attachments", "Personal note", "Subject", "First 2 lines of body", "Original email")
End Function

Private Function ManagedTable(ByVal doc As Object) As Object
    Dim table As Object, found As Object, headers As Variant, n As Long, ok As Boolean, value As String
    headers = TaskHeaders()
    For Each table In doc.Tables
        ok = True
        On Error Resume Next
        For n = 0 To 6
            Err.Clear: value = table.Cell(1, n + 1).Range.Text
            If Err.Number <> 0 Or value <> CStr(headers(n)) & Chr$(13) & Chr$(7) Then ok = False: Exit For
        Next n
        On Error GoTo 0
        If ok Then
            If Not found Is Nothing Then Err.Raise 5, , "The task contains two similar email tables. Its body was kept."
            Set found = table
        End If
    Next table
    Set ManagedTable = found
End Function

Private Sub PutBytes(ByVal path As String, ByVal bytes As Variant)
    Dim file As Integer, raw() As Byte, opened As Boolean, number As Long, detail As String
    On Error GoTo Failed
    raw = bytes: file = FreeFile: Open path For Binary Access Write As #file
    opened = True: Put #file, , raw
    Close #file: opened = False
    Exit Sub
Failed:
    number = Err.Number: detail = Err.Description
    On Error Resume Next
    If opened Then Close #file
    On Error GoTo 0
    Err.Raise number, "Read or write the task document", detail
End Sub

Private Function ReadBytes(ByVal path As String) As Variant
    Dim file As Integer, raw() As Byte, opened As Boolean, number As Long, detail As String
    On Error GoTo Failed
    file = FreeFile: Open path For Binary Access Read As #file
    opened = True
    If LOF(file) = 0 Then Err.Raise 5, , "Word returned an empty task document."
    ReDim raw(0 To LOF(file) - 1): Get #file, , raw
    Close #file: opened = False: ReadBytes = raw
    Exit Function
Failed:
    number = Err.Number: detail = Err.Description
    On Error Resume Next
    If opened Then Close #file
    On Error GoTo 0
    Err.Raise number, "Read or write the task document", detail
End Function

Private Sub RenderTask(ByVal task As Outlook.TaskItem, ByVal xml As Object, ByVal hadLinks As Boolean)
    Dim temp As String, word As Object, doc As Object, table As Object, rng As Object, cell As Object
    Dim node As Object, keys As Variant, headers As Variant, n As Long, row As Long, path As String, bytes As Variant
    Dim detail As String, num As Long
    On Error GoTo Failed
    temp = PT_CreateTempFolder(): path = temp & "\task.rtf"
    ' A private Word document can edit a real RTF table without relying on an
    ' Inspector being open. Existing task notes outside the managed table survive.
    Set word = CreateObject("Word.Application"): word.Visible = False: word.DisplayAlerts = 0
    If Len(task.EntryID) > 0 Or Len(task.Body) > 0 Then bytes = task.RTFBody
    If HasRtf(bytes) Then
        PutBytes path, bytes
        Set doc = word.Documents.Open(path, False, False, False)
    Else
        Set doc = word.Documents.Add
    End If
    If hadLinks Then
        Set table = ManagedTable(doc)
        If table Is Nothing Then Err.Raise 5, , "The linked-email table was removed or its headings were edited. Existing task text was kept."
        Set rng = table.Range.Duplicate: rng.Collapse 1
        n = rng.Start: table.Delete: Set rng = doc.Range(n, n)
    Else
        Set rng = doc.Range(doc.Content.End - 1, doc.Content.End - 1)
        If Len(task.Body) Then rng.InsertAfter vbCr: rng.Collapse 0
    End If
    headers = TaskHeaders(): keys = Array("date", "sender", "files", "note", "subject", "body")
    Set table = doc.Tables.Add(rng, xml.documentElement.childNodes.Length + 1, 7)
    table.Range.Font.Name = "Segoe UI": table.Range.Font.Size = 9: table.Borders.Enable = True
    For n = 0 To 6: table.Cell(1, n + 1).Range.Text = CStr(headers(n)): Next n
    table.Rows(1).Range.Font.Bold = True: table.Rows(1).Shading.BackgroundPatternColor = RGB(224, 236, 240)
    row = 1
    For Each node In xml.documentElement.childNodes
        row = row + 1
        For n = 0 To 5: table.Cell(row, n + 1).Range.Text = TaskCellText(CStr(node.getAttribute(CStr(keys(n))))): Next n
        Set cell = table.Cell(row, 7).Range: cell.End = cell.End - 1
        doc.Hyperlinks.Add cell, "outlook:" & CStr(node.getAttribute("entry")), "", "Open original email", "Open email"
    Next node
    table.AutoFitBehavior 2
    doc.SaveAs2 temp & "\updated.rtf", 6
    bytes = ReadBytes(temp & "\updated.rtf"): task.RTFBody = bytes
Finished:
    On Error Resume Next
    If Not doc Is Nothing Then doc.Close 0
    If Not word Is Nothing Then word.Quit 0
    If Len(temp) Then PT_CleanTemp temp
    On Error GoTo 0
    If num <> 0 Then Err.Raise num, "Build task email table", detail
    Exit Sub
Failed:
    num = Err.Number: detail = Err.Description
    Resume Finished
End Sub

Public Sub SaveLinkedFollowUp(ByVal selected As Collection, ByVal panel As frmPersonalOutlook)
    Dim task As Outlook.TaskItem, original As Outlook.MailItem, mail As Outlook.MailItem, ready As New Collection
    Dim needsFlag As Boolean, label As String
    Dim folder As Outlook.Folder, xml As Object, hadLinks As Boolean, failures As String, approved As Boolean, problem As String
    On Error GoTo Failed
    Set folder = Application.Session.GetDefaultFolder(olFolderTasks)
    If Len(panel.ExistingTaskID) Then
        Set task = Application.Session.GetItemFromID(panel.ExistingTaskID, folder.StoreID)
        If task.Complete Then Err.Raise 5, , "This task has just been completed. Choose another task."
        Set task = EditableItem(task)
    Else
        Set task = folder.Items.Add(olTaskItem): task.Sensitivity = olPrivate
    End If
    Set xml = LinkDocument(task): hadLinks = (xml.documentElement.childNodes.Length > 0)
    For Each original In selected
        On Error Resume Next
        label = "Selected email": label = original.Subject
        Err.Clear: Set mail = Nothing: Set mail = LinkMail(xml, original, panel.FollowUpNote)
        problem = Err.Description
        On Error GoTo Failed
        If mail Is Nothing Then failures = failures & vbCrLf & label & " - " & problem Else ready.Add mail
    Next original
    If ready.Count = 0 Then Err.Raise 5, , "No emails could be linked." & failures
    handling = True
    RenderTask task, xml, hadLinks
    task.Subject = panel.FollowUpTitle
    If Not panel.KeepDeadline Then
        task.DueDate = DateValue(panel.FollowUpDue)
        task.ReminderTime = panel.FollowUpDue: task.ReminderSet = True
    End If
    task.PropertyAccessor.SetProperty SCHEMA & TASK_XML, xml.XML
    task.PropertyAccessor.SetProperty SCHEMA & PENDING, "1"
    task.Save: approved = True
    For Each mail In ready
        On Error Resume Next
        Err.Clear
        needsFlag = Not mail.IsMarkedAsTask
        If Not needsFlag Then needsFlag = (Year(mail.TaskCompletedDate) < 4000 And Year(mail.TaskCompletedDate) > 1900)
        If needsFlag Then
            mail.MarkAsTask olMarkNoDate
            If Err.Number = 0 Then mail.PropertyAccessor.SetProperty SCHEMA & HIDE_FLAG, "1"
            If Err.Number = 0 Then mail.Save
        End If
        problem = Err.Description
        If Len(problem) Then failures = failures & vbCrLf & mail.Subject & " - " & problem
        On Error GoTo Failed
    Next mail
    PT_WriteSetting "UseLinkedFlagView", IIf(panel.UseFlagView, "1", "0")
    WatchTasks Application
    handling = False
    If Len(failures) Then PT_ShowReport "Follow Up saved", "The task is saved. Some messages need attention." & vbCrLf & failures
    Exit Sub
Failed:
    problem = Err.Description: handling = False
    If approved Then problem = "The task is already saved. " & problem
    MsgBox problem, vbInformation, "Follow Up"
End Sub

Public Sub CheckLinkedTask(ByVal task As Outlook.TaskItem, ByVal opening As Boolean)
    Dim xml As Object, node As Object, mail As Outlook.MailItem, moved As Boolean, reason As String
    Dim failures As String, completed As Boolean
    Dim resolved As Object, issues As Object, key As String, raw As String
    If handling Then Exit Sub
    On Error GoTo Failed
    completed = task.Complete
    If Not completed And Not opening Then Exit Sub
    If completed Then
        If ReadField(task, PENDING) <> "1" Then Exit Sub
    End If
    raw = ReadField(task, TASK_XML): If Len(raw) = 0 Then Exit Sub
    handling = True: Set xml = LinkDocument(task, raw)
    Set resolved = CreateObject("Scripting.Dictionary"): Set issues = CreateObject("Scripting.Dictionary")
    ResolveTaskRows xml.documentElement.childNodes, resolved, issues, moved
    For Each node In xml.documentElement.childNodes
        reason = "": Set mail = Nothing: key = CStr(node.getAttribute("key"))
        If issues.Exists(key) Then reason = CStr(issues(key))
        If resolved.Exists(key) Then Set mail = resolved(key)
        If Not mail Is Nothing And completed Then
            On Error Resume Next
            Err.Clear
            If mail.Saved Then
                Dim alreadyComplete As Boolean
                alreadyComplete = False
                If mail.IsMarkedAsTask Then alreadyComplete = (Year(mail.TaskCompletedDate) > 1900 And Year(mail.TaskCompletedDate) < 4000)
                If Not alreadyComplete Then
                    If Not mail.IsMarkedAsTask Then mail.MarkAsTask olMarkNoDate
                    If Err.Number = 0 Then mail.MarkAsTask olMarkComplete
                    If Err.Number = 0 Then mail.Save
                End If
            Else
                reason = "Email has pending edits. Completion will retry."
            End If
            If Err.Number <> 0 Then reason = Err.Description
            On Error GoTo Failed
        End If
        If Len(reason) Then failures = failures & vbCrLf & node.getAttribute("subject") & " - " & reason
    Next node
    If moved Or (completed And Len(failures) = 0) Then
        If Not task.Saved Then
            failures = failures & vbCrLf & "Save your task edits and reopen it to refresh its links."
            GoTo ReportResults
        End If
    End If
    If moved Then
        RenderTask task, xml, True: task.PropertyAccessor.SetProperty SCHEMA & TASK_XML, xml.XML
    End If
    If completed And Len(failures) = 0 Then task.PropertyAccessor.SetProperty SCHEMA & PENDING, "0"
    If moved Or (completed And Len(failures) = 0) Then task.Save
ReportResults:
    If Len(failures) And (completed Or opening) Then PT_ShowReport "Linked emails", "Some originals could not be resolved or updated." & vbCrLf & failures
Finished:
    handling = False: Exit Sub
Failed:
    problemReport "Linked task", Err.Description
    Resume Finished
End Sub

Private Sub problemReport(ByVal title As String, ByVal reason As String)
    PT_ShowReport "Follow Up - " & title, reason
End Sub

Public Sub ApplyLinkedFlagView(ByVal browser As Outlook.Explorer)
    Dim target As Outlook.Folder, view As Outlook.View, base As Outlook.View, filter As String, extra As String
    On Error GoTo Failed
    Dim enabled As Boolean
    enabled = (PT_ReadSetting("UseLinkedFlagView", "0") = "1")
    If Not enabled And PT_ReadSetting("PreviousToDoView", "") = "" Then Exit Sub
    Set target = Application.Session.GetDefaultFolder(olFolderToDo)
    If browser.CurrentFolder.EntryID <> target.EntryID Or browser.CurrentFolder.StoreID <> target.StoreID Then Exit Sub
    Set base = browser.CurrentView
    If Not enabled Then
        If base.Name = VIEW_NAME Then
            Set view = target.Views(PT_ReadSetting("PreviousToDoView", ""))
            view.Apply
        End If
        Exit Sub
    End If
    Dim created As Boolean, detail As String
    If base.Name <> VIEW_NAME Then PT_WriteSetting "PreviousToDoView", base.Name
    On Error Resume Next: Set view = target.Views(VIEW_NAME): On Error GoTo Failed
    If view Is Nothing Then
        Set view = base.Copy(VIEW_NAME, olViewSaveOptionThisFolderOnlyMe): created = True
    End If
    filter = view.Filter
    If InStr(1, filter, SCHEMA & HIDE_FLAG, vbTextCompare) = 0 Then
        extra = "(" & Chr$(34) & SCHEMA & HIDE_FLAG & Chr$(34) & " IS NULL OR " & Chr$(34) & SCHEMA & HIDE_FLAG & Chr$(34) & " <> '1')"
        If Len(filter) Then extra = "(" & filter & ") AND " & extra
        view.Filter = extra: view.Save
        view.Apply
    ElseIf base.Name <> VIEW_NAME Then
        view.Apply
    End If
    Exit Sub
Failed:
    detail = Err.Description
    On Error Resume Next
    PT_WriteSetting "UseLinkedFlagView", "0"
    If created Then
        base.Apply: view.Delete
    End If
    MsgBox "Outlook could not apply the personal To-Do view. The email flags and their highlighting are still available." & vbCrLf & detail, vbInformation, "To-Do List"
End Sub


Public Sub StartTaskMonitoring(ByVal app As Outlook.Application)
    Dim pendingTasks As Outlook.Items, task As Object, ids As New Collection, id As Variant, folder As Outlook.Folder
    On Error GoTo Finished
    WatchTasks app
    Set folder = app.Session.GetDefaultFolder(olFolderTasks)
    ' A server or phone can complete a task while Outlook is closed. Reconcile
    ' those marked pending by this project as well as live ItemChange events.
    Set pendingTasks = folder.Items.Restrict("@SQL=" & Chr$(34) & SCHEMA & PENDING & Chr$(34) & " = '1' AND " & Chr$(34) & "http://schemas.microsoft.com/mapi/id/{00062003-0000-0000-C000-000000000046}/811C000B" & Chr$(34) & " = 1")
    For Each task In pendingTasks: ids.Add task.EntryID: Next task
    For Each id In ids
        Set task = app.Session.GetItemFromID(CStr(id), folder.StoreID)
        If TypeOf task Is Outlook.TaskItem Then CheckLinkedTask task, False
    Next id
Finished:
End Sub


Public Sub OpenLinkedEmail(ByVal task As Outlook.TaskItem)
    Dim xml As Object, node As Object, panel As New frmPersonalOutlook, list As New Collection
    Dim reason As String, moved As Boolean, mail As Outlook.MailItem, index As Long
    On Error GoTo Failed
    Set xml = LinkDocument(task)
    For Each node In xml.documentElement.childNodes
        list.Add Array(CStr(node.getAttribute("date")), CStr(node.getAttribute("subject")), CStr(node.getAttribute("sender")))
    Next node
    If list.Count = 0 Then MsgBox "This task has no emails linked by Follow Up.", vbInformation, "Open linked email": Exit Sub
    panel.PrepareLinkedPicker list: panel.Show vbModal
    If panel.Result = 1 Then index = panel.SelectedNoteIndex Else index = -1
    Unload panel
    If index < 0 Then Exit Sub
    Set node = xml.documentElement.childNodes.Item(index)
    Set mail = ResolveLink(node, reason, moved)
    If mail Is Nothing Then MsgBox reason, vbInformation, "Open linked email" Else mail.Display
    Exit Sub
Failed:
    MsgBox Err.Description, vbInformation, "Open linked email"
End Sub


Private Function HasRtf(ByVal bytes As Variant) As Boolean
    On Error Resume Next
    If IsArray(bytes) Then HasRtf = UBound(bytes) >= LBound(bytes)
End Function


Public Sub SeparateWorkflowCopy(ByVal copy As Object)
    Dim names As Variant, field As Variant, changed As Boolean
    ' Outlook may duplicate named properties. A copy is a different filing item
    ' and must not acquire ownership of a task's originals or their completion.
    If TypeOf copy Is Outlook.MailItem Then
        names = Array(MAIL_KEY, HIDE_FLAG)
    ElseIf TypeOf copy Is Outlook.TaskItem Then
        names = Array(TASK_XML, PENDING)
    Else
        Exit Sub
    End If
    For Each field In names
        If Len(ReadField(copy, CStr(field))) Then
            copy.PropertyAccessor.DeleteProperty SCHEMA & CStr(field)
            changed = True
        End If
    Next field
    If changed Then copy.Save
End Sub


Private Function TaskCellText(ByVal value As String) As String
    value = Replace(Replace(value, vbCrLf, vbLf), vbCr, vbLf)
    TaskCellText = Replace(value, vbLf, Chr$(11))
End Function
