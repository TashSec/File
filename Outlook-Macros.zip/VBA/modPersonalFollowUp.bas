Attribute VB_Name = "modPersonalFollowUp"
' Standard module modPersonalFollowUp. Linked mail carries a random identity which
' normally survives a move. EntryID plus StoreID is the fast path. A moved email
' is accepted only when its own marker can be resolved to one accessible message.
Option Explicit
Option Private Module
Private Const SCHEMA As String = "http://schemas.microsoft.com/mapi/string/{00020329-0000-0000-C000-000000000046}/"
Private Const MAIL_KEY As String = "PersonalOfficeMailLink"
Private Const TASK_XML As String = "PersonalOfficeLinkedMail"
Private Const PENDING As String = "PersonalOfficeCompletionPending"
Private Const HIDE_FLAG As String = "PersonalOfficeNoDateFlag"
Private Const VIEW_NAME As String = "Tasks without linked email flags"
Private toDoEntry As String, toDoStore As String, retryToDoAfter As Date, lastViewIssue As String
Private taskEvents As clsPersonalTaskEvents
Private handling As Boolean
Private Const RESPONSE_RECEIPT As String = "http://schemas.microsoft.com/mapi/string/{8C5D3443-2CB1-46D6-8E43-60B5D2756E05}/TaskReceipt"
Private Const TABLE_DIRTY As String = "PersonalOfficeLinkTableNeedsRefresh"
Private taskQueue As Collection, taskTickets As Object, activeTask As Object, taskObject As Outlook.TaskItem
Private sweepPhase As Long, sweepStore As String, sweepTable As Outlook.Table, taskSweepTurn As Boolean
Private taskPhase As Long, taskIndex As Long, taskStoreIndex As Long, taskStoreCount As Long
Private taskStoreIDs As Collection, taskFrames As Collection, taskQueries As Collection, taskMatchTable As Outlook.Table
Private taskXmlDoc As Object, taskMissing As Object, taskFound As Object, taskDupes As Object, taskResolved As Object, taskIssues As Object
Private taskCompleting As Boolean, taskMoved As Boolean, taskIncomplete As Boolean
Private taskFailures As String, taskOriginalXml As String, taskVersion As Date

Public Sub WatchTasks(ByVal app As Outlook.Application)
    If taskEvents Is Nothing Then Set taskEvents = New clsPersonalTaskEvents
    taskEvents.Connect app
End Sub

Public Sub ReleaseTaskWatch(ByVal shutdown As Boolean)
    sweepPhase = 0: Set sweepTable = Nothing: Set taskQueue = Nothing: Set taskTickets = Nothing
    ReleaseTaskJob
    Set taskEvents = Nothing
    toDoEntry = "": toDoStore = "": retryToDoAfter = 0: lastViewIssue = ""
End Sub

Private Function ReadField(ByVal item As Object, ByVal name As String) As String
    Dim number As Long, detail As String
    On Error GoTo Failed
    ReadField = CStr(item.PropertyAccessor.GetProperty(SCHEMA & name))
    Exit Function
Failed:
    number = Err.Number: detail = Err.Description
    ' Only MAPI_E_NOT_FOUND means this item has no saved field. A disconnected
    ' or read-only store must never be mistaken for a task with an empty table.
    If number <> &H8004010F Then Err.Raise number, "Read linked email information", detail
End Function

Private Function LinkDocument(ByVal task As Outlook.TaskItem, Optional ByVal loaded As Variant) As Object
    Dim xml As Object, root As Object, raw As String
    Set xml = CreateObject("MSXML2.DOMDocument.6.0")
    If IsMissing(loaded) Then raw = ReadField(task, TASK_XML) Else raw = CStr(loaded)
    If Len(raw) Then
        If Not xml.LoadXML(raw) Then Err.Raise 5, , "The task's saved mail list could not be read. Its body has been kept."
    Else
        Set root = xml.createElement("emails"): xml.appendChild root
    End If
    If xml.documentElement.nodeName <> "emails" Then Err.Raise 5, , "The linked-email list is unrecognised."
    Dim node As Object, keys As Object, key As String, field As Variant
    Set keys = CreateObject("Scripting.Dictionary"): keys.CompareMode = vbTextCompare
    For Each node In xml.documentElement.childNodes
        If node.nodeName <> "mail" Then Err.Raise 5, , "The saved task contains an unexpected row. Existing links have been kept."
        For Each field In Array("key", "entry", "store", "stamp", "date", "sender", "files", "note", "subject", "body")
            If node.getAttributeNode(CStr(field)) Is Nothing Then Err.Raise 5, , "The saved email row is incomplete. Existing links have been kept."
        Next field
        key = UCase$(CStr(node.getAttribute("key")))
        node.setAttribute "key", key
        If Not ValidLinkKey(key) Or keys.Exists(key) Then Err.Raise 5, , "The saved mail list contains an invalid or repeated identity."
        keys.Add key, True
    Next node
    Set LinkDocument = xml
End Function

Public Function OpenTaskChoices(ByVal folder As Outlook.Folder) As Collection
    Dim result As New Collection, table As Outlook.Table, items As Outlook.Items, task As Object
    Dim batch As Variant, last As Long, i As Long, store As String, entry As String, title As String, kind As String
    store = folder.StoreID
    On Error GoTo UseItems
    Set table = folder.GetTable("[Complete] = False", olUserItems)
    table.Sort "Subject", False
    ' Outlook's default table columns start with EntryID, Subject, CreationTime,
    ' LastModificationTime and MessageClass. GetArray returns (column, row).
    Do Until table.EndOfTable
        batch = table.GetArray(128): last = TableBatchLastRow(batch)
        If last < 0 And Not table.EndOfTable Then GoTo UseItems
        For i = 0 To last
            entry = CStr(batch(0, i)): title = "": kind = LCase$(CStr(batch(4, i)))
            If Not IsNull(batch(1, i)) Then title = CStr(batch(1, i))
            If Len(title) >= 255 Or (kind <> "ipm.task" And Left$(kind, 9) <> "ipm.task.") Then
                ' Preserve custom task forms and full subjects beyond the table limit.
                Set task = Application.Session.GetItemFromID(entry, store)
                If Not TypeOf task Is Outlook.TaskItem Then GoTo NextTask
                title = task.Subject
            End If
            result.Add Array(title, entry, store, Format$(CDate(batch(2, i)), "dd/mm/yyyy hh:nn"))
NextTask:
        Next i
    Loop
    Set OpenTaskChoices = result
    Exit Function
UseItems:
    ' Providers may reject task-table filters or columns. Start fresh so a
    ' failure partway through a table cannot duplicate earlier dropdown rows.
    On Error GoTo 0
    Set result = New Collection
    Set items = folder.Items.Restrict("[Complete] = False"): items.Sort "[Subject]"
    For Each task In items
        If TypeOf task Is Outlook.TaskItem Then result.Add Array(task.Subject, task.EntryID, store, Format$(task.CreationTime, "dd/mm/yyyy hh:nn"))
    Next task
    Set OpenTaskChoices = result
End Function

Private Function TwoBodyLines(ByVal body As String) As String
    Dim part As Variant, n As Long, value As String
    For Each part In Split(Replace(Replace(body, vbCrLf, vbLf), vbCr, vbLf), vbLf)
        value = Trim$(CStr(part))
        If Len(value) Then
            If n Then TwoBodyLines = TwoBodyLines & vbCrLf
            TwoBodyLines = TwoBodyLines & value: n = n + 1
            If n = 2 Then Exit For
        End If
    Next part
End Function

Private Function LinkMail(ByVal xml As Object, ByVal original As Outlook.MailItem, ByVal note As String) As Object
    Dim mail As Outlook.MailItem, node As Object, nextNode As Object, id As String, stamp As Date, sortKey As String
    Dim oldNode As Object, anchor As Object
    Set mail = EditableItem(original)
    If Not mail.Sent Or Len(mail.EntryID) = 0 Then Err.Raise 5, , "Save or send the draft before linking it."
    id = UCase$(ReadField(mail, MAIL_KEY))
    If Not ValidLinkKey(id) Then
        id = WorkflowID()
        mail.PropertyAccessor.SetProperty SCHEMA & MAIL_KEY, id: mail.Save
    End If
    Set node = xml.documentElement.selectSingleNode("mail[@key='" & id & "']")
    If node Is Nothing Then
        Set node = xml.createElement("mail")
        node.setAttribute "key", id: node.setAttribute "note", note
    Else
        ' A copied message may inherit the marker. Never overwrite an existing
        ' link to a still-accessible different message with the copy's IDs.
        Dim prior As Object, why As String, moved As Boolean
        Set oldNode = node: Set node = oldNode.cloneNode(True)
        If CStr(node.getAttribute("entry")) <> mail.EntryID Or CStr(node.getAttribute("store")) <> mail.Parent.StoreID Then
            Set prior = ResolveLink(node, why, moved)
            If prior Is Nothing Then Err.Raise 5, , "The earlier link could not be verified. " & why
            If prior.EntryID <> mail.EntryID Or prior.Parent.StoreID <> mail.Parent.StoreID Then _
                Err.Raise 5, , "A different stored email already uses this link. The existing row was kept."
        End If
        If Len(note) Then node.setAttribute "note", note
    End If
    stamp = mail.ReceivedTime
    If Year(stamp) >= 4000 Or Year(stamp) < 1900 Then stamp = mail.SentOn
    sortKey = Format$(stamp, "yyyymmddhhnnss")
    node.setAttribute "entry", mail.EntryID: node.setAttribute "store", mail.Parent.StoreID
    node.setAttribute "stamp", sortKey: node.setAttribute "date", Format$(stamp, "dd/mm/yyyy hh:nn")
    node.setAttribute "sender", mail.SenderName: node.setAttribute "subject", mail.Subject
    node.setAttribute "files", IIf(PT_HasFileAttachments(mail), "Yes", "No")
    node.setAttribute "body", TwoBodyLines(mail.Body)
    ' Construct the complete detached row before touching the task document.
    ' Replacing one row avoids cloning and parsing the whole XML per selection.
    For Each nextNode In xml.documentElement.childNodes
        If Not (nextNode Is oldNode) Then
            If CStr(nextNode.getAttribute("stamp")) < sortKey Then Set anchor = nextNode: Exit For
        End If
    Next nextNode
    If anchor Is Nothing Then xml.documentElement.appendChild node Else xml.documentElement.insertBefore node, anchor
    If Not oldNode Is Nothing Then xml.documentElement.removeChild oldNode
    Set LinkMail = mail
End Function

Private Function IsDeletedMail(ByVal mail As Outlook.MailItem) As Boolean
    Dim current As Outlook.Folder, trash As Outlook.Folder
    Set current = mail.Parent
    Set trash = current.Store.GetDefaultFolder(olFolderDeletedItems)
    Do
        If current.EntryID = trash.EntryID Then IsDeletedMail = True: Exit Function
        If Not TypeOf current.Parent Is Outlook.Folder Then Exit Do
        Set current = current.Parent
    Loop
End Function



Private Function ValidLinkKey(ByVal key As String) As Boolean
    ValidLinkKey = (Len(key) = 32 And Not key Like "*[!A-Fa-f0-9]*")
End Function

Private Function StoredLink(ByVal node As Object, ByRef reason As String) As Outlook.MailItem
    Dim item As Object, code As Long, detail As String, key As String
    key = CStr(node.getAttribute("key"))
    On Error Resume Next
    Err.Clear
    Set item = Application.Session.GetItemFromID(CStr(node.getAttribute("entry")), CStr(node.getAttribute("store")))
    code = Err.Number: detail = Err.Description
    On Error GoTo Failed
    If item Is Nothing Then
        If code <> 0 And code <> &H8004010F And code <> &H80040107 Then reason = "The saved mailbox could not be checked. " & detail
        Exit Function
    End If
    If TypeOf item Is Outlook.MailItem Then
        If StrComp(ReadField(item, MAIL_KEY), key, vbTextCompare) = 0 Then
            If IsDeletedMail(item) Then reason = "Original is in Deleted Items.": Exit Function
            Set StoredLink = item
        End If
    End If
    Exit Function
Failed:
    reason = "The stored email could not be checked. " & Err.Description
End Function

Private Function MarkerQueries(ByVal keys As Object) As Collection
    Dim queries As New Collection, key As Variant, terms As String, count As Long, field As String
    field = Chr$(34) & SCHEMA & MAIL_KEY & Chr$(34)
    ' Limit restriction size per store provider. Validated keys contain hex only.
    For Each key In keys.Keys
        If Len(terms) Then terms = terms & " OR "
        terms = terms & field & " = '" & CStr(key) & "'": count = count + 1
        If count = 24 Then queries.Add "@SQL=(" & terms & ")": count = 0: terms = ""
    Next key
    If count Then queries.Add "@SQL=(" & terms & ")"
    Set MarkerQueries = queries
End Function

Private Sub ReadMarkedGroup(ByVal folder As Outlook.Folder, ByVal filter As String, ByVal missing As Object, ByVal found As Object, ByVal duplicates As Object, ByRef incomplete As Boolean)
    Dim table As Outlook.Table, row As Outlook.Row
    On Error GoTo QueryFailed
    Set table = folder.GetTable(filter, olUserItems)
    On Error GoTo RowFailed
    Do Until table.EndOfTable
        Set row = table.GetNextRow
        RememberMarkerRow row, folder, missing, found, duplicates
    Loop
    Exit Sub
QueryFailed:
    ' A folder which has never held this named property may reject its column.
    If Err.Number <> &H8004010F Then incomplete = True
    Exit Sub
RowFailed:
    incomplete = True
End Sub

Private Sub FindMarkedMail(ByVal folder As Outlook.Folder, ByVal queries As Collection, ByVal missing As Object, ByVal found As Object, ByVal duplicates As Object, ByRef incomplete As Boolean)
    Dim child As Outlook.Folder, kind As Long, filter As Variant
    On Error GoTo FolderFailed
    kind = PT_FolderKind(folder): If kind = 2 Then Exit Sub
    If kind = 1 And folder.DefaultItemType = olMailItem Then
        ' Include Deleted Items in the uniqueness check. A live copy must not
        ' stand in for a deleted original which carries the same marker.
        For Each filter In queries
            ReadMarkedGroup folder, CStr(filter), missing, found, duplicates, incomplete
        Next filter
    End If
    For Each child In folder.Folders
        FindMarkedMail child, queries, missing, found, duplicates, incomplete
    Next child
    Exit Sub
FolderFailed:
    incomplete = True
End Sub

Private Sub SearchMarkerStores(ByVal queries As Collection, ByVal missing As Object, ByVal found As Object, ByVal duplicates As Object, ByRef incomplete As Boolean)
    Dim store As Outlook.Store, root As Outlook.Folder, problem As Long
    On Error GoTo Failed
    For Each store In Application.Session.Stores
        Set root = Nothing
        On Error Resume Next
        Err.Clear: Set root = store.GetRootFolder: problem = Err.Number
        On Error GoTo Failed
        If problem <> 0 Or root Is Nothing Then
            incomplete = True
        Else
            FindMarkedMail root, queries, missing, found, duplicates, incomplete
        End If
    Next store
    Exit Sub
Failed:
    incomplete = True
End Sub

Private Sub AcceptRecoveredLink(ByVal node As Object, ByVal item As Outlook.MailItem, ByVal key As String, ByVal resolved As Object, ByVal issues As Object, ByRef moved As Boolean)
    On Error GoTo Failed
    If IsDeletedMail(item) Then issues(key) = "Original is in Deleted Items.": Exit Sub
    node.setAttribute "entry", item.EntryID: node.setAttribute "store", item.Parent.StoreID
    resolved.Add key, item: moved = True
    Exit Sub
Failed:
    issues(key) = "Could not verify the recovered email. " & Err.Description
End Sub

Private Sub ResolveTaskRows(ByVal nodes As Object, ByVal resolved As Object, ByVal issues As Object, ByRef moved As Boolean)
    Dim missing As Object, found As Object, duplicates As Object, queries As Collection, node As Object, item As Outlook.MailItem
    Dim key As String, id As Variant, detail As String, incomplete As Boolean
    Set missing = CreateObject("Scripting.Dictionary"): missing.CompareMode = vbTextCompare
    For Each node In nodes
        key = CStr(node.getAttribute("key")): detail = ""
        If ValidLinkKey(key) Then
            Set item = StoredLink(node, detail)
            If Not item Is Nothing Then
                resolved.Add key, item
            ElseIf Len(detail) Then
                issues(key) = detail
            Else
                missing.Add key, node
            End If
        Else
            issues(key) = "Invalid saved identity."
        End If
    Next node
    If missing.Count = 0 Then Exit Sub
    Set found = CreateObject("Scripting.Dictionary"): found.CompareMode = vbTextCompare
    Set duplicates = CreateObject("Scripting.Dictionary"): duplicates.CompareMode = vbTextCompare
    Set queries = MarkerQueries(missing)
    ' Resolve every missing original in one traversal of the mounted folder trees.
    SearchMarkerStores queries, missing, found, duplicates, incomplete
    For Each id In missing.Keys
        If duplicates.Exists(id) Then
            issues(id) = "More than one copy has this identity."
        ElseIf incomplete Then
            issues(id) = "Some folders could not be searched. Open the mailboxes and retry."
        ElseIf Not found.Exists(id) Then
            issues(id) = "Deleted, unavailable, or the mailbox did not preserve its link."
        Else
            Set node = missing(id): Set item = found(id)
            AcceptRecoveredLink node, item, CStr(id), resolved, issues, moved
        End If
    Next id
End Sub

Private Function ResolveLink(ByVal node As Object, ByRef reason As String, ByRef moved As Boolean) As Outlook.MailItem
    Dim nodes As New Collection, resolved As Object, issues As Object, key As String
    nodes.Add node: key = CStr(node.getAttribute("key"))
    Set resolved = CreateObject("Scripting.Dictionary"): Set issues = CreateObject("Scripting.Dictionary")
    ResolveTaskRows nodes, resolved, issues, moved
    If resolved.Exists(key) Then Set ResolveLink = resolved(key) Else reason = CStr(issues(key))
End Function

Private Function TaskHeaders() As Variant
    TaskHeaders = Array("Date", "From", "Attachments", "Personal note", "Subject", "First 2 lines of body", "Original email")
End Function

Private Function ManagedTable(ByVal doc As Object) As Object
    Dim table As Object, found As Object, headers As Variant, n As Long, ok As Boolean, value As String
    headers = TaskHeaders()
    For Each table In doc.Tables
        ok = True
        On Error Resume Next
        For n = 0 To 6
            Err.Clear: value = table.Cell(1, n + 1).Range.Text
            If Err.Number <> 0 Or value <> CStr(headers(n)) & Chr$(13) & Chr$(7) Then ok = False: Exit For
        Next n
        On Error GoTo 0
        If ok Then
            If Not found Is Nothing Then Err.Raise 5, , "The task contains two similar email tables. Its body was kept."
            Set found = table
        End If
    Next table
    Set ManagedTable = found
End Function

Private Sub PutBytes(ByVal path As String, ByVal bytes As Variant)
    Dim file As Integer, raw() As Byte, opened As Boolean, number As Long, detail As String
    On Error GoTo Failed
    raw = bytes: file = FreeFile: Open path For Binary Access Write As #file
    opened = True: Put #file, , raw
    Close #file: opened = False
    Exit Sub
Failed:
    number = Err.Number: detail = Err.Description
    On Error Resume Next
    If opened Then Close #file
    On Error GoTo 0
    Err.Raise number, "Read or write the task document", detail
End Sub

Private Function ReadBytes(ByVal path As String) As Variant
    Dim file As Integer, raw() As Byte, opened As Boolean, number As Long, detail As String
    On Error GoTo Failed
    file = FreeFile: Open path For Binary Access Read As #file
    opened = True
    If LOF(file) = 0 Then Err.Raise 5, , "Word returned an empty task document."
    ReDim raw(0 To LOF(file) - 1): Get #file, , raw
    Close #file: opened = False: ReadBytes = raw
    Exit Function
Failed:
    number = Err.Number: detail = Err.Description
    On Error Resume Next
    If opened Then Close #file
    On Error GoTo 0
    Err.Raise number, "Read or write the task document", detail
End Function

Private Sub RenderTask(ByVal task As Outlook.TaskItem, ByVal xml As Object, ByVal hadLinks As Boolean)
    Dim temp As String, word As Object, doc As Object, table As Object, rng As Object, cell As Object
    Dim node As Object, keys As Variant, headers As Variant, n As Long, row As Long, path As String, bytes As Variant
    Dim detail As String, num As Long
    On Error GoTo Failed
    temp = PT_CreateTempFolder(): path = temp & "\task.rtf"
    ' A private Word document can edit a real RTF table without relying on an
    ' Inspector being open. Existing task notes outside the managed table survive.
    Set word = CreateObject("Word.Application"): word.Visible = False: word.DisplayAlerts = 0
    If Len(task.EntryID) > 0 Or Len(task.Body) > 0 Then bytes = task.RTFBody
    If HasRtf(bytes) Then
        PutBytes path, bytes
        Set doc = word.Documents.Open(path, False, False, False)
    Else
        Set doc = word.Documents.Add
    End If
    If hadLinks Then
        Set table = ManagedTable(doc)
        If table Is Nothing Then Err.Raise 5, , "The linked-email table was removed or its headings were edited. Existing task text was kept."
        Set rng = table.Range.Duplicate: rng.Collapse 1
        n = rng.Start: table.Delete: Set rng = doc.Range(n, n)
    Else
        Set rng = doc.Range(doc.Content.End - 1, doc.Content.End - 1)
        If Len(task.Body) Then rng.InsertAfter vbCr: rng.Collapse 0
    End If
    headers = TaskHeaders(): keys = Array("date", "sender", "files", "note", "subject", "body")
    Set table = doc.Tables.Add(rng, xml.documentElement.childNodes.Length + 1, 7)
    table.Range.Font.Name = "Segoe UI": table.Range.Font.Size = 9: table.Borders.Enable = True
    For n = 0 To 6: table.Cell(1, n + 1).Range.Text = CStr(headers(n)): Next n
    table.Rows(1).Range.Font.Bold = True: table.Rows(1).Shading.BackgroundPatternColor = RGB(224, 236, 240)
    row = 1
    For Each node In xml.documentElement.childNodes
        row = row + 1
        For n = 0 To 5: table.Cell(row, n + 1).Range.Text = TaskCellText(CStr(node.getAttribute(CStr(keys(n))))): Next n
        Set cell = table.Cell(row, 7).Range: cell.End = cell.End - 1
        doc.Hyperlinks.Add cell, "outlook:" & CStr(node.getAttribute("entry")), "", "Open original email", "Open email"
    Next node
    table.AutoFitBehavior 2
    doc.SaveAs2 temp & "\updated.rtf", 6
    bytes = ReadBytes(temp & "\updated.rtf"): task.RTFBody = bytes
Finished:
    On Error Resume Next
    If Not doc Is Nothing Then doc.Close 0
    If Not word Is Nothing Then word.Quit 0
    If Len(temp) Then PT_CleanTemp temp
    On Error GoTo 0
    If num <> 0 Then Err.Raise num, "Build task email table", detail
    Exit Sub
Failed:
    num = Err.Number: detail = Err.Description
    Resume Finished
End Sub

Public Sub SaveLinkedFollowUp(ByVal selected As Collection, ByVal panel As frmPersonalOutlook, Optional ByRef savedID As String = "", Optional ByRef savedStore As String = "", Optional ByVal responseID As String = "")
    Dim task As Outlook.TaskItem, original As Outlook.MailItem, mail As Outlook.MailItem, ready As New Collection
    Dim needsFlag As Boolean, label As String
    Dim folder As Outlook.Folder, xml As Object, hadLinks As Boolean, failures As String, approved As Boolean, problem As String
    On Error GoTo Failed
    Set folder = Application.Session.GetDefaultFolder(olFolderTasks)
    If Len(panel.ExistingTaskID) Then
        Set task = Application.Session.GetItemFromID(panel.ExistingTaskID, folder.StoreID)
        If task.Complete Then Err.Raise 5, , "This task has just been completed. Choose another task."
        Set task = EditableItem(task)
    Else
        Set task = folder.Items.Add(olTaskItem): task.Sensitivity = olPrivate
    End If
    Set xml = LinkDocument(task): hadLinks = (xml.documentElement.childNodes.Length > 0)
    For Each original In selected
        On Error Resume Next
        label = "Selected email": label = original.Subject
        Err.Clear: Set mail = Nothing: Set mail = LinkMail(xml, original, panel.FollowUpNote)
        problem = Err.Description
        On Error GoTo Failed
        If mail Is Nothing Then failures = failures & vbCrLf & label & " - " & problem Else ready.Add mail
    Next original
    If ready.Count = 0 Then Err.Raise 5, , "No emails could be linked." & failures
    handling = True
    RenderTask task, xml, hadLinks
    task.Subject = panel.FollowUpTitle
    If Not panel.KeepDeadline Then
        task.DueDate = DateValue(panel.FollowUpDue)
        task.ReminderTime = panel.FollowUpDue: task.ReminderSet = True
    End If
    If Len(responseID) Then
        Dim savedRow As Object, linkedMail As Outlook.MailItem
        Set linkedMail = ready(1)
        Set savedRow = xml.documentElement.selectSingleNode("mail[@key='" & UCase$(ReadField(linkedMail, MAIL_KEY)) & "']")
        If Not savedRow Is Nothing Then savedRow.setAttribute "response", responseID
    End If
    task.PropertyAccessor.SetProperty SCHEMA & TASK_XML, xml.XML
    task.PropertyAccessor.SetProperty SCHEMA & PENDING, "1"
    If Len(responseID) And Len(panel.ExistingTaskID) = 0 Then task.PropertyAccessor.SetProperty RESPONSE_RECEIPT, responseID
    task.Save: approved = True
    savedID = task.EntryID: savedStore = task.Parent.StoreID
    For Each mail In ready
        On Error Resume Next
        Err.Clear
        needsFlag = Not mail.IsMarkedAsTask
        If Not needsFlag Then needsFlag = (Year(mail.TaskCompletedDate) < 4000 And Year(mail.TaskCompletedDate) > 1900)
        If needsFlag Then
            mail.MarkAsTask olMarkNoDate
            If Err.Number = 0 Then mail.PropertyAccessor.SetProperty SCHEMA & HIDE_FLAG, "1"
            If Err.Number = 0 Then mail.Save
        End If
        problem = Err.Description
        If Len(problem) Then failures = failures & vbCrLf & mail.Subject & " - " & problem
        On Error GoTo Failed
    Next mail
    PT_WriteSetting "UseLinkedFlagView", IIf(panel.UseFlagView, "1", "0")
    WatchTasks Application
    handling = False
    If Len(failures) Then PT_ShowReport "Follow Up saved", "The task is saved. Some messages need attention." & vbCrLf & failures
    Exit Sub
Failed:
    problem = Err.Description: handling = False
    If approved Then problem = "The task is already saved. " & problem
    MsgBox problem, vbInformation, "Follow Up"
End Sub

Public Sub CheckLinkedTask(ByVal task As Outlook.TaskItem, ByVal opening As Boolean)
    ' Outlook raises these callbacks while it opens inspectors or saves items.
    ' Keep only IDs here. Provider searches and flag updates run after return.
    On Error GoTo Unavailable
    If handling Or WorkspaceClosing() Then Exit Sub
    If Not opening Then
        If Not task.Complete Then Exit Sub
    End If
    QueueLinkedTask task.EntryID, task.Parent.StoreID, opening
    Exit Sub
Unavailable:
    PT_AlertLog "A task event could not be queued. Reopen the task to retry."
End Sub

Private Sub problemReport(ByVal title As String, ByVal reason As String)
    PT_ShowReport "Follow Up - " & title, reason
End Sub

Public Sub ApplyLinkedFlagView(ByVal browser As Outlook.Explorer)
    Dim target As Outlook.Folder, view As Outlook.View, base As Outlook.View, filter As String, extra As String
    On Error GoTo Failed
    Dim enabled As Boolean
    enabled = (PT_ReadSetting("UseLinkedFlagView", "0") = "1")
    If Not enabled And PT_ReadSetting("PreviousToDoView", "") = "" Then Exit Sub
    ' Store only the identity. Ordinary folder switches never need to reopen
    ' the default mailbox after its To-Do List has been identified.
    On Error GoTo FolderUnavailable
    Set target = browser.CurrentFolder
    If Len(toDoEntry) = 0 Then
        If Now < retryToDoAfter Then Exit Sub
        On Error GoTo IdentityUnavailable
        Dim todo As Outlook.Folder
        Set todo = Application.Session.GetDefaultFolder(olFolderToDo)
        toDoStore = todo.StoreID: toDoEntry = todo.EntryID
        On Error GoTo FolderUnavailable
    End If
    If target.EntryID <> toDoEntry Then Exit Sub
    If target.StoreID <> toDoStore Then Exit Sub
    On Error GoTo Failed
    Set base = browser.CurrentView
    If Not enabled Then
        If base.Name = VIEW_NAME Then
            Set view = target.Views(PT_ReadSetting("PreviousToDoView", ""))
            view.Apply
        End If
        Exit Sub
    End If
    Dim created As Boolean, detail As String
    If base.Name <> VIEW_NAME Then PT_WriteSetting "PreviousToDoView", base.Name
    On Error Resume Next: Set view = target.Views(VIEW_NAME): On Error GoTo Failed
    If view Is Nothing Then
        Set view = base.Copy(VIEW_NAME, olViewSaveOptionThisFolderOnlyMe): created = True
    End If
    filter = view.Filter
    If InStr(1, filter, SCHEMA & HIDE_FLAG, vbTextCompare) = 0 Then
        extra = "(" & Chr$(34) & SCHEMA & HIDE_FLAG & Chr$(34) & " IS NULL OR " & Chr$(34) & SCHEMA & HIDE_FLAG & Chr$(34) & " <> '1')"
        If Len(filter) Then extra = "(" & filter & ") AND " & extra
        view.Filter = extra: view.Save
        view.Apply
    ElseIf base.Name <> VIEW_NAME Then
        view.Apply
    End If
    lastViewIssue = ""
FolderUnavailable:
    Exit Sub
IdentityUnavailable:
    toDoEntry = "": retryToDoAfter = DateAdd("s", 60, Now)
    Exit Sub
Failed:
    detail = Err.Description
    On Error Resume Next
    PT_WriteSetting "UseLinkedFlagView", "0"
    If created Then
        base.Apply: view.Delete
    End If
    If detail <> lastViewIssue Then
        lastViewIssue = detail
        PT_AlertLog "The personal To-Do view could not be applied. Your mail flags are kept. " & detail
    End If
End Sub


Public Sub StartTaskMonitoring(ByVal app As Outlook.Application)
    WatchTasks app
    sweepPhase = 1
End Sub


Public Sub OpenLinkedEmail(ByVal task As Outlook.TaskItem)
    Dim xml As Object, node As Object, panel As New frmPersonalOutlook, list As New Collection
    Dim reason As String, moved As Boolean, mail As Outlook.MailItem, index As Long
    On Error GoTo Failed
    Set xml = LinkDocument(task)
    For Each node In xml.documentElement.childNodes
        list.Add Array(CStr(node.getAttribute("date")), CStr(node.getAttribute("subject")), CStr(node.getAttribute("sender")))
    Next node
    If list.Count = 0 Then MsgBox "This task has no emails linked by Follow Up.", vbInformation, "Open linked email": Exit Sub
    panel.PrepareLinkedPicker list: panel.Show vbModal
    If panel.Result = 1 Then index = panel.SelectedNoteIndex Else index = -1
    Unload panel
    If index < 0 Then Exit Sub
    Set node = xml.documentElement.childNodes.Item(index)
    Set mail = ResolveLink(node, reason, moved)
    If mail Is Nothing Then MsgBox reason, vbInformation, "Open linked email" Else mail.Display
    Exit Sub
Failed:
    MsgBox Err.Description, vbInformation, "Open linked email"
End Sub


Private Function HasRtf(ByVal bytes As Variant) As Boolean
    On Error Resume Next
    If IsArray(bytes) Then HasRtf = UBound(bytes) >= LBound(bytes)
End Function


Public Sub SeparateWorkflowCopy(ByVal copy As Object)
    Dim names As Variant, field As Variant, changed As Boolean
    ' Outlook may duplicate named properties. A copy is a different filing item
    ' and must not acquire ownership of a task's originals or their completion.
    If TypeOf copy Is Outlook.MailItem Then
        changed = RemoveResponseTag(copy)
        names = Array(MAIL_KEY, HIDE_FLAG)
    ElseIf TypeOf copy Is Outlook.TaskItem Then
        Dim receipt As Variant
        On Error Resume Next
        Err.Clear: receipt = copy.PropertyAccessor.GetProperty(RESPONSE_RECEIPT)
        Dim code As Long, description As String
        code = Err.Number: description = Err.Description
        On Error GoTo 0
        If code = 0 Then
            copy.PropertyAccessor.DeleteProperty RESPONSE_RECEIPT: changed = True
        ElseIf code <> &H8004010F Then
            Err.Raise code, "Separate task copy", description
        End If
        names = Array(TASK_XML, PENDING, TABLE_DIRTY)
    Else
        Exit Sub
    End If
    For Each field In names
        If Len(ReadField(copy, CStr(field))) Then
            copy.PropertyAccessor.DeleteProperty SCHEMA & CStr(field)
            changed = True
        End If
    Next field
    If changed Then copy.Save
End Sub


Private Function TaskCellText(ByVal value As String) As String
    value = Replace(Replace(value, vbCrLf, vbLf), vbCr, vbLf)
    TaskCellText = Replace(value, vbLf, Chr$(11))
End Function


Private Sub RememberMarkerRow(ByVal row As Outlook.Row, ByVal folder As Outlook.Folder, ByVal missing As Object, ByVal found As Object, ByVal duplicates As Object)
    Dim item As Object, first As Outlook.MailItem, key As String
    Set item = Application.Session.GetItemFromID(CStr(row("EntryID")), folder.StoreID)
    If TypeOf item Is Outlook.MailItem Then
        key = ReadField(item, MAIL_KEY)
        If missing.Exists(key) Then
            If found.Exists(key) Then
                Set first = found(key)
                If first.EntryID <> item.EntryID Or first.Parent.StoreID <> item.Parent.StoreID Then duplicates(key) = True
            Else
                found.Add key, item
            End If
        End If
    End If
End Sub


Private Sub QueueLinkedTask(ByVal entry As String, ByVal store As String, ByVal opening As Boolean)
    Dim key As String, ticket As Object
    If Len(entry) = 0 Or WorkspaceClosing() Then Exit Sub
    key = store & "|" & entry
    If Not activeTask Is Nothing Then
        If activeTask("key") = key Then
            If opening Then activeTask("open") = True
            Exit Sub
        End If
    End If
    If taskTickets Is Nothing Then Set taskTickets = CreateObject("Scripting.Dictionary"): Set taskQueue = New Collection
    If taskTickets.Exists(key) Then
        Set ticket = taskTickets(key)
        If opening Then ticket("open") = True
    Else
        Set ticket = CreateObject("Scripting.Dictionary")
        ticket.Add "key", key: ticket.Add "entry", entry: ticket.Add "store", store: ticket.Add "open", opening
        taskTickets.Add key, ticket: taskQueue.Add key
    End If
    RequestOutlookWork 100
End Sub

Public Function LinkedWorkPending() As Boolean
    If sweepPhase > 0 Or Not activeTask Is Nothing Then LinkedWorkPending = True: Exit Function
    If Not taskQueue Is Nothing Then LinkedWorkPending = (taskQueue.Count > 0)
End Function

Private Sub TaskSweepStep()
    Dim folder As Outlook.Folder, row As Outlook.Row, filter As String, n As Long, started As Double
    On Error GoTo Failed
    If sweepPhase = 1 Then
        Set folder = Application.Session.GetDefaultFolder(olFolderTasks)
        sweepStore = folder.StoreID
        filter = "@SQL=" & Chr$(34) & SCHEMA & PENDING & Chr$(34) & " = '1' AND " & Chr$(34) & "http://schemas.microsoft.com/mapi/id/{00062003-0000-0000-C000-000000000046}/811C000B" & Chr$(34) & " = 1"
        Set sweepTable = folder.GetTable(filter, olUserItems)
        sweepPhase = 2: Exit Sub
    End If
    started = Timer
    For n = 1 To 12
        If sweepTable.EndOfTable Then GoTo Finished
        Set row = sweepTable.GetNextRow
        QueueLinkedTask CStr(row("EntryID")), sweepStore, False
        If SliceExpired(started) Then Exit For
    Next n
    Exit Sub
Failed:
    If Err.Number <> &H8004010F Then PT_AlertLog "The pending task list could not be read. Opening a linked task will retry it. " & Err.Description
Finished:
    sweepPhase = 0: Set sweepTable = Nothing
End Sub

Private Sub PushTaskFolder(ByVal folder As Outlook.Folder)
    Dim frame As Object
    Set frame = CreateObject("Scripting.Dictionary")
    frame.Add "folder", folder: frame.Add "phase", 0&: taskFrames.Add frame
End Sub

Private Sub TaskSearchStep()
    Dim frame As Object, folder As Outlook.Folder, child As Outlook.Folder, children As Outlook.Folders, row As Outlook.Row
    Dim n As Long, store As Outlook.Store, started As Double
    On Error GoTo Failed
    If taskFrames.Count = 0 Then
        If taskStoreIndex > taskStoreIDs.Count Then
            taskIndex = 0: taskPhase = 4: Exit Sub
        End If
        n = taskStoreIndex: taskStoreIndex = taskStoreIndex + 1
        Set store = Application.Session.GetStoreFromID(CStr(taskStoreIDs(n)))
        PushTaskFolder store.GetRootFolder
        Exit Sub
    End If
    Set frame = taskFrames(taskFrames.Count): Set folder = frame("folder")
    Select Case CLng(frame("phase"))
        Case 0
            n = PT_FolderKind(folder)
            If n = 2 Then taskFrames.Remove taskFrames.Count: Exit Sub
            If n = 1 And folder.DefaultItemType = olMailItem Then frame("phase") = 1 Else frame("phase") = 2
            frame("query") = 1&
        Case 1
            If CLng(frame("query")) > taskQueries.Count Then frame("phase") = 2: Exit Sub
            If taskMatchTable Is Nothing Then
                On Error GoTo QueryFailed
                Set taskMatchTable = folder.GetTable(CStr(taskQueries(CLng(frame("query")))), olUserItems)
                Exit Sub
            End If
            started = Timer
            For n = 1 To 8
                If taskMatchTable.EndOfTable Then
                    Set taskMatchTable = Nothing: frame("query") = CLng(frame("query")) + 1: Exit Sub
                End If
                Set row = taskMatchTable.GetNextRow
                RememberMarkerRow row, folder, taskMissing, taskFound, taskDupes
                If SliceExpired(started) Then Exit For
            Next n
        Case 2
            Set children = folder.Folders: frame.Add "children", children
            frame.Add "count", children.Count: frame.Add "child", 1&: frame("phase") = 3
        Case 3
            n = CLng(frame("child"))
            If n > CLng(frame("count")) Then taskFrames.Remove taskFrames.Count: Exit Sub
            frame("child") = n + 1: Set children = frame("children")
            Set child = children.Item(n): PushTaskFolder child
    End Select
    Exit Sub
QueryFailed:
    If Err.Number <> &H8004010F Then taskIncomplete = True
    frame("query") = CLng(frame("query")) + 1: Exit Sub
Failed:
    taskIncomplete = True: Set taskMatchTable = Nothing
    If Not frame Is Nothing Then taskFrames.Remove taskFrames.Count
End Sub

Private Sub ReleaseTaskJob()
    Set activeTask = Nothing: Set taskObject = Nothing: Set taskXmlDoc = Nothing
    Set taskMissing = Nothing: Set taskFound = Nothing: Set taskDupes = Nothing: Set taskResolved = Nothing
    Set taskIssues = Nothing: Set taskQueries = Nothing: Set taskFrames = Nothing: Set taskStoreIDs = Nothing
    Set taskMatchTable = Nothing: taskPhase = 0
End Sub

Private Function CompleteOriginal(ByVal mail As Outlook.MailItem) As String
    Dim stamp As Date
    On Error GoTo Failed
    If Not mail.Saved Then CompleteOriginal = "The original has unsaved edits.": Exit Function
    If mail.IsMarkedAsTask Then
        stamp = mail.TaskCompletedDate
        If Year(stamp) > 1900 And Year(stamp) < 4000 Then Exit Function
    Else
        mail.MarkAsTask olMarkNoDate
    End If
    mail.MarkAsTask olMarkComplete: mail.Save
    Exit Function
Failed:
    CompleteOriginal = Err.Description
End Function

Public Sub LinkedWorkStep(Optional ByVal unused As Boolean = False)
    Dim key As String, node As Object, mail As Outlook.MailItem, issue As String, store As Outlook.Store, tuple As Variant
    Dim closingTask As Boolean, initial As String, opening As Boolean
    If handling Then Exit Sub
    On Error GoTo Failed
    taskSweepTurn = Not taskSweepTurn
    If sweepPhase > 0 And (taskSweepTurn Or taskQueue Is Nothing) Then TaskSweepStep: Exit Sub
    If activeTask Is Nothing Then
        If taskQueue Is Nothing Then Exit Sub
        If taskQueue.Count = 0 Then Exit Sub
        key = CStr(taskQueue(1)): taskQueue.Remove 1: Set activeTask = taskTickets(key): taskTickets.Remove key
        Set taskObject = Application.Session.GetItemFromID(CStr(activeTask("entry")), CStr(activeTask("store")))
        opening = CBool(activeTask("open"))
        closingTask = taskObject.Complete
        taskCompleting = False
        If closingTask Then taskCompleting = (ReadField(taskObject, PENDING) = "1")
        If Not taskCompleting And Not opening Then GoTo Done
        initial = ReadField(taskObject, TASK_XML): If Len(initial) = 0 Then GoTo Done
        Set taskXmlDoc = LinkDocument(taskObject, initial)
        taskOriginalXml = initial: taskVersion = taskObject.LastModificationTime
        Set taskMissing = CreateObject("Scripting.Dictionary"): taskMissing.CompareMode = vbTextCompare
        Set taskFound = CreateObject("Scripting.Dictionary"): taskFound.CompareMode = vbTextCompare
        Set taskDupes = CreateObject("Scripting.Dictionary"): taskDupes.CompareMode = vbTextCompare
        Set taskIssues = CreateObject("Scripting.Dictionary"): Set taskResolved = CreateObject("Scripting.Dictionary")
        taskPhase = 1: taskIndex = 0: taskMoved = False: taskIncomplete = False: taskFailures = ""
        Exit Sub
    End If
    Select Case taskPhase
        Case 1
            If taskIndex >= taskXmlDoc.documentElement.childNodes.length Then
                taskIndex = 0
                If taskMissing.Count = 0 Then taskPhase = 5: Exit Sub
                Set taskQueries = MarkerQueries(taskMissing): Set taskFrames = New Collection: Set taskStoreIDs = New Collection
                ' Read at most one store identity per dispatch before walking any folders.
                taskStoreIndex = 1: taskStoreCount = Application.Session.Stores.Count: taskPhase = 2: Exit Sub
            End If
            Set node = taskXmlDoc.documentElement.childNodes.Item(taskIndex): taskIndex = taskIndex + 1
            key = CStr(node.getAttribute("key")): Set mail = StoredLink(node, issue)
            If Not mail Is Nothing Then
                taskResolved(key) = True
            ElseIf Len(issue) Then
                taskIssues(key) = issue
            Else
                taskMissing.Add key, node
            End If
        Case 2
            If taskStoreIndex > taskStoreCount Then taskStoreIndex = 1: taskPhase = 3: Exit Sub
            Set store = Application.Session.Stores.Item(taskStoreIndex): taskStoreIDs.Add store.StoreID
            taskStoreIndex = taskStoreIndex + 1
        Case 3
            TaskSearchStep
        Case 4
            If taskIndex >= taskXmlDoc.documentElement.childNodes.length Then taskIndex = 0: taskPhase = 5: Exit Sub
            Set node = taskXmlDoc.documentElement.childNodes.Item(taskIndex): taskIndex = taskIndex + 1
            key = CStr(node.getAttribute("key"))
            If taskMissing.Exists(key) Then
                If taskDupes.Exists(key) Then
                    taskIssues(key) = "More than one copy has this identity."
                ElseIf taskIncomplete Then
                    taskIssues(key) = "Some folders could not be checked. Reopen the task to retry."
                ElseIf Not taskFound.Exists(key) Then
                    taskIssues(key) = "Deleted, inaccessible, or the mailbox did not preserve its link."
                Else
                    Set mail = taskFound(key)
                    AcceptRecoveredLink node, mail, key, taskResolved, taskIssues, taskMoved
                End If
            End If
        Case 5
            If taskIndex >= taskXmlDoc.documentElement.childNodes.length Then taskPhase = 6: Exit Sub
            Set node = taskXmlDoc.documentElement.childNodes.Item(taskIndex): taskIndex = taskIndex + 1: key = CStr(node.getAttribute("key"))
            If taskIssues.Exists(key) Then
                issue = CStr(taskIssues(key))
            ElseIf taskCompleting And taskResolved.Exists(key) Then
                If Not taskObject.Complete Or taskObject.LastModificationTime <> taskVersion Then GoTo Changed
                ' A search can span multiple turns. Recheck the final locator,
                ' marker and Deleted Items boundary just before changing a flag.
                Set mail = StoredLink(node, issue)
                If mail Is Nothing Then
                    If Len(issue) = 0 Then issue = "The email moved again. Reopen the task to retry."
                Else
                    issue = CompleteOriginal(mail)
                End If
            End If
            If Len(issue) Then taskFailures = taskFailures & vbCrLf & CStr(node.getAttribute("subject")) & " - " & issue
        Case 6
            opening = CBool(activeTask("open"))
            If Not taskObject.Saved Then issue = "Save your task edits and reopen it to refresh the links.": GoTo Report
            If taskObject.LastModificationTime <> taskVersion Then GoTo Changed
            If ReadField(taskObject, TASK_XML) <> taskOriginalXml Then GoTo Changed
            handling = True
            If taskMoved Then
                taskObject.PropertyAccessor.SetProperty SCHEMA & TASK_XML, taskXmlDoc.XML
                taskObject.PropertyAccessor.SetProperty SCHEMA & TABLE_DIRTY, "1"
            End If
            ' Background completion never starts Word. Refresh the visible RTF
            ' links when the task is next opened, preserving surrounding notes.
            If opening Then
                If ReadField(taskObject, TABLE_DIRTY) = "1" Then
                    RenderTask taskObject, taskXmlDoc, True
                    taskObject.PropertyAccessor.SetProperty SCHEMA & TABLE_DIRTY, "0"
                    taskMoved = True
                End If
            End If
            If taskCompleting And Len(taskFailures) = 0 Then taskObject.PropertyAccessor.SetProperty SCHEMA & PENDING, "0"
            If taskMoved Or (taskCompleting And Len(taskFailures) = 0) Then taskObject.Save
Report:
            handling = False
            If Len(issue) Then taskFailures = taskFailures & vbCrLf & issue
            If Len(taskFailures) Then
                PT_AlertLog "A linked task needs attention. Open it to see the affected originals and retry."
                If opening Then PT_ShowReport "Linked emails", taskFailures
            End If
            GoTo Done
    End Select
    Exit Sub
Changed:
    Dim ticket As Object
    Set ticket = activeTask: ReleaseTaskJob
    QueueLinkedTask CStr(ticket("entry")), CStr(ticket("store")), CBool(ticket("open"))
    Exit Sub
Done:
    handling = False: ReleaseTaskJob: Exit Sub
Failed:
    issue = Err.Description: handling = False
    PT_AlertLog "Linked task update paused. Reopen the task to retry. " & issue
    Resume Done
End Sub

Public Function ResponseMailAvailable(ByVal mail As Outlook.MailItem) As Boolean
    On Error GoTo Unavailable
    ResponseMailAvailable = Not IsDeletedMail(mail)
Unavailable:
End Function

Public Function TaskForResponse(ByVal ticket As String, ByVal target As String, ByVal targetStore As String) As Outlook.TaskItem
    Dim folder As Outlook.Folder, table As Outlook.Table, row As Outlook.Row, found As Object, code As Long, why As String
    On Error GoTo Failed
    If Len(target) Then
        Dim xml As Object, receipt As Object
        Set found = Application.Session.GetItemFromID(target, targetStore)
        If Not TypeOf found Is Outlook.TaskItem Then Exit Function
        Set xml = LinkDocument(found): Set receipt = xml.documentElement.selectSingleNode("mail[@response='" & ticket & "']")
        If Not receipt Is Nothing Then Set TaskForResponse = found
        Exit Function
    End If
    Set folder = Application.Session.GetDefaultFolder(olFolderTasks)
    Set table = folder.GetTable("@SQL=" & Chr$(34) & RESPONSE_RECEIPT & Chr$(34) & " = '" & ticket & "'", olUserItems)
    If table.EndOfTable Then Exit Function
    Set row = table.GetNextRow
    If Not table.EndOfTable Then Err.Raise 5, , "More than one task has this receipt. Check Tasks before continuing."
    Set found = Application.Session.GetItemFromID(CStr(row("EntryID")), folder.StoreID)
    If TypeOf found Is Outlook.TaskItem Then Set TaskForResponse = found
    Exit Function
Failed:
    code = Err.Number: why = Err.Description
    If code <> &H8004010F Then Err.Raise code, "Find saved follow-up task", why
End Function

Public Sub UpdateFiledTaskLink(ByVal taskEntry As String, ByVal taskStore As String, ByVal oldEntry As String, ByVal oldStore As String, ByVal filed As Object)
    Dim task As Outlook.TaskItem, xml As Object, node As Object, marker As String, expected As String
    If oldEntry = filed.EntryID And oldStore = filed.Parent.StoreID Then Exit Sub
    Set task = Application.Session.GetItemFromID(taskEntry, taskStore)
    If Not task.Saved Then Err.Raise 5, , "The task has open edits. Reopen it after saving to refresh its links."
    Set xml = LinkDocument(task)
    For Each node In xml.documentElement.childNodes
        If CStr(node.getAttribute("entry")) = oldEntry And CStr(node.getAttribute("store")) = oldStore Then
            expected = CStr(node.getAttribute("key")): marker = ReadField(filed, MAIL_KEY)
            If Len(marker) = 0 Then
                ' Move returned this exact object. A cross-store provider can
                ' drop named properties, so restore the original link marker.
                filed.PropertyAccessor.SetProperty SCHEMA & MAIL_KEY, expected: filed.Save
            ElseIf StrComp(marker, expected, vbTextCompare) <> 0 Then
                Err.Raise 5, , "The moved email reports a different task identity. Check the link on the task."
            End If
            node.setAttribute "entry", filed.EntryID: node.setAttribute "store", filed.Parent.StoreID
            task.PropertyAccessor.SetProperty SCHEMA & TASK_XML, xml.XML
            task.PropertyAccessor.SetProperty SCHEMA & TABLE_DIRTY, "1": task.Save
            Exit Sub
        End If
    Next node
End Sub

Public Function TaskChoiceDue(ByVal entry As String, ByVal store As String) As Date
    Dim task As Object, due As Date, savedDue As Date
    Set task = Application.Session.GetItemFromID(entry, store)
    If Not TypeOf task Is Outlook.TaskItem Then Err.Raise 5, , "The selected task is unavailable."
    If task.Complete Then Err.Raise 5, , "The selected task has already been completed."
    savedDue = task.DueDate: due = DateAdd("d", 7, Date) + TimeSerial(10, 0, 0)
    If Year(savedDue) < 4000 Then due = DateValue(savedDue) + TimeSerial(10, 0, 0)
    If task.ReminderSet Then due = DateValue(due) + TimeValue(task.ReminderTime)
    TaskChoiceDue = due
End Function
