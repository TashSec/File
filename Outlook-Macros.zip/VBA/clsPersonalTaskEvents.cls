VERSION 1.0 CLASS
BEGIN
  MultiUse = -1
END
Attribute VB_Name = "clsPersonalTaskEvents"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
' Class module clsPersonalTaskEvents. Keep the Items collection alive to observe
' completion in the normal Tasks list, including edits made outside this macro.
Private WithEvents tasks As Outlook.Items
Private WithEvents inspectors As Outlook.Inspectors
Public Sub Connect(ByVal app As Outlook.Application)
    Set tasks = app.Session.GetDefaultFolder(olFolderTasks).Items
    Set inspectors = app.Inspectors
End Sub
Private Sub tasks_ItemChange(ByVal Item As Object)
    If TypeOf Item Is Outlook.TaskItem Then CheckLinkedTask Item, False
End Sub
Private Sub inspectors_NewInspector(ByVal Inspector As Outlook.Inspector)
    Dim item As Object
    Set item = Inspector.CurrentItem
    If TypeOf item Is Outlook.TaskItem Then CheckLinkedTask item, True
End Sub
