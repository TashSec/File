VERSION 1.0 CLASS
BEGIN
  MultiUse = -1
END
Attribute VB_Name = "clsPersonalChainRow"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
' Insert a CLASS MODULE named clsPersonalChainRow. Each wrapped review row has its own checkbox and open events.
Option Explicit
Private WithEvents pick As MSForms.CheckBox
Private WithEvents messageText As MSForms.Label
Private WithEvents statusText As MSForms.Label
Private WithEvents senderText As MSForms.Label
Private WithEvents retentionText As MSForms.Label
Private WithEvents folderText As MSForms.Label
Private owner As frmPersonalOutlook
Private data As Object
Private changing As Boolean

' Bind one row. Only the checkbox changes the cleanup choice; double-clicking text opens the original.
Public Sub Connect(ByVal panel As frmPersonalOutlook, ByVal row As Object, ByVal host As MSForms.Frame, ByVal index As Long, ByVal keepFiles As Boolean)
    Dim y As Single, eligible As Boolean, info As Object, record As Variant, hint As String
    changing = True: Set owner = panel: Set data = row
    y = index * 72: record = row("record"): Set info = panel.ChainReview("folders")(CStr(row("folderKey")))
    eligible = PT_ChainRowEligible(row, keepFiles)
    Set pick = host.Controls.Add("Forms.CheckBox.1", "rowPick" & index, True)
    pick.Move 6, y + 9, 24, 24: pick.Caption = "": pick.BackStyle = fmBackStyleTransparent
    pick.Value = (CBool(row("wantDelete")) And eligible): pick.Enabled = eligible
    pick.ControlTipText = "Checked: include this older email in the reviewed Move/Delete action. Unchecked: keep it. Opening the row's text does not change this choice. Protected newest/unique-file rows cannot be checked."
    hint = PT_ChainRowStatus(row, keepFiles)
    Set messageText = Cell(host, "subject" & index, 38, y + 4, 308, 35, Left$(CStr(record(4)), 125), RGB(32, 54, 82))
    messageText.Font.Bold = True
    Set senderText = Cell(host, "sender" & index, 38, y + 41, 308, 27, CStr(row("sender")), RGB(35, 99, 105))
    Set statusText = Cell(host, "received" & index, 362, y + 4, 282, 15, Format$(CDate(record(6)), "dd/mm/yyyy hh:nn"), RGB(48, 72, 122))
    Set retentionText = Cell(host, "retention" & index, 362, y + 20, 282, 26, hint, RGB(116, 67, 84))
    Set folderText = Cell(host, "folder" & index, 362, y + 48, 282, 23, CStr(info("label")), RGB(47, 93, 71))
    DrawLine host, "rowLine" & index, 2, y + 71, 647, 1
    DrawLine host, "checkLine" & index, 32, y, 1, 72
    DrawLine host, "textLine" & index, 352, y, 1, 72
    changing = False
End Sub

' Apply checkbox state to the review model; the parent validates protection and refreshes totals.
Private Sub pick_Click()
    If changing Or owner Is Nothing Then Exit Sub
    owner.ChainRowChanged data, CBool(pick.Value)
End Sub

' Enter inspects the original while Space keeps its normal checkbox-toggle behaviour.
Private Sub pick_KeyDown(ByVal KeyCode As MSForms.ReturnInteger, ByVal Shift As Integer)
    If KeyCode = vbKeyReturn Then KeyCode = 0: owner.OpenChainRow data
End Sub

' Double-click is an inspection gesture, separate from the action checkbox.
Private Sub messageText_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    Cancel = True: If Not owner Is Nothing Then owner.OpenChainRow data
End Sub

' The received/folder/status column opens the same original item.
Private Sub statusText_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    Cancel = True: If Not owner Is Nothing Then owner.OpenChainRow data
End Sub

' Break form/row references before clearing controls or unloading the review.
Public Sub Disconnect()
    Set owner = Nothing: Set data = Nothing
    Set senderText = Nothing: Set retentionText = Nothing: Set folderText = Nothing
    Set pick = Nothing: Set messageText = Nothing: Set statusText = Nothing
End Sub


Private Function Cell(ByVal host As MSForms.Frame, ByVal key As String, ByVal x As Single, ByVal y As Single, ByVal w As Single, ByVal h As Single, ByVal value As String, ByVal ink As Long) As MSForms.Label
    Dim label As MSForms.Label
    Set label = host.Controls.Add("Forms.Label.1", key, True)
    label.Move x, y, w, h: label.Caption = value: label.ForeColor = ink
    label.Font.Name = "Segoe UI": label.Font.Size = 9: label.WordWrap = True: label.BackStyle = fmBackStyleTransparent
    label.ControlTipText = Left$("Double-click to open the original email. " & value, 250)
    Set Cell = label
End Function

Private Sub DrawLine(ByVal host As MSForms.Frame, ByVal key As String, ByVal x As Single, ByVal y As Single, ByVal w As Single, ByVal h As Single)
    Dim label As MSForms.Label
    Set label = host.Controls.Add("Forms.Label.1", key, True)
    label.Move x, y, w, h: label.Caption = "": label.BackColor = RGB(181, 193, 203)
End Sub


Private Sub senderText_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    Cancel = True: If Not owner Is Nothing Then owner.OpenChainRow data
End Sub


Private Sub retentionText_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    Cancel = True: If Not owner Is Nothing Then owner.OpenChainRow data
End Sub


Private Sub folderText_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    Cancel = True: If Not owner Is Nothing Then owner.OpenChainRow data
End Sub
