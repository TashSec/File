VERSION 1.0 CLASS
BEGIN
  MultiUse = -1
END
Attribute VB_Name = "clsPersonalRuleCell"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
' Class module clsPersonalRuleCell. Each accessible grid cell selects its rule,
' and a double-click displays the last result for that stable rule ID.
Option Explicit
Private WithEvents cell As MSForms.CommandButton
Private owner As frmPersonalOutlook
Private index As Long
Public Sub Connect(ByVal panel As frmPersonalOutlook, ByVal host As MSForms.Frame, ByVal row As Long, ByVal column As Long, ByVal x As Single, ByVal width As Single, ByVal value As String)
    Set owner = panel: index = row
    Set cell = host.Controls.Add("Forms.CommandButton.1", "r" & row & "c" & column, True)
    cell.Move x, row * 26, width, 26
    cell.Caption = value: cell.Font.Name = "Segoe UI": cell.Font.Size = 9
    cell.TakeFocusOnClick = True: cell.TabStop = (column = 0)
    cell.ControlTipText = Left$(value & ". Click to select this rule. Double-click to see its last run and any error.", 250)
    Highlight -1
End Sub
Public Sub Highlight(ByVal selected As Long)
    cell.BackColor = IIf(index = selected, RGB(214, 232, 240), IIf(index Mod 2 = 0, RGB(249, 251, 252), RGB(239, 244, 247)))
    cell.ForeColor = RGB(40, 55, 68)
End Sub
Private Sub cell_Click()
    owner.SelectRuleRow index, False
End Sub
Private Sub cell_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    Cancel = True: owner.SelectRuleRow index, True
End Sub
Private Sub cell_KeyDown(ByVal KeyCode As MSForms.ReturnInteger, ByVal Shift As Integer)
    If KeyCode = vbKeyReturn Then KeyCode = 0: owner.SelectRuleRow index, True
End Sub
Public Sub Disconnect()
    Set owner = Nothing: Set cell = Nothing
End Sub
