Attribute VB_Name = "modPersonalMailAlerts"
' PERSONAL OFFICE MACROS - lock-aware email notifications, 25 November 2026
' Paste into STANDARD MODULE modPersonalMailAlerts. Replace the whole older block.
' Requires frmPersonalOutlook, clsPersonalFolderWatcher and the session hooks.
' Pause with Settings_AlertsToggle and close previews before editing a running notification timer.
Option Explicit
#If VBA7 Then
Private Declare PtrSafe Function SetTimer Lib "user32" (ByVal hwnd As LongPtr, ByVal eventID As LongPtr, ByVal milliseconds As Long, ByVal callback As LongPtr) As LongPtr
Private Declare PtrSafe Function KillTimer Lib "user32" (ByVal hwnd As LongPtr, ByVal eventID As LongPtr) As Long
Private Declare PtrSafe Function FindWindowW Lib "user32" (ByVal className As LongPtr, ByVal caption As LongPtr) As LongPtr
Private Declare PtrSafe Function SetWindowPos Lib "user32" (ByVal hwnd As LongPtr, ByVal after As LongPtr, ByVal x As Long, ByVal y As Long, ByVal cx As Long, ByVal cy As Long, ByVal flags As Long) As Long
Private Declare PtrSafe Function GetWindowRect Lib "user32" (ByVal hwnd As LongPtr, ByRef rect As PA_RECT) As Long
Private Declare PtrSafe Function SystemParametersInfoW Lib "user32" (ByVal action As Long, ByVal param As Long, ByRef rect As PA_RECT, ByVal flags As Long) As Long
Private Declare PtrSafe Function WTSQuerySessionInformationW Lib "wtsapi32" (ByVal server As LongPtr, ByVal session As Long, ByVal info As Long, ByRef buffer As LongPtr, ByRef bytes As Long) As Long
Private Declare PtrSafe Sub WTSFreeMemory Lib "wtsapi32" (ByVal buffer As LongPtr)
Private Declare PtrSafe Sub PA_CopyMemory Lib "kernel32" Alias "RtlMoveMemory" (ByRef destination As Any, ByVal source As LongPtr, ByVal bytes As LongPtr)
Private alertTimer As LongPtr
#Else
Private Declare Function SetTimer Lib "user32" (ByVal hwnd As Long, ByVal eventID As Long, ByVal milliseconds As Long, ByVal callback As Long) As Long
Private Declare Function KillTimer Lib "user32" (ByVal hwnd As Long, ByVal eventID As Long) As Long
Private Declare Function FindWindowW Lib "user32" (ByVal className As Long, ByVal caption As Long) As Long
Private Declare Function SetWindowPos Lib "user32" (ByVal hwnd As Long, ByVal after As Long, ByVal x As Long, ByVal y As Long, ByVal cx As Long, ByVal cy As Long, ByVal flags As Long) As Long
Private Declare Function GetWindowRect Lib "user32" (ByVal hwnd As Long, ByRef rect As PA_RECT) As Long
Private Declare Function SystemParametersInfoW Lib "user32" (ByVal action As Long, ByVal param As Long, ByRef rect As PA_RECT, ByVal flags As Long) As Long
Private Declare Function WTSQuerySessionInformationW Lib "wtsapi32" (ByVal server As Long, ByVal session As Long, ByVal info As Long, ByRef buffer As Long, ByRef bytes As Long) As Long
Private Declare Sub WTSFreeMemory Lib "wtsapi32" (ByVal buffer As Long)
Private Declare Sub PA_CopyMemory Lib "kernel32" Alias "RtlMoveMemory" (ByRef destination As Any, ByVal source As Long, ByVal bytes As Long)
Private alertTimer As Long
#End If
' Window styles use pointer-sized APIs on 64-bit Office; the 32-bit aliases use the matching Windows entry points.
#If VBA7 Then
    #If Win64 Then
Private Declare PtrSafe Function PA_GetWindowLongPtr Lib "user32" Alias "GetWindowLongPtrW" (ByVal hwnd As LongPtr, ByVal index As Long) As LongPtr
Private Declare PtrSafe Function PA_SetWindowLongPtr Lib "user32" Alias "SetWindowLongPtrW" (ByVal hwnd As LongPtr, ByVal index As Long, ByVal value As LongPtr) As LongPtr
    #Else
Private Declare PtrSafe Function PA_GetWindowLongPtr Lib "user32" Alias "GetWindowLongW" (ByVal hwnd As LongPtr, ByVal index As Long) As LongPtr
Private Declare PtrSafe Function PA_SetWindowLongPtr Lib "user32" Alias "SetWindowLongW" (ByVal hwnd As LongPtr, ByVal index As Long, ByVal value As LongPtr) As LongPtr
    #End If
Private Declare PtrSafe Function PA_WindowProcess Lib "user32" Alias "GetWindowThreadProcessId" (ByVal hwnd As LongPtr, ByRef process As Long) As Long
Private Declare PtrSafe Function PA_CurrentProcess Lib "kernel32" Alias "GetCurrentProcessId" () As Long
#Else
Private Declare Function PA_GetWindowLongPtr Lib "user32" Alias "GetWindowLongW" (ByVal hwnd As Long, ByVal index As Long) As Long
Private Declare Function PA_SetWindowLongPtr Lib "user32" Alias "SetWindowLongW" (ByVal hwnd As Long, ByVal index As Long, ByVal value As Long) As Long
Private Declare Function PA_WindowProcess Lib "user32" Alias "GetWindowThreadProcessId" (ByVal hwnd As Long, ByRef process As Long) As Long
Private Declare Function PA_CurrentProcess Lib "kernel32" Alias "GetCurrentProcessId" () As Long
#End If

#If VBA7 Then
Private Declare PtrSafe Function DeskDC Lib "user32" Alias "GetDC" (ByVal hwnd As LongPtr) As LongPtr
Private Declare PtrSafe Function FreeDeskDC Lib "user32" Alias "ReleaseDC" (ByVal hwnd As LongPtr, ByVal hdc As LongPtr) As Long
Private Declare PtrSafe Function DeskCaps Lib "gdi32" Alias "GetDeviceCaps" (ByVal hdc As LongPtr, ByVal cap As Long) As Long
#Else
Private Declare Function DeskDC Lib "user32" Alias "GetDC" (ByVal hwnd As Long) As Long
Private Declare Function FreeDeskDC Lib "user32" Alias "ReleaseDC" (ByVal hwnd As Long, ByVal hdc As Long) As Long
Private Declare Function DeskCaps Lib "gdi32" Alias "GetDeviceCaps" (ByVal hdc As Long, ByVal cap As Long) As Long
#End If
Private Type PA_RECT
    left As Long
    top As Long
    right As Long
    bottom As Long
End Type
Private logBuffer As String, logLoaded As Boolean, logDirty As Boolean, logWritten As Date
Private failedArrival As Boolean
Private retryCardAfter As Date
Private noticeDismissed As Boolean
Private awayPeriods As Collection
Private lastLockStart As Date
Private lastUnlock As Date
Private timerBusy As Boolean, timerOff As Boolean, timerStart As Double, timerDelay As Long
Private watchQueue As Collection, watchPending As Object, watchRetry As Object, excludedByStore As Object
Private pollEligible As Object, watchLimitReported As Boolean, nextRetryCheck As Date
Private syncIndex As Long, pollTurn As Boolean, workspaceTurn As Boolean
Private quietPolls As Long, pollHadWork As Boolean
Private pollWanted As Boolean, pollActive As Boolean, pollIndex As Long, pollKeys As Variant
Private pollTable As Outlook.Table, pollBatch As Variant, pollRow As Long, pollLast As Long
Private pollStamp As Date, pollMissed As Boolean, pollStore As String, pollPrefix As String
Private rootDeepStarts As Object
Private pollRetryAfter As Object
Private lastPollStart As Date, lastSlowAt As Date, lastSlowLabel As String
Private alertApp As Outlook.Application
Private alertSettings As Object
Private alertFolders As Object
Private alertTrees As Object
Private alertSeen As Object
Private alertWatermarks As Object
Private alertRootStarts As Object
Private alertFloors As Object
Private watchStoreIDs As Object
Private alertChecked As Object
Private checkedAt As Date
Private alertSinks As Collection
Private alertSince As Date
Private alertRunning As Boolean
Private alertScanning As Boolean
Private alertConfigOpen As Boolean
Private alertQueue As Collection
Private alertNotice As frmPersonalOutlook
Private alertShownAt As Double
Private alertSeconds As Long
Private alertLastScan As Double
Private alertCurrent As Object ' Retain the full visible notification so a lock can put it back at the front.
Private alertUIBlocks As Long ' Nested attachment operations defer popups until all their dialogs have closed.
Private alertSessionState As Long ' 1 = unlocked/active; 0 = locked/disconnected; -1 = unavailable.
Private alertStateKnown As Boolean

' Return the running Outlook application used by the notification module.
Private Function PA_App() As Outlook.Application
    Set PA_App = Application
End Function

' Create an enabled rule in the editor while the global notification configuration starts disabled.
Public Function PT_NewMailAlertRule() As Object
    Dim r As Object, roots As New Collection
    Set r = CreateObject("Scripting.Dictionary")
    r.Add "name", "New notification": r.Add "enabled", True: r.Add "roots", roots
    r.Add "sender", "": r.Add "senderMode", 0: r.Add "subject", "": r.Add "subjectMode", 0
    r.Add "to", "": r.Add "cc", "": r.Add "recipientMode", 0
    r.Add "personal", "": r.Add "groups", ""
    r.Add "replayLocked", True: r.Add "toMode", 0: r.Add "ccMode", 0
    r.Add "headingText", "": r.Add "manualDismiss", False
    r.Add "heading", True: r.Add "showSender", True: r.Add "showSubject", True
    r.Add "showBody", False: r.Add "showFolder", False: r.Add "showTo", False: r.Add "showCc", False
    r.Add "bodyLines", 2: r.Add "seconds", 8: r.Add "position", 0: r.Add "sound", False
    Set PT_NewMailAlertRule = r
End Function

' Create the global notification configuration and an empty ordered rule list.
Public Function PT_NewMailAlertSettings() As Object
    Dim s As Object, rules As New Collection
    Set s = CreateObject("Scripting.Dictionary")
    s.Add "enabled", False: s.Add "rules", rules: s.Add "migrated", False: s.Add "replayLocked", True
    Set PT_NewMailAlertSettings = s
End Function

' Copy mutable rule fields and folder references so cancelled edits do not alter the original rule.
Public Function PT_CloneMailAlertRule(ByVal original As Object) As Object
    Dim r As Object, refs As New Collection, ref As Object, copy As Object, k As Variant
    Set r = PT_NewMailAlertRule()
    For Each k In r.Keys
        If CStr(k) <> "roots" Then r(k) = original(k)
    Next k
    For Each ref In original("roots")
        Set copy = CreateObject("Scripting.Dictionary")
        For Each k In ref.Keys: copy.Add k, ref(k): Next k
        refs.Add copy
    Next ref
    Set r("roots") = refs
    Set PT_CloneMailAlertRule = r
End Function

' Parse a bounded non-negative setting before using it to load a saved collection.
Private Function PA_Count(ByVal text As String, ByVal maximum As Long) As Long
    If Len(text) = 0 Or Len(text) > 5 Then GoTo Invalid
    If text Like "*[!0-9]*" Then GoTo Invalid
    PA_Count = CLng(text)
    If PA_Count <= maximum Then Exit Function
Invalid:
    Err.Raise 5, "modPersonalMailAlerts.PA_Count", "A saved notification count is invalid."
End Function

' Read the complete active notification slot and migrate earlier choices into a disabled draft.
Public Function PT_LoadMailAlertSettings() As Object
    Dim s As Object, r As Object, ref As Object, p As String, rp As String, slot As String
    Dim i As Long, j As Long, k As Variant, roots As Long, count As Long
    Set s = PT_NewMailAlertSettings()
    slot = PT_ReadSetting("NotifyActiveSlot", "")
    If Len(slot) = 0 Then
        ' Read old selections without overwriting their saved settings. Review/enable
        ' the replacement once; it never silently converts email alerts into popups.
        slot = PT_ReadSetting("AlertsActiveSlot", "")
        If Len(slot) = 0 Then Set PT_LoadMailAlertSettings = s: Exit Function
        If slot <> "0" And slot <> "1" Then GoTo Invalid
        p = "Alerts" & slot & "_"
        If PT_ReadSetting(p & "Complete", "0") <> "1" Then GoTo Invalid
        count = PA_Count(PT_ReadSetting(p & "Count", "0"), 100)
        If count > 0 Then
            Set r = PT_NewMailAlertRule(): r("name") = "Previous monitored folders - review before enabling"
            For j = 1 To count
                Set ref = CreateObject("Scripting.Dictionary")
                ref.Add "entry", PT_ReadSetting(p & j & "Entry", "")
                ref.Add "store", PT_ReadSetting(p & j & "Store", "")
                ref.Add "label", PT_ReadSetting(p & j & "Label", "Saved folder")
                ref.Add "recursive", (PT_ReadSetting(p & j & "Recursive", "0") = "1")
                r("roots").Add ref
            Next j
            s("rules").Add r
        End If
        s("migrated") = True
        Set PT_LoadMailAlertSettings = s: Exit Function
    End If
    If slot <> "0" And slot <> "1" Then GoTo Invalid
    p = "Notify" & slot & "_"
    If PT_ReadSetting(p & "Complete", "0") <> "1" Or PT_ReadSetting(p & "Schema", "") <> "1" Then GoTo Invalid
    s("enabled") = (PT_ReadSetting(p & "Enabled", "0") = "1")
    s("replayLocked") = (PT_ReadSetting(p & "ReplayLocked", "1") = "1")
    count = PA_Count(PT_ReadSetting(p & "Count", "0"), 50)
    For i = 1 To count
        Set r = PT_NewMailAlertRule(): rp = p & "R" & i & "_"
        r("replayLocked") = s("replayLocked")
        For Each k In r.Keys
            If CStr(k) <> "roots" Then
                Select Case VarType(r(k))
                    Case vbBoolean: r(k) = (PT_ReadSetting(rp & k, IIf(r(k), "1", "0")) = "1")
                    Case vbInteger, vbLong: r(k) = CLng(PT_ReadSetting(rp & k, CStr(r(k))))
                    Case Else: r(k) = PT_ReadSetting(rp & k, CStr(r(k)))
                End Select
            End If
        Next k
        If PT_ReadSetting(rp & "headingText", Chr$(1)) = Chr$(1) Then
            If CBool(r("heading")) Then r("headingText") = "Email Received" ' Preserve earlier checkbox choices during migration only.
        End If
        roots = PA_Count(PT_ReadSetting(rp & "Roots", "0"), 100)
        For j = 1 To roots
            Set ref = CreateObject("Scripting.Dictionary")
            ref.Add "entry", PT_ReadSetting(rp & j & "Entry", "")
            ref.Add "store", PT_ReadSetting(rp & j & "Store", "")
            ref.Add "label", PT_ReadSetting(rp & j & "Label", "Saved folder")
            ref.Add "recursive", (PT_ReadSetting(rp & j & "Recursive", "0") = "1")
            r("roots").Add ref
        Next j
        s("rules").Add r
    Next i
    PT_ValidateMailAlertSettings s
    Set PT_LoadMailAlertSettings = s: Exit Function
Invalid:
    Err.Raise 5, "modPersonalMailAlerts.PT_LoadMailAlertSettings", "Notification settings are incomplete or invalid. Restore your settings backup or choose your folders again."
End Function

' Check duration, detail choices, text filters and folder references before accepting a rule.
Public Sub PT_ValidateMailAlertRule(ByVal r As Object)
    Dim ref As Object, key As Variant, shown As Boolean, n As Long
    If Len(Trim$(CStr(r("name")))) = 0 Or Len(r("name")) > 100 Then Err.Raise 5, , "Enter a rule name of 1 to 100 characters."
    For Each key In Array("sender", "subject", "to", "cc", "personal", "groups")
        If Len(r(key)) > 2000 Or InStr(r(key), vbCr) > 0 Or InStr(r(key), vbLf) > 0 Then Err.Raise 5, , "Keep each filter on one line, up to 2,000 characters. Separate alternatives with semicolons."
        If Len(Trim$(r(key))) > 0 And Len(Replace(Replace(r(key), ";", ""), " ", "")) = 0 Then Err.Raise 5, , "A filter contains only separators. Enter a value or clear the field."
    Next key
    For Each key In Array("senderMode", "subjectMode", "toMode", "ccMode")
        n = CLng(r(key)): If n < 0 Or n > 3 Then Err.Raise 5, , "Choose a valid text-match option."
    Next key
    n = CLng(r("recipientMode")): If n < 0 Or n > 6 Then Err.Raise 5, , "Choose a valid recipient option."
    If r("roots").Count > 100 Then Err.Raise 5, , "Choose at most 100 mailbox/folder selections per rule."
    For Each ref In r("roots")
        If Len(ref("entry")) = 0 Or Len(ref("store")) = 0 Then Err.Raise 5, , "A selected folder has no saved ID. Remove it and choose it again."
    Next ref
    If n >= 1 And n <= 4 Then PA_ValidateAddresses CStr(r("personal")), CBool(r("enabled")), "your personal addresses"
    If n >= 5 Then PA_ValidateAddresses CStr(r("groups")), CBool(r("enabled")), "the group/list addresses"
    If r("enabled") And r("roots").Count = 0 Then Err.Raise 5, , "Choose a mailbox or folder for this enabled rule."
    If Not CBool(r("manualDismiss")) Then
        If CLng(r("seconds")) < 3 Or CLng(r("seconds")) > 120 Then Err.Raise 5, , "Choose a popup duration from 3 to 120 whole seconds."
    End If
    If CLng(r("bodyLines")) < 1 Or CLng(r("bodyLines")) > 5 Then Err.Raise 5, , "Choose 1 to 5 body lines."
    If CLng(r("position")) < 0 Or CLng(r("position")) > 3 Then Err.Raise 5, , "Choose a popup corner."
    If Len(CStr(r("headingText"))) > 120 Or InStr(CStr(r("headingText")), vbCr) > 0 Or InStr(CStr(r("headingText")), vbLf) > 0 Then Err.Raise 5, , "Keep the opening text on one line, up to 120 characters."
    shown = (Len(Trim$(CStr(r("headingText")))) > 0)
    For Each key In Array("showSender", "showSubject", "showBody", "showFolder", "showTo", "showCc")
        If CBool(r(key)) Then shown = True
    Next key
    If Not shown Then Err.Raise 5, , "Type opening text or choose at least one email detail. For a private card, type a generic heading and untick all email details."
End Sub

' Check the explicitly entered SMTP addresses used for personal and group matching.
Private Sub PA_ValidateAddresses(ByVal addresses As String, ByVal required As Boolean, ByVal label As String)
    Dim part As Variant, value As String, found As Boolean
    For Each part In Split(addresses, ";")
        value = Trim$(CStr(part))
        If Len(value) > 0 Then
            found = True
            If InStr(value, "@") < 2 Or InStr(value, "@") = Len(value) Or InStr(InStr(value, "@") + 1, value, "@") > 0 Or InStr(value, " ") > 0 Or InStr(value, ",") > 0 Or InStr(value, "<") > 0 Then Err.Raise 5, , "Enter " & label & " as plain email addresses separated by semicolons."
        End If
    Next part
    If required And Not found Then Err.Raise 5, , "Enter " & label & ". Include any aliases you receive mail through."
End Sub

' Validate the global notification configuration and every ordered rule before saving.
Public Sub PT_ValidateMailAlertSettings(ByVal s As Object)
    Dim r As Object, enabled As Long
    If VarType(s("replayLocked")) <> vbBoolean Then Err.Raise 5, , "The locked-screen replay choice must be on or off."
    If s("rules").Count > 50 Then Err.Raise 5, , "Use at most 50 notification rules."
    For Each r In s("rules")
        PT_ValidateMailAlertRule r
        If r("enabled") Then enabled = enabled + 1
    Next r

End Sub

' Write the entire inactive configuration before making it the active notification slot.
Public Sub PT_SaveMailAlertSettings(ByVal s As Object)
    Dim p As String, rp As String, slot As String, r As Object, ref As Object, k As Variant, i As Long, j As Long
    PT_ValidateMailAlertSettings s
    If PT_ReadSetting("NotifyActiveSlot", "") = "0" Then slot = "1" Else slot = "0"
    p = "Notify" & slot & "_": PT_WriteSetting p & "Complete", "0"
    PT_WriteSetting p & "Schema", "1": PT_WriteSetting p & "Enabled", IIf(s("enabled"), "1", "0")
    PT_WriteSetting p & "ReplayLocked", IIf(s("replayLocked"), "1", "0")
    PT_WriteSetting p & "Count", CStr(s("rules").Count)
    For Each r In s("rules")
        i = i + 1: rp = p & "R" & i & "_"
        For Each k In r.Keys
            If CStr(k) <> "roots" Then
                If VarType(r(k)) = vbBoolean Then
                    PT_WriteSetting rp & k, IIf(r(k), "1", "0")
                Else
                    PT_WriteSetting rp & k, CStr(r(k))
                End If
            End If
        Next k
        j = 0: PT_WriteSetting rp & "Roots", CStr(r("roots").Count)
        For Each ref In r("roots")
            j = j + 1
            PT_WriteSetting rp & j & "Entry", CStr(ref("entry"))
            PT_WriteSetting rp & j & "Store", CStr(ref("store"))
            PT_WriteSetting rp & j & "Label", CStr(ref("label"))
            PT_WriteSetting rp & j & "Recursive", IIf(ref("recursive"), "1", "0")
        Next ref
    Next r
    PT_WriteSetting p & "Complete", "1"
    PT_WriteSetting "NotifyActiveSlot", slot ' Activate only a fully written save.
End Sub

' Capture the selected folder's exact IDs, display label and subfolder option.
Public Function PT_AlertFolderReference(ByVal folder As Outlook.Folder, ByVal recursive As Boolean) As Object
    Dim ref As Object, kind As Long
    kind = PT_FolderKind(folder)
    If kind = 2 Then Err.Raise 5, , "Choose a physical mail folder or mailbox, not a Search Folder."
    If kind <> 0 And folder.DefaultItemType <> olMailItem Then Err.Raise 5, , "Choose a mail folder."
    Set ref = CreateObject("Scripting.Dictionary")
    ref.Add "entry", folder.EntryID: ref.Add "store", folder.StoreID
    ref.Add "recursive", (recursive Or kind = 0)
    ref.Add "label", folder.Store.DisplayName & " - " & folder.FolderPath
    Set PT_AlertFolderReference = ref
End Function

' Suggest the current user's SMTP address for the personal-recipient condition.
Public Function PT_DefaultAlertAddress() As String
    Dim account As Outlook.Account, seen As Object, value As String
    Set seen = CreateObject("Scripting.Dictionary"): seen.CompareMode = vbTextCompare
    On Error Resume Next
    For Each account In PA_App().Session.Accounts
        value = Trim$(account.SmtpAddress)
        If InStr(value, "@") > 1 And Not seen.Exists(value) Then
            seen.Add value, True
            If Len(PT_DefaultAlertAddress) > 0 Then PT_DefaultAlertAddress = PT_DefaultAlertAddress & "; "
            PT_DefaultAlertAddress = PT_DefaultAlertAddress & value
        End If
    Next account
End Function

' Suspend popup display during editing, then restart monitoring from the approved saved choices.
Public Sub Settings_ConfigureMailAlerts()
    Dim panel As frmPersonalOutlook, saved As Boolean
    On Error GoTo Failed
    alertConfigOpen = True
    PA_ParkNotice True ' Opening setup must not discard an unseen notification.
    Set panel = New frmPersonalOutlook
    panel.PrepareMailAlerts PT_LoadMailAlertSettings()
    panel.Show vbModal
    saved = (panel.Result = 1): Unload panel
    alertConfigOpen = False
    If saved Then
        If alertRunning Then RefreshActiveWatchers PA_App(), False
    End If
    Exit Sub
Failed:
    alertConfigOpen = False
    PT_ReportError "Set up email notifications", Err.Number, Err.Description, Err.Source, "modPersonalMailAlerts.Settings_ConfigureMailAlerts"
End Sub

' Describe the monitoring state and recent diagnostic log in the setup window.
Public Function PT_MailAlertStatus(Optional ByVal settings As Object = Nothing) As String
    Dim count As Long, waiting As Long, enabled As Long, rule As Object, status As String
    If settings Is Nothing Then Set settings = PT_LoadMailAlertSettings()
    For Each rule In settings("rules")
        If CBool(rule("enabled")) Then enabled = enabled + 1
    Next rule
    If Not alertFolders Is Nothing Then count = alertFolders.Count
    If Not alertQueue Is Nothing Then waiting = alertQueue.Count
    If Not NotificationsActive(settings) Then
        status = "Alerts paused. Use Settings_AlertsToggle to resume."
    ElseIf Not alertRunning And AlertStartupPending() Then
        status = "Alerts active. Monitoring will connect as Outlook opens."
    ElseIf Not alertRunning Then
        status = "Alerts are enabled, but monitoring could not start. Check today's log for the cause."
    ElseIf enabled = 0 Then
        status = "Alerts active. Enable a rule to receive notifications."
    ElseIf count = 0 Then
        status = "Alerts active. Waiting for the selected folders to connect."
    Else
        status = "Alerts active."
    End If
    Dim timing As String
    timing = PT_ReadSetting("LastSlowOutlookStep", "")
    If Left$(timing, 11) = Format$(Date, "yyyy-mm-dd") & "|" Then status = status & vbCrLf & "Last slow macro step: " & Mid$(timing, 12)
    PT_MailAlertStatus = status & vbCrLf & enabled & " enabled rule(s), " & count & " connected folder(s), " & waiting & " card(s) waiting." & vbCrLf & _
        "The first matching rule controls the card and its behaviour after unlock." & vbCrLf & vbCrLf & _
        "Today - " & Format$(Date, "dd/mm/yyyy") & vbCrLf & TodayAlertLog()
End Function
' Text filters: blank = any; alternatives separated by semicolons; no wildcard syntax.
' Modes: 0 contains any, 1 equals any, 2 starts with any, 3 contains none.
Public Function PT_AlertTextMatch(ByVal value As String, ByVal filters As String, ByVal matchMode As Long) As Boolean
    Dim part As Variant, token As String, found As Boolean, used As Boolean
    For Each part In Split(filters, ";")
        token = Trim$(CStr(part))
        If Len(token) > 0 Then
            used = True
            Select Case matchMode
                Case 0, 3: If InStr(1, value, token, vbTextCompare) > 0 Then found = True
                Case 1: If StrComp(Trim$(value), token, vbTextCompare) = 0 Then found = True
                Case 2: If StrComp(Left$(value, Len(token)), token, vbTextCompare) = 0 Then found = True
            End Select
        End If
    Next part
    If Not used Then
        PT_AlertTextMatch = True
    ElseIf matchMode = 3 Then
        PT_AlertTextMatch = Not found
    Else
        PT_AlertTextMatch = found
    End If
End Function

' Resolve a recipient address entry to SMTP, including Exchange directory entries.
Private Function PA_Address(ByVal entry As Outlook.AddressEntry) As String
    Dim person As Outlook.ExchangeUser, group As Outlook.ExchangeDistributionList, value As String
    On Error Resume Next
    If entry Is Nothing Then Exit Function
    value = entry.PropertyAccessor.GetProperty("http://schemas.microsoft.com/mapi/proptag/0x39FE001F")
    If Len(value) = 0 Then value = entry.PropertyAccessor.GetProperty("http://schemas.microsoft.com/mapi/proptag/0x39FE001E")
    If Len(value) Then PA_Address = value: Exit Function
    If entry.Type = "EX" Then
        Set person = entry.GetExchangeUser
        If Not person Is Nothing Then value = person.PrimarySmtpAddress
        If Len(value) = 0 Then
            Set group = entry.GetExchangeDistributionList
            If Not group Is Nothing Then value = group.PrimarySmtpAddress
        End If
    End If
    If Len(value) = 0 Then value = entry.Address
    PA_Address = value
End Function

' Choose the usable SMTP sender address for a notification filter.
Private Function PA_SenderAddress(ByVal mail As Outlook.MailItem) As String
    Dim value As String
    On Error Resume Next
    value = mail.PropertyAccessor.GetProperty("http://schemas.microsoft.com/mapi/proptag/0x5D01001F")
    If Len(value) = 0 Then value = PA_Address(mail.Sender)
    If Len(value) = 0 Then value = mail.SenderEmailAddress
    PA_SenderAddress = value
End Function

' Build resolved visible recipient rows for To and Cc matching.
Private Function PA_RecipientRows(ByVal mail As Outlook.MailItem) As Collection
    Dim rows As New Collection, recipient As Outlook.Recipient, r As Object, kind As Long
    For Each recipient In mail.Recipients
        kind = recipient.Type
        If kind = olTo Or kind = olCC Then
            Set r = CreateObject("Scripting.Dictionary")
            r.Add "type", kind: r.Add "name", recipient.Name
            r.Add "address", PA_RecipientSmtp(recipient)
            rows.Add r
        End If
    Next recipient
    Set PA_RecipientRows = rows
End Function

' Match the chosen recipient kind against any of the configured text alternatives.
Private Function PA_RecipientTextMatch(ByVal rows As Collection, ByVal kind As Long, ByVal filters As String, ByVal matchMode As Long) As Boolean
    Dim r As Object, found As Boolean, positive As Long
    If Len(Trim$(filters)) = 0 Then PA_RecipientTextMatch = True: Exit Function
    positive = matchMode: If positive = 3 Then positive = 0
    For Each r In rows
        If CLng(r("type")) = kind Then
            If PT_AlertTextMatch(CStr(r("name")), filters, positive) Or PT_AlertTextMatch(CStr(r("address")), filters, positive) Then found = True: Exit For
        End If
    Next r
    If matchMode = 3 Then PA_RecipientTextMatch = Not found Else PA_RecipientTextMatch = found
End Function

' Apply the personal-address and explicit group/list recipient condition.
Public Function PT_AlertRecipientModeMatch(ByVal rows As Collection, ByVal recipientMode As Long, ByVal personal As String, ByVal groups As String) As Boolean
    Dim r As Object, meTo As Boolean, meCc As Boolean, groupTo As Boolean, groupCc As Boolean, othersTo As Boolean
    If recipientMode = 0 Then PT_AlertRecipientModeMatch = True: Exit Function
    For Each r In rows
        If CLng(r("type")) = olTo Then
            If Len(Trim$(personal)) > 0 And PT_AlertTextMatch(CStr(r("address")), personal, 1) Then meTo = True Else othersTo = True
            If Len(Trim$(groups)) > 0 And PT_AlertTextMatch(CStr(r("address")), groups, 1) Then groupTo = True
        ElseIf CLng(r("type")) = olCC Then
            If Len(Trim$(personal)) > 0 And PT_AlertTextMatch(CStr(r("address")), personal, 1) Then meCc = True
            If Len(Trim$(groups)) > 0 And PT_AlertTextMatch(CStr(r("address")), groups, 1) Then groupCc = True
        End If
    Next r
    Select Case recipientMode
        Case 1: PT_AlertRecipientModeMatch = meTo
        Case 2: PT_AlertRecipientModeMatch = meTo And Not othersTo
        Case 3: PT_AlertRecipientModeMatch = meCc
        Case 4: PT_AlertRecipientModeMatch = meTo Or meCc
        Case 5: PT_AlertRecipientModeMatch = groupTo
        Case 6: PT_AlertRecipientModeMatch = groupTo Or groupCc
    End Select
End Function

' Match the exact selected folder or one of its permitted descendants in the same store.
Private Function PA_RuleFolderMatch(ByVal rule As Object, ByVal folder As Outlook.Folder, Optional ByVal locationInfo As Object = Nothing) As Boolean
    Dim ref As Object, ancestors As Object, current As Outlook.Folder, parent As Object
    If locationInfo Is Nothing Then
        Set locationInfo = CreateObject("Scripting.Dictionary")
        locationInfo.Add "store", folder.StoreID: locationInfo.Add "entry", folder.EntryID
    End If
    For Each ref In rule("roots")
        If StrComp(CStr(ref("store")), CStr(locationInfo("store")), vbTextCompare) = 0 Then
            If StrComp(CStr(ref("entry")), CStr(locationInfo("entry")), vbTextCompare) = 0 Then PA_RuleFolderMatch = True: Exit Function
            If CBool(ref("recursive")) Then
                If Not locationInfo.Exists("ancestors") Then
                    Set ancestors = CreateObject("Scripting.Dictionary"): ancestors.CompareMode = vbTextCompare
                    locationInfo.Add "ancestors", ancestors
                    locationInfo.Add "cursor", folder: locationInfo.Add "depth", 0&
                End If
                Set ancestors = locationInfo("ancestors")
                If ancestors.Exists(CStr(ref("entry"))) Then PA_RuleFolderMatch = True: Exit Function
                Do While CLng(locationInfo("depth")) < 100
                    Set current = locationInfo("cursor"): Set parent = current.Parent
                    If Not TypeOf parent Is Outlook.Folder Then locationInfo("depth") = 100: Exit Do
                    Set current = parent: ancestors(current.EntryID) = True
                    Set locationInfo("cursor") = current: locationInfo("depth") = CLng(locationInfo("depth")) + 1
                    If ancestors.Exists(CStr(ref("entry"))) Then PA_RuleFolderMatch = True: Exit Function
                Loop
            End If
        End If
    Next ref
End Function

' Apply the enabled rule's location, sender, subject and recipient conditions to one message.
Public Function PT_AlertRuleMatches(ByVal rule As Object, ByVal mail As Outlook.MailItem, ByVal folder As Outlook.Folder, Optional ByVal locationInfo As Object = Nothing) As Boolean
    Dim rows As Collection, mode As Long
    If Not rule("enabled") Then Exit Function
    If locationInfo Is Nothing Then
        Set locationInfo = CreateObject("Scripting.Dictionary")
        locationInfo.Add "store", folder.StoreID: locationInfo.Add "entry", folder.EntryID
    End If
    If Not PA_RuleFolderMatch(rule, folder, locationInfo) Then Exit Function
    If Len(Trim$(CStr(rule("subject")))) Then
        If Not locationInfo.Exists("subject") Then locationInfo.Add "subject", mail.Subject
        If Not PT_AlertTextMatch(CStr(locationInfo("subject")), rule("subject"), CLng(rule("subjectMode"))) Then Exit Function
    End If
    If Len(Trim$(rule("sender"))) Then
        mode = CLng(rule("senderMode"))
        If Not locationInfo.Exists("senderName") Then locationInfo.Add "senderName", mail.SenderName
        If mode = 3 Then
            If Not PT_AlertTextMatch(CStr(locationInfo("senderName")), rule("sender"), mode) Then Exit Function
            If Not PT_AlertTextMatch(PA_CachedSender(mail, locationInfo), rule("sender"), mode) Then Exit Function
        ElseIf Not PT_AlertTextMatch(CStr(locationInfo("senderName")), rule("sender"), mode) Then
            If Not PT_AlertTextMatch(PA_CachedSender(mail, locationInfo), rule("sender"), mode) Then Exit Function
        End If
    End If
    If CLng(rule("recipientMode")) <> 0 Or Len(Trim$(rule("to"))) > 0 Or Len(Trim$(rule("cc"))) > 0 Then
        ' This context belongs to one message. Multiple matching rules share
        ' a single recipient/address-book read, including unsuccessful matches.
        If Not locationInfo.Exists("recipients") Then locationInfo.Add "recipients", PA_RecipientRows(mail)
        Set rows = locationInfo("recipients")
        If Not PA_RecipientTextMatch(rows, olTo, rule("to"), CLng(rule("toMode"))) Then Exit Function
        If Not PA_RecipientTextMatch(rows, olCC, rule("cc"), CLng(rule("ccMode"))) Then Exit Function
        If Not PT_AlertRecipientModeMatch(rows, CLng(rule("recipientMode")), rule("personal"), rule("groups")) Then Exit Function
    End If
    PT_AlertRuleMatches = True
End Function

' Select the requested number of nonblank body lines for the optional preview.
Public Function PT_AlertBodyPreview(ByVal body As String, ByVal lines As Long) As String
    Dim part As Variant, value As String, count As Long, result As String
    body = Replace(Replace(Left$(body, 8000), vbCrLf, vbLf), vbCr, vbLf)
    For Each part In Split(body, vbLf)
        value = Trim$(Replace(CStr(part), vbTab, " "))
        If Len(value) > 0 Then
            If count > 0 Then result = result & vbCrLf
            result = result & Left$(value, 180): count = count + 1
            If count >= lines Then Exit For
        End If
    Next part
    If Len(result) = 0 Then result = "[Body preview unavailable]"
    PT_AlertBodyPreview = result
End Function

' Collapse control characters and limit popup field lengths for predictable wrapping.
Private Function PA_OneLine(ByVal text As String, ByVal maximum As Long) As String
    PA_OneLine = Left$(Replace(Replace(Replace(text, vbCr, " "), vbLf, " "), vbTab, " "), maximum)
End Function

' Render only the details enabled for this rule so an omitted field stays private.
Public Function PT_AlertRender(ByVal rule As Object, ByVal data As Object) As Collection
    Dim rows As New Collection, heading As String, line As Variant
    heading = Trim$(CStr(rule("headingText")))
    If Len(heading) Then rows.Add Array("", heading, True)
    If rule("showSender") Then rows.Add Array("From:", PA_OneLine(CStr(data("sender")), 180), False)
    If rule("showSubject") Then rows.Add Array("Subject:", PA_OneLine(CStr(data("subject")), 240), False)
    If rule("showTo") Then rows.Add Array("To:", PA_OneLine(CStr(data("to")), 240), False)
    If rule("showCc") Then rows.Add Array("Cc:", PA_OneLine(CStr(data("cc")), 240), False)
    If rule("showFolder") Then rows.Add Array("Folder:", PA_OneLine(CStr(data("folder")), 240), False)
    If rule("showBody") Then
        For Each line In Split(PT_AlertBodyPreview(CStr(data("body")), CLng(rule("bodyLines"))), vbCrLf)
            rows.Add Array("", CStr(line), False)
        Next line
    End If
    Set PT_AlertRender = rows
End Function

' Read the message fields needed to render the matching rule's popup.
Private Function PA_RenderMail(ByVal rule As Object, ByVal mail As Outlook.MailItem, ByVal folder As Outlook.Folder, ByVal fields As Object) As Collection
    Dim data As Object, body As String
    Set data = CreateObject("Scripting.Dictionary")
    ' Read only selected display fields. A private popup never reads the body.
    If rule("showSender") Then data.Add "sender", mail.SenderName & " <" & PA_CachedSender(mail, fields) & ">"
    If rule("showSubject") Then data.Add "subject", mail.Subject
    If rule("showTo") Then data.Add "to", mail.To
    If rule("showCc") Then data.Add "cc", mail.CC
    If rule("showFolder") Then data.Add "folder", folder.Store.DisplayName & " - " & folder.FolderPath
    If rule("showBody") Then
        On Error Resume Next
        body = mail.Body
        On Error GoTo 0
        data.Add "body", body
    End If
    Set PA_RenderMail = PT_AlertRender(rule, data)
End Function

' Show synthetic sample details using the current rule without watching or sending mail.
Public Sub PT_PreviewMailAlert(ByVal rule As Object)
    Dim data As Object, sample As Object
    Set sample = PT_CloneMailAlertRule(rule): sample("enabled") = False
    PT_ValidateMailAlertRule sample
    Set data = CreateObject("Scripting.Dictionary")
    data.Add "sender", "Example Sender <sender@example.invalid>": data.Add "subject", "Example email subject"
    data.Add "to", "me@example.invalid; team@example.invalid": data.Add "cc", "colleague@example.invalid"
    data.Add "folder", "Example mailbox - Inbox\Projects"
    data.Add "body", "This is the first example line." & vbCrLf & "This is the second example line." & vbCrLf & "A third example line."
    PA_ParkNotice True
    PA_ShowAlert PT_AlertRender(rule, data), CLng(rule("seconds")), CLng(rule("position")), CBool(rule("sound")), True, CBool(rule("manualDismiss"))
End Sub

' Attach selected folder and sync events, seed existing mail, and start the native popup timer.
Public Sub PT_AlertsStart(ByVal app As Outlook.Application, Optional ByVal requestedAt As Date = 0)
    Dim settings As Object, previousRoots As Object
    On Error GoTo Failed
    If alertRunning Then Exit Sub
    If PT_ReadSetting("NotifyMasterActive", "") = "0" Then Exit Sub
    Set settings = PT_LoadMailAlertSettings()
    If Not NotificationsActive(settings) Then Exit Sub
    Set alertApp = app: Set alertSettings = settings
    Set alertSeen = CreateObject("Scripting.Dictionary"): Set alertQueue = New Collection
    alertSince = requestedAt: If alertSince = 0 Then alertSince = Now
    checkedAt = Now: Set alertWatermarks = CreateObject("Scripting.Dictionary")
    Set alertChecked = CreateObject("Scripting.Dictionary"): Set previousRoots = CreateObject("Scripting.Dictionary")
    Set awayPeriods = New Collection: lastLockStart = 0: lastUnlock = 0
    AllocateWatchers
    AttachConfiguredLocations app, previousRoots, alertSince, previousRoots
    alertRunning = True: alertLastScan = Timer
    If watchQueue.Count > 0 Then
        alertSessionState = PA_ReadSessionState(): alertStateKnown = True
        If alertSessionState <> 1 Then lastLockStart = alertSince
        RequestOutlookWork 80
    End If
    PT_AlertLog "Alerts active. Selected locations will connect in short steps."
    Exit Sub
Failed:
    PT_AlertLog PT_ErrorText("Start email notifications", Err.Number, Err.Description, Err.Source, "modPersonalMailAlerts.PT_AlertsStart")
    PT_AlertsStop False
End Sub

Private Sub AllocateWatchers()
    Set alertFolders = CreateObject("Scripting.Dictionary"): Set alertTrees = CreateObject("Scripting.Dictionary")
    Set watchQueue = New Collection: Set watchPending = CreateObject("Scripting.Dictionary")
    Set watchRetry = CreateObject("Scripting.Dictionary"): Set excludedByStore = CreateObject("Scripting.Dictionary")
    Set rootDeepStarts = CreateObject("Scripting.Dictionary")
    Set pollRetryAfter = CreateObject("Scripting.Dictionary")
    Set pollEligible = CreateObject("Scripting.Dictionary"): Set pollTable = Nothing
    pollActive = False: pollWanted = False: pollKeys = Empty: pollBatch = Empty
    quietPolls = 0: pollHadWork = False
    nextRetryCheck = 0: lastPollStart = 0: watchLimitReported = False: syncIndex = 0
    Set alertRootStarts = CreateObject("Scripting.Dictionary")
    Set alertFloors = CreateObject("Scripting.Dictionary"): Set alertSinks = New Collection
End Sub

Private Sub AttachConfiguredLocations(ByVal app As Outlook.Application, ByVal previousRoots As Object, ByVal addedAt As Date, ByVal priorDeep As Object)
    Dim rule As Object, ref As Object, key As String, since As Date, branchStart As Date
    Set watchStoreIDs = CreateObject("Scripting.Dictionary"): watchStoreIDs.CompareMode = vbTextCompare
    For Each rule In alertSettings("rules")
        If rule("enabled") Then
            For Each ref In rule("roots")
                watchStoreIDs(CStr(ref("store"))) = True
                key = CStr(ref("store")) & "|" & CStr(ref("entry")): since = addedAt
                If previousRoots.Exists(key) Then since = CDate(previousRoots(key))
                alertRootStarts(key) = since
                branchStart = addedAt
                If CBool(ref("recursive")) Then
                    If priorDeep.Exists(key) Then branchStart = CDate(priorDeep(key))
                    rootDeepStarts(key) = branchStart
                End If
                QueueWatch CStr(ref("entry")), CStr(ref("store")), CBool(ref("recursive")), since, 0, branchStart
            Next ref
        End If
    Next rule
    If alertRootStarts.Count > 0 Then syncIndex = 1
End Sub



Private Sub RefreshActiveWatchers(ByVal app As Outlook.Application, ByVal recovering As Boolean)
    Dim previousRoots As Object, previousDeep As Object, settings As Object
    If Not alertRunning Then Exit Sub
    On Error GoTo Failed
    Set settings = PT_LoadMailAlertSettings()
    If SameWatchCoverage(alertSettings, settings) Then
        Set alertSettings = settings: alertChecked.RemoveAll
        PT_AlertLog "Saved notification rules applied."
        Exit Sub
    End If
    Set previousRoots = alertRootStarts: Set previousDeep = rootDeepStarts
    Set alertSettings = settings: AllocateWatchers
    AttachConfiguredLocations app, previousRoots, Now, previousDeep
    alertChecked.RemoveAll
    If watchQueue.Count Then RequestOutlookWork 80
    PT_AlertLog "Saved notification rules applied."
    Exit Sub
Failed:
    PT_AlertLog "Could not refresh notification setup. " & Err.Description
End Sub
' Stop the timer, close the current popup and release queued notices and watchers.
Public Sub PT_AlertsStop(ByVal unused As Boolean)
    alertRunning = False: alertScanning = False
    PA_CancelTimer
    quietPolls = 0: pollHadWork = False
    pollActive = False: pollWanted = False: pollBatch = Empty: pollKeys = Empty
    Set pollTable = Nothing: Set pollEligible = Nothing: Set pollRetryAfter = Nothing: syncIndex = 0
    Set watchPending = Nothing: Set watchRetry = Nothing: Set watchQueue = Nothing: Set excludedByStore = Nothing
    PA_CloseNotice
    Set alertQueue = Nothing: Set alertCurrent = Nothing: alertStateKnown = False
    Set alertSinks = Nothing: Set alertFolders = Nothing: Set alertTrees = Nothing
    Set alertSeen = Nothing: Set alertSettings = Nothing: Set alertApp = Nothing
    If Not WorkspaceClosing() Then
        If WorkspacePending() Then
            RequestOutlookWork 100
        ElseIf ResponseDelay() > 0 Then
            RequestOutlookWork ResponseDelay()
        End If
    End If
    Set watchStoreIDs = Nothing
    Set awayPeriods = Nothing
    Set alertWatermarks = Nothing: Set alertRootStarts = Nothing: Set rootDeepStarts = Nothing: Set alertFloors = Nothing: Set alertChecked = Nothing
End Sub

' Attach permitted physical folders once, including their child-folder events when requested.


' Attach a newly added child folder while retaining the current session's receive-time baseline.
Public Sub PT_AlertNewFolder(ByVal folder As Outlook.Folder)
    Dim parent As Outlook.Folder, key As String
    On Error GoTo Failed
    If Not alertRunning Then Exit Sub
    Set parent = folder.Parent: key = parent.StoreID & "|" & parent.EntryID
    If alertTrees.Exists(key) Then
        QueueWatch folder.EntryID, folder.StoreID, True, Now, 1
        RequestOutlookWork 80
    End If
    Exit Sub
Failed:
    PT_AlertLog "Could not queue a newly added notification folder. " & Err.Description
End Sub

' Accept arrivals since the monitoring baseline with a small allowance for future clock differences.
Public Function PT_AlertIsRecent(ByVal received As Date, ByVal since As Date, ByVal nowValue As Date) As Boolean
    PT_AlertIsRecent = (received >= since And received <= DateAdd("n", 5, nowValue))
End Function

' Exclude the store's Sent Items, Outbox and Drafts branches from received-mail notifications.


' Deduplicate an arrival within its store using Message-ID and the saved EntryID fallback.
Private Function PA_MessageKey(ByVal mail As Outlook.MailItem) As String
    Dim id As String, accessor As Outlook.PropertyAccessor
    Set accessor = mail.PropertyAccessor
    On Error Resume Next
    id = accessor.BinaryToString(accessor.GetProperty("http://schemas.microsoft.com/mapi/proptag/0x0FF90102"))
    On Error GoTo 0
    If Len(id) = 0 Then id = mail.EntryID ' Providers that omit PR_RECORD_KEY still expose the saved item's identifier.
    If Len(id) = 0 Then Err.Raise 5, , "The received message has no stable identifier."
    PA_MessageKey = mail.Parent.StoreID & "|" & id ' Separate physical deliveries can share an Internet Message-ID and must still notify separately.
End Function

' Queue one notice from the first matching rule after location, time and duplicate checks.
Public Sub PT_AlertArrived(ByVal item As Object)
    Dim mail As Outlook.MailItem, folder As Outlook.Folder, rule As Object, key As String, stepName As String, queued As Object, state As Long, started As Double
    On Error GoTo Failed
    If Not alertRunning Then Exit Sub
    If Not TypeOf item Is Outlook.MailItem Then Exit Sub
    started = Timer
    stepName = "Read message location": Set mail = item: Set folder = mail.Parent
    Dim location As String, checkedKey As String, received As Date, locationInfo As Object
    Set locationInfo = CreateObject("Scripting.Dictionary")
    locationInfo.Add "store", folder.StoreID: locationInfo.Add "entry", folder.EntryID
    location = CStr(locationInfo("store")) & "|" & CStr(locationInfo("entry"))
    If Not alertFolders.Exists(location) Then Exit Sub
    If Not pollEligible.Exists(location) Then Exit Sub
    If Not mail.Sent Then Exit Sub
    received = mail.ReceivedTime: checkedKey = location & "|" & mail.EntryID
    If alertChecked.Exists(checkedKey) Then Exit Sub
    If Not PT_AlertIsRecent(received, CDate(alertFloors(location)), Now) Then Exit Sub
    quietPolls = 0
    key = PA_MessageKey(mail)
    If alertSeen.Exists(key) Then GoTo Checked
    stepName = "Match notification filters"
    For Each rule In alertSettings("rules")
        If PT_AlertRuleMatches(rule, mail, folder, locationInfo) Then
            stepName = "Build selected popup details"
            If alertQueue Is Nothing Then Set alertQueue = New Collection
            Set queued = CreateObject("Scripting.Dictionary")
            queued.Add "seconds", CLng(rule("seconds")): queued.Add "position", CLng(rule("position")): queued.Add "sound", CBool(rule("sound"))
            state = PA_ReadSessionState()
            queued.Add "replayLocked", CBool(rule("replayLocked"))
            If SuppressAwayDelivery(CBool(rule("replayLocked")), state, received, lastLockStart, lastUnlock, awayPeriods) Then
                alertSeen(key) = Now
                PT_AlertLog "A matching notification was skipped while locked (replay is off)."
                GoTo Checked
            End If
            queued.Add "rows", PA_RenderMail(rule, mail, folder, locationInfo)
            queued.Add "manualDismiss", CBool(rule("manualDismiss"))
            queued.Add "received", received
            alertQueue.Add queued ' Retain every matching notification; there is no 30-message truncation.
            alertSeen(key) = Now ' Commit after all card fields and the queue insertion succeeded.
            PT_AlertLog "A matching email was queued."
            ' Display on the next UI tick, after the shared-store ItemAdd callback has returned.
            PA_EnsureTimer ' This also checks lock state, nested dialog blocks and active catch-up scans.
            GoTo Checked ' First matching rule wins, including its privacy choices.
        End If
    Next rule
Checked:
    ' Memoise this folder only. Moving a previously unmatched email to a new
    ' watched folder still checks its rules using a different key.
    alertChecked(checkedKey) = Now
    NoteWorkTime "Match a watched-folder notification", started
    Exit Sub
Failed:
    failedArrival = True
    PT_AlertLog PT_ErrorText("Incoming email | " & stepName, Err.Number, Err.Description, Err.Source, "modPersonalMailAlerts.PT_AlertArrived")
End Sub

' Resolve each NewMailEx entry and pass accessible items through the normal arrival checks.
Public Function HasNotificationWatch(Optional ByVal intoStores As Object = Nothing) As Boolean
    Dim store As Variant
    If Not alertRunning Or watchStoreIDs Is Nothing Then Exit Function
    HasNotificationWatch = (watchStoreIDs.Count > 0)
    If intoStores Is Nothing Then Exit Function
    For Each store In watchStoreIDs.Keys
        intoStores(CStr(store)) = True
    Next store
End Function

' Rescan watched folders from their last successful watermark with an overlap for event delivery delays.
Public Sub PT_AlertsCatchUp(ByVal reason As String)
    ' SyncEnd can fire repeatedly. It only requests work. Polling keeps its
    ' current table and watermark until that folder has finished successfully.
    If Not alertRunning Then Exit Sub
    If alertRootStarts.Count = 0 Then Exit Sub
    pollWanted = True
    If PollReady(Now) Then RequestOutlookWork 120
End Sub



' Seed current IDs or scan recent arrivals, reporting provider errors without advancing a failed watermark.


' Show the next queued popup after the previous one closes, including the burst overflow summary.
Private Sub PA_NextNotice(ByVal state As Long)
    Dim queued As Object
    If alertConfigOpen Or alertUIBlocks > 0 Or alertScanning Then Exit Sub
    If state <> 1 Then Exit Sub ' A locked or disconnected desktop must never consume the popup timeout.
    If Not alertNotice Is Nothing Then
        If Not noticeDismissed Then Exit Sub
        PA_CloseNotice
    End If
    If alertQueue Is Nothing Then Exit Sub
    If alertQueue.Count = 0 Or Now < retryCardAfter Then Exit Sub
    Set queued = alertQueue(1)
    Set alertCurrent = queued ' Keep a full copy of the visible notice so locking Windows cannot silently consume it.
    If PA_ShowAlert(queued("rows"), queued("seconds"), queued("position"), queued("sound"), False, CBool(queued("manualDismiss"))) Then alertQueue.Remove 1
End Sub
' Create a modeless popup and start timing its automatic dismissal.
Private Function PA_ShowAlert(ByVal detail As Collection, ByVal seconds As Long, ByVal position As Long, ByVal sound As Boolean, Optional ByVal preview As Boolean = False, Optional ByVal manualDismiss As Boolean = False) As Boolean
    Dim number As Long, description As String, origin As String
    On Error GoTo Failed
    noticeDismissed = False
    Set alertNotice = New frmPersonalOutlook
    alertNotice.PrepareTemporaryMailNotice detail, manualDismiss
    alertNotice.NoticeCorner = position
    alertShownAt = Timer: alertSeconds = seconds
    If manualDismiss Then alertSeconds = 0 ' Zero is the explicit no-timeout mode; the timer still handles locking and queued cards.
    PA_EnsureTimer ' A failed timer never leaves an undismissable temporary popup.
    If sound Then Beep
    If preview Then alertNotice.Show vbModal Else alertNotice.Show vbModeless
    PA_ShowAlert = True
    Exit Function
Failed:
    number = Err.Number: description = Err.Description: origin = Err.Source
    retryCardAfter = DateAdd("s", 10, Now)
    PA_CloseNotice
    PT_AlertLog PT_ErrorText("Show temporary email popup", number, description, origin, "modPersonalMailAlerts.PA_ShowAlert")
End Function

' Place the uniquely identified popup at the chosen corner of the primary work area.
Public Sub PT_PositionMailNotice(ByVal panel As frmPersonalOutlook, ByVal position As Long)
    Dim work As PA_RECT, rect As PA_RECT, x As Long, y As Long, title As String, process As Long
#If VBA7 Then
    Dim hwnd As LongPtr, style As LongPtr
#Else
    Dim hwnd As Long, style As Long
#End If
    title = "Personal Office Macros notification " & CStr(Timer)
    panel.Caption = title
    hwnd = FindWindowW(0, StrPtr(title))
    panel.Caption = ""
    If hwnd = 0 Then Exit Sub
    PA_WindowProcess hwnd, process
    If process <> PA_CurrentProcess() Then Exit Sub ' Only alter this VBA process's own uniquely named notification window.
    style = PA_GetWindowLongPtr(hwnd, -16)
    PA_SetWindowLongPtr hwnd, -16, style And Not (&HC00000 Or &H40000 Or &H80000) ' Remove caption, resizing frame and system menu from the card.
    style = PA_GetWindowLongPtr(hwnd, -20)
    PA_SetWindowLongPtr hwnd, -20, style And Not 1 ' Remove the dialog-frame decoration while preserving other extended styles.
    SetWindowPos hwnd, 0, 0, 0, 0, 0, &H1 Or &H2 Or &H4 Or &H10 Or &H20 ' Commit the frame change before measuring/positioning.
    If GetWindowRect(hwnd, rect) = 0 Or SystemParametersInfoW(48, 0, work, 0) = 0 Then Exit Sub
    x = work.right - (rect.right - rect.left) - 16
    y = work.bottom - (rect.bottom - rect.top) - 16
    If position = 1 Or position = 3 Then x = work.left + 16
    If position = 2 Or position = 3 Then y = work.top + 16
    If x < work.left Then x = work.left
    If y < work.top Then y = work.top
    SetWindowPos hwnd, -1, x, y, 0, 0, &H1 Or &H10 Or &H20 ' topmost, retain size, no activation
End Sub

' Hide and unload the current popup before releasing its form reference.
Private Sub PA_CloseNotice()
    On Error Resume Next
    If Not alertNotice Is Nothing Then Unload alertNotice
    Set alertNotice = Nothing: Set alertCurrent = Nothing
End Sub

' Cancel the registered Windows callback before entering code that can process more events.
Private Sub PA_CancelTimer()
    If alertTimer <> 0 Then KillTimer 0, alertTimer
    alertTimer = 0
End Sub

' Create one native timer when monitoring or an open preview needs further updates.
Private Sub PA_EnsureTimer()
    RequestOutlookWork 100
End Sub

' Measure seconds across Timer's midnight rollover.
Private Function PA_Elapsed(ByVal started As Double) As Double
    PA_Elapsed = CDbl(Timer) - started
    If PA_Elapsed < 0 Then PA_Elapsed = PA_Elapsed + 86400#
End Function

' Public callback has required arguments, so it does not appear in Alt+F8.
' Cancel first; never allow an error or reentrant callback to cross Windows.
#If VBA7 Then
' Cancel the callback first, process dismissal and catch-up work, then rearm only when needed.
Public Sub PT_MailAlertTimerProc(ByVal hwnd As LongPtr, ByVal message As Long, ByVal eventID As LongPtr, ByVal tick As Long)
#Else
' Cancel the callback first, process dismissal and catch-up work, then rearm only when needed.
Public Sub PT_MailAlertTimerProc(ByVal hwnd As Long, ByVal message As Long, ByVal eventID As Long, ByVal tick As Long)
#End If
    Dim state As Long, wasUnavailable As Boolean, watchWork As Boolean, stage As String, started As Double, delayMs As Long
    On Error GoTo Failed
    If timerBusy Or timerOff Or alertTimer = 0 Or eventID <> alertTimer Then Exit Sub
    timerBusy = True: PA_CancelTimer: started = Timer
    Dim observeLock As Boolean
    observeLock = Not alertNotice Is Nothing
    If alertRunning Then observeLock = observeLock Or (alertRootStarts.Count > 0)
    If observeLock Then
        state = PA_ReadSessionState()
        wasUnavailable = (alertStateKnown And alertSessionState <> 1)
        alertSessionState = state: alertStateKnown = True
        If state <> 1 Then
            If Not wasUnavailable Or lastLockStart = 0 Then
                lastLockStart = Now: PA_ParkNotice PA_ReplayEnabled(): FilterLockedQueue
            End If
        ElseIf wasUnavailable And alertRunning Then
            lastUnlock = Now
            If lastLockStart > 0 Then awayPeriods.Add Array(lastLockStart, lastUnlock)
            quietPolls = 0: pollWanted = True
        End If
        If Not alertNotice Is Nothing Then
            If noticeDismissed Then
                PA_CloseNotice
            ElseIf alertSeconds > 0 Then
                If PA_Elapsed(alertShownAt) >= alertSeconds Then PA_CloseNotice
            End If
        End If
        If Not alertConfigOpen Then PA_NextNotice state
    End If
    If Not alertConfigOpen And alertUIBlocks = 0 And Not ForegroundOperation() Then
        workspaceTurn = Not workspaceTurn: watchWork = AlertWorkReady()
        If WorkspacePending() And (workspaceTurn Or Not watchWork) Then
            stage = WorkspaceStep()
        ElseIf watchWork Then
            stage = AlertWorkStep()
        End If
    End If
    NoteWorkTime stage, started
    If logDirty And DateDiff("s", logWritten, Now) >= 10 Then FlushAlertLog
Finished:
    On Error Resume Next
    timerBusy = False: delayMs = NextWorkDelay()
    If delayMs > 0 Then RequestOutlookWork delayMs
    Exit Sub
Failed:
    PT_AlertLog PT_ErrorText("Scheduled Outlook update", Err.Number, Err.Description, Err.Source, "modPersonalMailAlerts.PT_MailAlertTimerProc")
    Resume Finished
End Sub

' Keep a bounded recent activity log without routine sender, subject or body text.
Public Sub PT_AlertLog(ByVal text As String)
    On Error Resume Next
    If Not logLoaded Then logBuffer = PT_ReadSetting("MailAlertLog", ""): logLoaded = True
    logBuffer = Left$(Format$(Now, "yyyy-mm-dd hh:nn:ss") & " " & text & vbCrLf & logBuffer, 16000)
    logDirty = True
    If logWritten = 0 Or DateDiff("s", logWritten, Now) >= 10 Then FlushAlertLog
End Sub

Private Sub FlushAlertLog()
    If Not logDirty Then Exit Sub
    PT_WriteSetting "MailAlertLog", logBuffer: logDirty = False: logWritten = Now
End Sub

' Read the current Windows session, using WTSINFOEX level 1 on supported Windows 10/11.
' The native union starts at byte 8; copy only the five DWORDs that contain level, session, state and flags.
' Return 1 only for an active, unlocked session. Hold notifications if Windows cannot supply a reliable answer.
Private Function PA_ReadSessionState() As Long
    Dim bytes As Long, header(0 To 4) As Long
#If VBA7 Then
    Dim buffer As LongPtr
#Else
    Dim buffer As Long
#End If
    On Error GoTo Finished
    PA_ReadSessionState = -1
    If WTSQuerySessionInformationW(0, -1, 25, buffer, bytes) = 0 Then GoTo Finished
    If buffer = 0 Or bytes < 20 Then GoTo Finished
    PA_CopyMemory header(0), buffer, 20 ' Never read more than the validated fixed header from the Windows allocation.
    PA_ReadSessionState = PA_DecodeSessionState(header(0), header(3), header(4))
Finished:
    If buffer <> 0 Then WTSFreeMemory buffer ' Always release the allocation owned by Windows, including on a failed decode.
End Function

' Keep decoding separate from the API call so unknown and disconnected states are explicit and reviewable.
Private Function PA_DecodeSessionState(ByVal level As Long, ByVal connection As Long, ByVal flags As Long) As Long
    PA_DecodeSessionState = -1
    If level <> 1 Then Exit Function
    If connection <> 0 Then PA_DecodeSessionState = 0: Exit Function ' WTSActive = 0; disconnected sessions cannot see a popup.
    If flags = 0 Or flags = 1 Then PA_DecodeSessionState = flags
End Function

' Default to retaining notifications if configuration has not yet been loaded.
Private Function PA_ReplayEnabled() As Boolean
    If Not alertCurrent Is Nothing Then PA_ReplayEnabled = CBool(alertCurrent("replayLocked"))
End Function

' Put an interrupted real notification back before unloading its form. Preview text is never queued.
Private Sub PA_ParkNotice(ByVal retain As Boolean)
    If Not alertCurrent Is Nothing And retain And Not noticeDismissed Then
        If alertQueue Is Nothing Then Set alertQueue = New Collection
        If alertQueue.Count = 0 Then alertQueue.Add alertCurrent Else alertQueue.Add alertCurrent, Before:=1
    End If
    PA_CloseNotice
End Sub

' These balanced calls are used around the attachment chooser and attachment saving, including nested workers.
Public Function DeferNotificationCards() As Boolean
    alertUIBlocks = alertUIBlocks + 1
    PA_ParkNotice True ' Prevent a modeless notification stealing focus while an Outlook dialog is active.
End Function

' Let the existing timer resume popups after returning to Outlook; do not show a form inside an email save/send event.
Public Function ReleaseNotificationCards() As Boolean
    If alertUIBlocks > 0 Then alertUIBlocks = alertUIBlocks - 1
End Function


Private Function NotificationsActive(ByVal settings As Object) As Boolean
    ' Read the old master switch only until the user first uses the new toggle.
    NotificationsActive = (PT_ReadSetting("NotifyMasterActive", IIf(settings("enabled"), "1", "0")) = "1")
End Function

Public Sub Settings_AlertsToggle()
    Dim active As Boolean
    On Error GoTo Failed
    active = Not NotificationsActive(PT_LoadMailAlertSettings())
    If active Then
        PT_WriteSetting "NotifyMasterActive", "1"
        PT_AlertsStart PA_App()
        If Not alertRunning Then
            PT_WriteSetting "NotifyMasterActive", "0"
            MsgBox "Alerts could not start. Open today's status log for the folder or connection that needs attention.", vbInformation, "Email alerts"
            Exit Sub
        End If
    Else
        PT_WriteSetting "NotifyMasterActive", "0"
        PT_AlertsStop False
    End If
    PT_AlertLog IIf(active, "Alerts now active", "Alerts now paused")
    MsgBox IIf(active, "Alerts now active", "Alerts now paused"), vbInformation, "Email alerts"
    Exit Sub
Failed:
    MsgBox Err.Description, vbExclamation, "Email alerts"
End Sub

Private Function TodayAlertLog() As String
    Dim raw As String, rows As Variant, row As Variant, keep As Boolean, day As String
    day = Format$(Date, "yyyy-mm-dd")
    If logLoaded Then raw = logBuffer Else raw = PT_ReadSetting("MailAlertLog", "")
    rows = Split(raw, vbCrLf)
    For Each row In rows
        If CStr(row) Like "####-##-## ##:##:##*" Then keep = (Left$(CStr(row), 10) = day)
        If keep Then TodayAlertLog = TodayAlertLog & row & vbCrLf
    Next row
    If Len(TodayAlertLog) = 0 Then TodayAlertLog = "No activity recorded today."
End Function

Public Sub DismissNotification(ByVal panel As frmPersonalOutlook)
    ' The timer owns the form. A button may hide it, but cannot unload its COM server mid-tick.
    noticeDismissed = True
    panel.Hide
End Sub

Private Sub FilterLockedQueue()
    Dim i As Long, queued As Object
    If alertQueue Is Nothing Then Exit Sub
    For i = alertQueue.Count To 1 Step -1
        Set queued = alertQueue(i)
        If Not CBool(queued("replayLocked")) Then alertQueue.Remove i
    Next i
End Sub


Public Sub FitToolWindow(ByVal panel As frmPersonalOutlook)
    Dim area As PA_RECT, dpi As Long, maxW As Single, maxH As Single, insideW As Single, insideH As Single
#If VBA7 Then
    Dim dc As LongPtr
#Else
    Dim dc As Long
#End If
    On Error Resume Next
    If SystemParametersInfoW(48, 0, area, 0) = 0 Then Exit Sub
    dc = DeskDC(0): If dc = 0 Then Exit Sub
    dpi = DeskCaps(dc, 88): FreeDeskDC 0, dc
    If dpi <= 0 Then Exit Sub
    maxW = (area.right - area.left) * 72! / dpi - 12
    maxH = (area.bottom - area.top) * 72! / dpi - 14
    If panel.Width <= maxW And panel.Height <= maxH Then Exit Sub
    insideW = panel.InsideWidth: insideH = panel.InsideHeight
    panel.ScrollBars = fmScrollBarsBoth: panel.KeepScrollBarsVisible = fmScrollBarsNone
    If panel.Width > maxW Then panel.Width = maxW
    If panel.Height > maxH Then panel.Height = maxH
    panel.ScrollWidth = insideW + 5: panel.ScrollHeight = insideH + 5
End Sub


Private Function SkipAwayCard(ByVal replay As Boolean, ByVal state As Long, ByVal received As Date, ByVal lockedAt As Date, ByVal unlockedAt As Date) As Boolean
    ' A shared mailbox may supply the message in the catch-up scan after unlock.
    ' Use its delivery timestamp to honour the same per-rule choice in both paths.
    SkipAwayCard = Not replay And (state <> 1 Or (lockedAt > 0 And received >= lockedAt And received <= unlockedAt))
End Function


Private Function AlertScanSince(ByVal lastSuccess As Date, ByVal locationStart As Date) As Date
    ' Two-minute overlap tolerates delivery timing differences. A newly selected
    ' folder must never show mail received before its monitoring began.
    AlertScanSince = DateAdd("n", -2, lastSuccess)
    If AlertScanSince < locationStart Then AlertScanSince = locationStart
End Function


Private Function SuppressAwayDelivery(ByVal replay As Boolean, ByVal state As Long, ByVal received As Date, ByVal lockedAt As Date, ByVal unlockedAt As Date, ByVal periods As Collection) As Boolean
    Dim interval As Variant
    If replay Then Exit Function
    If SkipAwayCard(False, state, received, lockedAt, unlockedAt) Then SuppressAwayDelivery = True: Exit Function
    If lockedAt > unlockedAt And received >= lockedAt Then SuppressAwayDelivery = True: Exit Function
    For Each interval In periods
        If received >= CDate(interval(0)) And received <= CDate(interval(1)) Then SuppressAwayDelivery = True: Exit Function
    Next interval
End Function


Private Sub QueueWatch(ByVal entry As String, ByVal store As String, ByVal deep As Boolean, ByVal since As Date, ByVal depth As Long, Optional ByVal branchStart As Date = 0)
    Dim key As String, job As Object
    If branchStart = 0 Then branchStart = since
    key = store & "|" & entry
    If watchPending.Exists(key) Then
        Set job = watchPending(key)
        If since < CDate(job("since")) Then job("since") = since
        If deep Then
            If Not CBool(job("deep")) Or branchStart < CDate(job("treeSince")) Then
                job("treeSince") = branchStart
                If CLng(job("nextChild")) > 1 Then job("nextChild") = 1
                If alertTrees.Exists(key) Then alertTrees(key) = branchStart
            End If
            job("deep") = True
        End If
        If depth < CLng(job("depth")) Then job("depth") = depth
        Exit Sub
    End If
    If alertFolders.Exists(key) Then
        If CDate(alertFloors(key)) <= since Then
            If Not deep Then Exit Sub
            If alertTrees.Exists(key) Then
                If CDate(alertTrees(key)) <= branchStart Then Exit Sub
            End If
        End If
    End If
    Set job = CreateObject("Scripting.Dictionary")
    job.Add "entry", entry: job.Add "store", store: job.Add "deep", deep: job.Add "since", since: job.Add "depth", depth
    job.Add "treeSince", branchStart
    job.Add "nextChild", 0&: job.Add "attempt", 0&
    watchPending.Add key, job: watchQueue.Add key
End Sub

Private Function IncomingWatchBranch(ByVal folder As Outlook.Folder, ByVal knownParent As Boolean) As Boolean
    Dim store As Outlook.Store, skip As Object, kind As Variant, other As Outlook.Folder, current As Outlook.Folder
    Set store = folder.Store
    If Not excludedByStore.Exists(store.StoreID) Then
        Set skip = CreateObject("Scripting.Dictionary")
        For Each kind In Array(olFolderSentMail, olFolderOutbox, olFolderDrafts)
            Set other = Nothing
            On Error Resume Next
            Set other = store.GetDefaultFolder(CLng(kind))
            On Error GoTo 0
            If Not other Is Nothing Then skip(other.EntryID) = True
        Next kind
        excludedByStore.Add store.StoreID, skip
    End If
    Set skip = excludedByStore(store.StoreID): Set current = folder
    Do
        If skip.Exists(current.EntryID) Then Exit Function
        If knownParent Then Exit Do
        If Not TypeOf current.Parent Is Outlook.Folder Then Exit Do
        Set current = current.Parent
    Loop
    IncomingWatchBranch = True
End Function

Private Sub ParkWatch(ByVal key As String, ByVal job As Object, ByVal detail As String)
    Dim delay As Long
    If watchPending.Exists(key) Then watchPending.Remove key
    If alertFolders.Exists(key) Then
        alertFolders.Remove key
        On Error Resume Next: alertSinks.Remove key: On Error GoTo 0
    End If
    If pollEligible.Exists(key) Then pollEligible.Remove key
    If alertTrees.Exists(key) Then alertTrees.Remove key
    If job.Exists("endChild") Then job.Remove "endChild"
    job("nextChild") = 0
    If job.Exists("children") Then job.Remove "children"
    job("attempt") = CLng(job("attempt")) + 1
    delay = 60 * CLng(job("attempt")): If delay > 300 Then delay = 300
    job("retry") = DateAdd("s", delay, Now)
    Set watchRetry(key) = job
    If nextRetryCheck = 0 Or CDate(job("retry")) < nextRetryCheck Then nextRetryCheck = CDate(job("retry"))
    If CLng(job("attempt")) = 1 Then PT_AlertLog "A watched folder is unavailable. It will retry separately. " & detail
End Sub

Private Sub RetryWatches()
    Dim key As Variant, job As Object, due As Date
    If nextRetryCheck = 0 Or Now < nextRetryCheck Then Exit Sub
    nextRetryCheck = 0
    For Each key In watchRetry.Keys
        Set job = watchRetry(key): due = CDate(job("retry"))
        If due <= Now Then
            watchRetry.Remove key
            If Not watchPending.Exists(key) Then watchPending.Add key, job: watchQueue.Add key
        ElseIf nextRetryCheck = 0 Or due < nextRetryCheck Then
            nextRetryCheck = due
        End If
    Next key
End Sub

Private Sub WatchFolderSlice()
    Dim key As String, job As Object, folder As Outlook.Folder, child As Outlook.Folder, children As Outlook.Folders
    Dim kind As Long, since As Date, n As Long, i As Long, sink As clsPersonalFolderWatcher, started As Double
    On Error GoTo Failed
    key = CStr(watchQueue(1)): watchQueue.Remove 1
    Set job = watchPending(key): since = CDate(job("since"))
    If CLng(job("nextChild")) = 0 Then
        Set folder = PA_App().Session.GetFolderFromID(CStr(job("entry")), CStr(job("store")))
        kind = PT_FolderKind(folder): If kind = 2 Then GoTo Done
        If Not IncomingWatchBranch(folder, CLng(job("depth")) > 0) Then GoTo Done
        If Not alertFolders.Exists(key) Then
            If alertFolders.Count >= 1000 Then
                If Not watchLimitReported Then PT_AlertLog "The 1,000 watched-folder limit was reached. Select narrower notification locations."
                watchLimitReported = True: GoTo Done
            End If
            Set sink = New clsPersonalFolderWatcher
            sink.WatchFolder folder, CBool(job("deep"))
            alertSinks.Add sink, key: alertFolders.Add key, folder
            If Not alertWatermarks.Exists(key) Then alertWatermarks(key) = since
            alertFloors(key) = since
        Else
            If since < CDate(alertFloors(key)) Then alertFloors(key) = since
            If CBool(job("deep")) Then alertSinks(key).WatchChildren folder
        End If
        If kind = 1 And folder.DefaultItemType = olMailItem Then
            pollEligible(key) = True: quietPolls = 0: pollWanted = True
        End If
        If Not CBool(job("deep")) Then GoTo Done
        alertTrees(key) = CDate(job("treeSince"))
        Set children = folder.Folders: job.Add "children", children
        job.Add "endChild", children.Count: job("nextChild") = 1
    End If
    Set children = job("children"): started = Timer
    For n = 1 To 8
        i = CLng(job("nextChild"))
        If i > CLng(job("endChild")) Then GoTo Done
        Set child = children.Item(i)
        QueueWatch child.EntryID, CStr(job("store")), True, CDate(job("treeSince")), CLng(job("depth")) + 1
        job("nextChild") = i + 1
        If SliceExpired(started) Then Exit For
    Next n
    watchQueue.Add key: Exit Sub
Done:
    watchPending.Remove key
    Exit Sub
Failed:
    Dim detail As String
    detail = Err.Description
    If Not job Is Nothing Then
        If job.Exists("endChild") Then job.Remove "endChild"
        ParkWatch key, job, detail
    End If
End Sub

Private Sub PollStep()
    Dim key As String, ids As Variant, folder As Outlook.Folder, since As Date, size As Long
    Dim job As Object, deep As Boolean, detail As String
    On Error GoTo Failed
    If Not pollActive Then
        pollWanted = False: pollHadWork = False: lastPollStart = Now
        If pollEligible.Count = 0 Then Exit Sub
        pollKeys = pollEligible.Keys: pollIndex = 0: pollActive = True
        If DateDiff("n", checkedAt, Now) >= 5 Then alertChecked.RemoveAll: checkedAt = Now
    End If
    key = CStr(pollKeys(pollIndex))
    If Not pollEligible.Exists(key) Then GoTo Advance
    If pollRetryAfter.Exists(key) Then
        pollHadWork = True
        If Now < CDate(pollRetryAfter(key)) Then GoTo Advance
    End If
    ids = Split(key, "|")
    If pollTable Is Nothing Then
        Set folder = PA_App().Session.GetFolderFromID(CStr(ids(1)), CStr(ids(0)))
        pollStamp = Now: since = AlertScanSince(CDate(alertWatermarks(key)), CDate(alertFloors(key)))
        Set pollTable = OpenAlertTable(folder, since)
        pollRow = 0: pollLast = -1: pollMissed = False
        pollStore = CStr(ids(0)): pollPrefix = key & "|"
        Exit Sub
    End If
    If Not ReadAlertRows(pollTable, pollStore, pollPrefix, pollBatch, pollRow, pollLast, pollMissed) Then Exit Sub
    If pollMissed Then
        If Not pollRetryAfter.Exists(key) Then PT_AlertLog "A watched folder has an unreadable message. Other mail will still be checked."
        pollRetryAfter(key) = DateAdd("s", 60, Now): GoTo Advance
    End If
    If pollRetryAfter.Exists(key) Then pollRetryAfter.Remove key
    alertWatermarks(key) = pollStamp
Advance:
    Set pollTable = Nothing: pollBatch = Empty: pollIndex = pollIndex + 1
    If pollIndex > UBound(pollKeys) Then
        pollActive = False: pollKeys = Empty: alertLastScan = Timer
        If pollHadWork Then
            quietPolls = 0
        ElseIf quietPolls < 4 Then
            quietPolls = quietPolls + 1
        End If
    End If
    Exit Sub
Failed:
    detail = Err.Description: pollHadWork = True
    If Len(key) And Not watchPending.Exists(key) Then
        If alertFloors.Exists(key) Then
            deep = alertTrees.Exists(key): ids = Split(key, "|")
            Set job = CreateObject("Scripting.Dictionary")
            job.Add "entry", CStr(ids(1)): job.Add "store", CStr(ids(0)): job.Add "deep", deep
            job.Add "since", CDate(alertFloors(key)): job.Add "depth", 0&: job.Add "attempt", 0&
            job.Add "treeSince", CDate(alertFloors(key))
            If deep Then job("treeSince") = CDate(alertTrees(key))
            ParkWatch key, job, detail
        End If
    End If
    If pollActive Then Resume Advance
End Sub

Private Function OpenAlertTable(ByVal folder As Outlook.Folder, ByVal since As Date) As Outlook.Table
    Dim table As Outlook.Table, filter As String
    filter = "[ReceivedTime] >= '" & Format$(since, "ddddd h:nn AMPM") & "'"
    Set table = folder.GetTable(filter, olUserItems)
    table.Columns.RemoveAll: table.Columns.Add "EntryID"
    Set OpenAlertTable = table
End Function

Private Function ReadAlertRows(ByVal table As Outlook.Table, ByVal store As String, ByVal prefix As String, ByRef records As Variant, ByRef row As Long, ByRef lastRow As Long, ByRef missed As Boolean) As Boolean
    Dim number As Long, detail As String
    Dim entry As String, key As String, item As Object, session As Outlook.NameSpace, started As Double
    If row > lastRow Then
        If table.EndOfTable Then ReadAlertRows = True: Exit Function
        records = table.GetArray(16): row = 0: lastRow = TableBatchLastRow(records)
        If lastRow < 0 Then
            If Not table.EndOfTable Then Err.Raise 5, , "The watched folder returned an incomplete message table."
            ReadAlertRows = True: Exit Function
        End If
    End If
    started = Timer: Set session = PA_App().Session
    Do While row <= lastRow
        entry = CStr(records(0, row)): key = prefix & entry
        If Not alertChecked.Exists(key) Then
            pollHadWork = True
            Set item = Nothing
            On Error Resume Next
            Err.Clear: Set item = session.GetItemFromID(entry, store)
            number = Err.Number: detail = Err.Description
            On Error GoTo 0
            If number = &H8004010F Then
                ' The row moved or disappeared after the table was opened.
                ' A later pass or delivery event can still find it at its new location.
            ElseIf number = &H80010007 Or number = &H80010108 Or number = &H800706BA Or number = &H80040115 Then
                Err.Raise number, "Read watched folder", detail
            ElseIf number <> 0 Or item Is Nothing Then
                missed = True
            Else
                failedArrival = False: PT_AlertArrived item
                If failedArrival Then missed = True Else alertChecked(key) = Now
            End If
        End If
        row = row + 1
        If SliceExpired(started) Then Exit Do
    Loop
    If row > lastRow Then ReadAlertRows = table.EndOfTable
End Function


Public Sub RequestOutlookWork(ByVal delayMs As Long)
    Dim remaining As Double
    If timerOff Or timerBusy Or WorkspaceClosing() Then Exit Sub
    If alertTimer <> 0 Then
        remaining = timerDelay - 1000# * PA_Elapsed(timerStart)
        If remaining <= delayMs Then Exit Sub
        PA_CancelTimer
    End If
    timerStart = Timer: timerDelay = delayMs
    alertTimer = SetTimer(0, 0, delayMs, AddressOf PT_MailAlertTimerProc)
    If alertTimer = 0 Then Err.Raise 5, , "Windows could not schedule the next Outlook update."
End Sub

Public Sub StopOutlookWork(ByVal closing As Boolean)
    timerOff = closing: PA_CancelTimer
    On Error Resume Next: FlushAlertLog
End Sub

Private Function PollReady(ByVal instant As Date) As Boolean
    If pollActive Then PollReady = True: Exit Function
    If pollEligible.Count = 0 Then Exit Function
    If lastPollStart = 0 Then PollReady = True: Exit Function
    ' Keep ItemAdd immediate. Only fallback scans slow down after consecutive
    ' empty passes. An explicit unlock or a new scope resets the shorter wait.
    Dim seconds As Long
    If pollWanted Then seconds = 15 * (1 + quietPolls) Else seconds = 60 * (1 + quietPolls)
    PollReady = (PA_Elapsed(alertLastScan) >= seconds)
End Function

Private Function AlertWorkReady() As Boolean
    If Not alertRunning Then Exit Function
    RetryWatches
    AlertWorkReady = (watchQueue.Count > 0 Or syncIndex > 0 Or PollReady(Now))
End Function

Private Function AlertWorkStep() As String
    Dim sink As clsPersonalFolderWatcher, syncs As Outlook.SyncObjects
    If syncIndex > 0 Then
        On Error GoTo SyncUnavailable
        Set syncs = PA_App().Session.SyncObjects
        If syncIndex <= syncs.Count Then
            Set sink = New clsPersonalFolderWatcher: sink.WatchSync syncs.Item(syncIndex): alertSinks.Add sink
            syncIndex = syncIndex + 1
        Else
            syncIndex = 0
        End If
        AlertWorkStep = "Connect send/receive events": Exit Function
    End If
    pollTurn = Not pollTurn
    If watchQueue.Count And (pollTurn Or Not PollReady(Now)) Then
        AlertWorkStep = "Connect watched folder": WatchFolderSlice
    ElseIf PollReady(Now) Then
        AlertWorkStep = "Read watched-folder batch": PollStep
    End If
    Exit Function
SyncUnavailable:
    syncIndex = 0 ' A provider without SyncObjects still has ItemAdd and timed catch-up.
End Function

Public Sub NoteWorkTime(ByVal stage As String, ByVal started As Double)
    Dim elapsed As Double, text As String
    On Error Resume Next ' Optional timing must never interrupt delivery or a scheduled action.
    If Len(stage) = 0 Or stage = "Choose sent follow-up" Then Exit Sub
    elapsed = PA_Elapsed(started)
    If elapsed < 0.75 Then Exit Sub
    If lastSlowLabel = stage And DateDiff("s", lastSlowAt, Now) < 60 Then Exit Sub
    lastSlowLabel = stage: lastSlowAt = Now
    text = stage & " took " & Format$(elapsed, "0.0") & " seconds at " & Format$(Now, "dd/mm/yyyy hh:nn:ss")
    PT_WriteSetting "LastSlowOutlookStep", Format$(Date, "yyyy-mm-dd") & "|" & text
End Sub

Private Function NextWorkDelay() As Long
    If timerOff Or WorkspaceClosing() Then Exit Function
    If Not alertConfigOpen And alertUIBlocks = 0 And Not ForegroundOperation() Then
        If (WorkspacePending() And Not WaitingForFirstWindow()) Or AlertWorkReady() Then NextWorkDelay = 80: Exit Function
    End If
    If Not alertNotice Is Nothing Then NextWorkDelay = 350: Exit Function
    If Not alertQueue Is Nothing Then
        If alertQueue.Count > 0 Then NextWorkDelay = 500: Exit Function
    End If
    If WorkspacePending() Then NextWorkDelay = 1000: Exit Function
    If alertRunning Then
        If alertRootStarts.Count > 0 Then NextWorkDelay = 2000
    End If
    Dim due As Long
    due = ResponseDelay()
    If due > 0 Then
        If NextWorkDelay = 0 Or due < NextWorkDelay Then NextWorkDelay = due
    End If
End Function


Private Function ConfiguredWatchRoots(ByVal settings As Object) As Object
    Dim roots As Object, rule As Object, ref As Object, key As String
    Set roots = CreateObject("Scripting.Dictionary")
    For Each rule In settings("rules")
        If CBool(rule("enabled")) Then
            For Each ref In rule("roots")
                key = CStr(ref("store")) & "|" & CStr(ref("entry"))
                If Not roots.Exists(key) Then roots.Add key, False
                If CBool(ref("recursive")) Then roots(key) = True
            Next ref
        End If
    Next rule
    Set ConfiguredWatchRoots = roots
End Function

Private Function SameWatchCoverage(ByVal oldSettings As Object, ByVal newSettings As Object) As Boolean
    Dim oldRoots As Object, newRoots As Object, key As Variant
    Set oldRoots = ConfiguredWatchRoots(oldSettings): Set newRoots = ConfiguredWatchRoots(newSettings)
    If oldRoots.Count <> newRoots.Count Then Exit Function
    For Each key In oldRoots.Keys
        If Not newRoots.Exists(key) Then Exit Function
        If CBool(oldRoots(key)) <> CBool(newRoots(key)) Then Exit Function
    Next key
    SameWatchCoverage = True
End Function

Public Function ResponseWindowReady() As Boolean
    If PA_ReadSessionState() = 1 Then ResponseWindowReady = ResponseWindowActive()
End Function

Private Function PA_CachedSender(ByVal mail As Outlook.MailItem, ByVal fields As Object) As String
    If Not fields.Exists("smtp") Then fields.Add "smtp", PA_SenderAddress(mail)
    PA_CachedSender = CStr(fields("smtp"))
End Function

Private Function PA_RecipientSmtp(ByVal recipient As Outlook.Recipient) As String
    Dim value As String
    ' Most stored messages already carry an SMTP address on the recipient row.
    ' Consult the address book only when the transport did not save one there.
    On Error Resume Next
    value = CStr(recipient.PropertyAccessor.GetProperty("http://schemas.microsoft.com/mapi/proptag/0x39FE001E"))
    If Len(value) = 0 Then value = CStr(recipient.PropertyAccessor.GetProperty("http://schemas.microsoft.com/mapi/proptag/0x39FE001F"))
    On Error GoTo 0
    If Len(value) = 0 Then value = PA_Address(recipient.AddressEntry)
    PA_RecipientSmtp = value
End Function
