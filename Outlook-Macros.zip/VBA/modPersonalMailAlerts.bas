Attribute VB_Name = "modPersonalMailAlerts"
' PERSONAL OFFICE MACROS - lock-aware email notifications, 25 November 2026
' Paste into STANDARD MODULE modPersonalMailAlerts. Replace the whole older block.
' Requires frmPersonalOutlook, clsPersonalFolderWatcher and the session hooks.
' Pause with Settings_AlertsToggle and close previews before editing a running notification timer.
Option Explicit
#If VBA7 Then
Private Declare PtrSafe Function SetTimer Lib "user32" (ByVal hwnd As LongPtr, ByVal eventID As LongPtr, ByVal milliseconds As Long, ByVal callback As LongPtr) As LongPtr
Private Declare PtrSafe Function KillTimer Lib "user32" (ByVal hwnd As LongPtr, ByVal eventID As LongPtr) As Long
Private Declare PtrSafe Function FindWindowW Lib "user32" (ByVal className As LongPtr, ByVal caption As LongPtr) As LongPtr
Private Declare PtrSafe Function SetWindowPos Lib "user32" (ByVal hwnd As LongPtr, ByVal after As LongPtr, ByVal x As Long, ByVal y As Long, ByVal cx As Long, ByVal cy As Long, ByVal flags As Long) As Long
Private Declare PtrSafe Function GetWindowRect Lib "user32" (ByVal hwnd As LongPtr, ByRef rect As PA_RECT) As Long
Private Declare PtrSafe Function SystemParametersInfoW Lib "user32" (ByVal action As Long, ByVal param As Long, ByRef rect As PA_RECT, ByVal flags As Long) As Long
Private Declare PtrSafe Function WTSQuerySessionInformationW Lib "wtsapi32" (ByVal server As LongPtr, ByVal session As Long, ByVal info As Long, ByRef buffer As LongPtr, ByRef bytes As Long) As Long
Private Declare PtrSafe Sub WTSFreeMemory Lib "wtsapi32" (ByVal buffer As LongPtr)
Private Declare PtrSafe Sub PA_CopyMemory Lib "kernel32" Alias "RtlMoveMemory" (ByRef destination As Any, ByVal source As LongPtr, ByVal bytes As LongPtr)
Private alertTimer As LongPtr
#Else
Private Declare Function SetTimer Lib "user32" (ByVal hwnd As Long, ByVal eventID As Long, ByVal milliseconds As Long, ByVal callback As Long) As Long
Private Declare Function KillTimer Lib "user32" (ByVal hwnd As Long, ByVal eventID As Long) As Long
Private Declare Function FindWindowW Lib "user32" (ByVal className As Long, ByVal caption As Long) As Long
Private Declare Function SetWindowPos Lib "user32" (ByVal hwnd As Long, ByVal after As Long, ByVal x As Long, ByVal y As Long, ByVal cx As Long, ByVal cy As Long, ByVal flags As Long) As Long
Private Declare Function GetWindowRect Lib "user32" (ByVal hwnd As Long, ByRef rect As PA_RECT) As Long
Private Declare Function SystemParametersInfoW Lib "user32" (ByVal action As Long, ByVal param As Long, ByRef rect As PA_RECT, ByVal flags As Long) As Long
Private Declare Function WTSQuerySessionInformationW Lib "wtsapi32" (ByVal server As Long, ByVal session As Long, ByVal info As Long, ByRef buffer As Long, ByRef bytes As Long) As Long
Private Declare Sub WTSFreeMemory Lib "wtsapi32" (ByVal buffer As Long)
Private Declare Sub PA_CopyMemory Lib "kernel32" Alias "RtlMoveMemory" (ByRef destination As Any, ByVal source As Long, ByVal bytes As Long)
Private alertTimer As Long
#End If
' Window styles use pointer-sized APIs on 64-bit Office; the 32-bit aliases use the matching Windows entry points.
#If VBA7 Then
    #If Win64 Then
Private Declare PtrSafe Function PA_GetWindowLongPtr Lib "user32" Alias "GetWindowLongPtrW" (ByVal hwnd As LongPtr, ByVal index As Long) As LongPtr
Private Declare PtrSafe Function PA_SetWindowLongPtr Lib "user32" Alias "SetWindowLongPtrW" (ByVal hwnd As LongPtr, ByVal index As Long, ByVal value As LongPtr) As LongPtr
    #Else
Private Declare PtrSafe Function PA_GetWindowLongPtr Lib "user32" Alias "GetWindowLongW" (ByVal hwnd As LongPtr, ByVal index As Long) As LongPtr
Private Declare PtrSafe Function PA_SetWindowLongPtr Lib "user32" Alias "SetWindowLongW" (ByVal hwnd As LongPtr, ByVal index As Long, ByVal value As LongPtr) As LongPtr
    #End If
Private Declare PtrSafe Function PA_WindowProcess Lib "user32" Alias "GetWindowThreadProcessId" (ByVal hwnd As LongPtr, ByRef process As Long) As Long
Private Declare PtrSafe Function PA_CurrentProcess Lib "kernel32" Alias "GetCurrentProcessId" () As Long
#Else
Private Declare Function PA_GetWindowLongPtr Lib "user32" Alias "GetWindowLongW" (ByVal hwnd As Long, ByVal index As Long) As Long
Private Declare Function PA_SetWindowLongPtr Lib "user32" Alias "SetWindowLongW" (ByVal hwnd As Long, ByVal index As Long, ByVal value As Long) As Long
Private Declare Function PA_WindowProcess Lib "user32" Alias "GetWindowThreadProcessId" (ByVal hwnd As Long, ByRef process As Long) As Long
Private Declare Function PA_CurrentProcess Lib "kernel32" Alias "GetCurrentProcessId" () As Long
#End If

#If VBA7 Then
Private Declare PtrSafe Function DeskDC Lib "user32" Alias "GetDC" (ByVal hwnd As LongPtr) As LongPtr
Private Declare PtrSafe Function FreeDeskDC Lib "user32" Alias "ReleaseDC" (ByVal hwnd As LongPtr, ByVal hdc As LongPtr) As Long
Private Declare PtrSafe Function DeskCaps Lib "gdi32" Alias "GetDeviceCaps" (ByVal hdc As LongPtr, ByVal cap As Long) As Long
#Else
Private Declare Function DeskDC Lib "user32" Alias "GetDC" (ByVal hwnd As Long) As Long
Private Declare Function FreeDeskDC Lib "user32" Alias "ReleaseDC" (ByVal hwnd As Long, ByVal hdc As Long) As Long
Private Declare Function DeskCaps Lib "gdi32" Alias "GetDeviceCaps" (ByVal hdc As Long, ByVal cap As Long) As Long
#End If
Private Type PA_RECT
    left As Long
    top As Long
    right As Long
    bottom As Long
End Type
Private failedArrival As Boolean
Private retryCardAfter As Date
Private noticeDismissed As Boolean
Private awayPeriods As Collection
Private lastLockStart As Date
Private lastUnlock As Date
Private alertRebindDue As Boolean
Private lastRebindAt As Date
Private alertApp As Outlook.Application
Private alertSettings As Object
Private alertFolders As Object
Private alertTrees As Object
Private alertSeen As Object
Private alertWatermarks As Object
Private alertRootStarts As Object
Private alertFloors As Object
Private alertChecked As Object
Private checkedAt As Date
Private alertSinks As Collection
Private alertSince As Date
Private alertRunning As Boolean
Private alertScanning As Boolean
Private alertConfigOpen As Boolean
Private alertQueue As Collection
Private alertNotice As frmPersonalOutlook
Private alertShownAt As Double
Private alertSeconds As Long
Private alertLastScan As Double
Private alertCurrent As Object ' Retain the full visible notification so a lock can put it back at the front.
Private alertUIBlocks As Long ' Nested attachment operations defer popups until all their dialogs have closed.
Private alertSessionState As Long ' 1 = unlocked/active; 0 = locked/disconnected; -1 = unavailable.
Private alertStateKnown As Boolean

' Return the running Outlook application used by the notification module.
Private Function PA_App() As Outlook.Application
    Set PA_App = Application
End Function

' Create an enabled rule in the editor while the global notification configuration starts disabled.
Public Function PT_NewMailAlertRule() As Object
    Dim r As Object, roots As New Collection
    Set r = CreateObject("Scripting.Dictionary")
    r.Add "name", "New notification": r.Add "enabled", True: r.Add "roots", roots
    r.Add "sender", "": r.Add "senderMode", 0: r.Add "subject", "": r.Add "subjectMode", 0
    r.Add "to", "": r.Add "cc", "": r.Add "recipientMode", 0
    r.Add "personal", "": r.Add "groups", ""
    r.Add "replayLocked", True: r.Add "toMode", 0: r.Add "ccMode", 0
    r.Add "headingText", "": r.Add "manualDismiss", False
    r.Add "heading", True: r.Add "showSender", True: r.Add "showSubject", True
    r.Add "showBody", False: r.Add "showFolder", False: r.Add "showTo", False: r.Add "showCc", False
    r.Add "bodyLines", 2: r.Add "seconds", 8: r.Add "position", 0: r.Add "sound", False
    Set PT_NewMailAlertRule = r
End Function

' Create the global notification configuration and an empty ordered rule list.
Public Function PT_NewMailAlertSettings() As Object
    Dim s As Object, rules As New Collection
    Set s = CreateObject("Scripting.Dictionary")
    s.Add "enabled", False: s.Add "rules", rules: s.Add "migrated", False: s.Add "replayLocked", True
    Set PT_NewMailAlertSettings = s
End Function

' Copy mutable rule fields and folder references so cancelled edits do not alter the original rule.
Public Function PT_CloneMailAlertRule(ByVal original As Object) As Object
    Dim r As Object, refs As New Collection, ref As Object, copy As Object, k As Variant
    Set r = PT_NewMailAlertRule()
    For Each k In r.Keys
        If CStr(k) <> "roots" Then r(k) = original(k)
    Next k
    For Each ref In original("roots")
        Set copy = CreateObject("Scripting.Dictionary")
        For Each k In ref.Keys: copy.Add k, ref(k): Next k
        refs.Add copy
    Next ref
    Set r("roots") = refs
    Set PT_CloneMailAlertRule = r
End Function

' Parse a bounded non-negative setting before using it to load a saved collection.
Private Function PA_Count(ByVal text As String, ByVal maximum As Long) As Long
    If Len(text) = 0 Or Len(text) > 5 Then GoTo Invalid
    If text Like "*[!0-9]*" Then GoTo Invalid
    PA_Count = CLng(text)
    If PA_Count <= maximum Then Exit Function
Invalid:
    Err.Raise 5, "modPersonalMailAlerts.PA_Count", "A saved notification count is invalid."
End Function

' Read the complete active notification slot and migrate earlier choices into a disabled draft.
Public Function PT_LoadMailAlertSettings() As Object
    Dim s As Object, r As Object, ref As Object, p As String, rp As String, slot As String
    Dim i As Long, j As Long, k As Variant, roots As Long, count As Long
    Set s = PT_NewMailAlertSettings()
    slot = PT_ReadSetting("NotifyActiveSlot", "")
    If Len(slot) = 0 Then
        ' Read old selections without overwriting their saved settings. Review/enable
        ' the replacement once; it never silently converts email alerts into popups.
        slot = PT_ReadSetting("AlertsActiveSlot", "")
        If Len(slot) = 0 Then Set PT_LoadMailAlertSettings = s: Exit Function
        If slot <> "0" And slot <> "1" Then GoTo Invalid
        p = "Alerts" & slot & "_"
        If PT_ReadSetting(p & "Complete", "0") <> "1" Then GoTo Invalid
        count = PA_Count(PT_ReadSetting(p & "Count", "0"), 100)
        If count > 0 Then
            Set r = PT_NewMailAlertRule(): r("name") = "Previous monitored folders - review before enabling"
            For j = 1 To count
                Set ref = CreateObject("Scripting.Dictionary")
                ref.Add "entry", PT_ReadSetting(p & j & "Entry", "")
                ref.Add "store", PT_ReadSetting(p & j & "Store", "")
                ref.Add "label", PT_ReadSetting(p & j & "Label", "Saved folder")
                ref.Add "recursive", (PT_ReadSetting(p & j & "Recursive", "0") = "1")
                r("roots").Add ref
            Next j
            s("rules").Add r
        End If
        s("migrated") = True
        Set PT_LoadMailAlertSettings = s: Exit Function
    End If
    If slot <> "0" And slot <> "1" Then GoTo Invalid
    p = "Notify" & slot & "_"
    If PT_ReadSetting(p & "Complete", "0") <> "1" Or PT_ReadSetting(p & "Schema", "") <> "1" Then GoTo Invalid
    s("enabled") = (PT_ReadSetting(p & "Enabled", "0") = "1")
    s("replayLocked") = (PT_ReadSetting(p & "ReplayLocked", "1") = "1")
    count = PA_Count(PT_ReadSetting(p & "Count", "0"), 50)
    For i = 1 To count
        Set r = PT_NewMailAlertRule(): rp = p & "R" & i & "_"
        r("replayLocked") = s("replayLocked")
        For Each k In r.Keys
            If CStr(k) <> "roots" Then
                Select Case VarType(r(k))
                    Case vbBoolean: r(k) = (PT_ReadSetting(rp & k, IIf(r(k), "1", "0")) = "1")
                    Case vbInteger, vbLong: r(k) = CLng(PT_ReadSetting(rp & k, CStr(r(k))))
                    Case Else: r(k) = PT_ReadSetting(rp & k, CStr(r(k)))
                End Select
            End If
        Next k
        If PT_ReadSetting(rp & "headingText", Chr$(1)) = Chr$(1) Then
            If CBool(r("heading")) Then r("headingText") = "Email Received" ' Preserve earlier checkbox choices during migration only.
        End If
        roots = PA_Count(PT_ReadSetting(rp & "Roots", "0"), 100)
        For j = 1 To roots
            Set ref = CreateObject("Scripting.Dictionary")
            ref.Add "entry", PT_ReadSetting(rp & j & "Entry", "")
            ref.Add "store", PT_ReadSetting(rp & j & "Store", "")
            ref.Add "label", PT_ReadSetting(rp & j & "Label", "Saved folder")
            ref.Add "recursive", (PT_ReadSetting(rp & j & "Recursive", "0") = "1")
            r("roots").Add ref
        Next j
        s("rules").Add r
    Next i
    PT_ValidateMailAlertSettings s
    Set PT_LoadMailAlertSettings = s: Exit Function
Invalid:
    Err.Raise 5, "modPersonalMailAlerts.PT_LoadMailAlertSettings", "Notification settings are incomplete or invalid. Restore your settings backup or choose your folders again."
End Function

' Check duration, detail choices, text filters and folder references before accepting a rule.
Public Sub PT_ValidateMailAlertRule(ByVal r As Object)
    Dim ref As Object, key As Variant, shown As Boolean, n As Long
    If Len(Trim$(CStr(r("name")))) = 0 Or Len(r("name")) > 100 Then Err.Raise 5, , "Enter a rule name of 1 to 100 characters."
    For Each key In Array("sender", "subject", "to", "cc", "personal", "groups")
        If Len(r(key)) > 2000 Or InStr(r(key), vbCr) > 0 Or InStr(r(key), vbLf) > 0 Then Err.Raise 5, , "Keep each filter on one line, up to 2,000 characters. Separate alternatives with semicolons."
        If Len(Trim$(r(key))) > 0 And Len(Replace(Replace(r(key), ";", ""), " ", "")) = 0 Then Err.Raise 5, , "A filter contains only separators. Enter a value or clear the field."
    Next key
    For Each key In Array("senderMode", "subjectMode", "toMode", "ccMode")
        n = CLng(r(key)): If n < 0 Or n > 3 Then Err.Raise 5, , "Choose a valid text-match option."
    Next key
    n = CLng(r("recipientMode")): If n < 0 Or n > 6 Then Err.Raise 5, , "Choose a valid recipient option."
    If r("roots").Count > 100 Then Err.Raise 5, , "Choose at most 100 mailbox/folder selections per rule."
    For Each ref In r("roots")
        If Len(ref("entry")) = 0 Or Len(ref("store")) = 0 Then Err.Raise 5, , "A selected folder has no saved ID. Remove it and choose it again."
    Next ref
    If n >= 1 And n <= 4 Then PA_ValidateAddresses CStr(r("personal")), CBool(r("enabled")), "your personal addresses"
    If n >= 5 Then PA_ValidateAddresses CStr(r("groups")), CBool(r("enabled")), "the group/list addresses"
    If r("enabled") And r("roots").Count = 0 Then Err.Raise 5, , "Choose a mailbox or folder for this enabled rule."
    If Not CBool(r("manualDismiss")) Then
        If CLng(r("seconds")) < 3 Or CLng(r("seconds")) > 120 Then Err.Raise 5, , "Choose a popup duration from 3 to 120 whole seconds."
    End If
    If CLng(r("bodyLines")) < 1 Or CLng(r("bodyLines")) > 5 Then Err.Raise 5, , "Choose 1 to 5 body lines."
    If CLng(r("position")) < 0 Or CLng(r("position")) > 3 Then Err.Raise 5, , "Choose a popup corner."
    If Len(CStr(r("headingText"))) > 120 Or InStr(CStr(r("headingText")), vbCr) > 0 Or InStr(CStr(r("headingText")), vbLf) > 0 Then Err.Raise 5, , "Keep the opening text on one line, up to 120 characters."
    shown = (Len(Trim$(CStr(r("headingText")))) > 0)
    For Each key In Array("showSender", "showSubject", "showBody", "showFolder", "showTo", "showCc")
        If CBool(r(key)) Then shown = True
    Next key
    If Not shown Then Err.Raise 5, , "Type opening text or choose at least one email detail. For a private card, type a generic heading and untick all email details."
End Sub

' Check the explicitly entered SMTP addresses used for personal and group matching.
Private Sub PA_ValidateAddresses(ByVal addresses As String, ByVal required As Boolean, ByVal label As String)
    Dim part As Variant, value As String, found As Boolean
    For Each part In Split(addresses, ";")
        value = Trim$(CStr(part))
        If Len(value) > 0 Then
            found = True
            If InStr(value, "@") < 2 Or InStr(value, "@") = Len(value) Or InStr(InStr(value, "@") + 1, value, "@") > 0 Or InStr(value, " ") > 0 Or InStr(value, ",") > 0 Or InStr(value, "<") > 0 Then Err.Raise 5, , "Enter " & label & " as plain email addresses separated by semicolons."
        End If
    Next part
    If required And Not found Then Err.Raise 5, , "Enter " & label & ". Include any aliases you receive mail through."
End Sub

' Validate the global notification configuration and every ordered rule before saving.
Public Sub PT_ValidateMailAlertSettings(ByVal s As Object)
    Dim r As Object, enabled As Long
    If VarType(s("replayLocked")) <> vbBoolean Then Err.Raise 5, , "The locked-screen replay choice must be on or off."
    If s("rules").Count > 50 Then Err.Raise 5, , "Use at most 50 notification rules."
    For Each r In s("rules")
        PT_ValidateMailAlertRule r
        If r("enabled") Then enabled = enabled + 1
    Next r

End Sub

' Write the entire inactive configuration before making it the active notification slot.
Public Sub PT_SaveMailAlertSettings(ByVal s As Object)
    Dim p As String, rp As String, slot As String, r As Object, ref As Object, k As Variant, i As Long, j As Long
    PT_ValidateMailAlertSettings s
    If PT_ReadSetting("NotifyActiveSlot", "") = "0" Then slot = "1" Else slot = "0"
    p = "Notify" & slot & "_": PT_WriteSetting p & "Complete", "0"
    PT_WriteSetting p & "Schema", "1": PT_WriteSetting p & "Enabled", IIf(s("enabled"), "1", "0")
    PT_WriteSetting p & "ReplayLocked", IIf(s("replayLocked"), "1", "0")
    PT_WriteSetting p & "Count", CStr(s("rules").Count)
    For Each r In s("rules")
        i = i + 1: rp = p & "R" & i & "_"
        For Each k In r.Keys
            If CStr(k) <> "roots" Then
                If VarType(r(k)) = vbBoolean Then
                    PT_WriteSetting rp & k, IIf(r(k), "1", "0")
                Else
                    PT_WriteSetting rp & k, CStr(r(k))
                End If
            End If
        Next k
        j = 0: PT_WriteSetting rp & "Roots", CStr(r("roots").Count)
        For Each ref In r("roots")
            j = j + 1
            PT_WriteSetting rp & j & "Entry", CStr(ref("entry"))
            PT_WriteSetting rp & j & "Store", CStr(ref("store"))
            PT_WriteSetting rp & j & "Label", CStr(ref("label"))
            PT_WriteSetting rp & j & "Recursive", IIf(ref("recursive"), "1", "0")
        Next ref
    Next r
    PT_WriteSetting p & "Complete", "1"
    PT_WriteSetting "NotifyActiveSlot", slot ' Activate only a fully written save.
End Sub

' Capture the selected folder's exact IDs, display label and subfolder option.
Public Function PT_AlertFolderReference(ByVal folder As Outlook.Folder, ByVal recursive As Boolean) As Object
    Dim ref As Object, kind As Long
    kind = PT_FolderKind(folder)
    If kind = 2 Then Err.Raise 5, , "Choose a physical mail folder or mailbox, not a Search Folder."
    If kind <> 0 And folder.DefaultItemType <> olMailItem Then Err.Raise 5, , "Choose a mail folder."
    Set ref = CreateObject("Scripting.Dictionary")
    ref.Add "entry", folder.EntryID: ref.Add "store", folder.StoreID
    ref.Add "recursive", (recursive Or kind = 0)
    ref.Add "label", folder.Store.DisplayName & " - " & folder.FolderPath
    Set PT_AlertFolderReference = ref
End Function

' Suggest the current user's SMTP address for the personal-recipient condition.
Public Function PT_DefaultAlertAddress() As String
    Dim account As Outlook.Account, seen As Object, value As String
    Set seen = CreateObject("Scripting.Dictionary"): seen.CompareMode = vbTextCompare
    On Error Resume Next
    For Each account In PA_App().Session.Accounts
        value = Trim$(account.SmtpAddress)
        If InStr(value, "@") > 1 And Not seen.Exists(value) Then
            seen.Add value, True
            If Len(PT_DefaultAlertAddress) > 0 Then PT_DefaultAlertAddress = PT_DefaultAlertAddress & "; "
            PT_DefaultAlertAddress = PT_DefaultAlertAddress & value
        End If
    Next account
End Function

' Suspend popup display during editing, then restart monitoring from the approved saved choices.
Public Sub Settings_ConfigureMailAlerts()
    Dim panel As frmPersonalOutlook, saved As Boolean
    On Error GoTo Failed
    alertConfigOpen = True
    PA_ParkNotice True ' Opening setup must not discard an unseen notification.
    Set panel = New frmPersonalOutlook
    panel.PrepareMailAlerts PT_LoadMailAlertSettings()
    panel.Show vbModal
    saved = (panel.Result = 1): Unload panel
    alertConfigOpen = False
    If saved Then
        If alertRunning Then RefreshActiveWatchers PA_App(), False
    End If
    Exit Sub
Failed:
    alertConfigOpen = False
    PT_ReportError "Set up email notifications", Err.Number, Err.Description, Err.Source, "modPersonalMailAlerts.Settings_ConfigureMailAlerts"
End Sub

' Describe the monitoring state and recent diagnostic log in the setup window.
Public Function PT_MailAlertStatus() As String
    Dim count As Long, waiting As Long, enabled As Long, settings As Object, rule As Object, status As String
    Set settings = PT_LoadMailAlertSettings()
    For Each rule In settings("rules")
        If CBool(rule("enabled")) Then enabled = enabled + 1
    Next rule
    If Not alertFolders Is Nothing Then count = alertFolders.Count
    If Not alertQueue Is Nothing Then waiting = alertQueue.Count
    If Not NotificationsActive(settings) Then
        status = "Alerts paused. Use Settings_AlertsToggle to resume."
    ElseIf Not alertRunning Then
        status = "Alerts are enabled, but monitoring could not start. Check today's log for the cause."
    ElseIf enabled = 0 Then
        status = "Alerts active. Enable a rule to receive notifications."
    ElseIf count = 0 Then
        status = "Alerts active. Waiting for the selected folders to connect."
    Else
        status = "Alerts active."
    End If
    PT_MailAlertStatus = status & vbCrLf & enabled & " enabled rule(s), " & count & " connected folder(s), " & waiting & " card(s) waiting." & vbCrLf & _
        "The first matching rule controls the card and its behaviour after unlock." & vbCrLf & vbCrLf & _
        "Today - " & Format$(Date, "dd/mm/yyyy") & vbCrLf & TodayAlertLog()
End Function
' Text filters: blank = any; alternatives separated by semicolons; no wildcard syntax.
' Modes: 0 contains any, 1 equals any, 2 starts with any, 3 contains none.
Public Function PT_AlertTextMatch(ByVal value As String, ByVal filters As String, ByVal matchMode As Long) As Boolean
    Dim part As Variant, token As String, found As Boolean, used As Boolean
    For Each part In Split(filters, ";")
        token = Trim$(CStr(part))
        If Len(token) > 0 Then
            used = True
            Select Case matchMode
                Case 0, 3: If InStr(1, value, token, vbTextCompare) > 0 Then found = True
                Case 1: If StrComp(Trim$(value), token, vbTextCompare) = 0 Then found = True
                Case 2: If StrComp(Left$(value, Len(token)), token, vbTextCompare) = 0 Then found = True
            End Select
        End If
    Next part
    If Not used Then
        PT_AlertTextMatch = True
    ElseIf matchMode = 3 Then
        PT_AlertTextMatch = Not found
    Else
        PT_AlertTextMatch = found
    End If
End Function

' Resolve a recipient address entry to SMTP, including Exchange directory entries.
Private Function PA_Address(ByVal entry As Outlook.AddressEntry) As String
    Dim person As Outlook.ExchangeUser, group As Outlook.ExchangeDistributionList, value As String
    On Error Resume Next
    If entry Is Nothing Then Exit Function
    value = entry.PropertyAccessor.GetProperty("http://schemas.microsoft.com/mapi/proptag/0x39FE001F")
    If Len(value) = 0 Then value = entry.PropertyAccessor.GetProperty("http://schemas.microsoft.com/mapi/proptag/0x39FE001E")
    If Len(value) = 0 And entry.Type = "EX" Then
        Set person = entry.GetExchangeUser
        If Not person Is Nothing Then value = person.PrimarySmtpAddress
        If Len(value) = 0 Then
            Set group = entry.GetExchangeDistributionList
            If Not group Is Nothing Then value = group.PrimarySmtpAddress
        End If
    End If
    If Len(value) = 0 Then value = entry.Address
    PA_Address = value
End Function

' Choose the usable SMTP sender address for a notification filter.
Private Function PA_SenderAddress(ByVal mail As Outlook.MailItem) As String
    Dim value As String
    On Error Resume Next
    value = mail.PropertyAccessor.GetProperty("http://schemas.microsoft.com/mapi/proptag/0x5D01001F")
    If Len(value) = 0 Then value = PA_Address(mail.Sender)
    If Len(value) = 0 Then value = mail.SenderEmailAddress
    PA_SenderAddress = value
End Function

' Build resolved visible recipient rows for To and Cc matching.
Private Function PA_RecipientRows(ByVal mail As Outlook.MailItem) As Collection
    Dim rows As New Collection, recipient As Outlook.Recipient, r As Object
    For Each recipient In mail.Recipients
        If recipient.Type = olTo Or recipient.Type = olCC Then
            Set r = CreateObject("Scripting.Dictionary")
            r.Add "type", recipient.Type: r.Add "name", recipient.Name
            r.Add "address", PA_Address(recipient.AddressEntry)
            rows.Add r
        End If
    Next recipient
    Set PA_RecipientRows = rows
End Function

' Match the chosen recipient kind against any of the configured text alternatives.
Private Function PA_RecipientTextMatch(ByVal rows As Collection, ByVal kind As Long, ByVal filters As String, ByVal matchMode As Long) As Boolean
    Dim r As Object, found As Boolean, positive As Long
    If Len(Trim$(filters)) = 0 Then PA_RecipientTextMatch = True: Exit Function
    positive = matchMode: If positive = 3 Then positive = 0
    For Each r In rows
        If CLng(r("type")) = kind Then
            If PT_AlertTextMatch(CStr(r("name")), filters, positive) Or PT_AlertTextMatch(CStr(r("address")), filters, positive) Then found = True: Exit For
        End If
    Next r
    If matchMode = 3 Then PA_RecipientTextMatch = Not found Else PA_RecipientTextMatch = found
End Function

' Apply the personal-address and explicit group/list recipient condition.
Public Function PT_AlertRecipientModeMatch(ByVal rows As Collection, ByVal recipientMode As Long, ByVal personal As String, ByVal groups As String) As Boolean
    Dim r As Object, meTo As Boolean, meCc As Boolean, groupTo As Boolean, groupCc As Boolean, othersTo As Boolean
    If recipientMode = 0 Then PT_AlertRecipientModeMatch = True: Exit Function
    For Each r In rows
        If CLng(r("type")) = olTo Then
            If Len(Trim$(personal)) > 0 And PT_AlertTextMatch(CStr(r("address")), personal, 1) Then meTo = True Else othersTo = True
            If Len(Trim$(groups)) > 0 And PT_AlertTextMatch(CStr(r("address")), groups, 1) Then groupTo = True
        ElseIf CLng(r("type")) = olCC Then
            If Len(Trim$(personal)) > 0 And PT_AlertTextMatch(CStr(r("address")), personal, 1) Then meCc = True
            If Len(Trim$(groups)) > 0 And PT_AlertTextMatch(CStr(r("address")), groups, 1) Then groupCc = True
        End If
    Next r
    Select Case recipientMode
        Case 1: PT_AlertRecipientModeMatch = meTo
        Case 2: PT_AlertRecipientModeMatch = meTo And Not othersTo
        Case 3: PT_AlertRecipientModeMatch = meCc
        Case 4: PT_AlertRecipientModeMatch = meTo Or meCc
        Case 5: PT_AlertRecipientModeMatch = groupTo
        Case 6: PT_AlertRecipientModeMatch = groupTo Or groupCc
    End Select
End Function

' Match the exact selected folder or one of its permitted descendants in the same store.
Private Function PA_RuleFolderMatch(ByVal rule As Object, ByVal folder As Outlook.Folder) As Boolean
    Dim ref As Object, current As Outlook.Folder, depth As Long
    For Each ref In rule("roots")
        If StrComp(CStr(ref("store")), folder.StoreID, vbTextCompare) = 0 Then
            Set current = folder: depth = 0
            Do While Not current Is Nothing
                If StrComp(current.EntryID, CStr(ref("entry")), vbTextCompare) = 0 Then PA_RuleFolderMatch = True: Exit Function
                If Not ref("recursive") Or depth >= 100 Then Exit Do
                If Not TypeOf current.Parent Is Outlook.Folder Then Exit Do
                Set current = current.Parent: depth = depth + 1
            Loop
        End If
    Next ref
End Function

' Apply the enabled rule's location, sender, subject and recipient conditions to one message.
Public Function PT_AlertRuleMatches(ByVal rule As Object, ByVal mail As Outlook.MailItem, ByVal folder As Outlook.Folder) As Boolean
    Dim rows As Collection, address As String, mode As Long
    If Not rule("enabled") Then Exit Function
    If Not PA_RuleFolderMatch(rule, folder) Then Exit Function
    If Len(Trim$(rule("sender"))) > 0 Then
        address = PA_SenderAddress(mail): mode = CLng(rule("senderMode"))
        If mode = 3 Then
            If Not PT_AlertTextMatch(mail.SenderName, rule("sender"), mode) Or Not PT_AlertTextMatch(address, rule("sender"), mode) Then Exit Function
        Else
            If Not PT_AlertTextMatch(mail.SenderName, rule("sender"), mode) And Not PT_AlertTextMatch(address, rule("sender"), mode) Then Exit Function
        End If
    End If
    If Not PT_AlertTextMatch(mail.Subject, rule("subject"), CLng(rule("subjectMode"))) Then Exit Function
    If CLng(rule("recipientMode")) <> 0 Or Len(Trim$(rule("to"))) > 0 Or Len(Trim$(rule("cc"))) > 0 Then
        Set rows = PA_RecipientRows(mail)
        If Not PA_RecipientTextMatch(rows, olTo, rule("to"), CLng(rule("toMode"))) Then Exit Function
        If Not PA_RecipientTextMatch(rows, olCC, rule("cc"), CLng(rule("ccMode"))) Then Exit Function
        If Not PT_AlertRecipientModeMatch(rows, CLng(rule("recipientMode")), rule("personal"), rule("groups")) Then Exit Function
    End If
    PT_AlertRuleMatches = True
End Function

' Select the requested number of nonblank body lines for the optional preview.
Public Function PT_AlertBodyPreview(ByVal body As String, ByVal lines As Long) As String
    Dim part As Variant, value As String, count As Long, result As String
    body = Replace(Replace(Left$(body, 8000), vbCrLf, vbLf), vbCr, vbLf)
    For Each part In Split(body, vbLf)
        value = Trim$(Replace(CStr(part), vbTab, " "))
        If Len(value) > 0 Then
            If count > 0 Then result = result & vbCrLf
            result = result & Left$(value, 180): count = count + 1
            If count >= lines Then Exit For
        End If
    Next part
    If Len(result) = 0 Then result = "[Body preview unavailable]"
    PT_AlertBodyPreview = result
End Function

' Collapse control characters and limit popup field lengths for predictable wrapping.
Private Function PA_OneLine(ByVal text As String, ByVal maximum As Long) As String
    PA_OneLine = Left$(Replace(Replace(Replace(text, vbCr, " "), vbLf, " "), vbTab, " "), maximum)
End Function

' Render only the details enabled for this rule so an omitted field stays private.
Public Function PT_AlertRender(ByVal rule As Object, ByVal data As Object) As String
    Dim text As String
    If Len(Trim$(CStr(rule("headingText")))) > 0 Then text = CStr(rule("headingText")) & vbCrLf
    If rule("showSender") Then text = text & "From: " & PA_OneLine(CStr(data("sender")), 180) & vbCrLf
    If rule("showSubject") Then text = text & "Subject: " & PA_OneLine(CStr(data("subject")), 240) & vbCrLf
    If rule("showTo") Then text = text & "To: " & PA_OneLine(CStr(data("to")), 240) & vbCrLf
    If rule("showCc") Then text = text & "Cc: " & PA_OneLine(CStr(data("cc")), 240) & vbCrLf
    If rule("showFolder") Then text = text & "Folder: " & PA_OneLine(CStr(data("folder")), 240) & vbCrLf
    If rule("showBody") Then text = text & PT_AlertBodyPreview(CStr(data("body")), CLng(rule("bodyLines"))) & vbCrLf
    If Right$(text, 2) = vbCrLf Then text = Left$(text, Len(text) - 2)
    PT_AlertRender = text
End Function

' Read the message fields needed to render the matching rule's popup.
Private Function PA_RenderMail(ByVal rule As Object, ByVal mail As Outlook.MailItem, ByVal folder As Outlook.Folder) As String
    Dim data As Object, body As String
    Set data = CreateObject("Scripting.Dictionary")
    ' Read only selected display fields. A private popup never reads the body.
    If rule("showSender") Then data.Add "sender", mail.SenderName & " <" & PA_SenderAddress(mail) & ">"
    If rule("showSubject") Then data.Add "subject", mail.Subject
    If rule("showTo") Then data.Add "to", mail.To
    If rule("showCc") Then data.Add "cc", mail.CC
    If rule("showFolder") Then data.Add "folder", folder.Store.DisplayName & " - " & folder.FolderPath
    If rule("showBody") Then
        On Error Resume Next
        body = mail.Body
        On Error GoTo 0
        data.Add "body", body
    End If
    PA_RenderMail = PT_AlertRender(rule, data)
End Function

' Show synthetic sample details using the current rule without watching or sending mail.
Public Sub PT_PreviewMailAlert(ByVal rule As Object)
    Dim data As Object, sample As Object
    Set sample = PT_CloneMailAlertRule(rule): sample("enabled") = False
    PT_ValidateMailAlertRule sample
    Set data = CreateObject("Scripting.Dictionary")
    data.Add "sender", "Example Sender <sender@example.invalid>": data.Add "subject", "Example email subject"
    data.Add "to", "me@example.invalid; team@example.invalid": data.Add "cc", "colleague@example.invalid"
    data.Add "folder", "Example mailbox - Inbox\Projects"
    data.Add "body", "This is the first example line." & vbCrLf & "This is the second example line." & vbCrLf & "A third example line."
    PA_ParkNotice True
    PA_ShowAlert PT_AlertRender(rule, data), CLng(rule("seconds")), CLng(rule("position")), CBool(rule("sound")), True, CBool(rule("manualDismiss")), CStr(rule("headingText"))
End Sub

' Attach selected folder and sync events, seed existing mail, and start the native popup timer.
Public Sub PT_AlertsStart(ByVal app As Outlook.Application)
    Dim settings As Object, previousRoots As Object
    On Error GoTo Failed
    If alertRunning Then Exit Sub
    Set settings = PT_LoadMailAlertSettings()
    If Not NotificationsActive(settings) Then Exit Sub
    PT_ValidateMailAlertSettings settings
    Set alertApp = app: Set alertSettings = settings
    Set alertSeen = CreateObject("Scripting.Dictionary"): Set alertQueue = New Collection
    alertSince = Now: checkedAt = alertSince
    lastRebindAt = alertSince: alertRebindDue = False
    Set alertWatermarks = CreateObject("Scripting.Dictionary")
    Set alertChecked = CreateObject("Scripting.Dictionary")
    Set previousRoots = CreateObject("Scripting.Dictionary")
    AllocateWatchers
    AttachConfiguredLocations app, previousRoots, alertSince
    ' Set the precise start before subscribing. The first catch-up includes mail
    ' which arrived while shared folders were connecting, without seeding it as seen.
    alertSessionState = PA_ReadSessionState(): alertStateKnown = True
    Set awayPeriods = New Collection: lastLockStart = 0: lastUnlock = 0
    If alertSessionState <> 1 Then lastLockStart = alertSince
    alertLastScan = Timer: PA_EnsureTimer: alertRunning = True
    PT_AlertsCatchUp "Monitoring started"
    PT_AlertLog "Alerts active. Connected folders: " & alertFolders.Count & "."
    Exit Sub
Failed:
    PT_AlertLog PT_ErrorText("Start email notifications", Err.Number, Err.Description, Err.Source, "modPersonalMailAlerts.PT_AlertsStart")
    PT_AlertsStop False
End Sub

Private Sub AllocateWatchers()
    Set alertFolders = CreateObject("Scripting.Dictionary"): Set alertTrees = CreateObject("Scripting.Dictionary")
    Set alertRootStarts = CreateObject("Scripting.Dictionary")
    Set alertFloors = CreateObject("Scripting.Dictionary"): Set alertSinks = New Collection
End Sub

Private Sub AttachConfiguredLocations(ByVal app As Outlook.Application, ByVal previousRoots As Object, ByVal addedAt As Date)
    Dim rule As Object, ref As Object, folder As Outlook.Folder, sync As Outlook.SyncObject, sink As clsPersonalFolderWatcher
    Dim key As String, since As Date
    For Each rule In alertSettings("rules")
        If rule("enabled") Then
            For Each ref In rule("roots")
                key = CStr(ref("store")) & "|" & CStr(ref("entry"))
                since = addedAt
                If previousRoots.Exists(key) Then since = CDate(previousRoots(key))
                ' Remember even an offline root so reconnect uses its real start.
                alertRootStarts(key) = since
                Set folder = Nothing
                On Error Resume Next
                Err.Clear: Set folder = app.Session.GetFolderFromID(CStr(ref("entry")), CStr(ref("store")))
                If folder Is Nothing Then
                    alertRebindDue = True
                    PT_AlertLog "Waiting for the watched location " & ref("label") & ". " & Err.Description
                End If
                On Error GoTo 0
                If Not folder Is Nothing Then PA_AddTree folder, CBool(ref("recursive")), 0, since
            Next ref
        End If
    Next rule
    ' Some shared providers have no SyncObject. ItemAdd and polling still cover them.
    On Error Resume Next
    For Each sync In app.Session.SyncObjects
        Set sink = New clsPersonalFolderWatcher: sink.WatchSync sync: alertSinks.Add sink
    Next sync
End Sub



Private Sub RefreshActiveWatchers(ByVal app As Outlook.Application, ByVal recovering As Boolean)
    Dim previousSettings As Object, previousFolders As Object, previousTrees As Object, previousRoots As Object, previousFloors As Object
    Dim previousSinks As Collection, key As Variant, stamp As Date, newSettings As Object, detail As String
    If Not alertRunning Then Exit Sub
    On Error GoTo Failed
    Set newSettings = PT_LoadMailAlertSettings(): stamp = Now
    Set previousSettings = alertSettings: Set previousFolders = alertFolders
    Set previousTrees = alertTrees: Set previousRoots = alertRootStarts: Set previousFloors = alertFloors: Set previousSinks = alertSinks
    Set alertSettings = newSettings: AllocateWatchers
    AttachConfiguredLocations app, previousRoots, stamp
    ' Re-evaluate unmatched items under edited criteria. Recovering a connection
    ' preserves completed work and all last-successful physical-folder watermarks.
    If Not recovering Then alertChecked.RemoveAll
    Set previousSinks = Nothing
    PT_AlertsCatchUp IIf(recovering, "Shared folder reconnected", "Configuration updated")
    PT_AlertLog "Watch list refreshed. Connected folders: " & alertFolders.Count & "."
    Exit Sub
Failed:
    detail = Err.Description
    If Not previousSinks Is Nothing Then
        Set alertSinks = previousSinks: Set alertTrees = previousTrees: Set alertRootStarts = previousRoots: Set alertFloors = previousFloors
        Set alertSettings = previousSettings: Set alertFolders = previousFolders
    End If
    alertRebindDue = True
    PT_AlertLog "Could not refresh the watch list. Monitoring will retry. " & detail
End Sub
' Stop the timer, close the current popup and release queued notices and watchers.
Public Sub PT_AlertsStop(ByVal unused As Boolean)
    alertRunning = False: alertScanning = False
    PA_CancelTimer
    PA_CloseNotice
    Set alertQueue = Nothing: Set alertCurrent = Nothing: alertStateKnown = False
    Set alertSinks = Nothing: Set alertFolders = Nothing: Set alertTrees = Nothing
    Set alertSeen = Nothing: Set alertSettings = Nothing: Set alertApp = Nothing
    Set awayPeriods = Nothing
    Set alertWatermarks = Nothing: Set alertRootStarts = Nothing: Set alertFloors = Nothing: Set alertChecked = Nothing
End Sub

' Attach permitted physical folders once, including their child-folder events when requested.
Private Sub PA_AddTree(ByVal folder As Outlook.Folder, ByVal recursive As Boolean, ByVal depth As Long, ByVal since As Date)
    Dim key As String, sink As clsPersonalFolderWatcher, child As Outlook.Folder, kind As Long
    On Error GoTo Failed
    If depth > 100 Then Err.Raise 5, , "Folder nesting exceeds 100 levels."
    key = folder.StoreID & "|" & folder.EntryID: kind = PT_FolderKind(folder)
    If kind = 2 Then Exit Sub
    If Not alertFolders.Exists(key) Then
        If alertFolders.Count >= 1000 Then Err.Raise 5, , "The limit is 1,000 watched folders. Choose smaller folder trees."
        Set sink = New clsPersonalFolderWatcher: sink.WatchFolder folder, recursive
        alertSinks.Add sink, key: alertFolders.Add key, folder
        If Not alertWatermarks.Exists(key) Then alertWatermarks(key) = since
        alertFloors(key) = since
    ElseIf recursive Then
        alertSinks(key).WatchChildren folder
    End If
    If since < CDate(alertFloors(key)) Then alertFloors(key) = since
    If recursive Then
        If alertTrees.Exists(key) Then
            If CDate(alertTrees(key)) <= since Then Exit Sub
        End If
        alertTrees(key) = since
        For Each child In folder.Folders: PA_AddTree child, True, depth + 1, since: Next child
    End If
    Exit Sub
Failed:
    alertRebindDue = True
    PT_AlertLog PT_ErrorText("Attach watched folder", Err.Number, Err.Description, Err.Source, "modPersonalMailAlerts.PA_AddTree")
End Sub

' Attach a newly added child folder while retaining the current session's receive-time baseline.
Public Sub PT_AlertNewFolder(ByVal folder As Outlook.Folder)
    Dim parent As Outlook.Folder, key As String
    On Error GoTo Detached
    If Not alertRunning Then Exit Sub
    Set parent = folder.Parent
    key = parent.StoreID & "|" & parent.EntryID
    If alertTrees.Exists(key) Then PA_AddTree folder, True, 0, CDate(alertTrees(key))
    Exit Sub
Detached:
    alertRebindDue = True
End Sub

' Accept arrivals since the monitoring baseline with a small allowance for future clock differences.
Public Function PT_AlertIsRecent(ByVal received As Date, ByVal since As Date, ByVal nowValue As Date) As Boolean
    PT_AlertIsRecent = (received >= since And received <= DateAdd("n", 5, nowValue))
End Function

' Exclude the store's Sent Items, Outbox and Drafts branches from received-mail notifications.
Private Function PA_IsIncomingFolder(ByVal folder As Outlook.Folder) As Boolean
    Dim kind As Variant, excluded As Outlook.Folder, current As Outlook.Folder, depth As Long
    PA_IsIncomingFolder = True
    For Each kind In Array(olFolderSentMail, olFolderOutbox, olFolderDrafts)
        Set excluded = Nothing
        On Error Resume Next
        Set excluded = folder.Store.GetDefaultFolder(CLng(kind))
        On Error GoTo 0
        If Not excluded Is Nothing Then
            Set current = folder: depth = 0
            Do
                If current.EntryID = excluded.EntryID Then PA_IsIncomingFolder = False: Exit Function
                If Not TypeOf current.Parent Is Outlook.Folder Or depth >= 100 Then Exit Do
                Set current = current.Parent: depth = depth + 1
            Loop
        End If
    Next kind
End Function

' Deduplicate an arrival within its store using Message-ID and the saved EntryID fallback.
Private Function PA_MessageKey(ByVal mail As Outlook.MailItem) As String
    Dim id As String, accessor As Outlook.PropertyAccessor
    Set accessor = mail.PropertyAccessor
    On Error Resume Next
    id = accessor.BinaryToString(accessor.GetProperty("http://schemas.microsoft.com/mapi/proptag/0x0FF90102"))
    On Error GoTo 0
    If Len(id) = 0 Then id = mail.EntryID ' Providers that omit PR_RECORD_KEY still expose the saved item's identifier.
    If Len(id) = 0 Then Err.Raise 5, , "The received message has no stable identifier."
    PA_MessageKey = mail.Parent.StoreID & "|" & id ' Separate physical deliveries can share an Internet Message-ID and must still notify separately.
End Function

' Queue one notice from the first matching rule after location, time and duplicate checks.
Public Sub PT_AlertArrived(ByVal item As Object)
    Dim mail As Outlook.MailItem, folder As Outlook.Folder, rule As Object, key As String, stepName As String, queued As Object, state As Long
    On Error GoTo Failed
    If Not alertRunning Then Exit Sub
    If Not TypeOf item Is Outlook.MailItem Then Exit Sub
    stepName = "Read message location": Set mail = item: Set folder = mail.Parent
    Dim location As String, checkedKey As String, received As Date
    location = folder.StoreID & "|" & folder.EntryID
    If Not alertFolders.Exists(location) Then Exit Sub
    If Not mail.Sent Or Not PA_IsIncomingFolder(folder) Then Exit Sub
    received = mail.ReceivedTime: checkedKey = location & "|" & mail.EntryID
    If Not PT_AlertIsRecent(received, CDate(alertFloors(location)), Now) Then Exit Sub
    key = PA_MessageKey(mail)
    If alertSeen.Exists(key) Then GoTo Checked
    stepName = "Match notification filters"
    For Each rule In alertSettings("rules")
        If PT_AlertRuleMatches(rule, mail, folder) Then
            stepName = "Build selected popup details"
            If alertQueue Is Nothing Then Set alertQueue = New Collection
            Set queued = CreateObject("Scripting.Dictionary")
            queued.Add "text", PA_RenderMail(rule, mail, folder)
            queued.Add "seconds", CLng(rule("seconds")): queued.Add "position", CLng(rule("position")): queued.Add "sound", CBool(rule("sound"))
            state = PA_ReadSessionState()
            queued.Add "replayLocked", CBool(rule("replayLocked"))
            queued.Add "heading", CStr(rule("headingText"))
            If SuppressAwayDelivery(CBool(rule("replayLocked")), state, received, lastLockStart, lastUnlock, awayPeriods) Then
                alertSeen(key) = Now
                PT_AlertLog "A matching notification was skipped while locked (replay is off)."
                GoTo Checked
            End If
            queued.Add "manualDismiss", CBool(rule("manualDismiss"))
            queued.Add "received", received
            alertQueue.Add queued ' Retain every matching notification; there is no 30-message truncation.
            alertSeen(key) = Now ' Commit after all card fields and the queue insertion succeeded.
            PT_AlertLog "A matching email was queued."
            ' Display on the next UI tick, after the shared-store ItemAdd callback has returned.
            PA_EnsureTimer ' This also checks lock state, nested dialog blocks and active catch-up scans.
            GoTo Checked ' First matching rule wins, including its privacy choices.
        End If
    Next rule
Checked:
    ' Memoise this folder only. Moving a previously unmatched email to a new
    ' watched folder still checks its rules using a different key.
    alertChecked(checkedKey) = Now
    Exit Sub
Failed:
    failedArrival = True
    If Err.Number = &H80010007 Or Err.Number = &H80010108 Then alertRebindDue = True
    PT_AlertLog PT_ErrorText("Incoming email | " & stepName, Err.Number, Err.Description, Err.Source, "modPersonalMailAlerts.PT_AlertArrived")
End Sub

' Resolve each NewMailEx entry and pass accessible items through the normal arrival checks.
Public Function HasNotificationWatch() As Boolean
    HasNotificationWatch = alertRunning
End Function

' Rescan watched folders from their last successful watermark with an overlap for event delivery delays.
Public Sub PT_AlertsCatchUp(ByVal reason As String)
    Dim key As Variant
    If Not alertRunning Or alertScanning Or alertUIBlocks > 0 Then Exit Sub
    On Error GoTo Failed
    alertScanning = True
    If DateDiff("n", checkedAt, Now) >= 5 Then
        ' Only the short polling overlap needs memoisation. Direct delivery
        ' events still use the session-wide record key for duplicate suppression.
        For Each key In alertChecked.Keys
            If DateDiff("n", CDate(alertChecked(key)), Now) >= 5 Then alertChecked.Remove key
        Next key
        checkedAt = Now
    End If
    For Each key In alertFolders.Keys
        ScanWatchedLocation CStr(key)
    Next key
Finished:
    alertScanning = False: alertLastScan = Timer
    Exit Sub
Failed:
    PT_AlertLog "Folder catch-up: " & Err.Description
    Resume Finished
End Sub

Private Sub ScanWatchedLocation(ByVal key As String)
    Dim ids As Variant, folder As Outlook.Folder, since As Date, stamp As Date
    On Error GoTo Detached
    ids = Split(key, "|")
    Set folder = PA_App().Session.GetFolderFromID(CStr(ids(1)), CStr(ids(0)))
    If folder.DefaultItemType <> olMailItem Then Exit Sub
    If Not PA_IsIncomingFolder(folder) Then Exit Sub
    stamp = Now: since = AlertScanSince(CDate(alertWatermarks(key)), CDate(alertFloors(key)))
    If PA_ScanFolder(folder, since) Then
        alertWatermarks(key) = stamp
    Else
        alertRebindDue = True
    End If
    Exit Sub
Detached:
    alertRebindDue = True
    PT_AlertLog "A watched folder disconnected. Outlook will reconnect and retry from its last successful scan. " & Err.Description
End Sub

' Seed current IDs or scan recent arrivals, reporting provider errors without advancing a failed watermark.
Private Function PA_ScanFolder(ByVal folder As Outlook.Folder, ByVal since As Date) As Boolean
    Dim table As Outlook.Table, item As Object, session As Outlook.NameSpace, records As Variant
    Dim lastRow As Long, missed As Boolean, row As Long, entry As String, store As String, prefix As String, key As String, filter As String
    On Error GoTo Failed
    filter = "[ReceivedTime] >= '" & Format$(since, "ddddd h:nn AMPM") & "'"
    Set table = folder.GetTable(filter, olUserItems)
    table.Columns.RemoveAll: table.Columns.Add "EntryID"
    Set session = PA_App().Session: store = folder.StoreID: prefix = store & "|" & folder.EntryID & "|"
    Do Until table.EndOfTable
        records = table.GetArray(128)
        lastRow = TableBatchLastRow(records)
        If lastRow < 0 Then
            If Not table.EndOfTable Then Err.Raise 5, , "The watched folder returned an incomplete message table."
            Exit Do
        End If
        For row = 0 To lastRow
            entry = CStr(records(0, row)): key = prefix & entry
            ' Folder is part of the key. A move into another watched folder can match
            ' a different rule. A provider failure stays eligible for the next scan.
            If Not alertChecked.Exists(key) Then
                Set item = session.GetItemFromID(entry, store)
                If item Is Nothing Then
                    missed = True
                Else
                    failedArrival = False: PT_AlertArrived item
                    If failedArrival Then missed = True Else alertChecked(key) = Now
                End If
            End If
        Next row
    Loop
    PA_ScanFolder = Not missed: Exit Function
Failed:
    PT_AlertLog PT_ErrorText("Read watched-folder message table", Err.Number, Err.Description, Err.Source, "modPersonalMailAlerts.PA_ScanFolder")
End Function

' Show the next queued popup after the previous one closes, including the burst overflow summary.
Private Sub PA_NextNotice()
    Dim queued As Object
    If alertConfigOpen Or alertUIBlocks > 0 Or alertScanning Then Exit Sub
    If PA_ReadSessionState() <> 1 Then Exit Sub ' A locked or disconnected desktop must never consume the popup timeout.
    If Not alertNotice Is Nothing Then
        If Not noticeDismissed Then Exit Sub
        PA_CloseNotice
    End If
    If alertQueue Is Nothing Then Exit Sub
    If alertQueue.Count = 0 Or Now < retryCardAfter Then Exit Sub
    Set queued = alertQueue(1)
    Set alertCurrent = queued ' Keep a full copy of the visible notice so locking Windows cannot silently consume it.
    If PA_ShowAlert(queued("text"), queued("seconds"), queued("position"), queued("sound"), False, CBool(queued("manualDismiss")), CStr(queued("heading"))) Then alertQueue.Remove 1
End Sub
' Create a modeless popup and start timing its automatic dismissal.
Private Function PA_ShowAlert(ByVal detail As String, ByVal seconds As Long, ByVal position As Long, ByVal sound As Boolean, Optional ByVal preview As Boolean = False, Optional ByVal manualDismiss As Boolean = False, Optional ByVal heading As String = "") As Boolean
    Dim number As Long, description As String, origin As String
    On Error GoTo Failed
    noticeDismissed = False
    Set alertNotice = New frmPersonalOutlook
    alertNotice.PrepareTemporaryMailNotice detail, manualDismiss, heading
    alertNotice.NoticeCorner = position
    alertShownAt = Timer: alertSeconds = seconds
    If manualDismiss Then alertSeconds = 0 ' Zero is the explicit no-timeout mode; the timer still handles locking and queued cards.
    PA_EnsureTimer ' A failed timer never leaves an undismissable temporary popup.
    If sound Then Beep
    If preview Then alertNotice.Show vbModal Else alertNotice.Show vbModeless
    PA_ShowAlert = True
    Exit Function
Failed:
    number = Err.Number: description = Err.Description: origin = Err.Source
    retryCardAfter = DateAdd("s", 10, Now)
    PA_CloseNotice
    PT_AlertLog PT_ErrorText("Show temporary email popup", number, description, origin, "modPersonalMailAlerts.PA_ShowAlert")
End Function

' Place the uniquely identified popup at the chosen corner of the primary work area.
Public Sub PT_PositionMailNotice(ByVal panel As frmPersonalOutlook, ByVal position As Long)
    Dim work As PA_RECT, rect As PA_RECT, x As Long, y As Long, title As String, process As Long
#If VBA7 Then
    Dim hwnd As LongPtr, style As LongPtr
#Else
    Dim hwnd As Long, style As Long
#End If
    title = "Personal Office Macros notification " & CStr(Timer)
    panel.Caption = title
    hwnd = FindWindowW(0, StrPtr(title))
    panel.Caption = ""
    If hwnd = 0 Then Exit Sub
    PA_WindowProcess hwnd, process
    If process <> PA_CurrentProcess() Then Exit Sub ' Only alter this VBA process's own uniquely named notification window.
    style = PA_GetWindowLongPtr(hwnd, -16)
    PA_SetWindowLongPtr hwnd, -16, style And Not (&HC00000 Or &H40000 Or &H80000) ' Remove caption, resizing frame and system menu from the card.
    style = PA_GetWindowLongPtr(hwnd, -20)
    PA_SetWindowLongPtr hwnd, -20, style And Not 1 ' Remove the dialog-frame decoration while preserving other extended styles.
    SetWindowPos hwnd, 0, 0, 0, 0, 0, &H1 Or &H2 Or &H4 Or &H10 Or &H20 ' Commit the frame change before measuring/positioning.
    If GetWindowRect(hwnd, rect) = 0 Or SystemParametersInfoW(48, 0, work, 0) = 0 Then Exit Sub
    x = work.right - (rect.right - rect.left) - 16
    y = work.bottom - (rect.bottom - rect.top) - 16
    If position = 1 Or position = 3 Then x = work.left + 16
    If position = 2 Or position = 3 Then y = work.top + 16
    If x < work.left Then x = work.left
    If y < work.top Then y = work.top
    SetWindowPos hwnd, -1, x, y, 0, 0, &H1 Or &H10 Or &H20 ' topmost, retain size, no activation
End Sub

' Hide and unload the current popup before releasing its form reference.
Private Sub PA_CloseNotice()
    On Error Resume Next
    If Not alertNotice Is Nothing Then Unload alertNotice
    Set alertNotice = Nothing: Set alertCurrent = Nothing
End Sub

' Cancel the registered Windows callback before entering code that can process more events.
Private Sub PA_CancelTimer()
    If alertTimer <> 0 Then KillTimer 0, alertTimer
    alertTimer = 0
End Sub

' Create one native timer when monitoring or an open preview needs further updates.
Private Sub PA_EnsureTimer()
    If alertTimer = 0 Then
        alertTimer = SetTimer(0, 0, 500, AddressOf PT_MailAlertTimerProc)
        If alertTimer = 0 Then Err.Raise 5, , "Windows could not create the notification timer."
    End If
End Sub

' Measure seconds across Timer's midnight rollover.
Private Function PA_Elapsed(ByVal started As Double) As Double
    PA_Elapsed = CDbl(Timer) - started
    If PA_Elapsed < 0 Then PA_Elapsed = PA_Elapsed + 86400#
End Function

' Public callback has required arguments, so it does not appear in Alt+F8.
' Cancel first; never allow an error or reentrant callback to cross Windows.
#If VBA7 Then
' Cancel the callback first, process dismissal and catch-up work, then rearm only when needed.
Public Sub PT_MailAlertTimerProc(ByVal hwnd As LongPtr, ByVal message As Long, ByVal eventID As LongPtr, ByVal tick As Long)
#Else
' Cancel the callback first, process dismissal and catch-up work, then rearm only when needed.
Public Sub PT_MailAlertTimerProc(ByVal hwnd As Long, ByVal message As Long, ByVal eventID As Long, ByVal tick As Long)
#End If
    Dim number As Long, description As String, origin As String, state As Long, wasUnavailable As Boolean
    On Error GoTo Failed
    If alertTimer = 0 Or eventID <> alertTimer Then Exit Sub
    PA_CancelTimer
    state = PA_ReadSessionState() ' Check lock state before consuming any visible popup timeout.
    wasUnavailable = (alertStateKnown And alertSessionState <> 1)
    alertSessionState = state: alertStateKnown = True
    If state <> 1 Then
        If Not wasUnavailable Or lastLockStart = 0 Then lastLockStart = Now
        PA_ParkNotice PA_ReplayEnabled()
        FilterLockedQueue ' Requeue even a partly displayed notification; give it its full duration after unlock.
    ElseIf wasUnavailable And alertRunning Then
        lastUnlock = Now
        If lastLockStart > 0 Then awayPeriods.Add Array(lastLockStart, lastUnlock)
        If Not alertConfigOpen Then PT_AlertsCatchUp "Windows unlocked"
    End If
    If Not alertNotice Is Nothing Then
        If noticeDismissed Then
            PA_CloseNotice
        ElseIf alertSeconds > 0 Then
            If PA_Elapsed(alertShownAt) >= alertSeconds Then PA_CloseNotice
        End If
    End If
    If Not alertConfigOpen Then PA_NextNotice ' This also checks lock state, nested dialog blocks and active catch-up scans.
    If alertRunning And Not alertConfigOpen And alertUIBlocks = 0 Then
        If alertRebindDue And DateDiff("s", lastRebindAt, Now) >= 60 Then
            alertRebindDue = False: lastRebindAt = Now
            RefreshActiveWatchers PA_App(), True
        ElseIf PA_Elapsed(alertLastScan) >= 30 Then
            PT_AlertsCatchUp "30-second check"
        End If
    End If
Finished:
    On Error Resume Next
    If alertRunning Or Not alertNotice Is Nothing Then PA_EnsureTimer
    Exit Sub
Failed:
    number = Err.Number: description = Err.Description: origin = Err.Source
    If number = &H80010007 Or number = &H80010108 Then alertRebindDue = True
    PA_ParkNotice True
    PT_AlertLog PT_ErrorText("Notification timer", number, description, origin, "modPersonalMailAlerts.PT_MailAlertTimerProc")
    Resume Finished
End Sub

' Keep a bounded recent activity log without routine sender, subject or body text.
Public Sub PT_AlertLog(ByVal text As String)
    On Error Resume Next
    ' No subject, sender, recipient or body content is recorded in routine activity.
    PT_WriteSetting "MailAlertLog", Left$(Format$(Now, "yyyy-mm-dd hh:nn:ss") & " " & text & vbCrLf & PT_ReadSetting("MailAlertLog", ""), 16000)
End Sub

' Read the current Windows session, using WTSINFOEX level 1 on supported Windows 10/11.
' The native union starts at byte 8; copy only the five DWORDs that contain level, session, state and flags.
' Return 1 only for an active, unlocked session. Hold notifications if Windows cannot supply a reliable answer.
Private Function PA_ReadSessionState() As Long
    Dim bytes As Long, header(0 To 4) As Long
#If VBA7 Then
    Dim buffer As LongPtr
#Else
    Dim buffer As Long
#End If
    On Error GoTo Finished
    PA_ReadSessionState = -1
    If WTSQuerySessionInformationW(0, -1, 25, buffer, bytes) = 0 Then GoTo Finished
    If buffer = 0 Or bytes < 20 Then GoTo Finished
    PA_CopyMemory header(0), buffer, 20 ' Never read more than the validated fixed header from the Windows allocation.
    PA_ReadSessionState = PA_DecodeSessionState(header(0), header(3), header(4))
Finished:
    If buffer <> 0 Then WTSFreeMemory buffer ' Always release the allocation owned by Windows, including on a failed decode.
End Function

' Keep decoding separate from the API call so unknown and disconnected states are explicit and reviewable.
Private Function PA_DecodeSessionState(ByVal level As Long, ByVal connection As Long, ByVal flags As Long) As Long
    PA_DecodeSessionState = -1
    If level <> 1 Then Exit Function
    If connection <> 0 Then PA_DecodeSessionState = 0: Exit Function ' WTSActive = 0; disconnected sessions cannot see a popup.
    If flags = 0 Or flags = 1 Then PA_DecodeSessionState = flags
End Function

' Default to retaining notifications if configuration has not yet been loaded.
Private Function PA_ReplayEnabled() As Boolean
    If Not alertCurrent Is Nothing Then PA_ReplayEnabled = CBool(alertCurrent("replayLocked"))
End Function

' Put an interrupted real notification back before unloading its form. Preview text is never queued.
Private Sub PA_ParkNotice(ByVal retain As Boolean)
    If Not alertCurrent Is Nothing And retain And Not noticeDismissed Then
        If alertQueue Is Nothing Then Set alertQueue = New Collection
        If alertQueue.Count = 0 Then alertQueue.Add alertCurrent Else alertQueue.Add alertCurrent, Before:=1
    End If
    PA_CloseNotice
End Sub

' These balanced calls are used around the attachment chooser and attachment saving, including nested workers.
Public Function DeferNotificationCards() As Boolean
    alertUIBlocks = alertUIBlocks + 1
    PA_ParkNotice True ' Prevent a modeless notification stealing focus while an Outlook dialog is active.
End Function

' Let the existing timer resume popups after returning to Outlook; do not show a form inside an email save/send event.
Public Function ReleaseNotificationCards() As Boolean
    If alertUIBlocks > 0 Then alertUIBlocks = alertUIBlocks - 1
End Function


Private Function NotificationsActive(ByVal settings As Object) As Boolean
    ' Read the old master switch only until the user first uses the new toggle.
    NotificationsActive = (PT_ReadSetting("NotifyMasterActive", IIf(settings("enabled"), "1", "0")) = "1")
End Function

Public Sub Settings_AlertsToggle()
    Dim active As Boolean
    On Error GoTo Failed
    active = Not NotificationsActive(PT_LoadMailAlertSettings())
    If active Then
        PT_WriteSetting "NotifyMasterActive", "1"
        PT_AlertsStart PA_App()
        If Not alertRunning Then
            PT_WriteSetting "NotifyMasterActive", "0"
            MsgBox "Alerts could not start. Open today's status log for the folder or connection that needs attention.", vbInformation, "Email alerts"
            Exit Sub
        End If
    Else
        PT_WriteSetting "NotifyMasterActive", "0"
        PT_AlertsStop False
    End If
    PT_AlertLog IIf(active, "Alerts now active", "Alerts now paused")
    MsgBox IIf(active, "Alerts now active", "Alerts now paused"), vbInformation, "Email alerts"
    Exit Sub
Failed:
    MsgBox Err.Description, vbExclamation, "Email alerts"
End Sub

Private Function TodayAlertLog() As String
    Dim raw As String, rows As Variant, row As Variant, keep As Boolean, day As String
    day = Format$(Date, "yyyy-mm-dd")
    raw = PT_ReadSetting("MailAlertLog", ""): rows = Split(raw, vbCrLf)
    For Each row In rows
        If CStr(row) Like "####-##-## ##:##:##*" Then keep = (Left$(CStr(row), 10) = day)
        If keep Then TodayAlertLog = TodayAlertLog & row & vbCrLf
    Next row
    If Len(TodayAlertLog) = 0 Then TodayAlertLog = "No activity recorded today."
End Function

Public Sub DismissNotification(ByVal panel As frmPersonalOutlook)
    ' The timer owns the form. A button may hide it, but cannot unload its COM server mid-tick.
    noticeDismissed = True
    panel.Hide
End Sub

Private Sub FilterLockedQueue()
    Dim i As Long, queued As Object
    If alertQueue Is Nothing Then Exit Sub
    For i = alertQueue.Count To 1 Step -1
        Set queued = alertQueue(i)
        If Not CBool(queued("replayLocked")) Then alertQueue.Remove i
    Next i
End Sub


Public Sub FitToolWindow(ByVal panel As frmPersonalOutlook)
    Dim area As PA_RECT, dpi As Long, maxW As Single, maxH As Single, insideW As Single, insideH As Single
#If VBA7 Then
    Dim dc As LongPtr
#Else
    Dim dc As Long
#End If
    On Error Resume Next
    If SystemParametersInfoW(48, 0, area, 0) = 0 Then Exit Sub
    dc = DeskDC(0): If dc = 0 Then Exit Sub
    dpi = DeskCaps(dc, 88): FreeDeskDC 0, dc
    If dpi <= 0 Then Exit Sub
    maxW = (area.right - area.left) * 72! / dpi - 12
    maxH = (area.bottom - area.top) * 72! / dpi - 14
    If panel.Width <= maxW And panel.Height <= maxH Then Exit Sub
    insideW = panel.InsideWidth: insideH = panel.InsideHeight
    panel.ScrollBars = fmScrollBarsBoth: panel.KeepScrollBarsVisible = fmScrollBarsNone
    If panel.Width > maxW Then panel.Width = maxW
    If panel.Height > maxH Then panel.Height = maxH
    panel.ScrollWidth = insideW + 5: panel.ScrollHeight = insideH + 5
End Sub


Private Function SkipAwayCard(ByVal replay As Boolean, ByVal state As Long, ByVal received As Date, ByVal lockedAt As Date, ByVal unlockedAt As Date) As Boolean
    ' A shared mailbox may supply the message in the catch-up scan after unlock.
    ' Use its delivery timestamp to honour the same per-rule choice in both paths.
    SkipAwayCard = Not replay And (state <> 1 Or (lockedAt > 0 And received >= lockedAt And received <= unlockedAt))
End Function


Private Function AlertScanSince(ByVal lastSuccess As Date, ByVal locationStart As Date) As Date
    ' Two-minute overlap tolerates delivery timing differences. A newly selected
    ' folder must never show mail received before its monitoring began.
    AlertScanSince = DateAdd("n", -2, lastSuccess)
    If AlertScanSince < locationStart Then AlertScanSince = locationStart
End Function


Private Function SuppressAwayDelivery(ByVal replay As Boolean, ByVal state As Long, ByVal received As Date, ByVal lockedAt As Date, ByVal unlockedAt As Date, ByVal periods As Collection) As Boolean
    Dim interval As Variant
    If replay Then Exit Function
    If SkipAwayCard(False, state, received, lockedAt, unlockedAt) Then SuppressAwayDelivery = True: Exit Function
    If lockedAt > unlockedAt And received >= lockedAt Then SuppressAwayDelivery = True: Exit Function
    For Each interval In periods
        If received >= CDate(interval(0)) And received <= CDate(interval(1)) Then SuppressAwayDelivery = True: Exit Function
    Next interval
End Function
