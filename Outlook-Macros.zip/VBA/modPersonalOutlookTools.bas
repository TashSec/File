Attribute VB_Name = "modPersonalOutlookTools"
' PERSONAL OFFICE MACROS - Outlook update 2026-11-25 - CLASSIC OUTLOOK FOR WINDOWS
' Paste into ONE ordinary Module named modPersonalOutlookTools.
' Insert one blank UserForm named frmPersonalOutlook and paste its separate code.
' No helper programs, imported forms or automatic shortcuts. The separate ThisOutlookSession
' event block runs enabled opening, closing and genuine new-delivery rules in priority order.
' Use all ten components together. The guide identifies each module, form and class.
' Outlook VBA is unavailable in new Outlook. The mail-alert feature displays temporary popups and sends no notification emails.
' Add/edit/remove operations save stored emails. Reply macros save and verify their new drafts.
' No installer, administrator rights or add-ins are required. Automatic actions use the event hooks.
Option Explicit ' Catch misspelled variable names at compile time.
Private Const PT_V6_TAG As String = "http://schemas.microsoft.com/mapi/proptag/"
Private Const PT_SETTINGS_APP As String = "PersonalOfficeMacros"
Private replyInProgress As Boolean
Private attachmentPicker As frmPersonalOutlook
#If VBA7 Then
Private Declare PtrSafe Function CoCreateGuid Lib "ole32" (ByRef firstByte As Byte) As Long
#Else
Private Declare Function CoCreateGuid Lib "ole32" (ByRef firstByte As Byte) As Long
#End If
Private chainReviewPanel As frmPersonalOutlook
Private cachedArrivalRules As Collection
Private cachedArrivalGeneration As String
Private arrivalSeen As Object ' Delivery-only provenance; ItemAdd never enters the arrival-rule engine.
Private automationBusy As Boolean
Private startupHandled As Boolean
Private shutdownHandled As Boolean
Private searchFolderEvents As clsPersonalSearchFolderEvents ' Keep Outlook's search and navigation listeners alive.
Private Const PT_SEARCH_VIEW As String = "Personal Macros - Search results" ' A view owned by one saved Search Folder.
Private Const PT_SEARCH_KEY As String = "SearchFolderView_" ' Per-profile recipe keyed by the saved folder's EntryID.

' VBA7 includes BOTH 32-bit and 64-bit Office. LongPtr selects the right pointer width.
' In modern Office the legacy #Else declarations are inactive and may appear red in the VBE.
' Keep both branches; Debug > Compile checks the active one. Never change handles to Long on 64-bit.
#If VBA7 Then ' Modern Office uses pointer-sized declarations on either 32-bit or 64-bit Office.
Private Declare PtrSafe Function RtlCompareMemory Lib "ntdll.dll" (ByRef leftBytes As Any, ByRef rightBytes As Any, ByVal byteCount As LongPtr) As LongPtr
Private Declare PtrSafe Function GetOpenFileNameW Lib "comdlg32.dll" (ByRef data As OPENFILENAMEW) As Long ' Show the native Unicode attachment file picker.
Private Declare PtrSafe Function GetActiveWindow Lib "user32.dll" () As LongPtr
Private Declare PtrSafe Function GetAncestor Lib "user32" (ByVal hwnd As LongPtr, ByVal flags As Long) As LongPtr
Private Declare PtrSafe Function IsWindow Lib "user32" (ByVal hwnd As LongPtr) As Long
Private Declare PtrSafe Function RedrawWindow Lib "user32" (ByVal hwnd As LongPtr, ByVal updateRect As LongPtr, ByVal updateRegion As LongPtr, ByVal flags As Long) As Long
Private Declare PtrSafe Function CommDlgExtendedError Lib "comdlg32.dll" () As Long ' Distinguish file-picker cancellation from an actual failure.
Private Declare PtrSafe Function MoveFileExW Lib "kernel32.dll" (ByVal existing As LongPtr, ByVal destination As LongPtr, ByVal flags As Long) As Long ' Commit a complete staged export by renaming it on the same volume.
#Else ' Retain declarations for older 32-bit VBA hosts.
Private Declare Function RtlCompareMemory Lib "ntdll.dll" (ByRef leftBytes As Any, ByRef rightBytes As Any, ByVal byteCount As Long) As Long
Private Declare Function GetOpenFileNameW Lib "comdlg32.dll" (ByRef data As OPENFILENAMEW) As Long ' Use 32-bit pointers on older Office.
Private Declare Function GetActiveWindow Lib "user32.dll" () As Long
Private Declare Function GetAncestor Lib "user32" (ByVal hwnd As Long, ByVal flags As Long) As Long
Private Declare Function IsWindow Lib "user32" (ByVal hwnd As Long) As Long
Private Declare Function RedrawWindow Lib "user32" (ByVal hwnd As Long, ByVal updateRect As Long, ByVal updateRegion As Long, ByVal flags As Long) As Long
Private Declare Function CommDlgExtendedError Lib "comdlg32.dll" () As Long ' Read native file-picker errors.
Private Declare Function MoveFileExW Lib "kernel32.dll" (ByVal existing As Long, ByVal destination As Long, ByVal flags As Long) As Long ' Rename a complete export, optionally replacing an existing file.
#End If ' Only the host-appropriate declarations are compiled.

' Windows requires this exact field order and pointer sizes for its file-picker structure.
Private Type OPENFILENAMEW
    lStructSize As Long ' Tell Windows the full structure size, including 64-bit alignment.
#If VBA7 Then ' Pointers must match the Office process size.
    hwndOwner As LongPtr ' Parent window handle.
    hInstance As LongPtr ' Unused application-instance handle, left zero.
    lpstrFilter As LongPtr ' Pointer to the double-null-terminated file filter.
    lpstrCustomFilter As LongPtr ' Unused custom filter buffer, left zero.
#Else ' Older VBA supports only 32-bit pointers.
    hwndOwner As Long ' Parent window handle.
    hInstance As Long ' Unused instance handle.
    lpstrFilter As Long ' File-filter string pointer.
    lpstrCustomFilter As Long ' Unused custom-filter pointer.
#End If ' Continue with fixed-size Windows fields.
    nMaxCustFilter As Long ' No custom-filter buffer is supplied.
    nFilterIndex As Long ' Select the first and only All files filter.
#If VBA7 Then ' Unicode output buffer pointers use native pointer width.
    lpstrFile As LongPtr ' Pointer to the selected-path buffer.
#Else ' Older VBA output pointer.
    lpstrFile As Long ' Pointer to the selected-path buffer.
#End If ' Buffer lengths are character counts, not pointer-sized values.
    nMaxFile As Long ' Capacity of the selected-path buffer in Unicode characters.
#If VBA7 Then ' Optional title buffer pointer.
    lpstrFileTitle As LongPtr ' Unused output-title buffer, left zero.
#Else ' Older VBA title pointer.
    lpstrFileTitle As Long ' Unused output-title buffer.
#End If ' The following field is a fixed-size length.
    nMaxFileTitle As Long ' No output-title buffer is supplied.
#If VBA7 Then ' Optional initial-folder and caption pointers.
    lpstrInitialDir As LongPtr ' Zero lets Windows choose its usual recent location.
    lpstrTitle As LongPtr ' Pointer to the picker caption.
#Else ' Older VBA folder and caption pointers.
    lpstrInitialDir As Long ' No forced initial folder.
    lpstrTitle As Long ' Caption string pointer.
#End If ' These picker settings have fixed Windows types.
    flags As Long ' Enable Explorer layout, multiple files and existing-file checks.
    nFileOffset As Integer ' Windows fills the file-name offset; the parser does not need it.
    nFileExtension As Integer ' Windows fills the extension offset; the parser does not need it.
#If VBA7 Then ' Remaining optional pointers retain the structure's correct layout.
    lpstrDefExt As LongPtr ' No default extension: every file type is allowed.
    lCustData As LongPtr ' No callback-specific data is used.
    lpfnHook As LongPtr ' No hook procedure is installed.
    lpTemplateName As LongPtr ' No custom dialog template is used.
    pvReserved As LongPtr ' Windows requires this reserved pointer to be zero.
#Else ' Older VBA uses fixed 32-bit pointers.
    lpstrDefExt As Long ' No default extension.
    lCustData As Long ' No custom callback data.
    lpfnHook As Long ' No hook.
    lpTemplateName As Long ' No dialog template.
    pvReserved As Long ' Reserved; leave zero.
#End If ' Finish the modern OPENFILENAME structure.
    dwReserved As Long ' Reserved Windows field, left zero.
    flagsEx As Long ' No additional extended flags are needed.
End Type ' Complete the exact Windows structure layout; its field order must remain unchanged.

#If VBA7 Then
Private Declare PtrSafe Function FindWindowExW Lib "user32" (ByVal parent As LongPtr, ByVal after As LongPtr, ByVal className As LongPtr, ByVal caption As LongPtr) As LongPtr
Private Declare PtrSafe Function PostMessageW Lib "user32" (ByVal hwnd As LongPtr, ByVal message As Long, ByVal wParam As LongPtr, ByVal lParam As LongPtr) As Long
#Else
Private Declare Function FindWindowExW Lib "user32" (ByVal parent As Long, ByVal after As Long, ByVal className As Long, ByVal caption As Long) As Long
Private Declare Function PostMessageW Lib "user32" (ByVal hwnd As Long, ByVal message As Long, ByVal wParam As Long, ByVal lParam As Long) As Long
#End If

Private Const CID As String = "http://schemas.microsoft.com/mapi/proptag/0x3712001F" ' Inline images use this Content-ID in the HTML body.
Private Const LOCATION As String = "http://schemas.microsoft.com/mapi/proptag/0x3713001F" ' Preserve an attachment's content-location when present.
Private Const MIME As String = "http://schemas.microsoft.com/mapi/proptag/0x370E001F" ' Preserve MIME content types when available.
Private Const HIDDEN As String = "http://schemas.microsoft.com/mapi/proptag/0x7FFE000B" ' Inline images may be intentionally hidden from the attachment bar.
Private pendingNoteEditor As Outlook.MailItem
Private pendingNoteTargets As Collection
Private pendingEditTarget As Outlook.MailItem
Private pendingNoteMode As String
Private pendingNoteSelfAddress As String ' Automatic To-yourself address for Send interception.
Private pendingNoteToken As String
Private pendingNoteIndex As Long
Private pendingNoteCount As Long
Private pendingNoteModified As Date
Private pendingOriginalNote As String
Private pendingNoteFolder As String
Private pendingKeepBackup As Boolean
Private pendingNoteWatcher As frmPersonalOutlook ' Hidden note event sink; folder rules use the separate ThisOutlookSession hooks.
Private pendingRuleNotePath As String
Private pendingNoteInSend As Boolean ' Outlook forbids closing an inspector inside its Send event.
Private pendingNoteBusy As Boolean
Private bulkRunning As Boolean ' Prevent overlapping move/delete batches while yielding to Outlook.
Private attachmentRunning As Boolean ' Prevent a second attachment chooser entering the first one.
Private exportRunning As Boolean ' Prevent a second export starting while progress processing yields to Outlook.

' Use Outlook's own Application; test-only host/isolation hooks are documented in the validation record.
Private Function MailApp() As Outlook.Application
    Set MailApp = Application ' In Outlook this is the running Outlook instance.
End Function

' Snapshot individual selected email objects before a dialog changes focus.
' Collapsed conversation headers and non-mail items are not silently expanded into messages.
Public Function PT_SelectedMessages() As Collection
    Dim result As New Collection ' A stable collection protects the operation from later selection changes.
    Dim window As Object ' The active window can be an Explorer or an Inspector.
    Dim item As Object ' Outlook selections can contain non-mail objects.
    Dim selected As Outlook.Selection ' Hold the Explorer's current individual-item selection.
    Set window = MailApp().ActiveWindow ' Prefer the window where the user invoked the command.
    If TypeOf window Is Outlook.Inspector Then ' A separate message window acts on that one message.
        Set item = window.CurrentItem ' Read the item in the active pop-out window.
        If TypeOf item Is Outlook.MailItem Then result.Add item ' Ignore appointments and other item types.
    ElseIf TypeOf window Is Outlook.Explorer Then ' A main Outlook window can contain multiple selected messages.
        Set selected = window.Selection ' Capture the selection once.
        For Each item In selected ' Examine each selected row independently.
            If TypeOf item Is Outlook.MailItem Then result.Add item ' Include email messages only.
        Next item ' Continue through the selection.
    End If ' With no active Outlook window, return an empty collection.
    Set PT_SelectedMessages = result ' Return the captured email objects to the caller.
End Function

' Open the complete scrollable macro reference, including manually assigned shortcut suggestions.
Public Sub Settings_ShowMacros()
    Dim panel As frmPersonalOutlook ' Keep the reference separate from any other open form.
    Set panel = New frmPersonalOutlook ' The form builds its controls from its pasted VBA code.
    panel.PrepareCatalog PT_CatalogText() ' Supply the macro list and shortcut explanation.
    panel.Show vbModeless ' Let Outlook remain usable while the reference is open.
End Sub
' Remove all attachments only after the code-built form shows a red, explicit warning.
Public Sub Mail_RemoveAttachments()
    Dim mails As Collection ' Snapshot the selected emails before confirmation.
    Dim item As Outlook.MailItem ' Count and process each selected email.
    Dim panel As frmPersonalOutlook ' Use coloured UserForm labels because a normal MsgBox cannot colour its text red.
    Dim total As Long ' Show the number of attachments about to be removed.
    Dim confirmed As Boolean ' Closing the form must not imply approval.
    Dim successes As Long ' Count successfully saved message changes.
    Dim failures As String ' Keep per-message failures in the final scrolling report.
    Dim failure As String ' Capture one worker error before continuing.
    On Error GoTo Failed ' Handle selection and form failures plainly.
    Set mails = PT_SelectedMessages() ' Use only individual MailItems.
    If mails.Count = 0 Then Err.Raise vbObjectError + 810, "modPersonalOutlookTools.Mail_RemoveAttachments", "Select individual email messages first." ' Refuse an empty target list.
    For Each item In mails ' Count all attachment types, including hidden inline pictures.
        total = total + item.Attachments.Count ' Do not exclude notes or images from a delete-all warning.
    Next item ' Finish the warning's total.
    If total = 0 Then ' Nothing needs deleting or saving.
        Exit Sub ' Do not save unchanged messages.
    End If ' A destructive operation requires explicit confirmation.
    Set panel = New frmPersonalOutlook ' Build a dedicated warning instance.
    panel.PrepareRemoval mails.Count, total ' Show red text and a special multiple-email warning.
    panel.Show vbModal ' Wait for confirmation or cancellation before touching messages.
    confirmed = (panel.Result = 1) ' Only the explicit Delete button produces approval.
    Unload panel ' Release the warning form.
    If Not confirmed Then Exit Sub ' Cancel or X leaves every attachment intact.
    For Each item In mails ' Process the same targets the user was shown.
        If item.Attachments.Count > 0 Then ' Leave attachment-free emails unsaved and unchanged.
            On Error Resume Next ' Read-only or protected emails should not stop the remaining messages.
            Err.Clear ' Keep error reporting specific to this item.
            PT_RemoveFromOne item ' Remove backwards and persist this email's attachment changes.
            failure = PT_ErrorText("Mail_RemoveAttachments", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.Mail_RemoveAttachments") ' Preserve any permission/save failure.
            If Err.Number = 0 Then ' The message change was saved successfully.
                successes = successes + 1 ' Count only persisted removals.
            Else ' Record the actual failed email.
                failures = failures & vbCrLf & item.Subject & ": " & failure ' Do not report partial failure as full success.
            End If ' Continue with the next selected email.
            On Error GoTo Failed ' Restore normal outer error handling.
        End If ' Unchanged emails need no Save call.
    Next item ' Finish all confirmed targets.
    If Len(failures) > 0 Then PT_ShowReport "Remove attachments results", CStr(successes) & " message(s) had all attachments removed and saved." & vbCrLf & failures ' Keep a long failure list scrollable.
    Exit Sub ' No automatic backup or additional mailbox action is performed.
Failed:
    PT_ReportError "Remove attachments", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.Mail_RemoveAttachments" ' Explain why deletion could not start.
End Sub

' The public worker takes an argument, so it is not offered as a bypass in the macro list.
Public Sub PT_RemoveFromOne(ByVal item As Outlook.MailItem)
    Dim index As Long ' Deleting from the end prevents attachment indexes shifting underneath the loop.
    Dim failure As String ' Preserve a failure while discarding uncommitted edits.
    If Len(item.EntryID) = 0 Then Err.Raise vbObjectError + 811, "modPersonalOutlookTools.PT_RemoveFromOne", "Save this new draft yourself before removing its attachments." ' Avoid automatically creating/saving a new mailbox item.
    If Not item.Saved Then Err.Raise vbObjectError + 812, "modPersonalOutlookTools.PT_RemoveFromOne", "Save or discard your existing edits to this email first." ' Do not persist unrelated user edits.
    On Error GoTo Failed ' A failed mailbox write must be reported.
    For index = item.Attachments.Count To 1 Step -1 ' Include visible files, inline pictures and attached notes.
        item.Attachments.Remove index ' Delete exactly this attachment.
    Next index ' Continue until the collection is empty.
    item.Save ' Persist the user-confirmed attachment deletion on this stored EMAIL.
    Exit Sub ' Never send, delete or move the email itself.
Failed:
    failure = PT_ErrorText("PT_RemoveFromOne", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_RemoveFromOne") ' Preserve the permission or attachment error.
    On Error Resume Next ' Attempt to discard uncommitted removals, without masking the original failure.
    Err.Clear ' Do not confuse the rollback result with the original failure still in Err.
    item.Close olDiscard ' The item was confirmed clean beforehand, so no unrelated unsaved edits are discarded.
    If Err.Number <> 0 Then failure = failure & " Unsaved attachment changes could not be discarded; close this email without saving." ' Be explicit if rollback also fails.
    On Error GoTo 0 ' Restore normal errors for the batch caller.
    Err.Raise vbObjectError + 813, "modPersonalOutlookTools.PT_RemoveFromOne", failure ' Report this message as failed.
End Sub

' Export complete .msg emails to a chosen folder with a visible per-message progress bar.
Public Sub Mail_SaveSelectedEmails()
    Dim mails As Collection ' Snapshot targets before the folder/options form takes focus.
    Dim item As Outlook.MailItem ' Export one email at a time.
    Dim options As frmPersonalOutlook ' Collect the user's destination and naming choices.
    Dim progress As frmPersonalOutlook ' Keep progress responsive without a separate ActiveX progress-bar component.
    Dim folder As String ' Use the user's chosen folder; no prescribed setup folder exists.
    Dim prefixKind As Long ' None, custom text, received date or sender name.
    Dim prefixText As String ' Hold any user-entered prefix.
    Dim suffixKind As Long ' Allow a suffix independently of the prefix.
    Dim suffixText As String ' Hold any user-entered suffix.
    Dim overwrite As Boolean ' True means the user explicitly selected overwrite.
    Dim attempted As Long ' Progress advances after each completed or failed attempt.
    Dim successes As Long ' Count successfully committed .msg files.
    Dim failures As Long ' Count failed messages separately.
    Dim report As String ' Keep destination, written filenames and errors in one scrolling result.
    Dim path As String ' Hold the final export path for one email.
    Dim failure As String ' Capture one export error without stopping the whole batch.
    On Error GoTo Failed ' Restore the re-entry guard if any setup-level error occurs.
    If exportRunning Then Err.Raise vbObjectError + 814, "modPersonalOutlookTools.Mail_SaveSelectedEmails", "An export is already running. Wait for it to finish or cancel the remaining messages." ' DoEvents must not allow nested exports.
    Set mails = PT_SelectedMessages() ' Capture only selected emails, preserving their original order.
    If mails.Count = 0 Then Err.Raise vbObjectError + 815, "modPersonalOutlookTools.Mail_SaveSelectedEmails", "Select individual email messages first." ' Require at least one email.
    Set options = New frmPersonalOutlook ' Create the code-built folder/naming chooser.
    options.PrepareExport mails(1) ' Show an actual first-message filename preview.
    options.Show vbModal ' Wait for Save or Cancel.
    If options.Result <> 1 Then ' Title-bar X and Cancel produce no export.
        Unload options ' Release the cancelled form.
        Exit Sub ' No output files are created.
    End If ' The user has chosen the concrete export settings.
    folder = options.DestinationFolder ' Copy settings before unloading their form.
    prefixKind = options.PrefixKind ' Keep the independent prefix choice.
    prefixText = options.PrefixText ' Keep custom prefix text exactly as entered until filename cleaning.
    suffixKind = options.SuffixKind ' Keep the independent suffix choice.
    suffixText = options.SuffixText ' Keep custom suffix text.
    overwrite = options.OverwriteExisting ' The default is numbered copies, not overwrite.
    Unload options ' Release the settings form once captured.
    exportRunning = True ' Block another export while progress yields to the UI.
    Set progress = New frmPersonalOutlook ' Build progress from ordinary labels and a frame.
    progress.PrepareProgress mails.Count ' Start at zero completed messages.
    progress.Show vbModeless ' Allow repainting and cancellation between messages.
    report = "Folder: " & folder & vbCrLf ' Record the exact chosen destination in the on-screen result.
    For Each item In mails ' Attempt one .msg export per captured email.
        If progress.CancelRequested Then Exit For ' Cancellation stops remaining messages without deleting completed exports.
        progress.UpdateProgress attempted, mails.Count, "Saving: " & item.Subject ' Paint the current item before the potentially slow SaveAs call.
        If progress.CancelRequested Then Exit For ' Honour cancellation received during the repaint.
        On Error Resume Next ' An inaccessible message should not abort all later exports.
        Err.Clear ' Make the next failure specific to this email.
        path = PT_ExportOne(item, folder, prefixKind, prefixText, suffixKind, suffixText, overwrite) ' Save the complete email, including attachments.
        failure = PT_ErrorText("Mail_SaveSelectedEmails", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.Mail_SaveSelectedEmails") ' Capture the reason before returning to outer handling.
        If Err.Number = 0 Then ' Only count a successfully committed final file.
            successes = successes + 1 ' Count complete exported messages.
            report = report & vbCrLf & "Saved: " & path ' Show the final name, including any (2) collision suffix.
        Else ' Keep failed attempts separate from successful files.
            failures = failures + 1 ' Track the failed-message total.
            report = report & vbCrLf & "FAILED: " & item.Subject & " - " & failure ' Preserve the useful error detail.
        End If ' Continue with the remaining messages.
        On Error GoTo Failed ' Restore outer error handling after this attempt.
        attempted = attempted + 1 ' Advance progress only after the attempt ends.
        progress.UpdateProgress attempted, mails.Count, CStr(successes) & " saved; " & CStr(failures) & " failed" ' Display actual completed work.
    Next item ' Continue until done or the user cancels remaining work.
    report = CStr(successes) & " saved; " & CStr(failures) & " failed; " & CStr(mails.Count - attempted) & " not attempted." & vbCrLf & vbCrLf & report ' Report cancellation/partial completion truthfully.
    If failures = 0 And attempted = mails.Count Then
        Unload progress
    Else
        progress.FinishProgress report
    End If ' Replace the running view with a scrollable result and Close button.
    exportRunning = False ' The next user-requested export may now start.
    Exit Sub ' Do not alter, save to the mailbox, move or delete source emails.
Failed:
    failure = PT_ErrorText("Mail_SaveSelectedEmails", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.Mail_SaveSelectedEmails") ' Preserve the setup-level failure.
    exportRunning = False ' Always release the re-entry guard.
    If Not progress Is Nothing Then progress.FinishProgress "Stopped: " & failure & vbCrLf & report ' Keep completed-file details visible after a failure.
    MsgBox failure, vbExclamation, "Save selected emails" ' Explain why the batch could not continue.
End Sub

' Save into a temporary name in the CHOSEN folder, then rename the complete file into place.
' This avoids destroying an existing destination file if Outlook's SaveAs fails partway.
Public Function PT_ExportOne(ByVal item As Outlook.MailItem, ByVal folder As String, ByVal prefixKind As Long, ByVal prefixText As String, ByVal suffixKind As Long, ByVal suffixText As String, ByVal overwrite As Boolean) As String
    Dim fso As Object ' Late-bound Windows filesystem operations require no extra reference.
    Dim target As String ' The requested final filename, possibly with a numbered collision suffix.
    Dim stage As String ' A unique temporary .msg in the same destination folder/volume.
    Dim flags As Long ' Control whether the final rename may replace an existing file.
    Dim failure As String ' Keep the actual error while cleaning a failed staged export.
    On Error GoTo Failed ' A failure removes only the staging file, not an existing final file.
    Set fso = CreateObject("Scripting.FileSystemObject") ' Use Windows' existing filesystem component.
    If Not fso.FolderExists(folder) Then Err.Raise vbObjectError + 816, "modPersonalOutlookTools.PT_ExportOne", "The destination folder does not exist." ' Do not create an unexpected directory tree.
    target = PT_ChooseExportPath(folder, PT_ExportFileName(item, prefixKind, prefixText, suffixKind, suffixText), overwrite) ' Apply safe names and the chosen collision rule.
    Do ' Reserve an unused staging path rather than replacing somebody else's temporary file.
        stage = fso.BuildPath(folder, "~POMv2-" & fso.GetTempName & ".msg") ' Keep staging on the same volume for an atomic rename.
    Loop While fso.FileExists(stage) Or fso.FolderExists(stage) ' A rare random-name collision simply gets another name.
    item.SaveAs stage, olMSGUnicode ' Store the complete Outlook message and its attachments in Unicode .msg format.
    If Not fso.FileExists(stage) Then Err.Raise vbObjectError + 817, "modPersonalOutlookTools.PT_ExportOne", "Outlook did not create an export file." ' Do not claim an unwritten export succeeded.
    If fso.GetFile(stage).Size = 0 Then Err.Raise vbObjectError + 818, "modPersonalOutlookTools.PT_ExportOne", "Outlook created an empty export file." ' Refuse an obviously incomplete export.
    flags = &H8 ' MOVEFILE_WRITE_THROUGH waits for the move operation to complete.
    If overwrite Then flags = flags Or &H1 ' MOVEFILE_REPLACE_EXISTING is enabled only by the user's explicit choice.
    If MoveFileExW(StrPtr(stage), StrPtr(target), flags) = 0 Then Err.Raise vbObjectError + 819, "modPersonalOutlookTools.PT_ExportOne", "Could not commit the export (Windows error " & CStr(Err.LastDllError) & ")." ' Never fake success if a rename, lock or collision prevents completion.
    PT_ExportOne = target ' Return the actual committed filename.
    Exit Function ' Source mailbox content is never saved or changed by exporting.
Failed:
    failure = PT_ErrorText("PT_ExportOne", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_ExportOne") ' Keep the original SaveAs/rename error.
    On Error Resume Next ' Cleanup failure must not hide the useful error.
    If Len(stage) > 0 Then ' Only the unique path created by this function may be cleaned up.
        If Not fso Is Nothing Then ' Filesystem creation itself may have failed.
            If fso.FileExists(stage) Then fso.DeleteFile stage, True ' Remove a partial staged export; never touch the existing final file here.
        End If ' Leave unrelated files alone.
    End If ' No stage path means nothing needs deleting.
    On Error GoTo 0 ' Restore normal error behaviour.
    Err.Raise vbObjectError + 820, "modPersonalOutlookTools.PT_ExportOne", failure ' Let the batch show this export as failed.
End Function

' Compose independent prefix/suffix choices around the original subject.
Public Function PT_ExportFileName(ByVal item As Outlook.MailItem, ByVal prefixKind As Long, ByVal prefixText As String, ByVal suffixKind As Long, ByVal suffixText As String) As String
    Dim stem As String ' Build the filename without its mandatory .msg extension.
    Dim part As String ' Hold each optional component.
    part = PT_NamePart(item, prefixKind, prefixText) ' Get the selected prefix source.
    If Len(part) > 0 Then stem = part & " - " ' Add a separator only when a prefix exists.
    stem = stem & item.Subject ' Keep the subject as the core filename.
    part = PT_NamePart(item, suffixKind, suffixText) ' Obtain the suffix independently of the prefix.
    If Len(part) > 0 Then stem = stem & " - " & part ' Add the suffix only when requested.
    PT_ExportFileName = PT_SafeFileName(stem) & ".msg" ' Clean Windows-invalid characters and always use .msg.
End Function

' Native combo choices use indexes 0-3: none, custom, received date, sender name.
Private Function PT_NamePart(ByVal item As Outlook.MailItem, ByVal kind As Long, ByVal custom As String) As String
    Dim received As Date ' Outlook sometimes uses a far-future placeholder for an unsent draft's ReceivedTime.
    Select Case kind ' Keep the options explicit rather than evaluating arbitrary filename templates.
        Case 1 ' User-supplied text is treated as literal filename content.
            PT_NamePart = Trim$(custom) ' Avoid a separator-only component from surrounding spaces.
        Case 2 ' Date naming uses received date, with creation date for an unsent placeholder.
            received = item.ReceivedTime ' Prefer the email's received date.
            If Year(received) > 4000 Then received = item.CreationTime ' Drafts may lack a meaningful received date.
            PT_NamePart = Format$(received, "yyyy-mm-dd") ' Use a sortable unambiguous date prefix/suffix.
        Case 3 ' Sender naming uses Outlook's displayed sender name.
            PT_NamePart = Trim$(item.SenderName) ' Blank sender names produce no extra separator.
        Case Else ' None or an unsupported index produces no component.
            PT_NamePart = "" ' Do not invent extra filename content.
    End Select ' Return the chosen literal component.
End Function

' Respect overwrite or append-(2), while keeping paths within conservative Outlook/Windows limits.
Public Function PT_ChooseExportPath(ByVal folder As String, ByVal filename As String, ByVal overwrite As Boolean) As String
    Dim fso As Object ' Check both files and directories occupying a name.
    Dim stem As String ' Preserve the .msg extension while shortening an overlong subject.
    Dim target As String ' Hold the candidate full path.
    Dim suffix As String ' Add the user-requested numbered collision marker when needed.
    Dim number As Long ' Start duplicate filenames at (2), then (3), and so on.
    Dim limit As Long ' Leave room for the extension, separator and an ordinary collision suffix.
    Set fso = CreateObject("Scripting.FileSystemObject") ' No manual reference is required.
    folder = fso.GetAbsolutePathName(folder) ' Resolve the chosen folder to an absolute filesystem path.
    limit = 230 - Len(folder) - 1 - 4 - 16 ' Keep complete paths short enough for older Outlook save behaviour.
    If limit < 12 Then Err.Raise vbObjectError + 821, "modPersonalOutlookTools.PT_ChooseExportPath", "This destination path is too long for Outlook. Choose a shorter folder path." ' Explain the real limitation instead of silently failing.
    If limit > 160 Then limit = 160 ' Bound very long subjects to practical filenames.
    stem = PT_SafeFileName(fso.GetBaseName(filename)) ' Remove the extension before adding a collision suffix.
    stem = Left$(stem, limit) ' Shorten only the filename, not the chosen folder.
    stem = PT_SafeFileName(stem) ' Truncation may expose a trailing dot/space; clean it again.
    target = fso.BuildPath(folder, stem & ".msg") ' Construct the primary final path.
    If overwrite Then ' The user explicitly allowed replacing a file with this name.
        If fso.FolderExists(target) Then Err.Raise vbObjectError + 822, "modPersonalOutlookTools.PT_ChooseExportPath", "A folder already uses this export filename." ' Never replace a directory.
    Else ' Keep both existing files and every same-name email in the current batch.
        number = 1 ' The first conflict becomes copy number 2.
        Do While fso.FileExists(target) Or fso.FolderExists(target) ' Avoid collisions with files and directories alike.
            number = number + 1 ' Advance to the next available copy number.
            suffix = " (" & CStr(number) & ")" ' Match the requested Windows-style (2) naming.
            target = fso.BuildPath(folder, stem & suffix & ".msg") ' Keep the number before the extension.
        Loop ' Continue until a free filename is found.
    End If ' The final rename still refuses an unexpected race when overwrite is false.
    PT_ChooseExportPath = target ' Return the exact path the export will attempt.
End Function

' Show long outcomes in a read-only scrolling window instead of truncating a MsgBox.


' Read optional attachment metadata without treating its absence as a copy failure.
Private Function PT_TryAttachmentProperty(ByVal attachment As Outlook.Attachment, ByVal property As String, ByRef value As Variant) As Boolean
    On Error GoTo Missing ' Many ordinary attachments legitimately lack inline metadata.
    value = attachment.PropertyAccessor.GetProperty(property) ' Read the requested MAPI property.
    PT_TryAttachmentProperty = True ' Only True permits the caller to use value.
Missing:
End Function

' Convert an optional metadata string to empty text when it is absent.
Private Function PT_PropertyText(ByVal attachment As Outlook.Attachment, ByVal property As String) As String
    Dim value As Variant ' Preserve the property's actual returned type until it is known to exist.
    If PT_TryAttachmentProperty(attachment, property, value) Then PT_PropertyText = CStr(value) ' An absent optional string returns empty; classification also checks other body markers.
End Function

' Choose a safe extracted filename; embedded Outlook items need a .msg extension.
Private Function PT_AttachmentFileName(ByVal attachment As Outlook.Attachment, ByVal index As Long) As String
    Dim name As String ' Keep the original name when available.
    name = attachment.FileName ' Read the actual attachment name, including added notes.
    If Len(name) = 0 Then name = "Attachment-" & CStr(index) ' Provide a stable fallback for unusual unnamed attachments.
    If attachment.Type = olEmbeddeditem And LCase$(Right$(name, 4)) <> ".msg" Then name = name & ".msg" ' Preserve embedded messages in the format Attachments.Add understands.
    PT_AttachmentFileName = PT_SafeFileName(name) ' Remove characters Windows cannot use in a filename.
End Function

' Compare files in small byte blocks so large attachments are not loaded wholly into memory.
Private Function PT_FilesEqual(ByVal first As String, ByVal second As String) As Boolean
    Dim leftFile As Integer ' Native binary handles allow bounded-memory reads without another component.
    Dim rightFile As Integer ' Read the candidate alongside the source.
    Dim leftOpen As Boolean ' Close only a successfully opened source handle.
    Dim rightOpen As Boolean ' Track successful candidate opening independently.
    Dim leftBytes() As Byte ' Hold only the current small source block.
    Dim rightBytes() As Byte ' Hold the corresponding candidate block.
    Dim remaining As Long ' Track the source bytes still to compare.
    Dim blockSize As Long ' Read no more than 64 KiB at a time.
    On Error GoTo Finished ' An unreadable candidate cannot be considered a match.
    leftFile = FreeFile ' Reserve an unused VBA file number.
    Open first For Binary Access Read As #leftFile ' Read the actual source bytes.
    leftOpen = True ' Cleanup may now close this handle.
    rightFile = FreeFile ' Reserve a different file number while the first remains open.
    Open second For Binary Access Read As #rightFile ' Read the candidate without charset conversion.
    rightOpen = True ' Track successful candidate opening.
    If LOF(leftFile) <> LOF(rightFile) Then GoTo Finished ' Different byte lengths prove the attachments differ.
    remaining = LOF(leftFile) ' Empty files need no block reads.
    Do While remaining > 0 ' Compare the complete payload before accepting equality.
        blockSize = remaining ' The final block may contain fewer than 64 KiB.
        If blockSize > 65536 Then blockSize = 65536 ' Bound memory use per comparison block.
        ReDim leftBytes(0 To blockSize - 1) ' Allocate exactly the source block size.
        ReDim rightBytes(0 To blockSize - 1) ' Allocate the matching candidate block size.
        Get #leftFile, , leftBytes ' Read the next raw source block.
        Get #rightFile, , rightBytes ' Read the corresponding candidate block.
        ' Native comparison is binary-safe (including NUL bytes) and much faster than a VBA byte loop.
        If RtlCompareMemory(leftBytes(0), rightBytes(0), blockSize) <> blockSize Then GoTo Finished
        remaining = remaining - blockSize ' Advance only after comparing the entire block.
    Loop ' Compare all remaining blocks.
    PT_FilesEqual = True ' Complete contents match, not merely names or lengths.
Finished:
    On Error Resume Next ' Cleanup must not mask a file access failure.
    If leftOpen Then Close #leftFile ' Release the source handle even after a mismatch.
    If rightOpen Then Close #rightFile ' Release the candidate handle as well.
    On Error GoTo 0 ' Restore ordinary error handling for the caller.
End Function

' Use Windows' ordinary multi-file picker; no Excel instance or special folder is required.
Public Function PT_BrowseFiles(Optional ByVal owner As Variant) As Collection
    Dim chosen As New Collection ' Cancellation returns an empty collection.
    Dim data As OPENFILENAMEW ' Supply the exact Windows dialog structure.
    Dim buffer As String ' Hold one full path, or a folder followed by multiple filenames.
    Dim filter As String ' Keep the filter string alive while Windows reads its pointer.
    Dim title As String ' Keep the dialog title string alive too.
    Dim parts As Variant ' Parse the null-separated Unicode output.
    Dim index As Long ' Walk the selected names in multi-file mode.
    Dim errorCode As Long ' Report native picker errors without confusing them with Cancel.
    buffer = String$(65536, vbNullChar) ' Reserve space for many selected paths.
    filter = "All files (*.*)" & vbNullChar & "*.*" & vbNullChar & vbNullChar ' Windows requires a double-null terminator.
    title = "Choose files to attach" ' Let the user start from any folder Windows normally offers.
    data.lStructSize = LenB(data) ' Include the correct 32/64-bit native structure size.
    If IsMissing(owner) Then owner = GetAncestor(GetActiveWindow(), 3)
    If IsWindow(owner) <> 0 Then data.hwndOwner = owner ' A live root owner avoids handing the dialog a transient navigation flyout or disposed form handle.
    data.lpstrFilter = StrPtr(filter) ' Pass a Unicode pointer, avoiding ANSI filename corruption.
    data.nFilterIndex = 1 ' Select the All files filter.
    data.lpstrFile = StrPtr(buffer) ' Supply the writable Unicode path buffer.
    data.nMaxFile = Len(buffer) ' Windows expects a character count here.
    data.lpstrTitle = StrPtr(title) ' Supply the dialog caption.
    data.flags = &H80000 Or &H200 Or &H1000 Or &H800 Or &H8 ' Explorer mode, multiple selection, existing file/path checks, and no working-directory change.
    If GetOpenFileNameW(data) = 0 Then ' Zero means either Cancel or a native dialog error.
        errorCode = CommDlgExtendedError() ' A zero extended error means ordinary user cancellation.
        If errorCode <> 0 Then Err.Raise vbObjectError + 823, "modPersonalOutlookTools.PT_BrowseFiles", "The file picker failed (Windows code " & CStr(errorCode) & ")." ' Do not pretend an error was a cancellation.
    Else ' Parse the successfully returned selection.
        parts = Split(buffer, vbNullChar) ' Windows separates folder/filenames using null characters.
        If Len(parts(1)) = 0 Then ' A single selected file is returned as one full path.
            chosen.Add CStr(parts(0)) ' Keep the complete Unicode path.
        Else ' Multiple selections start with a common folder.
            index = 1 ' Filenames start after the folder component.
            Do While Len(parts(index)) > 0 ' The final empty component terminates the list.
                chosen.Add CStr(parts(0)) & "\" & CStr(parts(index)) ' Build each selected file's complete path.
                index = index + 1 ' Advance to the next filename.
            Loop ' Keep every selected file in the list.
        End If ' Single and multiple selections now have the same collection format.
    End If ' Cancellation simply leaves the collection empty.
    Set PT_BrowseFiles = chosen ' Return the chosen file paths.
End Function

' Allow native-structure validation without displaying the file picker.
Public Function PT_FilePickerStructureBytes() As Long
    Dim data As OPENFILENAMEW ' Allocate the same structure the real picker uses.
    PT_FilePickerStructureBytes = LenB(data) ' Expected size is 152 bytes on 64-bit Office, 88 on 32-bit Office.
End Function

' Make a Windows-safe filename while retaining Unicode and the user's readable wording.
Public Function PT_SafeFileName(ByVal name As String) As String
    Dim bad As Variant ' Enumerate Windows' forbidden filename characters.
    Dim index As Long ' Remove control characters as well as punctuation.
    Dim stem As String ' Windows reserves device names even when they have extensions.
    name = Trim$(name) ' Strip accidental leading/trailing spaces.
    For Each bad In Array("\", "/", ":", "*", "?", """", "<", ">", "|") ' These characters cannot be used in ordinary Windows filenames.
        name = Replace(name, CStr(bad), "_") ' Substitute rather than silently remove meaningful separators.
    Next bad ' Clean every forbidden punctuation character.
    For index = 0 To 31 ' Windows also forbids these control characters.
        name = Replace(name, ChrW(index), "_") ' Keep the resulting filename single-line and valid.
    Next index ' Finish control-character cleaning.
    name = Left$(name, 160) ' Bound subject-derived names before later path-length handling.
    Do While Len(name) > 0 ' Truncation may leave a trailing dot or space.
        If Right$(name, 1) <> "." And Right$(name, 1) <> " " Then Exit Do ' Stop when the last character is valid.
        name = Left$(name, Len(name) - 1) ' Remove one invalid trailing character.
    Loop ' Repeat until valid or empty.
    If Len(name) = 0 Then name = "Message" ' A blank subject still needs a usable filename.
    stem = UCase$(Split(name, ".")(0)) ' Check the device-name component before the first dot.
    If stem = "CON" Or stem = "PRN" Or stem = "AUX" Or stem = "NUL" Or stem Like "COM[1-9]" Or stem Like "LPT[1-9]" Or stem Like "COM[���]" Or stem Like "LPT[���]" Then name = "File-" & name ' Avoid Windows reserved device names, including their superscript forms.
    PT_SafeFileName = name ' Return the safe single filename component, never a folder path.
End Function

' Own a uniquely named folder under Windows TEMP; callers never choose this internal location.
Public Function PT_CreateTempFolder() As String
    Dim fso As Object ' Late-bound filesystem access needs no setup reference.
    Dim folder As String ' Hold the candidate path.
    Set fso = CreateObject("Scripting.FileSystemObject") ' Use the existing Windows component.
    Do ' Rare random collisions must not overwrite an existing folder.
        folder = fso.GetSpecialFolder(2).Path & "\PersonalOfficeMacrosV6-" & fso.GetTempName ' Use a distinctive owned prefix under the actual TEMP directory.
    Loop While fso.FileExists(folder) Or fso.FolderExists(folder) ' Retry if either a file or a directory already occupies the path.
    fso.CreateFolder folder ' Create only this unique internal working folder.
    PT_CreateTempFolder = folder ' Return ownership to the caller for later cleanup.
End Function

' Restrict recursive cleanup to a single direct TEMP child with this package's exact prefix.
Public Sub PT_CleanTemp(ByVal folder As String)
    Dim fso As Object ' Resolve paths before any recursive deletion.
    Dim root As String ' Hold the intended exact parent directory.
    Dim resolved As String ' Hold the final absolute cleanup target.
    Dim leaf As String ' Check the owned basename, not a loose path prefix.
    On Error Resume Next ' A locked temp file should not mask the real operation result.
    Set fso = CreateObject("Scripting.FileSystemObject") ' Use native Windows filesystem access.
    root = fso.GetAbsolutePathName(fso.GetSpecialFolder(2).Path) ' Resolve the actual TEMP root.
    resolved = fso.GetAbsolutePathName(folder) ' Canonicalise the target before checking it.
    leaf = fso.GetFileName(resolved) ' Inspect only the single direct child's name.
    If StrComp(fso.GetParentFolderName(resolved), root, vbTextCompare) = 0 Then ' The absolute parent MUST be exactly Windows TEMP.
        If Left$(leaf, Len("PersonalOfficeMacrosV6-")) = "PersonalOfficeMacrosV6-" Then ' A matching owned prefix is also required.
            If Len(leaf) > Len("PersonalOfficeMacrosV6-") Then ' Never delete a bare prefix directory.
                If fso.FolderExists(resolved) Then fso.DeleteFolder resolved, True ' Delete only the verified owned working folder.
            End If ' A missing unique suffix cannot be a valid generated target.
        End If ' Other TEMP folders are never cleanup targets.
    End If ' Paths outside TEMP and nested paths are never deleted.
    On Error GoTo 0 ' Restore normal error behaviour for the caller.
End Sub

' Outlook has no Excel-style shortcut assignment; native QAT positions provide Alt key tips.
Public Function PT_CatalogText() As String
    Dim text As String
    text = "Classic Outlook personal macros" & vbCrLf & "Command | suggested ribbon label | status" & vbCrLf
    text = text & vbCrLf & "Mail_CountSelectedMessages  |  _CountSelectedMessages  |  Done" & vbCrLf & "Count the individual emails in the current selection or the open email." & vbCrLf
    text = text & vbCrLf & "Mail_AddAttachmentOrNote  |  _AddAttachmentOrNote  |  Updated" & vbCrLf & "Add files or a rich note to selected emails. Its Copy attachments button lets you choose a source and a different destination." & vbCrLf
    text = text & vbCrLf & "Mail_AddFolderSummary  |  _AddFolderSummary  |  Updated" & vbCrLf & "Open an editable summary post in the current filing folder, using the saved summary template." & vbCrLf
    text = text & vbCrLf & "Mail_CategoriseEmails  |  _CategoriseEmails  |  Updated" & vbCrLf & "Apply several Outlook categories and custom category notes to the selected emails." & vbCrLf
    text = text & vbCrLf & "Mail_CleanEmailChains  |  _CleanEmailChains  |  Updated" & vbCrLf & "Find linked or similar emails across the chosen locations. Review protected items and attachment evidence before moving or deleting checked mail." & vbCrLf
    text = text & vbCrLf & "Mail_FollowUp  |  _FollowUp  |  Updated" & vbCrLf & "Create or update an Outlook task, link selected emails in date order and synchronise their completion." & vbCrLf
    text = text & vbCrLf & "Mail_MoveSelectedItems  |  _MoveSelectedItems  |  Updated" & vbCrLf & "Move or copy the selection, set its read state and apply categories in one window." & vbCrLf
    text = text & vbCrLf & "Mail_RemoveAttachments  |  _RemoveAttachments  |  Done" & vbCrLf & "Remove all attachments, including inline pictures and notes, after explicit acknowledgement." & vbCrLf
    text = text & vbCrLf & "Mail_ReplyWithAttachments  |  _ReplyWithAttachments  |  Updated" & vbCrLf & "Prepare verified Reply or Reply All drafts with ordinary attachments and a progress bar. Review them before sending." & vbCrLf
    text = text & vbCrLf & "Mail_RunRules  |  _RunRules  |  Done" & vbCrLf & "Run enabled rules assigned to RunRules, including earlier open/close rules that retain that choice." & vbCrLf
    text = text & vbCrLf & "Mail_SaveSelectedEmails  |  _SaveSelectedEmails  |  Done" & vbCrLf & "Export complete emails as .msg files with a filename preview and a choice for existing files." & vbCrLf
    text = text & vbCrLf & "Settings_AlertsToggle  |  Settings_AlertsToggle  |  New" & vbCrLf & "Pause or resume notification monitoring for this Outlook profile and show its new state." & vbCrLf
    text = text & vbCrLf & "Settings_ConfigureFolderRules  |  Settings_ConfigureFolderRules  |  Updated" & vbCrLf & "Set rule priority, triggers, folder actions and destinations. Preview or run one rule, or double-click its row for the last result." & vbCrLf
    text = text & vbCrLf & "Settings_ConfigureMailAlerts  |  Settings_ConfigureMailAlerts  |  Updated" & vbCrLf & "Set monitored folders, match criteria, popup appearance and unlock behaviour for each notification rule." & vbCrLf
    text = text & vbCrLf & "Settings_CreateUnreadOrRecentSearchFolder  |  Settings_CreateUnreadOrRecentSearchFolder  |  Updated" & vbCrLf & "Build a saved unread-or-recent view using a separate day window and subfolder choice for each location." & vbCrLf
    text = text & vbCrLf & "Settings_EditRuleNoteTemplate  |  Settings_EditRuleNoteTemplate  |  Updated" & vbCrLf & "Manage reusable notes and create categories for folder rules, Categorise emails and Move selected items." & vbCrLf
    text = text & vbCrLf & "Settings_EditSummaryTemplate  |  Settings_EditSummaryTemplate  |  Done" & vbCrLf & "Edit the default subject and body for folder-summary posts." & vbCrLf
    text = text & vbCrLf & "Settings_ShowMacros  |  Settings_ShowMacros  |  Done" & vbCrLf & "Read the command list, suggested ribbon labels, effects and completion status." & vbCrLf
    text = text & vbCrLf & "Customise the Ribbon or Quick Access Toolbar in Outlook Options to assign these commands. Use Rename for the display label. Copy attachments is available inside Add attachment or note."
    PT_CatalogText = text
End Function

' Show exactly the requested count text and a Close button, without explanatory extras.
Public Sub Mail_CountSelectedMessages()
    Dim mails As Collection ' Hold the selected individual email objects.
    Dim panel As frmPersonalOutlook ' Use a plain small form because MsgBox's button says OK, not Close.
    On Error GoTo Failed ' Report a real Outlook selection error if one occurs.
    Set mails = PT_SelectedMessages() ' An open email counts as one; non-mail rows do not count.
    Set panel = New frmPersonalOutlook ' Create a new snapshot counter.
    panel.PrepareCount mails.Count ' Its only body text is the requested sentence.
    panel.Show vbModeless ' Preserve the original modeless-count behaviour.
    Exit Sub ' No mailbox or file changes occur.
Failed:
    PT_ReportError "Outlook personal macros", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.Mail_CountSelectedMessages" ' Use a normal error dialog only if counting failed.
End Sub

' Offer the familiar file-attachment action or Outlook's own full rich-note editor.
Public Sub Mail_AddAttachmentOrNote()
    Dim mails As Collection, panel As frmPersonalOutlook, choice As Long, files As Collection
    Dim ui As Object, number As Long, description As String, origin As String
    If attachmentRunning Then Exit Sub ' A second click must not replace the captured selection or dialog owner.
    attachmentRunning = True
    On Error GoTo Failed
    Set ui = PT_CaptureExplorerUI()
    DeferNotificationCards ' Queue incoming popups while the modal form and Windows picker own the Outlook UI.
    Set mails = PT_SelectedMessages()
    
    Set panel = New frmPersonalOutlook
    panel.PrepareAddChoice mails.Count
    panel.Show vbModal
    choice = panel.Result
    Unload panel: Set panel = Nothing
    If choice = 1 Then
        Set files = PT_BrowseFiles(ui("owner"))
        If files.Count > 0 Then PT_AddFilesToMessages mails, files
    ElseIf choice = 2 Then
        PT_BeginNewNote mails
    ElseIf choice = 3 Then
        StartCopyPicker mails
    End If
Finished:
    On Error Resume Next
    If Not panel Is Nothing Then Unload panel
    PT_RestoreExplorerUI ui
    ReleaseNotificationCards ' The timer resumes popups after this command returns, rather than inside an Outlook save/send callback.
    attachmentRunning = False
    On Error GoTo 0
    If number <> 0 Then PT_ReportError "Add attachment or note", number, description, origin, "modPersonalOutlookTools.Mail_AddAttachmentOrNote"
    Exit Sub
Failed:
    number = Err.Number: description = Err.Description: origin = Err.Source
    Resume Finished
End Sub

' Attach a finished rich note as a complete .msg container, preserving its inline images.
' Return True only once the note has been processed; False keeps the editor open for correction.
Public Function PT_ApplyRichNote(ByVal mails As Collection, ByVal editor As Outlook.MailItem) As Boolean
    Dim temp As String ' Own one temporary folder for the note's exported .msg.
    Dim path As String ' Use the note subject as a safe filename.
    Dim files As New Collection ' Reuse the ordinary attachment worker.
    Dim failure As String ' Preserve an error before cleaning up temporary files.
    On Error GoTo Failed ' A closed/invalid editor or save failure leaves targets unchanged.
    If editor.Recipients.Count > 0 Then Err.Raise vbObjectError + 802, "modPersonalOutlookTools.PT_ApplyRichNote", "Remove all recipients from the note. Use Send in the tracked note editor to apply it." ' A note is an attachment, not an outbound email.
    If Len(Trim$(Replace(editor.Body, ChrW(160), " "))) = 0 And editor.Attachments.Count = 0 Then Err.Raise vbObjectError + 803, "modPersonalOutlookTools.PT_ApplyRichNote", "Write your note or insert a picture before attaching it." ' Avoid adding an empty note accidentally.
    temp = PT_CreateTempFolder() ' Export only to a uniquely owned temporary folder.
    path = temp & "\" & PT_SafeFileName(editor.Subject) & ".msg" ' Keep rich content in a single Outlook-readable file.
    editor.SaveAs path, olMSGUnicode ' Preserve HTML, embedded pictures, hyperlinks and any attached files together.
    files.Add path ' Treat the complete note as one file attachment.
    PT_AddFilesToMessages mails, files, True ' Keep only failed targets, so a retry does not duplicate notes on successes.
    If mails.Count > 0 Then ' Preserve the composed note when any target could not be updated.
        PT_CleanTemp temp ' The editor still owns the complete rich note.
        Exit Function ' Return False and keep the note editor open for the remaining targets.
    End If ' Close the editor only after all captured targets succeed.
    If Not pendingNoteInSend Then editor.Close olDiscard ' Close the composing note without sending; Outlook may retain a saved/autosaved draft.
    PT_CleanTemp temp ' Remove only this macro's own temporary folder.
    PT_ApplyRichNote = True ' Let PT_SaveNote release the captured workflow after processing.
    Exit Function ' This note workflow never sends the composed note.
Failed:
    failure = PT_ErrorText("PT_ApplyRichNote", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_ApplyRichNote") ' Keep the meaningful cause before cleanup.
    If Len(temp) > 0 Then PT_CleanTemp temp ' Avoid leaving an exported rich note in the temp folder.
    MsgBox failure, vbExclamation, "Attach rich note" ' Keep the note editor available so the user can correct the problem.
End Function

' Apply one file list to the original snapshot of target messages.
Public Sub PT_AddFilesToMessages(ByVal mails As Collection, ByVal files As Collection, Optional ByVal keepOnlyFailures As Boolean = False)
    Dim item As Outlook.MailItem, successes As Long, failures As String, failure As String
    Dim index As Long, total As Long, ui As Object, number As Long, description As String, origin As String
    Dim ref As Variant, itemLabel As String
    On Error GoTo Failed
    Set ui = PT_CaptureExplorerUI(): DeferNotificationCards ' Standalone note saves use the same balanced protection as the attachment chooser.
    total = mails.Count
    For index = mails.Count To 1 Step -1
        Set item = Nothing: itemLabel = "Email " & index
        On Error Resume Next
        Err.Clear
        If IsObject(mails(index)) Then
            Set item = mails(index)
            If Not item Is Nothing Then itemLabel = item.Subject
        Else
            ref = mails(index): itemLabel = CStr(ref(2))
            Set item = MailApp().Session.GetItemFromID(CStr(ref(0)), CStr(ref(1)))
        End If
        If Err.Number = 0 Then
            If item Is Nothing Then Err.Raise 5, , "This email is no longer available in its original mailbox."
        End If
        If Err.Number = 0 Then PT_AddFilesToOne item, files
        number = Err.Number ' Preserve the result before building a diagnostic can touch Err.
        failure = PT_ErrorText(IIf(keepOnlyFailures, "Attach your rich note", "Attach files"), number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_AddFilesToMessages")
        If number = 0 Then
            successes = successes + 1
            If keepOnlyFailures Then mails.Remove index
        Else
            failures = failures & vbCrLf & itemLabel & ": " & failure
        End If
        On Error GoTo Failed
    Next index
    number = 0
Finished:
    PT_RestoreExplorerUI ui: ReleaseNotificationCards
    If number <> 0 Then Err.Raise number, origin, description ' Report the original failure only after releasing popup deferral and restoring the pane.
    If Len(failures) > 0 Then
        Dim title As String, summary As String
        title = IIf(keepOnlyFailures, "Your note is still open", "Attachment update")
        summary = successes & " of " & total & " email(s) updated."
        If keepOnlyFailures Then summary = summary & " Your note is available to retry only the remaining emails."
        PT_ShowReport title, summary & vbCrLf & failures
    End If
    Exit Sub
Failed:
    number = Err.Number: description = Err.Description: origin = Err.Source
    Resume Finished
End Sub

' Save additions to stored emails so a later Reply All reads their current attachments.
' Resolve stored targets by ID and ask before committing or discarding pending edits.
Public Sub PT_AddFilesToOne(ByVal item As Outlook.MailItem, ByVal files As Collection)
    Dim file As Variant ' File paths in the collection are strings wrapped in variants.
    Dim before As Long ' Roll back only attachments added by this operation if it fails.
    Dim stored As Boolean ' An unsaved new draft should remain unsaved.
    Dim failure As String ' Preserve the original error while undoing uncommitted additions.
    Dim fso As Object ' Validate every input file before modifying the email.
    Set fso = CreateObject("Scripting.FileSystemObject") ' Late binding avoids a manual Scripting Runtime reference.
    stored = (Len(item.EntryID) > 0) ' A stored email has a stable mailbox identifier.
    If stored Then Set item = EditableItem(item)
    For Each file In files ' Check the entire file list before adding its first item.
        If Not fso.FileExists(CStr(file)) Then Err.Raise vbObjectError + 805, "modPersonalOutlookTools.PT_AddFilesToOne", "Attachment file not found: " & CStr(file) ' Fail before partially updating the email.
    Next file ' All files must exist.
    before = item.Attachments.Count ' Keep original attachments intact on rollback.
    On Error GoTo Failed ' Roll back newly added attachments on an add/save failure.
    For Each file In files ' Add all files, including .msg rich notes and ordinary .txt notes.
        item.Attachments.Add CStr(file), olByValue ' Embed the file contents rather than linking to a temporary path.
    Next file ' Complete the full list for this email.
    If stored Then item.Save ' Commit stored mail. The owner of a new draft decides when to save it.
    Exit Sub ' A new unsaved draft is left for the user to save/send manually.
Failed:
    failure = PT_ErrorText("PT_AddFilesToOne", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_AddFilesToOne") ' Capture the real add/save failure.
    On Error Resume Next ' Rollback should not mask the original error.
    Do While item.Attachments.Count > before ' Remove only attachments added after the recorded starting count.
        Err.Clear ' Detect a failed removal and stop instead of looping forever.
        item.Attachments.Remove item.Attachments.Count ' Remove the most recently added attachment first.
        If Err.Number <> 0 Then Exit Do ' Avoid an endless loop when a read-only item refuses changes.
    Loop ' Continue until the original attachment count is restored.
    On Error GoTo 0 ' Re-enable normal error reporting.
    Err.Raise vbObjectError + 806, "modPersonalOutlookTools.PT_AddFilesToOne", failure ' Let the batch report this message as failed.
End Sub

' One toolbar command, with one explicit choice for the captured selection.
' Outlook's ordinary Reply buttons are not intercepted. Nothing here sends mail.
Public Sub Mail_ReplyWithAttachments()
    Dim mails As Collection, chooser As frmPersonalOutlook
    Dim choice As Long
    On Error GoTo Failed
    If replyInProgress Then Exit Sub
    Set mails = PT_SelectedMessages()
    If mails.Count = 0 Then Err.Raise vbObjectError + 807, "modPersonalOutlookTools.Mail_ReplyWithAttachments", "Select the original email(s), then run Reply with attachments."
    Set chooser = New frmPersonalOutlook
    chooser.PrepareReplyChoice mails.Count
    chooser.Show vbModal
    choice = chooser.Result
    Unload chooser
    If choice = 0 Then Exit Sub
    replyInProgress = True
    PT_ReplySelection mails, (choice = 2)
    replyInProgress = False
    Exit Sub
Failed:
    replyInProgress = False
    PT_ReportError "Reply with attachments", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.Mail_ReplyWithAttachments" 
End Sub

' Create one reply for each captured message and collect failures without losing the remaining selection.
Private Sub PT_ReplySelection(ByVal mails As Collection, ByVal replyToAll As Boolean)
    Dim source As Outlook.MailItem, draft As Outlook.MailItem, meter As frmPersonalOutlook
    Dim failures As String, detail As String, index As Long, problem As String
    Set meter = New frmPersonalOutlook
    meter.PrepareReplyProgress: meter.Show vbModeless
    For Each source In mails
        If meter.CancelRequested Then Exit For
        meter.BeginReply index, mails.Count
        On Error Resume Next
        Err.Clear: Set draft = PT_CreateReply(source, replyToAll, detail, meter)
        problem = Err.Description
        On Error GoTo 0
        If Len(problem) Then failures = failures & vbCrLf & source.Subject & " - " & problem
        index = index + 1
        meter.ReplyStep 1, "Finished draft attempt"
    Next source
    Unload meter
    If Len(failures) Then PT_ShowReport "Reply with attachments", failures
End Sub

' Snapshot genuine file attachments once. Reuse those bytes for both copy and verification.
' RTF needs a closed Word editor while adding files; otherwise Outlook can drop attachments.
' HTML/plain-text replies avoid that extra close/reopen cycle.
Public Function PT_CreateReply(ByVal source As Outlook.MailItem, Optional ByVal replyToAll As Boolean = False, Optional ByRef detail As String = "", Optional ByVal meter As frmPersonalOutlook = Nothing) As Outlook.MailItem
    Dim draft As Outlook.MailItem, originals As Collection
    Dim folder As String, draftID As String, storeID As String
    Dim failure As String, cleanup As String, checked As Long, originalCount As Long
    Dim modified As Date, wasDisplayed As Boolean, wasSaved As Boolean
    On Error GoTo Failed
    PT_CheckReplySource source
    originalCount = source.Attachments.Count
    modified = source.LastModificationTime
    If Not meter Is Nothing Then meter.ReplyStep 0, "Reading the original email"
    Set originals = New Collection
    If originalCount > 0 Then
        folder = PT_CreateTempFolder()
        Set originals = PT_SnapshotFileAttachments(source, folder, meter)
    End If
    If replyToAll Then
        Set draft = source.ReplyAll
    Else
        Set draft = source.Reply
    End If
    If Not meter Is Nothing Then meter.ReplyStep 0.4, "Outlook created the reply"
    ' RTF may reorder attachment positions when its editor opens. Only that format
    ' needs the initial display/save/reopen cycle before verification.
    If originals.Count = 0 Then
        If source.Attachments.Count <> originalCount Then Err.Raise 5, , "The original attachment list changed during the reply."
        draft.Save: wasSaved = True
        If Len(folder) Then PT_CleanTemp folder
        wasDisplayed = True: draft.Display
        detail = "No file attachments to copy."
        Set PT_CreateReply = draft: Exit Function
    End If
    If draft.BodyFormat = olFormatRichText Then
        wasDisplayed = True: draft.Display: draft.Save: wasSaved = True
        draftID = draft.EntryID: storeID = draft.Parent.StoreID
        draft.Close olSave
        Set draft = MailApp().Session.GetItemFromID(draftID, storeID)
    End If
    checked = PT_MatchFileAttachments(originals, draft, folder, True, meter)
    draft.Save: wasSaved = True
    If Not meter Is Nothing Then meter.ReplyStep 0.74, "Saved draft; checking attachments"
    If draft.BodyFormat = olFormatRichText Then draft.Display: draft.Save
    If source.Attachments.Count <> originalCount Or source.LastModificationTime <> modified Then Err.Raise vbObjectError + 880, "modPersonalOutlookTools.PT_CreateReply", "The original email changed while making this reply. Run the macro again."
    checked = PT_MatchFileAttachments(originals, draft, folder, False, meter)
    detail = "File attachments: " & CStr(originals.Count) & "; verified in the saved reply: " & CStr(checked) & "." & vbCrLf & "Body/hidden items excluded: " & CStr(originalCount - originals.Count) & "."
    PT_CleanTemp folder
    If draft.BodyFormat <> olFormatRichText Then draft.Display
    Set PT_CreateReply = draft
    Exit Function
Failed:
    failure = PT_ErrorText("PT_CreateReply", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_CreateReply")
    On Error Resume Next
    If Len(folder) > 0 Then PT_CleanTemp folder
    If Not draft Is Nothing Then
        ' A displayed Inspector can already contain the user's text. Keep every
        ' saved or displayed draft for inspection after a failure.
        If Not wasSaved And Not wasDisplayed Then wasSaved = (Len(draft.EntryID) > 0)
        If wasSaved Or wasDisplayed Then
            cleanup = vbCrLf & "The reply was kept. Check its attachments before sending or retrying."
        Else
            draft.Close olDiscard
        End If
    End If
    On Error GoTo 0
    Err.Raise vbObjectError + 808, "modPersonalOutlookTools.PT_CreateReply", "Reply creation/attachment verification failed. " & failure & cleanup
End Function

' Reject a source with unsaved edits before taking attachment snapshots for a reply.
Public Sub PT_CheckReplySource(ByVal source As Outlook.MailItem)
    Dim state As Long, available As Boolean, flagged As Variant
    On Error Resume Next
    Err.Clear
    state = source.DownloadState
    available = (Err.Number = 0)
    On Error GoTo 0
    If available Then
        If state = olHeaderOnly Then Err.Raise vbObjectError + 881, "modPersonalOutlookTools.PT_CheckReplySource", "The original email is only partly downloaded. Open it and download its full contents before retrying."
    End If
    If source.Attachments.Count = 0 Then
        On Error Resume Next
        Err.Clear
        flagged = source.PropertyAccessor.GetProperty("http://schemas.microsoft.com/mapi/proptag/0x0E1B000B")
        available = (Err.Number = 0)
        On Error GoTo 0
        If available Then
            If CBool(flagged) Then Err.Raise vbObjectError + 882, "modPersonalOutlookTools.PT_CheckReplySource", "Outlook flags attachments but has not exposed them. Fully download/open the original email before retrying."
        End If
    End If
    ' No real files is valid: make an ordinary reply. Body links are not downloaded files.
End Sub

' Hidden items, rendered-body attachments and referenced HTML resources are not file attachments.
' A .png/.jpg extension, a filename such as image001.png, or a Content-ID ALONE is not enough:
' photos attached as ordinary files must still be copied and verified.
Public Function PT_IsFileAttachment(ByVal attachment As Outlook.Attachment, ByVal html As String) As Boolean
    Dim value As Variant, contentID As String, location As String
    If PT_TryAttachmentProperty(attachment, HIDDEN, value) Then
        If CBool(value) Then Exit Function
    End If
    If Len(html) > 0 Then
        If PT_TryAttachmentProperty(attachment, "http://schemas.microsoft.com/mapi/proptag/0x37140003", value) Then
            If (CLng(value) And 4) <> 0 Then Exit Function ' HTML attRenderedInBody, not PidTagAttachmentFlags.
        End If
    End If
    ' RTF file icons can ALSO carry bit 4. They are real attachments, so never filter
    ' non-HTML files by that flag. Actual RTF body objects use olOLE/Hidden instead.
    If attachment.Type = olOLE Then Exit Function ' RTF body objects are part of the quoted body.
    contentID = PT_PropertyText(attachment, CID)
    If Len(contentID) = 0 Then contentID = PT_PropertyText(attachment, "http://schemas.microsoft.com/mapi/proptag/0x3712001E")
    If Len(contentID) > 1 Then
        If Left$(contentID, 1) = "<" And Right$(contentID, 1) = ">" Then contentID = Mid$(contentID, 2, Len(contentID) - 2)
    End If
    If Len(contentID) > 0 Then
        If PT_HtmlReferences(html, "cid:" & contentID) Then Exit Function
    End If
    location = PT_PropertyText(attachment, LOCATION)
    If Len(location) = 0 Then location = PT_PropertyText(attachment, "http://schemas.microsoft.com/mapi/proptag/0x3713001E")
    If Len(location) > 0 Then
        If PT_HtmlReferences(html, location) Then Exit Function
    End If
    PT_IsFileAttachment = True
End Function

' Read URI values in HTML attributes/CSS, not a casual mention of a filename in body text.
' Compare whole values so cid:photo cannot accidentally match cid:photo-extra.
Private Function PT_HtmlReferences(ByVal html As String, ByVal uri As String) As Boolean
    Dim re As Object, matches As Object, match As Object, value As String
    If Len(html) = 0 Or Len(uri) = 0 Then Exit Function
    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = "(?:src|background|data|href)\s*=\s*(?:""([^""]*)""|'([^']*)'|([^\s>]+))|url\(\s*[""']?([^\)""']+)"
    Set matches = re.Execute(html)
    For Each match In matches
        value = CStr(match.SubMatches(0)) & CStr(match.SubMatches(1)) & CStr(match.SubMatches(2)) & CStr(match.SubMatches(3))
        If StrComp(PT_DecodeHtmlURI(Trim$(value)), PT_DecodeHtmlURI(uri), vbTextCompare) = 0 Then
            PT_HtmlReferences = True
            Exit Function
        End If
    Next match
End Function

' Decode HTML URI escapes before checking whether an attachment is used by the message body.
Private Function PT_DecodeHtmlURI(ByVal value As String) As String
    Dim i As Long, pair As String, output As String
    value = Replace(value, "&amp;", "&", 1, -1, vbTextCompare)
    value = Replace(value, "&lt;", "<", 1, -1, vbTextCompare)
    value = Replace(value, "&gt;", ">", 1, -1, vbTextCompare)
    i = 1
    Do While i <= Len(value)
        If Mid$(value, i, 1) = "%" And i + 2 <= Len(value) Then
            pair = Mid$(value, i + 1, 2)
            If pair Like "[0-9A-Fa-f][0-9A-Fa-f]" Then
                output = output & ChrW$(CLng("&H" & pair))
                i = i + 3
            Else
                output = output & Mid$(value, i, 1)
                i = i + 1
            End If
        Else
            output = output & Mid$(value, i, 1)
            i = i + 1
        End If
    Loop
    PT_DecodeHtmlURI = output
End Function

' Record each real file attachment in a temporary folder for byte verification of the reply.
Private Function PT_SnapshotFileAttachments(ByVal source As Outlook.MailItem, ByVal folder As String, Optional ByVal meter As frmPersonalOutlook = Nothing) As Collection
    Dim entries As New Collection, attachment As Outlook.Attachment, fso As Object
    Dim i As Long, html As String, path As String, failure As String
    On Error GoTo Failed
    If source.BodyFormat = olFormatHTML Then html = source.HTMLBody
    Set fso = CreateObject("Scripting.FileSystemObject")
    For i = 1 To source.Attachments.Count
        Set attachment = source.Attachments(i)
        If PT_IsFileAttachment(attachment, html) Then
            fso.CreateFolder folder & "\source-" & CStr(i)
            path = folder & "\source-" & CStr(i) & "\" & PT_AttachmentFileName(attachment, i)
            attachment.SaveAsFile path
            entries.Add Array(attachment.FileName, PT_AttachmentFileName(attachment, i), path, attachment.Type = olEmbeddeditem Or LCase$(Right$(attachment.FileName, 4)) = ".msg")
        End If
        If Not meter Is Nothing Then meter.ReplyStep 0.35 * i / source.Attachments.Count, "Reading attachment " & i
    Next i
    Set PT_SnapshotFileAttachments = entries
    Exit Function
Failed:
    failure = PT_ErrorText("PT_SnapshotFileAttachments", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_SnapshotFileAttachments")
    Err.Raise vbObjectError + 809, "modPersonalOutlookTools.PT_SnapshotFileAttachments", "Could not read file attachment " & CStr(i) & ". " & failure
End Function

' Each existing file is extracted at most once per pass and can satisfy only one original.
' A fresh verification pass after Save reads the current attachment bytes again.
Private Function PT_MatchFileAttachments(ByVal originals As Collection, ByVal draft As Outlook.MailItem, ByVal folder As String, ByVal addMissing As Boolean, Optional ByVal meter As frmPersonalOutlook = Nothing) As Long
    Dim used As Object, paths As Object, byName As Object, wanted As Object, bucket As Collection
    Dim original As Variant, candidate As Outlook.Attachment, html As String, name As String
    Dim i As Long, j As Long, found As Boolean, rich As Boolean
    If originals.Count = 0 Then Exit Function
    Set used = PT_V6Dict(): Set paths = PT_V6Dict(): Set byName = PT_V6Dict()
    byName.CompareMode = vbTextCompare
    Set wanted = PT_V6Dict(): wanted.CompareMode = vbTextCompare
    For Each original In originals
        wanted(CStr(original(0))) = True: wanted(CStr(original(1))) = True
    Next original
    rich = (draft.BodyFormat = olFormatRichText)
    If draft.BodyFormat = olFormatHTML Then html = draft.HTMLBody
    For j = 1 To draft.Attachments.Count
        Set candidate = draft.Attachments(j)
        name = candidate.FileName
        If wanted.Exists(name) Then
            If PT_IsFileAttachment(candidate, html) Then
                If Not byName.Exists(name) Then
                    Set bucket = New Collection
                    byName.Add name, bucket
                End If
                Set bucket = byName(name): bucket.Add j
            End If
        End If
    Next j
    For i = 1 To originals.Count
        original = originals(i)
        found = ClaimReplyFile(byName, CStr(original(0)), used, paths, original, draft, folder)
        If Not found And StrComp(CStr(original(0)), CStr(original(1)), vbTextCompare) <> 0 Then
            found = ClaimReplyFile(byName, CStr(original(1)), used, paths, original, draft, folder)
        End If
        If Not found Then
            If addMissing Then
                ' Never set Content-ID/Hidden/rendering flags on an ordinary attached file.
                ' RTF position is AFTER the text, not hidden position zero.
                If rich Then
                    draft.Attachments.Add CStr(original(2)), olByValue, Len(draft.Body) + 1
                Else
                    draft.Attachments.Add CStr(original(2)), olByValue
                End If
            Else
                Err.Raise vbObjectError + 883, "modPersonalOutlookTools.PT_MatchFileAttachments", "File attachment " & CStr(i) & " (" & CStr(original(0)) & ") did not match the saved reply."
            End If
        End If
        If Not meter Is Nothing Then meter.ReplyStep IIf(addMissing, 0.4, 0.75) + IIf(addMissing, 0.3, 0.23) * i / originals.Count, IIf(addMissing, "Copying file ", "Verifying file ") & i & " of " & originals.Count
        PT_MatchFileAttachments = PT_MatchFileAttachments + 1
    Next i
End Function

' Public workers are also useful for independent verification; normal replies reuse one snapshot.
Public Sub PT_CopyOriginalAttachments(ByVal source As Outlook.MailItem, ByVal draft As Outlook.MailItem)
    Dim folder As String, originals As Collection, count As Long, failure As String
    On Error GoTo Failed
    folder = PT_CreateTempFolder()
    Set originals = PT_SnapshotFileAttachments(source, folder)
    count = PT_MatchFileAttachments(originals, draft, folder, True)
    PT_CleanTemp folder
    Exit Sub
Failed:
    failure = PT_ErrorText("PT_CopyOriginalAttachments", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_CopyOriginalAttachments")
    If Len(folder) > 0 Then PT_CleanTemp folder
    Err.Raise vbObjectError + 809, "modPersonalOutlookTools.PT_CopyOriginalAttachments", failure
End Sub

' Count the source files that are verified as present in the new reply.
Public Function PT_VerifyAttachmentCopies(ByVal source As Outlook.MailItem, ByVal draft As Outlook.MailItem) As Long
    Dim folder As String, originals As Collection, failure As String
    On Error GoTo Failed
    folder = PT_CreateTempFolder()
    Set originals = PT_SnapshotFileAttachments(source, folder)
    PT_VerifyAttachmentCopies = PT_MatchFileAttachments(originals, draft, folder, False)
    PT_CleanTemp folder
    Exit Function
Failed:
    failure = PT_ErrorText("PT_VerifyAttachmentCopies", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_VerifyAttachmentCopies")
    If Len(folder) > 0 Then PT_CleanTemp folder
    Err.Raise vbObjectError + 884, "modPersonalOutlookTools.PT_VerifyAttachmentCopies", failure
End Function


' Prove every original is represented separately. Same names and duplicate payloads do not merge.
Private Function PT_VerifyAllNoteAttachments(ByVal source As Outlook.MailItem, ByVal draft As Object) As Long
    Dim folder As String, originalPath As String, copiedPath As String
    Dim matched As Object, fso As Object
    Dim original As Outlook.Attachment, candidate As Outlook.Attachment
    Dim i As Long, j As Long, found As Boolean
    Dim expectedName As String, failure As String
    On Error GoTo Failed
    If source.Attachments.Count = 0 Then Exit Function
    folder = PT_CreateTempFolder()
    Set matched = CreateObject("Scripting.Dictionary")
    Set fso = CreateObject("Scripting.FileSystemObject")
    For i = 1 To source.Attachments.Count
        Set original = source.Attachments(i)
        expectedName = PT_AttachmentFileName(original, i)
        originalPath = folder & "\original-" & CStr(i) & ".bin"
        original.SaveAsFile originalPath
        found = False
        For j = 1 To draft.Attachments.Count
            If Not matched.Exists(CStr(j)) Then
                Set candidate = draft.Attachments(j)
                If StrComp(candidate.FileName, expectedName, vbTextCompare) = 0 Or StrComp(candidate.FileName, original.FileName, vbTextCompare) = 0 Then
                    If PT_PropertyText(candidate, CID) = PT_PropertyText(original, CID) Then
                        copiedPath = folder & "\copy-" & CStr(j) & ".bin"
                        candidate.SaveAsFile copiedPath
                        If PT_AttachmentFilesEqual(originalPath, copiedPath, original.Type = olEmbeddeditem Or LCase$(Right$(original.FileName, 4)) = ".msg") Then
                            found = True
                            matched(CStr(j)) = True
                            Exit For
                        End If
                    End If
                End If
            End If
        Next j
        If Not found Then Err.Raise vbObjectError + 883, "modPersonalOutlookTools.PT_VerifyAllNoteAttachments", "Attachment " & CStr(i) & " (" & original.FileName & ") could not be verified after saving the reply."
        PT_VerifyAllNoteAttachments = PT_VerifyAllNoteAttachments + 1
    Next i
    PT_CleanTemp folder
    Exit Function
Failed:
    failure = PT_ErrorText("PT_VerifyAllNoteAttachments", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_VerifyAllNoteAttachments")
    If Len(folder) > 0 Then PT_CleanTemp folder
    Err.Raise vbObjectError + 884, "modPersonalOutlookTools.PT_VerifyAllNoteAttachments", failure
End Function

' Match only byte-identical existing attachments, one-to-one, never just a shared filename.
' NOTE EDITING ONLY: preserve the note body resources as well as all of its attachments.
Private Sub PT_CopyAllNoteAttachments(ByVal source As Outlook.MailItem, ByVal draft As Object)
    Dim temp As String ' Isolate every extracted source/candidate file in one owned temporary folder.
    Dim fso As Object ' Create numbered folders so identical filenames cannot overwrite one another.
    Dim matched As Object ' Track which pre-existing reply attachments already represent a source attachment.
    Dim original As Outlook.Attachment ' Hold the current original attachment, including embedded .msg notes.
    Dim candidate As Outlook.Attachment ' Inspect attachments Outlook already placed in the reply.
    Dim added As Outlook.Attachment ' Apply inline metadata to each newly copied attachment.
    Dim index As Long ' Walk all current source attachments, not a cached earlier count.
    Dim other As Long ' Search only attachments present before this copy operation.
    Dim existingCount As Long ' Do not match newly added copies against later duplicate originals.
    Dim found As Boolean ' True means one pre-existing reply attachment represents this exact source.
    Dim sourcePath As String ' Hold a unique extracted original file.
    Dim candidatePath As String ' Hold a unique extracted candidate for an exact byte comparison.
    Dim property As Variant ' Copy the supported inline metadata fields.
    Dim value As Variant ' Hold a property value only when it exists.
    Dim failure As String ' Preserve a meaningful error before temporary cleanup.
    On Error GoTo Failed ' Unsupported attachments cause an explicit failure instead of being silently dropped.
    If source.Attachments.Count = 0 Then Exit Sub ' No temporary files are needed for an attachment-free source.
    temp = PT_CreateTempFolder() ' Use a unique folder under Windows' temporary directory.
    Set fso = CreateObject("Scripting.FileSystemObject") ' No additional reference must be installed.
    Set matched = CreateObject("Scripting.Dictionary") ' Count repeated attachments separately.
    existingCount = draft.Attachments.Count ' Outlook may already include inline pictures in the quoted body.
    For index = 1 To source.Attachments.Count ' Include every original attachment without exception filters.
        Set original = source.Attachments(index) ' Read the attachment as it exists now, including newly added notes.
        fso.CreateFolder temp & "\s" & CStr(index) ' A distinct folder protects duplicate filenames.
        sourcePath = temp & "\s" & CStr(index) & "\" & PT_AttachmentFileName(original, index) ' Preserve the original extension where possible.
        original.SaveAsFile sourcePath ' Extract the actual current attachment bytes.
        found = False ' Require a new one-to-one match for each source attachment.
        For other = 1 To existingCount ' Inspect only attachments Outlook supplied automatically.
            If Not matched.Exists(CStr(other)) Then ' One candidate cannot represent two original attachments.
                Set candidate = draft.Attachments(other) ' Inspect the next unmatched candidate.
                If StrComp(candidate.FileName, original.FileName, vbTextCompare) = 0 Then ' Names narrow the search but never prove equality.
                    If PT_PropertyText(candidate, CID) = PT_PropertyText(original, CID) Then ' Inline references must also agree.
                        candidatePath = temp & "\candidate-" & CStr(other) & ".bin" ' Use a separate path from every extracted original.
                        candidate.SaveAsFile candidatePath ' Compare actual attachment bytes, including notes with repeated names.
                        If PT_AttachmentFilesEqual(sourcePath, candidatePath, original.Type = olEmbeddeditem Or LCase$(Right$(original.FileName, 4)) = ".msg") Then ' Equal lengths alone are not enough.
                            matched(CStr(other)) = True ' Reserve this candidate for this source attachment only.
                            found = True ' The reply already contains this exact source attachment.
                            Exit For ' No duplicate copy is needed for this original.
                        End If ' Different contents must still be copied even with the same name.
                    End If ' Different Content-IDs cannot represent the same inline reference.
                End If ' Other names cannot be exact named-attachment matches.
            End If ' Previously matched candidates are not reused.
        Next other ' Continue searching existing reply attachments.
        If Not found Then ' The exact source is missing from the reply.
            Set added = draft.Attachments.Add(sourcePath, olByValue, 1) ' Embed the complete bytes, including .txt and .msg notes.
            For Each property In Array(CID, LOCATION, MIME, HIDDEN) ' Retain inline rendering metadata when it exists.
                If PT_TryAttachmentProperty(original, CStr(property), value) Then ' Missing optional properties are normal.
                    added.PropertyAccessor.SetProperty CStr(property), value ' Failure is reported rather than silently breaking an inline image.
                End If ' Do not invent metadata absent from the original.
            Next property ' Copy the next supported metadata field.
        End If ' Every original is now represented by an exact existing item or a new copy.
    Next index ' Continue through all original attachments, including duplicates.
    PT_CleanTemp temp ' Attachments.Add embeds the bytes, so the extracted files are no longer needed.
    Exit Sub ' Return only after the complete attachment copy succeeds.
Failed:
    failure = PT_ErrorText("PT_CopyAllNoteAttachments", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_CopyAllNoteAttachments") ' Preserve the original extraction/copy failure.
    If Len(temp) > 0 Then PT_CleanTemp temp ' Clean up even after a failed original.
    Err.Raise vbObjectError + 809, "modPersonalOutlookTools.PT_CopyAllNoteAttachments", "Attachment " & CStr(index) & " could not be preserved. " & failure ' The caller discards the incomplete reply.
End Sub


' Open one attached note for editing. Capture the chosen email before a dialog changes focus.

' Both the current .msg notes and older UTF-8/UTF-16 .txt notes can be selected explicitly.
Public Function PT_IsEditableNote(ByVal attachment As Outlook.Attachment) As Boolean
    Dim extension As String
    extension = LCase$(Right$(attachment.FileName, 4))
    PT_IsEditableNote = (extension = ".msg" Or extension = ".txt" Or attachment.Type = olEmbeddeditem)
End Function

' Capture the exact note attachment and source-message state before opening its separate editor.
Private Sub PT_StartNoteEdit(ByVal target As Outlook.MailItem, ByVal index As Long)
    Dim folder As String
    Dim original As String
    Dim editor As Outlook.MailItem
    Dim modified As Date
    Dim count As Long
    Dim failure As String
    On Error GoTo Failed
    PT_RequireNoPendingNote
    modified = target.LastModificationTime
    count = target.Attachments.Count
    folder = PT_CreateTempFolder()
    original = folder & "\" & PT_AttachmentFileName(target.Attachments(index), index)
    target.Attachments(index).SaveAsFile original
    Set editor = PT_OpenNoteEditor(original)
    Set pendingNoteEditor = editor
    Set pendingEditTarget = target
    pendingNoteMode = "edit"
    pendingNoteIndex = index
    pendingNoteCount = count
    pendingNoteModified = modified
    pendingOriginalNote = original
    pendingNoteFolder = folder
    pendingKeepBackup = False
    PT_MarkPendingEditor
    PT_WatchPendingNote
    Exit Sub
Failed:
    failure = PT_ErrorText("PT_StartNoteEdit", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_StartNoteEdit")
    On Error Resume Next
    If Not editor Is Nothing Then editor.Close olDiscard
    If Len(folder) > 0 Then PT_CleanTemp folder
    On Error GoTo 0
    MsgBox failure, vbExclamation, "Open attached note"
End Sub

' Work on a new composition, not the attached original. This also makes a saved .msg editable.
Public Function PT_OpenNoteEditor(ByVal original As String) As Outlook.MailItem
    Dim saved As Object
    Dim editor As Outlook.MailItem
    Dim fso As Object
    Dim failure As String
    Dim editorID As String, storeID As String, verified As Long
    On Error GoTo Failed
    Set fso = CreateObject("Scripting.FileSystemObject")
    Set editor = MailApp().CreateItem(olMailItem)
    If LCase$(fso.GetExtensionName(original)) = "txt" Then
        editor.BodyFormat = olFormatPlain
        editor.Display
        editor.Subject = fso.GetBaseName(original)
        editor.Body = PT_ReadTextNote(original)
    Else
        Set saved = MailApp().Session.OpenSharedItem(original)
        If Not TypeOf saved Is Outlook.MailItem Then Err.Raise vbObjectError + 863, "modPersonalOutlookTools.PT_OpenNoteEditor", "This attached item is not an email-format note."
        editor.BodyFormat = saved.BodyFormat
        editor.Display ' Initialise Outlook's editor/signature before setting the note body.
        editor.Subject = saved.Subject
        Select Case saved.BodyFormat
            Case olFormatHTML: editor.HTMLBody = saved.HTMLBody
            Case olFormatRichText: editor.RTFBody = saved.RTFBody
            Case Else: editor.Body = saved.Body
        End Select
        If editor.BodyFormat = olFormatRichText Then
            ' Flush the Word editor before attaching; otherwise RTF can lose all but one file.
            editor.Save
            editorID = editor.EntryID
            storeID = editor.Parent.StoreID
            editor.Close olSave
            Set editor = MailApp().Session.GetItemFromID(editorID, storeID)
            PT_CopyAllNoteAttachments saved, editor
            editor.Save
            editor.Display
            editor.Save
            verified = PT_VerifyAllNoteAttachments(saved, editor)
        Else
            PT_CopyAllNoteAttachments saved, editor
        End If
        saved.Close olDiscard
        Set saved = Nothing
    End If
    ' A fresh composition has no recipients. Applying a note also explicitly checks this.
    Set PT_OpenNoteEditor = editor
    Exit Function
Failed:
    failure = PT_ErrorText("PT_OpenNoteEditor", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_OpenNoteEditor")
    On Error Resume Next
    If Not saved Is Nothing Then saved.Close olDiscard
    If Not editor Is Nothing Then editor.Close olDiscard
    On Error GoTo 0
    Err.Raise vbObjectError + 864, "modPersonalOutlookTools.PT_OpenNoteEditor", "Could not open the note for editing. " & failure
End Function

' Load an attached text note using its supported encoding for the editable note window.
Public Function PT_ReadTextNote(ByVal path As String) As String
    Dim stream As Object
    Dim bytes As Variant
    Dim charset As String
    Dim text As String
    Dim failure As String
    On Error GoTo Failed
    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1
    stream.Open
    stream.LoadFromFile path
    If stream.Size = 0 Then
        stream.Close
        Exit Function
    End If
    bytes = stream.Read
    charset = "utf-8"
    If UBound(bytes) >= 1 Then
        If bytes(0) = 255 And bytes(1) = 254 Then charset = "unicode"
        If bytes(0) = 254 And bytes(1) = 255 Then charset = "unicodeFFFE"
    End If
    If charset = "utf-8" Then
        If Not PT_ValidUTF8(bytes) Then Err.Raise vbObjectError + 865, "modPersonalOutlookTools.PT_ReadTextNote", "This text note is not UTF-8 or BOM-marked UTF-16. Convert a copy to UTF-8 in a text editor first; the attached original has not been changed."
    ElseIf (stream.Size Mod 2) <> 0 Then
        Err.Raise vbObjectError + 866, "modPersonalOutlookTools.PT_ReadTextNote", "This UTF-16 text note has incomplete data. The original has not been changed."
    End If
    stream.Position = 0
    stream.Type = 2
    stream.charset = charset
    text = stream.ReadText(-1)
    If Len(text) > 0 Then
        If AscW(Left$(text, 1)) = -257 Then text = Mid$(text, 2) ' Remove U+FEFF if the reader returned it.
    End If
    stream.Close
    PT_ReadTextNote = text
    Exit Function
Failed:
    failure = PT_ErrorText("PT_ReadTextNote", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_ReadTextNote")
    On Error Resume Next
    If Not stream Is Nothing Then stream.Close
    On Error GoTo 0
    Err.Raise vbObjectError + 867, "modPersonalOutlookTools.PT_ReadTextNote", failure
End Function

' Refuse invalid UTF-8 rather than silently corrupting an older ANSI text note.
Private Function PT_ValidUTF8(ByVal bytes As Variant) As Boolean
    Dim i As Long, j As Long, count As Long, c As Long, second As Long
    On Error GoTo Invalid
    i = LBound(bytes)
    Do While i <= UBound(bytes)
        c = CLng(bytes(i))
        count = 0
        If c >= 194 And c <= 223 Then count = 1
        If c >= 224 And c <= 239 Then count = 2
        If c >= 240 And c <= 244 Then count = 3
        If c >= 128 And count = 0 Then Exit Function
        If i + count > UBound(bytes) Then Exit Function
        For j = 1 To count
            If bytes(i + j) < 128 Or bytes(i + j) > 191 Then Exit Function
        Next j
        If count > 0 Then
            second = CLng(bytes(i + 1))
            If c = 224 And second < 160 Then Exit Function
            If c = 237 And second > 159 Then Exit Function
            If c = 240 And second < 144 Then Exit Function
            If c = 244 And second > 143 Then Exit Function
        End If
        i = i + count + 1
    Loop
    PT_ValidUTF8 = True
Invalid:
End Function

' Check the stored email again immediately before applying an edited note.
Public Function PT_CurrentNoteTarget(ByVal target As Outlook.MailItem, ByVal index As Long, ByVal expectedCount As Long, ByVal expectedModified As Date, ByVal original As String, ByVal checkPath As String) As Outlook.MailItem
    Dim current As Outlook.MailItem
    If Not target.Saved Then Err.Raise vbObjectError + 868, "modPersonalOutlookTools.PT_CurrentNoteTarget", "This email has unsaved changes. Save or discard those changes before working with its note attachment."
    Set current = MailApp().Session.GetItemFromID(target.EntryID, target.Parent.StoreID)
    If Not current.Saved Then Err.Raise vbObjectError + 868, "modPersonalOutlookTools.PT_CurrentNoteTarget", "This email has unsaved changes. Reopen the note after resolving them."
    If current.LastModificationTime <> expectedModified Or current.Attachments.Count <> expectedCount Then Err.Raise vbObjectError + 869, "modPersonalOutlookTools.PT_CurrentNoteTarget", "The email changed while the note was open. Open the note attachment manually in Outlook and check its current contents."
    If index < 1 Or index > current.Attachments.Count Then Err.Raise vbObjectError + 870, "modPersonalOutlookTools.PT_CurrentNoteTarget", "The selected note no longer exists."
    current.Attachments(index).SaveAsFile checkPath
    If Not PT_AttachmentFilesEqual(original, checkPath, LCase$(Right$(original, 4)) = ".msg") Then Err.Raise vbObjectError + 871, "modPersonalOutlookTools.PT_CurrentNoteTarget", "The original note changed while you were editing. Reopen it before applying changes."
    Set PT_CurrentNoteTarget = current
End Function

' Save and verify the replacement BEFORE deleting the old attachment. If the second save fails,
' the previously saved email still contains both copies; the extracted original is retained too.
Public Sub PT_ReplaceAttachedNote(ByVal target As Outlook.MailItem, ByVal index As Long, ByVal expectedCount As Long, ByVal expectedModified As Date, ByVal original As String, ByVal replacement As String, ByVal folder As String)
    Dim current As Outlook.MailItem
    Dim added As Outlook.Attachment
    Dim failure As String
    Dim staged As Boolean
    On Error GoTo Failed
    Set current = PT_CurrentNoteTarget(target, index, expectedCount, expectedModified, original, folder & "\check-original.bin")
    Set added = current.Attachments.Add(replacement, olByValue, Len(current.Body) + 1)
    current.Save
    staged = True
    If current.Attachments.Count <> expectedCount + 1 Then Err.Raise vbObjectError + 872, "modPersonalOutlookTools.PT_ReplaceAttachedNote", "The replacement attachment count did not match."
    current.Attachments(current.Attachments.Count).SaveAsFile folder & "\check-replacement.msg"
    If Not PT_AttachmentFilesEqual(replacement, folder & "\check-replacement.msg", True) Then Err.Raise vbObjectError + 873, "modPersonalOutlookTools.PT_ReplaceAttachedNote", "The replacement could not be verified. The original has been kept."
    ' The stored old attachment must still match before removal, even after staging the new copy.
    current.Attachments(index).SaveAsFile folder & "\check-original.bin"
    If Not PT_AttachmentFilesEqual(original, folder & "\check-original.bin", LCase$(Right$(original, 4)) = ".msg") Then Err.Raise vbObjectError + 874, "modPersonalOutlookTools.PT_ReplaceAttachedNote", "The selected original changed. Both notes have been kept."
    current.Attachments.Remove index
    current.Save
    If current.Attachments.Count <> expectedCount Then Err.Raise vbObjectError + 875, "modPersonalOutlookTools.PT_ReplaceAttachedNote", "Unexpected attachment count after the replacement."
    Exit Sub
Failed:
    failure = PT_ErrorText("PT_ReplaceAttachedNote", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_ReplaceAttachedNote")
    On Error Resume Next
    If Not current Is Nothing Then current.Close olDiscard
    On Error GoTo 0
    If staged Then failure = failure & vbCrLf & "A replacement was staged. Inspect this email for two note copies before retrying."
    Err.Raise vbObjectError + 876, "modPersonalOutlookTools.PT_ReplaceAttachedNote", failure & vbCrLf & "The extracted original remains at: " & original
End Sub

' Replace the captured note only after verifying that the source message and attachment still match.
Public Function PT_ApplyEditedNote(ByVal target As Outlook.MailItem, ByVal editor As Outlook.MailItem, ByVal index As Long, ByVal expectedCount As Long, ByVal expectedModified As Date, ByVal original As String, ByVal folder As String) As Boolean
    Dim replacement As String
    Dim fso As Object
    On Error GoTo Failed
    If editor.Recipients.Count > 0 Then Err.Raise vbObjectError + 877, "modPersonalOutlookTools.PT_ApplyEditedNote", "Remove recipients from the note. Use Send in the tracked note editor to apply it."
    If Len(Trim$(Replace(editor.Body, ChrW(160), " "))) = 0 And editor.Attachments.Count = 0 Then Err.Raise vbObjectError + 878, "modPersonalOutlookTools.PT_ApplyEditedNote", "The edited note is empty. Add text or an attachment first."
    Set fso = CreateObject("Scripting.FileSystemObject")
    If Not fso.FolderExists(folder & "\edited") Then fso.CreateFolder folder & "\edited"
    replacement = folder & "\edited\" & PT_SafeFileName(editor.Subject) & ".msg"
    editor.SaveAs replacement, olMSGUnicode
    PT_ReplaceAttachedNote target, index, expectedCount, expectedModified, original, replacement, folder
    PT_ApplyEditedNote = True ' Replacement is committed even if closing the composing window fails.
    On Error Resume Next
    If Not pendingNoteInSend Then editor.Close olDiscard
    On Error GoTo 0
    Exit Function
Failed:
    PT_ReportError "Note was not fully applied", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_ApplyEditedNote" 
End Function

' One captured note at a time. No modeless confirmation panel obscures the Outlook editor.
' These variables are in-memory only; do not reset/edit the VBA project while a note is open.
Private Sub PT_RequireNoPendingNote()
    If pendingNoteMode = "completed" Then PT_ReleasePendingNote True
    If Not pendingNoteEditor Is Nothing Then Err.Raise vbObjectError + 890, "modPersonalOutlookTools.PT_RequireNoPendingNote", "A note is already open. Use Send to save it, or close it with X to cancel, before starting another note."
End Sub

' Open a tracked local note editor for the captured email selection.
Private Sub PT_BeginNewNote(ByVal mails As Collection)
    Dim targets As New Collection, item As Outlook.MailItem
    PT_RequireNoPendingNote
    Set pendingNoteEditor = MailApp().CreateItem(olMailItem)
    For Each item In mails
        If Len(item.EntryID) > 0 Then
            targets.Add Array(item.EntryID, item.Parent.StoreID, item.Subject)
        Else
            targets.Add item
        End If
    Next item
    Set pendingNoteTargets = targets
    pendingNoteMode = "new"
    pendingNoteEditor.BodyFormat = olFormatHTML
    pendingNoteEditor.Subject = "Note - " & Format$(Now, "yyyy-mm-dd hh-nn")
    pendingNoteEditor.Display
    pendingNoteEditor.HTMLBody = "<html><body><p></p></body></html>"
    PT_MarkPendingEditor
    PT_WatchPendingNote
End Sub

' A private marker also works for unsaved drafts, whose EntryID is blank. COM can return
' different wrappers for the same item, so object identity alone is not a reliable check.
Private Sub PT_MarkPendingEditor()
    Dim marker As Outlook.UserProperty
    If Len(pendingNoteToken) = 0 Then pendingNoteToken = CStr(Now) & "-" & CreateObject("Scripting.FileSystemObject").GetTempName
    Set marker = pendingNoteEditor.UserProperties.Find("PTPendingNoteToken")
    If marker Is Nothing Then Set marker = pendingNoteEditor.UserProperties.Add("PTPendingNoteToken", olText, False)
    marker.Value = pendingNoteToken
End Sub

' Check the private marker before handling a note editor's save or close event.
Private Function PT_IsPendingInspector(ByVal inspector As Outlook.Inspector) As Boolean
    Dim marker As Outlook.UserProperty
    On Error GoTo Finished
    If Not TypeOf inspector.CurrentItem Is Outlook.MailItem Then Exit Function
    Set marker = inspector.CurrentItem.UserProperties.Find("PTPendingNoteToken")
    If Not marker Is Nothing Then PT_IsPendingInspector = (marker.Value = pendingNoteToken)
Finished:
End Function

' Internal save handler: not exposed as a ribbon/Quick Access Toolbar macro.
' Outlook's ordinary Save saves a draft. This macro (or Send in the watched editor) applies
' an attached note or saves the summary template locally. The Send event always cancels mail.
Private Sub PT_SaveNote()
    Dim applied As Boolean
    Dim inspector As Outlook.Inspector
    Dim editorOpen As Boolean
    On Error GoTo Failed
    If pendingNoteEditor Is Nothing Then Err.Raise vbObjectError + 891, "modPersonalOutlookTools.PT_SaveNote", "No note is being tracked. Start with Add attachment or note, or Edit summary template."
    If pendingNoteBusy Then Exit Sub
    If pendingNoteMode = "completed" Then
        If Not pendingNoteInSend Then PT_ReleasePendingNote True
        Exit Sub
    End If
    For Each inspector In MailApp().Inspectors
        If PT_IsPendingInspector(inspector) Then editorOpen = True
    Next inspector
    If Not editorOpen Then
        PT_CancelNote
        Err.Raise vbObjectError + 892, "modPersonalOutlookTools.PT_SaveNote", "The note editor was closed and its pending workflow has been cancelled. Start a new note/edit. X cancels; Send applies the note."
    End If
    pendingNoteBusy = True
    PT_RemoveLocalSaveRecipient
    pendingNoteEditor.UserProperties.Find("PTPendingNoteToken").Delete
    If pendingNoteMode = "rule-template" Then
        applied = PT_ApplySummaryTemplate(pendingNoteEditor, pendingRuleNotePath)
    ElseIf pendingNoteMode = "template" Then
        applied = PT_ApplySummaryTemplate(pendingNoteEditor)
    ElseIf pendingNoteMode = "edit" Then
        pendingKeepBackup = True
        applied = PT_ApplyEditedNote(pendingEditTarget, pendingNoteEditor, pendingNoteIndex, pendingNoteCount, pendingNoteModified, pendingOriginalNote, pendingNoteFolder)
    Else
        applied = PT_ApplyRichNote(pendingNoteTargets, pendingNoteEditor)
    End If
    If applied Then
        pendingKeepBackup = False
        If pendingNoteInSend Then
            PT_CompleteSentEditor
        Else
            PT_ReleasePendingNote False
        End If
    Else
        PT_MarkPendingEditor
        PT_AddLocalSaveRecipient
    End If
    pendingNoteBusy = False
    Exit Sub
Failed:
    pendingNoteBusy = False
    PT_ReportError "Save note", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_SaveNote" 
    On Error Resume Next
    If Not pendingNoteEditor Is Nothing Then
        PT_MarkPendingEditor
        PT_AddLocalSaveRecipient
    End If
    On Error GoTo 0
End Sub

' Explicit cancellation and closing the note with X share this cleanup path.
Private Sub PT_CancelNote()
    If pendingNoteBusy Then Exit Sub
    PT_ReleasePendingNote True
End Sub

' Release the tracked editor and temporary files after saving or cancelling the note.
Private Sub PT_ReleasePendingNote(ByVal discardEditor As Boolean)
    Dim watcher As frmPersonalOutlook
    On Error Resume Next
    ' Detach before closing so the nested Close event cannot cancel a successful Save/Cancel.
    Set watcher = pendingNoteWatcher
    If Not watcher Is Nothing Then watcher.StopWatchingNote
    Set pendingNoteWatcher = Nothing
    If Not watcher Is Nothing Then Unload watcher
    If discardEditor Then
        If Not pendingNoteEditor Is Nothing Then pendingNoteEditor.Close olDiscard
    End If
    If Len(pendingNoteFolder) > 0 Then
        If pendingKeepBackup Then
            MsgBox "The earlier apply attempt failed or was partial. The original extracted note has been kept at:" & vbCrLf & pendingOriginalNote, vbExclamation, "Note recovery copy retained"
        Else
            PT_CleanTemp pendingNoteFolder
        End If
    End If
    Set pendingNoteEditor = Nothing
    Set pendingNoteTargets = Nothing
    Set pendingEditTarget = Nothing
    pendingNoteMode = ""
    pendingRuleNotePath = ""
    pendingNoteToken = ""
    pendingNoteSelfAddress = ""
    pendingNoteFolder = ""
    pendingOriginalNote = ""
    pendingKeepBackup = False
    On Error GoTo 0
End Sub

' Outlook reserialises embedded .msg containers. Compare their content, not storage layout.
' Ordinary file attachments must still match byte for byte. Ignore only volatile item IDs
' and storage timestamps; compare text/format, headers, sender, recipients and nested files.
Private Function PT_AttachmentFilesEqual(ByVal first As String, ByVal second As String, ByVal isMessage As Boolean, Optional ByVal depth As Long = 0) As Boolean
    Dim leftItem As Object, rightItem As Object
    Dim folder As String, i As Long, j As Long, found As Boolean
    Dim matched As Object, a As Outlook.Attachment, b As Outlook.Attachment
    Dim leftPath As String, rightPath As String, fso As Object
    Dim leftBytes As Variant, rightBytes As Variant
    On Error GoTo Finished
    If PT_FilesEqual(first, second) Then
        PT_AttachmentFilesEqual = True
        Exit Function
    End If
    If Not isMessage Or depth >= 16 Then Exit Function
    folder = PT_CreateTempFolder()
    Set fso = CreateObject("Scripting.FileSystemObject")
    fso.CopyFile first, folder & "\left.msg"
    fso.CopyFile second, folder & "\right.msg"
    Set leftItem = MailApp().Session.OpenSharedItem(folder & "\left.msg")
    Set rightItem = MailApp().Session.OpenSharedItem(folder & "\right.msg")
    If Not TypeOf leftItem Is Outlook.MailItem Or Not TypeOf rightItem Is Outlook.MailItem Then GoTo Finished
    If leftItem.MessageClass <> rightItem.MessageClass Then GoTo Finished
    If leftItem.Subject <> rightItem.Subject Then GoTo Finished
    If leftItem.BodyFormat <> rightItem.BodyFormat Then GoTo Finished
    If leftItem.Body <> rightItem.Body Then GoTo Finished
    If leftItem.BodyFormat = olFormatHTML Then
        If leftItem.HTMLBody <> rightItem.HTMLBody Then GoTo Finished
    ElseIf leftItem.BodyFormat = olFormatRichText Then
        leftBytes = leftItem.RTFBody: rightBytes = rightItem.RTFBody
        If UBound(leftBytes) <> UBound(rightBytes) Then GoTo Finished
        For i = LBound(leftBytes) To UBound(leftBytes)
            If leftBytes(i) <> rightBytes(i) Then GoTo Finished
        Next i
    End If
    If leftItem.SenderName <> rightItem.SenderName Then GoTo Finished
    If leftItem.SenderEmailAddress <> rightItem.SenderEmailAddress Then GoTo Finished
    If leftItem.SentOn <> rightItem.SentOn Or leftItem.ReceivedTime <> rightItem.ReceivedTime Then GoTo Finished
    If PT_MessageProperty(leftItem, "0x007D001F") <> PT_MessageProperty(rightItem, "0x007D001F") Then GoTo Finished
    If leftItem.Recipients.Count <> rightItem.Recipients.Count Then GoTo Finished
    For i = 1 To leftItem.Recipients.Count
        If leftItem.Recipients(i).Type <> rightItem.Recipients(i).Type Then GoTo Finished
        If leftItem.Recipients(i).Name <> rightItem.Recipients(i).Name Then GoTo Finished
        If leftItem.Recipients(i).Address <> rightItem.Recipients(i).Address Then GoTo Finished
    Next i
    If leftItem.Attachments.Count <> rightItem.Attachments.Count Then GoTo Finished
    Set matched = CreateObject("Scripting.Dictionary")
    For i = 1 To leftItem.Attachments.Count
        Set a = leftItem.Attachments(i)
        leftPath = folder & "\source-" & CStr(i) & ".bin"
        a.SaveAsFile leftPath
        found = False
        For j = 1 To rightItem.Attachments.Count
            If Not matched.Exists(CStr(j)) Then
                Set b = rightItem.Attachments(j)
                If a.FileName = b.FileName And PT_PropertyText(a, CID) = PT_PropertyText(b, CID) Then
                    rightPath = folder & "\copy-" & CStr(j) & ".bin"
                    b.SaveAsFile rightPath
                    If PT_AttachmentFilesEqual(leftPath, rightPath, a.Type = olEmbeddeditem Or LCase$(Right$(a.FileName, 4)) = ".msg", depth + 1) Then
                        matched(CStr(j)) = True
                        found = True
                        Exit For
                    End If
                End If
            End If
        Next j
        If Not found Then GoTo Finished
    Next i
    PT_AttachmentFilesEqual = True
Finished:
    On Error Resume Next
    If Not leftItem Is Nothing Then leftItem.Close olDiscard
    If Not rightItem Is Nothing Then rightItem.Close olDiscard
    If Len(folder) > 0 Then PT_CleanTemp folder
    On Error GoTo 0
End Function

' Read optional message metadata while allowing a provider to omit an unsupported property.
Private Function PT_MessageProperty(ByVal item As Object, ByVal tag As String) As String
    On Error Resume Next
    PT_MessageProperty = CStr(item.PropertyAccessor.GetProperty("http://schemas.microsoft.com/mapi/proptag/" & tag))
    On Error GoTo 0
End Function


' Keep a hidden UserForm instance alive solely for the native note-window Close event.
Private Sub PT_WatchPendingNote()
    Set pendingNoteWatcher = New frmPersonalOutlook
    pendingNoteWatcher.WatchNote pendingNoteEditor
    PT_AddLocalSaveRecipient
End Sub

' Cancel a tracked note operation when its editor closes before a successful local save.
Public Sub PT_NoteWindowClosing(ByRef Cancel As Boolean)
    If pendingNoteBusy Or pendingNoteEditor Is Nothing Then Exit Sub
    Cancel = True ' Replace the normal prompt-to-save close with the explicit Cancel note action.
    PT_CancelNote
End Sub

' Add a standalone Outlook post to the folder currently displayed in the main mail window.
' A post has an author but no To field: it is stored in the folder without sending an email.
' The native Post button commits it. Its position follows the folder's existing sort/filter.
Public Sub Mail_AddFolderSummary()
    Dim explorer As Outlook.Explorer, item As Outlook.PostItem
    On Error GoTo Failed
    Set explorer = MailApp().ActiveExplorer
    If explorer Is Nothing Then Err.Raise vbObjectError + 895, "modPersonalOutlookTools.Mail_AddFolderSummary", "Open the destination mail folder in Outlook's main window first."
    If PT_FolderKind(explorer.CurrentFolder) = 2 Then
        MsgBox "Can't add a folder summary here as you are in a search folder, rather than a filing folder", vbInformation, "Folder summary"
        Exit Sub
    End If
    Set item = PT_CreateFolderSummary(explorer.CurrentFolder)
    Exit Sub
Failed:
    PT_ReportError "Add folder summary", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.Mail_AddFolderSummary" 
End Sub

' Create a separate summary post for the chosen physical Outlook folder.
Public Function PT_CreateFolderSummary(ByVal target As Outlook.Folder) As Outlook.PostItem
    Dim item As Outlook.PostItem, searchFolder As Outlook.Folder
    If target.DefaultItemType <> olMailItem Then Err.Raise vbObjectError + 896, "modPersonalOutlookTools.PT_CreateFolderSummary", "Choose a normal mail folder for the summary."
    For Each searchFolder In target.Store.GetSearchFolders
        If searchFolder.EntryID = target.EntryID Then Err.Raise vbObjectError + 897, "modPersonalOutlookTools.PT_CreateFolderSummary", "Choose the actual filing folder, not a Search Folder."
    Next searchFolder
    Set item = target.Items.Add("IPM.Post")
    PT_FillFolderSummary item, target
    Set PT_CreateFolderSummary = item
End Function

' The editable default is a per-Windows-user .msg, independent of the VBA source folder.
' Back up this file separately when moving to a different PC. There is no registry/install step.
Public Function PT_SummaryTemplatePath() As String
    Dim root As String, fso As Object
    root = Environ$("APPDATA")
    If Len(root) = 0 Then Err.Raise vbObjectError + 950, "modPersonalOutlookTools.PT_SummaryTemplatePath", "Windows did not provide an AppData folder for the summary template."
    Set fso = CreateObject("Scripting.FileSystemObject")
    root = fso.BuildPath(root, "PersonalOfficeMacros")
    If Not fso.FolderExists(root) Then fso.CreateFolder root
    PT_SummaryTemplatePath = fso.BuildPath(root, "FolderSummaryTemplate.msg")
End Function

' One editor at a time: Send saves this default; X leaves it unchanged.
Public Sub Settings_EditSummaryTemplate()
    Dim path As String, fso As Object
    On Error GoTo Failed
    PT_RequireNoPendingNote
    path = PT_SummaryTemplatePath()
    Set fso = CreateObject("Scripting.FileSystemObject")
    If fso.FileExists(path) Then
        Set pendingNoteEditor = PT_OpenNoteEditor(path)
    Else
        Set pendingNoteEditor = MailApp().CreateItem(olMailItem)
        pendingNoteEditor.BodyFormat = olFormatHTML
        pendingNoteEditor.Display
        pendingNoteEditor.Subject = "Summary - {date}"
        pendingNoteEditor.HTMLBody = PT_DefaultSummaryBody()
    End If
    pendingNoteMode = "template"
    PT_MarkPendingEditor
    PT_WatchPendingNote
    Exit Sub
Failed:
    PT_ReportError "Edit summary template", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.Settings_EditSummaryTemplate" 
End Sub

' Supply editable text for the first folder-summary template.
Private Function PT_DefaultSummaryBody() As String
    PT_DefaultSummaryBody = "<html><body><p><b>Task / outcome</b></p><p>&nbsp;</p>" & _
        "<p><b>What happened</b></p><p>&nbsp;</p><p><b>Decisions / next steps</b></p><p>&nbsp;</p></body></html>"
End Function

' Stage and read back the new .msg before atomically replacing the live default.
' Keep one previous .msg alongside it; a cancelled/failed editor never overwrites the default.
Private Function PT_ApplySummaryTemplate(ByVal editor As Outlook.MailItem, Optional ByVal destinationPath As String = "") As Boolean
    Dim path As String, stage As String, failure As String, fso As Object, check As Object, attachment As Outlook.Attachment
    On Error GoTo Failed
    If editor.Recipients.Count > 0 Then Err.Raise vbObjectError + 951, "modPersonalOutlookTools.PT_ApplySummaryTemplate", "Leave To/Cc/Bcc empty. Send saves this template locally; it does not email it."
    For Each attachment In editor.Attachments
        ' Outlook cannot export/reconstruct OLE body objects through Attachment.SaveAsFile.
        ' Keep the prior template rather than accepting a default that cannot be reused.
        If attachment.Type = olOLE Then Err.Raise vbObjectError + 956, "modPersonalOutlookTools.PT_ApplySummaryTemplate", "This template contains an embedded OLE object (often an RTF picture). Use HTML format and reinsert that picture or file, then save again. The earlier template is unchanged."
    Next attachment
    path = destinationPath
    If Len(path) = 0 Then path = PT_SummaryTemplatePath()
    Set fso = CreateObject("Scripting.FileSystemObject")
    stage = fso.BuildPath(fso.GetParentFolderName(path), fso.GetTempName & ".msg")
    editor.SaveAs stage, olMSGUnicode
    Set check = MailApp().Session.OpenSharedItem(stage)
    If Not TypeOf check Is Outlook.MailItem Then Err.Raise vbObjectError + 952, "modPersonalOutlookTools.PT_ApplySummaryTemplate", "The saved template is not an Outlook message."
    If check.Subject <> editor.Subject Or check.Body <> editor.Body Then Err.Raise vbObjectError + 953, "modPersonalOutlookTools.PT_ApplySummaryTemplate", "The template text could not be verified."
    If check.Attachments.Count <> editor.Attachments.Count Then Err.Raise vbObjectError + 953, "modPersonalOutlookTools.PT_ApplySummaryTemplate", "The template attachment count could not be verified."
    If PT_VerifyAllNoteAttachments(editor, check) <> editor.Attachments.Count Then Err.Raise vbObjectError + 953, "modPersonalOutlookTools.PT_ApplySummaryTemplate", "The template attachment contents could not be verified."
    check.Close olDiscard
    Set check = Nothing
    If fso.FileExists(path) Then fso.CopyFile path, path & ".previous.msg", True
    If MoveFileExW(StrPtr(stage), StrPtr(path), 9) = 0 Then Err.Raise vbObjectError + 954, "modPersonalOutlookTools.PT_ApplySummaryTemplate", "Windows could not commit the template. The earlier default is unchanged."
    PT_ApplySummaryTemplate = True
    On Error Resume Next
    If Not pendingNoteInSend Then editor.Close olDiscard
    On Error GoTo 0
    Exit Function
Failed:
    failure = PT_ErrorText("PT_ApplySummaryTemplate", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_ApplySummaryTemplate")
    On Error Resume Next
    If Not check Is Nothing Then check.Close olDiscard
    Set check = Nothing
    If Len(stage) > 0 Then
        If Not fso Is Nothing Then
            If fso.FileExists(stage) Then fso.DeleteFile stage, True ' Only this call's explicit staged file.
        End If
    End If
    On Error GoTo 0
    MsgBox failure, vbExclamation, "Template was not saved"
End Function

' Apply all template content, including embedded images. Templates are not reply attachments.
Private Sub PT_FillFolderSummary(ByRef item As Outlook.PostItem, ByVal target As Outlook.Folder)
    Dim path As String, template As Object, temp As String, copied As Long, failure As String
    Dim fso As Object
    On Error GoTo Failed
    Set fso = CreateObject("Scripting.FileSystemObject")
    path = PT_SummaryTemplatePath()
    If Not fso.FileExists(path) Then
        item.Subject = "Summary - " & Format$(Now, "yyyy-mm-dd")
        item.BodyFormat = olFormatHTML
        item.HTMLBody = PT_DefaultSummaryBody()
        item.Display
        Exit Sub
    End If
    ' Open a private copy so repeated summary windows do not lock the user's template file.
    temp = PT_CreateTempFolder()
    fso.CopyFile path, temp & "\template.msg"
    Set template = MailApp().Session.OpenSharedItem(temp & "\template.msg")
    If Not TypeOf template Is Outlook.MailItem Then Err.Raise vbObjectError + 955, "modPersonalOutlookTools.PT_FillFolderSummary", "The saved summary template is not a message."
    ' Convert only this private copy to HTML. Native Post can discard programmatically
    ' added RTF file icons when it commits; HTML keeps the formatted body and file list.
    ' The user's saved default retains its original format. OLE templates are refused on save.
    If template.BodyFormat = olFormatRichText Then template.BodyFormat = olFormatHTML
    item.BodyFormat = template.BodyFormat
    item.Display
    item.Subject = Replace(Replace(template.Subject, "{date}", Format$(Now, "yyyy-mm-dd"), 1, -1, vbTextCompare), "{folder}", target.Name, 1, -1, vbTextCompare)
    If Len(Trim$(item.Subject)) = 0 Then item.Subject = "Summary - " & Format$(Now, "yyyy-mm-dd")
    Select Case template.BodyFormat
        Case olFormatHTML: item.HTMLBody = template.HTMLBody
        Case olFormatRichText: item.RTFBody = template.RTFBody
        Case Else: item.Body = template.Body
    End Select
    PT_CopyAllNoteAttachments template, item
    copied = PT_VerifyAllNoteAttachments(template, item)
    template.Close olDiscard
    Set template = Nothing
    PT_CleanTemp temp
    Exit Sub
Failed:
    failure = PT_ErrorText("PT_FillFolderSummary", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_FillFolderSummary")
    On Error Resume Next
    If Not template Is Nothing Then template.Close olDiscard
    Set template = Nothing
    If Len(temp) > 0 Then PT_CleanTemp temp
    item.Close olDiscard
    On Error GoTo 0
    Err.Raise vbObjectError + 956, "modPersonalOutlookTools.PT_FillFolderSummary", "Could not apply the summary template. " & failure
End Sub

' Snapshot layout shared by move and delete workers: EntryID, StoreID, parent EntryID,
' modification time, display label, message class, age/conversation date, conversation ID.
' IDs (not list positions) keep the batch stable when Outlook changes the selection/list.
Public Function PT_SelectedItems() As Collection
    Dim result As New Collection, window As Object, item As Object
    Set window = MailApp().ActiveWindow
    If TypeOf window Is Outlook.Explorer Then
        For Each item In window.Selection
            result.Add item
        Next item
    ElseIf TypeOf window Is Outlook.Inspector Then
        result.Add window.CurrentItem
    End If
    Set PT_SelectedItems = result
End Function

' Build a readable item label for reports when Subject is empty or unavailable.
Private Function PT_ItemLabel(ByVal item As Object) As String
    On Error Resume Next
    PT_ItemLabel = CStr(item.Subject)
    If Len(PT_ItemLabel) = 0 Then PT_ItemLabel = CStr(item.MessageClass)
    If Len(PT_ItemLabel) = 0 Then PT_ItemLabel = "Outlook item"
    On Error GoTo 0
End Function

' Snapshot stable item and folder IDs, modification time, label and ordering date before a dialog opens.
Private Function PT_Record(ByVal item As Object, Optional ByVal when As Date = 0, Optional ByVal chain As String = "") As Variant
    If Len(item.EntryID) = 0 Then Err.Raise vbObjectError + 960, "modPersonalOutlookTools.PT_Record", "Save this item first: " & PT_ItemLabel(item)
    If Not item.Saved Then Err.Raise vbObjectError + 961, "modPersonalOutlookTools.PT_Record", "Save/discard existing edits first: " & PT_ItemLabel(item)
    PT_Record = Array(item.EntryID, item.Parent.StoreID, item.Parent.EntryID, item.LastModificationTime, PT_ItemLabel(item), item.MessageClass, when, chain)
End Function

' Reopen that exact item and reject moved, edited or unsaved items before applying a recorded action.
Private Function PT_ReloadRecord(ByVal record As Variant) As Object
    Dim item As Object
    Set item = MailApp().Session.GetItemFromID(CStr(record(0)), CStr(record(1)))
    If StrComp(item.Parent.EntryID, CStr(record(2)), vbTextCompare) <> 0 Then Err.Raise vbObjectError + 962, "modPersonalOutlookTools.PT_ReloadRecord", "Item moved to another folder; skipped: " & CStr(record(4))
    If Not item.Saved Or item.LastModificationTime <> CDate(record(3)) Then Err.Raise vbObjectError + 963, "modPersonalOutlookTools.PT_ReloadRecord", "Item changed or has unsaved edits; skipped: " & CStr(record(4))
    Set PT_ReloadRecord = item
End Function

' Use Outlook's native picker and return Nothing when the user cancels it.
Public Function PT_PickOutlookFolder() As Outlook.Folder
    Set PT_PickOutlookFolder = MailApp().Session.PickFolder
End Function

' Destination selection is the action: no second confirmation and no success box.
Public Sub Mail_MoveSelectedItems()
    OrganiseSelection True
End Sub

' Move each captured item once, quietly skipping its current folder and reporting item-specific failures.
Public Function PT_MoveRecords(ByVal records As Collection, ByVal destination As Outlook.Folder, ByRef failures As String) As Long
    Dim record As Variant, item As Object, moved As Object, count As Long, problem As String
    PT_CheckFolder destination
    For Each record In records
        On Error Resume Next
        Err.Clear
        Set item = PT_ReloadRecord(record)
        If Err.Number = 0 Then
            If StrComp(CStr(record(1)), destination.StoreID, vbTextCompare) <> 0 Or StrComp(CStr(record(2)), destination.EntryID, vbTextCompare) <> 0 Then
                Set moved = item.Move(destination)
                If Err.Number = 0 Then
                    If StrComp(moved.Parent.EntryID, destination.EntryID, vbTextCompare) = 0 Then PT_MoveRecords = PT_MoveRecords + 1
                End If
            End If ' Already in the chosen folder is a quiet no-op, not a second copy.
        End If
        problem = PT_ErrorText("PT_MoveRecords", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_MoveRecords")
        If Err.Number <> 0 Then failures = failures & vbCrLf & CStr(record(4)) & ": " & problem
        On Error GoTo 0
        count = count + 1
        If count Mod 50 = 0 Then DoEvents
    Next record
End Function

' Exclude Outlook's missing-date sentinel as well as invalid or unsupported calendar dates.
Private Function PT_UsableDate(ByVal value As Variant) As Boolean
    On Error GoTo Finished
    If IsDate(value) Then PT_UsableDate = (Year(CDate(value)) >= 1900 And Year(CDate(value)) < 4500)
Finished:
End Function

' Read an optional Outlook table date and return zero when no usable value is available.
Private Function PT_RowDate(ByVal row As Outlook.Row, ByVal name As String) As Date
    Dim value As Variant
    On Error GoTo Finished
    value = row(name)
    If PT_UsableDate(value) Then PT_RowDate = CDate(value)
Finished:
End Function

' Choose sent or received time in the requested order, then fall back to the creation date.
Private Function PT_ItemDate(ByVal item As Object, Optional ByVal preferSent As Boolean = False) As Date
    Dim value As Variant
    On Error Resume Next
    If TypeOf item Is Outlook.MailItem Or TypeOf item Is Outlook.PostItem Then
        If preferSent Then
            value = item.SentOn
            If PT_UsableDate(value) Then PT_ItemDate = CDate(value): Exit Function
        End If
        value = Empty: value = item.ReceivedTime
        If PT_UsableDate(value) Then PT_ItemDate = CDate(value): Exit Function
        value = Empty: value = item.SentOn
        If PT_UsableDate(value) Then PT_ItemDate = CDate(value): Exit Function
    End If
    value = Empty: value = item.CreationTime
    If PT_UsableDate(value) Then PT_ItemDate = CDate(value)
    On Error GoTo 0
End Function

' Recognise the store's actual Sent Items folder for the age-date preference.
Private Function PT_IsSentFolder(ByVal folder As Outlook.Folder) As Boolean
    Dim sent As Outlook.Folder
    On Error GoTo Finished
    Set sent = folder.Store.GetDefaultFolder(olFolderSentMail)
    PT_IsSentFolder = (StrComp(folder.EntryID, sent.EntryID, vbTextCompare) = 0)
Finished:
End Function

' Exact Deleted Items root means permanent deletion, as requested. Other folders,
' including its subfolders, first move their matching items to the Deleted Items root.
Public Function PT_PermanentHere(ByVal folder As Outlook.Folder) As Boolean
    Dim deleted As Outlook.Folder
    PT_CheckFolder folder
    Set deleted = folder.Store.GetDefaultFolder(olFolderDeletedItems)
    PT_PermanentHere = (StrComp(folder.EntryID, deleted.EntryID, vbTextCompare) = 0)
End Function

' Open a count-first deletion setup for the current physical folder.


' Lightweight rows avoid opening every message body. Dates are Outlook local Date values,
' and the strict boundary is the captured current time minus the chosen whole day count.
Public Function PT_OldItemPlan(ByVal folder As Outlook.Folder, ByVal days As Long, ByVal referenceTime As Date) As Object
    Dim plan As Object, records As New Collection, snapshot As Collection, record As Variant, failures As String, cutoff As Date
    PT_CheckFolder folder
    If days < 0 Or days > 36500 Then Err.Raise vbObjectError + 969, "modPersonalOutlookTools.PT_OldItemPlan", "Enter a whole number of days from 0 to 36500."
    cutoff = DateAdd("d", -days, referenceTime)
    Set plan = PT_NewDeletionPlan(folder, "age")
    plan.Add "cutoff", cutoff: plan.Add "allItems", (days = 0)
    plan.Add "preferSent", PT_IsSentFolder(folder)
    Set snapshot = PT_CaptureFolderRecords(folder, failures)
    For Each record In snapshot
        If days = 0 Or (CDate(record(6)) > 0 And CDate(record(6)) < cutoff) Then records.Add record
    Next record
    plan.Add "items", records: plan.Add "captureFailures", failures
    Set PT_OldItemPlan = plan
End Function

' Capture the source folder and its actual Deleted Items destination in an action plan.
Private Function PT_NewDeletionPlan(ByVal folder As Outlook.Folder, ByVal mode As String) As Object
    Dim plan As Object, deleted As Outlook.Folder
    Set deleted = folder.Store.GetDefaultFolder(olFolderDeletedItems)
    Set plan = CreateObject("Scripting.Dictionary")
    plan.Add "mode", mode
    plan.Add "source", folder
    plan.Add "destination", deleted
    plan.Add "permanent", PT_PermanentHere(folder)
    Set PT_NewDeletionPlan = plan
End Function

' Do not group by a stripped subject: unrelated messages can have the same subject.
' Require the real 16-byte MAPI conversation ID; legacy/unsupported items fail closed.

Public Function PT_HasFileAttachments(ByVal mail As Outlook.MailItem) As Boolean
    Dim attachment As Outlook.Attachment, html As String
    If mail.BodyFormat = olFormatHTML Then html = mail.HTMLBody
    For Each attachment In mail.Attachments
        If PT_IsFileAttachment(attachment, html) Then PT_HasFileAttachments = True: Exit Function
    Next attachment
End Function

' Scan only the current folder's lightweight conversation IDs. Even in Deleted Items,
' this works without Conversation.GetTable (which omits Deleted Items altogether).
Public Function PT_ChainPlan(ByVal selected As Collection, ByVal folder As Outlook.Folder, ByVal keepFiles As Boolean) As Object
    ' Compatibility for existing callers of the old one-folder helper: use the new
    ' link/participant checks, but expose only the requested folder's deletion candidates.
    Dim roots As New Collection, model As Object, plan As Object, records As New Collection, row As Object, info As Object, key As Variant
    roots.Add folder
    Set model = PT_BuildChainReview(roots, selected, False)
    model("keepFiles") = keepFiles
    For Each key In model("folders").Keys
        Set info = model("folders")(key)
        info("include") = (info("folder").EntryID = folder.EntryID And info("folder").StoreID = folder.StoreID)
    Next key
    For Each row In model("rows")
        Set info = model("folders")(CStr(row("folderKey")))
        If CBool(info("include")) And PT_ChainRowEligible(row, keepFiles) Then records.Add row("record")
    Next row
    Set plan = PT_NewDeletionPlan(folder, "review")
    plan.Add "review", model
    plan.Add "items", records
    Set PT_ChainPlan = plan
End Function

' Revalidate an age-plan record before moving it to Deleted Items or permanently deleting it there.
Private Sub PT_DeleteRecord(ByVal record As Variant, ByVal plan As Object)
    Dim item As Object, moved As Object, destination As Outlook.Folder, when As Date
    If plan("mode") <> "age" Then Err.Raise vbObjectError + 975, "modPersonalOutlookTools.PT_DeleteRecord", "Invalid deletion plan."
    Set item = PT_ReloadRecord(record)
    when = PT_ItemDate(item, CBool(plan("preferSent")))
    If Not CBool(plan("allItems")) And (when = 0 Or when >= CDate(plan("cutoff"))) Then Err.Raise vbObjectError + 975, "modPersonalOutlookTools.PT_DeleteRecord", "Item no longer meets the age rule: " & CStr(record(4))
    Set destination = plan("destination")
    If CBool(plan("permanent")) Then
        If StrComp(item.Parent.EntryID, destination.EntryID, vbTextCompare) <> 0 Then Err.Raise vbObjectError + 980, "modPersonalOutlookTools.PT_DeleteRecord", "Item left Deleted Items; permanent deletion refused."
        item.Delete
    Else
        Set moved = item.Move(destination)
    End If
End Sub

' No preview, second confirmation or routine completion box. Only failures are reported.
Public Function PT_ApplyDeletionPlan(ByVal plan As Object, ByRef failures As String) As Long
    Dim record As Variant, records As Collection, problem As String, count As Long
    If plan.Exists("review") Then
        PT_ApplyDeletionPlan = PT_ApplyChainReview(plan("review"), failures)
        Exit Function
    End If
    If plan.Exists("captureFailures") Then failures = failures & CStr(plan("captureFailures"))
    Set records = plan("items")
    For Each record In records
        On Error Resume Next
        Err.Clear
        PT_DeleteRecord record, plan
        problem = PT_ErrorText("PT_ApplyDeletionPlan", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_ApplyDeletionPlan")
        If Err.Number = 0 Then
            PT_ApplyDeletionPlan = PT_ApplyDeletionPlan + 1
        Else
            failures = failures & vbCrLf & CStr(record(4)) & ": " & problem
        End If
        On Error GoTo 0
        count = count + 1
        If count Mod 50 = 0 Then DoEvents
    Next record
End Function

' Outlook validates a recipient before raising MailItem.Send. The user chose to address
' note/template editors to themselves so Send can be intercepted. The send handler cancels
' first, strips ONLY this automatic recipient, then saves locally. If VBA is stopped/reset,
' the hook is lost and Outlook could send this message to that user: finish/cancel first.
Private Function PT_OwnSmtpAddress(ByVal editor As Outlook.MailItem) As String
    Dim account As Outlook.Account, entry As Outlook.AddressEntry, exchangeUser As Outlook.ExchangeUser
    On Error Resume Next
    Set account = editor.SendUsingAccount
    If Not account Is Nothing Then PT_OwnSmtpAddress = Trim$(account.SmtpAddress)
    If InStr(PT_OwnSmtpAddress, "@") = 0 Then
        Set entry = MailApp().Session.CurrentUser.AddressEntry
        If Not entry Is Nothing Then
            If UCase$(entry.Type) = "EX" Then
                Set exchangeUser = entry.GetExchangeUser
                If Not exchangeUser Is Nothing Then PT_OwnSmtpAddress = Trim$(exchangeUser.PrimarySmtpAddress)
            Else
                PT_OwnSmtpAddress = Trim$(entry.Address)
            End If
        End If
    End If
    On Error GoTo 0
    If InStr(PT_OwnSmtpAddress, "@") < 2 Then Err.Raise vbObjectError + 957, "modPersonalOutlookTools.PT_OwnSmtpAddress", "Could not determine your own email address. Choose an Outlook account with a resolvable email address, then start the note again."
End Function

' Resolve a recipient to its SMTP address, including an Exchange address entry.
Private Function PT_RecipientSmtp(ByVal recipient As Outlook.Recipient) As String
    Dim entry As Outlook.AddressEntry, exchangeUser As Outlook.ExchangeUser
    Set entry = recipient.AddressEntry
    If UCase$(entry.Type) = "EX" Then
        Set exchangeUser = entry.GetExchangeUser
        If Not exchangeUser Is Nothing Then PT_RecipientSmtp = exchangeUser.PrimarySmtpAddress
    Else
        PT_RecipientSmtp = entry.Address
    End If
End Function

' Address only the tracked note editor to the current user so its Send event can perform a local save.
Private Sub PT_AddLocalSaveRecipient()
    Dim recipient As Outlook.Recipient
    If pendingNoteEditor Is Nothing Then Exit Sub
    If pendingNoteEditor.Recipients.Count > 0 Then Exit Sub ' Never silently replace recipients the user typed.
    If Len(pendingNoteSelfAddress) = 0 Then pendingNoteSelfAddress = PT_OwnSmtpAddress(pendingNoteEditor)
    Set recipient = pendingNoteEditor.Recipients.Add(pendingNoteSelfAddress)
    recipient.Type = olTo
    recipient.Resolve
    If Not recipient.Resolved Then
        recipient.Delete
        Err.Raise vbObjectError + 958, "modPersonalOutlookTools.PT_AddLocalSaveRecipient", "Outlook could not resolve your own address. Choose an Outlook account with a resolvable email address, then start the note again."
    End If
End Sub

' Remove the automatic self-recipient after interception and reject unexpected additional recipients.
Private Sub PT_RemoveLocalSaveRecipient()
    If pendingNoteEditor.Recipients.Count = 0 Then Exit Sub ' An editor without recipients needs no automatic-recipient cleanup.
    If pendingNoteEditor.Recipients.Count = 1 And Len(pendingNoteSelfAddress) > 0 Then
        If pendingNoteEditor.Recipients(1).Type = olTo Then
            If StrComp(PT_RecipientSmtp(pendingNoteEditor.Recipients(1)), pendingNoteSelfAddress, vbTextCompare) = 0 Then
                pendingNoteEditor.Recipients.Remove 1
                Exit Sub
            End If
        End If
    End If
    Err.Raise vbObjectError + 959, "modPersonalOutlookTools.PT_RemoveLocalSaveRecipient", "Keep only the automatic To-yourself recipient (or clear all recipients). This note/template is saved locally, not sent."
End Sub

' Cancel Send first. Queue a native close message only after the local save succeeds.
' Outlook processes the queued close after this Send handler returns; never DoEvents here.
' A second Send is cancelled without applying the note twice.
Public Sub PT_SaveNoteFromSend(ByRef Cancel As Boolean)
    Cancel = True
    On Error GoTo Failed
    If pendingNoteMode = "completed" Then PT_QueueCompletedNoteClose: Exit Sub
    pendingNoteInSend = True
    PT_SaveNote
    pendingNoteInSend = False
    If pendingNoteMode = "completed" Then PT_QueueCompletedNoteClose
    Exit Sub
Failed:
    pendingNoteInSend = False ' Never strand later toolbar saves in Send-event mode.
    Err.Raise Err.Number, Err.Source, Err.Description
End Sub

' Mark the local save complete before queuing the editor close so a second Send cannot reapply the note.
Private Sub PT_CompleteSentEditor()
    pendingNoteMode = "completed" ' Commit state FIRST so a caption/recipient failure cannot reapply it.
    Set pendingNoteTargets = Nothing
    Set pendingEditTarget = Nothing
    If Len(pendingNoteFolder) > 0 Then PT_CleanTemp pendingNoteFolder
    pendingNoteFolder = ""
    pendingOriginalNote = ""
    PT_MarkPendingEditor
    pendingNoteEditor.Subject = "[Saved locally] " & pendingNoteEditor.Subject
    PT_AddLocalSaveRecipient
End Sub

' Linked-chain review uses reply evidence. Optional subject matches are separate unchecked candidates.
' ConversationID can itself be a hash of a reused subject. Link actual Message-ID / reply
' references and genuine timestamped ConversationIndex roots. Recipient changes do not split a proven chain; exact content copies can also be linked.

Private Function PT_V6Dict() As Object
    Set PT_V6Dict = CreateObject("Scripting.Dictionary")
End Function

' Read a MAPI string and try its ANSI version when the Unicode property is unavailable.
Private Function PT_V6Property(ByVal accessor As Object, ByVal tag As String) As String
    On Error Resume Next
    PT_V6Property = CStr(accessor.GetProperty(PT_V6_TAG & tag))
    If Len(PT_V6Property) = 0 And Right$(tag, 4) = "001F" Then
        Err.Clear
        PT_V6Property = CStr(accessor.GetProperty(PT_V6_TAG & Left$(tag, Len(tag) - 4) & "001E"))
    End If
    On Error GoTo 0
End Function

' Read optional table text without failing the whole scan for one unsupported column.
Private Function PT_V6RowText(ByVal row As Outlook.Row, ByVal column As String) As String
    On Error Resume Next
    PT_V6RowText = CStr(row(column))
    On Error GoTo 0
End Function

' Read ConversationIndex bytes from a full message or its table row.
Private Function PT_V6Index(ByVal item As Object, ByVal isRow As Boolean) As String
    On Error Resume Next
    If isRow Then
        PT_V6Index = item.BinaryToString(PT_V6_TAG & "0x00710102")
    Else
        PT_V6Index = item.PropertyAccessor.BinaryToString(item.PropertyAccessor.GetProperty(PT_V6_TAG & "0x00710102"))
    End If
    On Error GoTo 0
End Function

' Create reply-link tokens and mark genuine conversation roots or reply references as strong evidence.
Private Function PT_V6Tokens(ByVal index As String, ByVal messageID As String, ByVal references As String, ByVal replyTo As String, ByVal unique As String, ByRef strong As Boolean) As Collection
    Dim tokens As New Collection, seen As Object, id As Variant, ids As Collection, token As String
    Set seen = PT_V6Dict()
    index = UCase$(index)
    ' A zero timestamp prefix is a synthetic conversation index and may be topic-derived.
    If Len(index) >= 44 And Left$(index, 2) = "01" And Left$(index, 12) <> "010000000000" Then
        If (Len(index) - 44) Mod 10 = 0 And Mid$(index, 13, 32) <> String$(32, "0") Then
            token = "I:" & Left$(index, 44): seen(token) = True: strong = True
        End If
    End If
    Set ids = PT_V6MessageIDs(references & " " & replyTo)
    If ids.Count > 0 Then strong = True
    For Each id In ids: seen("M:" & CStr(id)) = True: Next id
    Set ids = PT_V6MessageIDs(messageID)
    For Each id In ids: seen("M:" & CStr(id)) = True: Next id
    If seen.Count = 0 Then seen("U:" & unique) = True
    For Each id In seen.Keys: tokens.Add CStr(id): Next id
    Set PT_V6Tokens = tokens
End Function

' Extract the full message's index, message ID, references and reply-to metadata for chain matching.
Private Function PT_V6MailTokens(ByVal mail As Outlook.MailItem, ByRef strong As Boolean) As Collection
    Set PT_V6MailTokens = PT_V6Tokens(PT_V6Index(mail, False), PT_V6Property(mail.PropertyAccessor, "0x1035001F"), PT_V6Property(mail.PropertyAccessor, "0x1039001F"), PT_V6Property(mail.PropertyAccessor, "0x1042001F"), mail.Parent.StoreID & mail.EntryID, strong)
End Function

' Find and compress a reply-token component in the union-find dictionary.
Private Function PT_V6Find(ByVal parents As Object, ByVal token As String) As String
    Dim root As String, nextToken As String
    If Not parents.Exists(token) Then parents.Add token, token
    root = token
    Do While CStr(parents(root)) <> root: root = CStr(parents(root)): Loop
    Do While CStr(parents(token)) <> token
        nextToken = CStr(parents(token)): parents(token) = root: token = nextToken
    Loop
    PT_V6Find = root
End Function

' Connect the metadata tokens that belong to the same individual message.
Private Sub PT_V6Join(ByVal parents As Object, ByVal tokens As Collection)
    Dim token As Variant, first As String, other As String
    first = PT_V6Find(parents, CStr(tokens(1)))
    For Each token In tokens
        other = PT_V6Find(parents, CStr(token))
        If first <> other Then parents(other) = first
    Next token
End Sub

' Collect accessible profile store roots while preserving errors for inaccessible mailboxes.
Public Function PT_ProfileRoots(Optional ByRef warnings As String = "") As Collection
    Dim roots As New Collection, stores As Outlook.Stores, store As Outlook.Store, root As Outlook.Folder, n As Long
    Dim number As Long, description As String, origin As String
    Set stores = MailApp().Session.Stores
    For n = 1 To stores.Count
        Set root = Nothing: Set store = Nothing
        On Error Resume Next
        Err.Clear
        Set store = stores.Item(n)
        If Not store Is Nothing Then Set root = store.GetRootFolder
        number = Err.Number: description = Err.Description: origin = Err.Source
        On Error GoTo 0
        If number <> 0 Then warnings = warnings & vbCrLf & PT_ErrorText("Read mailbox " & CStr(n), number, description, origin, "modPersonalOutlookTools.PT_ProfileRoots")
        If Not root Is Nothing Then roots.Add root
    Next n
    Set PT_ProfileRoots = roots
End Function

' Refresh chain-search progress and let a modeless Close request stop between batches.
Private Function PT_V6Progress(ByVal model As Object, ByVal panel As frmPersonalOutlook, ByVal status As String) As Boolean
    Dim tick As Double, elapsed As Double
    If Not panel Is Nothing Then
        tick = Timer
        If model.Exists("lastPaint") Then elapsed = tick - CDbl(model("lastPaint")) Else elapsed = 1
        If elapsed < 0 Or elapsed >= 0.15 Then
            panel.ReportChainProgress status: DoEvents: model("lastPaint") = tick
        End If
        If panel.CancelRequested Then model("cancelled") = True
    End If
    PT_V6Progress = Not CBool(model("cancelled"))
End Function

' Resolve a visible participant to a usable SMTP address for the chain audience comparison.
Private Function PT_V6Address(ByVal entry As Outlook.AddressEntry) As String
    Dim exchangeUser As Outlook.ExchangeUser, address As String
    On Error Resume Next
    If Not entry Is Nothing Then
        address = PT_V6Property(entry.PropertyAccessor, "0x39FE001F")
        If Len(address) = 0 Then address = entry.Address
        If InStr(address, "@") = 0 And UCase$(entry.Type) = "EX" Then
            Set exchangeUser = entry.GetExchangeUser
            If Not exchangeUser Is Nothing Then address = exchangeUser.PrimarySmtpAddress
        End If
    End If
    On Error GoTo 0
    If InStr(address, "@") > 1 And InStr(address, " ") = 0 Then PT_V6Address = LCase$(Trim$(address))
End Function

' Create an order-independent participant or identity string from distinct dictionary keys.
Private Function PT_V6SortedKeys(ByVal values As Object) As String
    Dim keys As Variant, i As Long, j As Long, temp As String
    If values.Count = 0 Then Exit Function
    keys = values.Keys
    For i = LBound(keys) To UBound(keys) - 1
        For j = i + 1 To UBound(keys)
            If StrComp(CStr(keys(i)), CStr(keys(j)), vbBinaryCompare) > 0 Then
                temp = CStr(keys(i)): keys(i) = keys(j): keys(j) = temp
            End If
        Next j
    Next i
    PT_V6SortedKeys = Join(keys, "|")
End Function

' Resolve the visible sender and recipients so changes in the audience form separate chain groups.
Private Function PT_V6Participants(ByVal mail As Outlook.MailItem, ByRef description As String) As String
    Dim values As Object, recipient As Outlook.Recipient, address As String, fromAddress As String
    Set values = PT_V6Dict()
    fromAddress = PT_V6Address(mail.Sender)
    If Len(fromAddress) = 0 Then
        fromAddress = LCase$(Trim$(mail.SenderEmailAddress))
        If InStr(fromAddress, "@") < 2 Or InStr(fromAddress, " ") > 0 Then Exit Function
    End If
    values(fromAddress) = True
    address = LCase$(PT_V6Property(mail.PropertyAccessor, "0x5D02001F"))
    If InStr(address, "@") > 1 Then values(address) = True ' Represented From, for delegated sending.
    If mail.Recipients.Count = 0 Then Exit Function ' Missing recipient information cannot prove equal audiences.
    For Each recipient In mail.Recipients
        address = PT_V6Address(recipient.AddressEntry)
        If Len(address) = 0 Then Exit Function
        values(address) = True
        If Len(description) > 0 Then description = description & "; "
        description = description & address
    Next recipient
    PT_V6Participants = PT_V6SortedKeys(values)
End Function

' Record the reply-link metadata used to detect a changed message during action revalidation.
Private Function PT_V6Identity(ByVal mail As Outlook.MailItem) As String
    Dim tokens As Collection, strong As Boolean, token As Variant, values As Object
    Set tokens = PT_V6MailTokens(mail, strong)
    Set values = PT_V6Dict()
    For Each token In tokens: values(CStr(token)) = True: Next token
    PT_V6Identity = PT_V6SortedKeys(values)
End Function

' Load candidate details, attachment protection and saved identity without changing the message.
Private Function PT_V6Hydrate(ByVal envelope As Object, ByVal component As String, ByVal strong As Boolean, ByVal model As Object, Optional ByVal subjectOnly As Boolean = False) As Object
    Dim mail As Outlook.MailItem, row As Object, folder As Outlook.Folder, destination As Outlook.Folder, info As Object
    Dim key As String, participants As String, recipients As String, attachment As Outlook.Attachment, html As String, messageDate As Date
    On Error GoTo Failed
    Set folder = envelope("folder")
    Set mail = MailApp().Session.GetItemFromID(CStr(envelope("entry")), folder.StoreID)
    If mail.Parent.EntryID <> folder.EntryID Or mail.Parent.StoreID <> folder.StoreID Then Err.Raise vbObjectError + 1000, "modPersonalOutlookTools.PT_V6Hydrate", "Message moved while locating; kept."
    If Not mail.Sent Or Not mail.Saved Then Exit Function
    ' A subject-only candidate must still match the full subject when its details are opened.
    If subjectOnly Then
        If Not PT_ChainSubjectMatches(CStr(model("subject")), mail.Subject, CLng(model("match"))) Then Exit Function
    End If
    participants = PT_V6Participants(mail, recipients)
    Set row = PT_V6Dict()
    ' Keep the original ordering date for chains and use received time first for subject matches.
    messageDate = PT_ItemDate(mail, False) ' Prefer actual receipt time over the remote sender clock; sent time remains the fallback.
    row.Add "record", PT_Record(mail, messageDate, "")
    row.Add "component", component
    row.Add "participants", participants
    row.Add "identity", PT_V6Identity(mail)
    row.Add "group", component ' Reply links define a chain; changing To/Cc does not create a separate conversation.
    row.Add "messageIDs", PT_V6MessageIDs(PT_V6Property(mail.PropertyAccessor, "0x1035001F"))
    row.Add "replyIDs", PT_V6MessageIDs(PT_V6Property(mail.PropertyAccessor, "0x1039001F") & " " & PT_V6Property(mail.PropertyAccessor, "0x1042001F"))
    row.Add "threadIndex", PT_V6Index(mail, False)
    row.Add "hasReplyParent", (row("replyIDs").Count > 0 Or Len(CStr(row("threadIndex"))) > 44)
    row.Add "exactCopy", model("exactCopies").Exists(folder.StoreID & "|" & mail.EntryID)
    row.Add "copyClass", ""
    If CBool(row("exactCopy")) Then row("copyClass") = CStr(model("exactCopies")(folder.StoreID & "|" & mail.EntryID))
    row.Add "sender", mail.SenderName & " <" & mail.SenderEmailAddress & ">"
    row.Add "recipients", recipients
    row.Add "files", 0&
    row.Add "fileNames", ""
    If mail.BodyFormat = olFormatHTML Then html = mail.HTMLBody
    For Each attachment In mail.Attachments
        If PT_IsFileAttachment(attachment, html) Then
            row("files") = CLng(row("files")) + 1
            row("fileNames") = CStr(row("fileNames")) & attachment.FileName & "; "
        End If
    Next attachment
    row.Add "strong", strong
    row.Add "latest", False
    row.Add "subjectOnly", subjectOnly
    row.Add "wantDelete", Not subjectOnly ' Subject resemblance alone never preselects an action.
    row.Add "reason", ""
    If Not subjectOnly Then
        If Not strong Then row("reason") = "Kept: no proven reply link"

    End If
    If CDate(row("record")(6)) = 0 Then row("reason") = "Kept: date unavailable"
    key = folder.StoreID & "|" & folder.EntryID
    row.Add "folderKey", key
    If Not model("folders").Exists(key) Then
        Set info = PT_V6Dict()
        info.Add "folder", folder
        info.Add "label", folder.Store.DisplayName & " - " & folder.FolderPath
        info.Add "include", True
        info.Add "count", 0&
        Set destination = folder.Store.GetDefaultFolder(olFolderDeletedItems)
        info.Add "destination", destination
        info.Add "permanent", (folder.EntryID = destination.EntryID)
        model("folders").Add key, info
    End If
    Set info = model("folders")(key)
    info("count") = CLng(info("count")) + 1
    row.Add "permanent", CBool(info("permanent"))
    Set PT_V6Hydrate = row
    Exit Function
Failed:
    model("warnings") = CStr(model("warnings")) & vbCrLf & PT_ErrorText("Read message details for chain review", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_V6Hydrate")
End Function

' roots is explicit so tests can supply only their owned PST. The UI supplies profile roots.
Public Function PT_BuildChainReview(ByVal roots As Collection, ByVal selected As Collection, ByVal allChains As Boolean, Optional ByVal panel As frmPersonalOutlook = Nothing, Optional ByVal searchSettings As Object = Nothing) As Object
    Dim model As Object, parents As Object, visited As Object, selectedRoots As Object, componentCounts As Object, strongComponents As Object
    Dim envelopes As New Collection, rows As New Collection, seeds As New Collection, root As Outlook.Folder, mail As Outlook.MailItem
    Dim envelope As Object, row As Object, tokens As Collection, token As Variant, component As String, strong As Boolean, group As String
    Dim keepers As Object, index As Long
    Dim matchMode As Long, subjectOnly As Boolean, linked As Boolean
    Set model = PT_V6Dict(): Set parents = PT_V6Dict(): Set visited = PT_V6Dict()
    Set selectedRoots = PT_V6Dict(): Set componentCounts = PT_V6Dict(): Set strongComponents = PT_V6Dict()
    Set keepers = PT_V6Dict()
    model.Add "folders", PT_V6Dict(): model.Add "warnings", "": model.Add "cancelled", False
    model.Add "rows", rows: model.Add "keepers", keepers: model.Add "keepFiles", True
    model.Add "cutoff", CDate(0)
    model.Add "match", 0&: model.Add "subject", ""
    If Not searchSettings Is Nothing Then
        model.Add "scope", searchSettings
        If Not searchSettings("allTime") Then model("cutoff") = DateAdd("d", -CLng(searchSettings("days")), Date)
        If searchSettings.Exists("match") And Not allChains Then matchMode = CLng(searchSettings("match"))
    End If
    If matchMode > 0 Then
        Set mail = selected(1)
        model("subject") = PT_NormaliseSubject(mail.Subject)
        If Len(model("subject")) = 0 Then Err.Raise 5, , "Choose an email with a subject or use Linked chain."
        model("match") = matchMode
    End If
    If Not allChains Then
        For Each mail In selected
            Set tokens = Nothing: strong = False
            On Error Resume Next
            Err.Clear
            Set tokens = PT_V6MailTokens(mail, strong)
            If Err.Number <> 0 Then model("warnings") = CStr(model("warnings")) & vbCrLf & PT_ErrorText("Read selected email reply links", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_BuildChainReview")
            On Error GoTo 0
            If Not tokens Is Nothing Then
                PT_V6Join parents, tokens
                For Each token In tokens: seeds.Add CStr(token): Next token
            End If
        Next mail
    End If
    For Each root In roots
        PT_V6Collect root, model, envelopes, parents, visited, panel, 0, ScanDescendants(root, searchSettings)
        If CBool(model("cancelled")) Then Set PT_BuildChainReview = model: Exit Function
    Next root
    PT_JoinExactCopies selected, envelopes, parents, model, panel, allChains
    If CBool(model("cancelled")) Then Set PT_BuildChainReview = model: Exit Function
    For Each token In seeds: selectedRoots(PT_V6Find(parents, CStr(token))) = True: Next token
    For Each envelope In envelopes
        Set tokens = envelope("tokens")
        component = PT_V6Find(parents, CStr(tokens(1)))
        If Not componentCounts.Exists(component) Then componentCounts.Add component, 0&
        componentCounts(component) = CLng(componentCounts(component)) + 1
        If CBool(envelope("strong")) Or model("exactCopies").Exists(CStr(envelope("store")) & "|" & CStr(envelope("entry"))) Then strongComponents(component) = True
    Next envelope
    For Each envelope In envelopes
        Set tokens = envelope("tokens")
        component = PT_V6Find(parents, CStr(tokens(1)))
        linked = (allChains And CLng(componentCounts(component)) > 1) Or (Not allChains And selectedRoots.Exists(component))
        subjectOnly = False
        If Not linked And matchMode > 0 Then subjectOnly = PT_ChainSubjectMatches(CStr(model("subject")), CStr(envelope("subject")), matchMode)
        If linked Or subjectOnly Then
            Set row = PT_V6Hydrate(envelope, component, strongComponents.Exists(component), model, subjectOnly)
            If Not row Is Nothing Then
                If CDate(row("record")(6)) >= CDate(model("cutoff")) Then
                    rows.Add row
                End If
            End If
        End If
        index = index + 1
        If index Mod 25 = 0 Then
            If Not PT_V6Progress(model, panel, "Reading message details: " & CStr(index) & " / " & CStr(envelopes.Count)) Then Set PT_BuildChainReview = model: Exit Function
        End If
    Next envelope
    PT_ProtectChainTips model
    PT_VerifyChainFileCoverage model, panel
    Set PT_BuildChainReview = model
End Function

' Allow an action only for an unprotected row, respecting the file-attachment option.
Public Function PT_ChainRowEligible(ByVal row As Object, ByVal keepFiles As Boolean) As Boolean
    PT_ChainRowEligible = (Len(CStr(row("reason"))) = 0 And Not CBool(row("latest")))
    If keepFiles And CLng(row("files")) > 0 Then
        If Not row.Exists("filesRetained") Then
            PT_ChainRowEligible = False
        ElseIf Not CBool(row("filesRetained")) Then
            PT_ChainRowEligible = False
        End If
    End If
End Function

' Explain why a row is kept or requires an individual move or deletion choice.
Public Function PT_ChainRowStatus(ByVal row As Object, ByVal keepFiles As Boolean) As String
    PT_ChainRowStatus = CStr(row("reason"))
    If Len(PT_ChainRowStatus) > 0 Then Exit Function
    If keepFiles And CLng(row("files")) > 0 Then
        If row.Exists("filesRetained") Then
            If CBool(row("filesRetained")) Then PT_ChainRowStatus = "Files verified in retained newer mail": Exit Function
        End If
        PT_ChainRowStatus = "Kept: unique or unverified files"
    ElseIf PT_IsSubjectOnly(row) Then
        PT_ChainRowStatus = "Subject only - choose individually"
    ElseIf CBool(row("permanent")) Then
        PT_ChainRowStatus = "Permanent deletion if selected"
    Else
        PT_ChainRowStatus = "Move to Deleted Items if selected"
    End If
End Function

' Accept older review records that predate the optional subject-only marker.
Private Function PT_IsSubjectOnly(ByVal row As Object) As Boolean
    ' Older review records and existing callers may omit the new subject-only marker.
    If row.Exists("subjectOnly") Then PT_IsSubjectOnly = CBool(row("subjectOnly"))
End Function

' Recheck the saved item, sent state, participants and reply metadata immediately before an action.
Private Sub PT_V6ValidateRow(ByVal row As Object, ByRef item As Outlook.MailItem)
    Dim recipients As String
    Set item = PT_ReloadRecord(row("record"))
    If Not item.Sent Then Err.Raise vbObjectError + 1001, "modPersonalOutlookTools.PT_V6ValidateRow", "Message is no longer sent; kept."
    If PT_IsSubjectOnly(row) Then
        If item.Subject <> CStr(row("record")(4)) Then Err.Raise 5, , "Subject changed after review; kept."
    End If
    If PT_V6Participants(item, recipients) <> CStr(row("participants")) Then Err.Raise vbObjectError + 1002, "modPersonalOutlookTools.PT_V6ValidateRow", "Participants changed; kept."
    If PT_V6Identity(item) <> CStr(row("identity")) Then Err.Raise vbObjectError + 1003, "modPersonalOutlookTools.PT_V6ValidateRow", "Reply-link metadata changed; kept."
End Sub

' Validate the chosen candidate and newer keepers, then apply its requested move or deletion.
Private Function PT_V6ApplyRow(ByVal row As Object, ByVal model As Object, ByVal destination As Outlook.Folder) As Boolean
    Dim item As Outlook.MailItem, retained As Outlook.MailItem, keeper As Object, info As Object, moved As Object
    PT_V6ValidateRow row, item
    If Not PT_ChainRowEligible(row, CBool(model("keepFiles"))) Then Err.Raise vbObjectError + 1004, "modPersonalOutlookTools.PT_V6ApplyRow", "This preview row is protected."
    If CBool(model("keepFiles")) And PT_HasFileAttachments(item) Then
        If Not PT_ChainFilesRetained(row, model) Then Err.Raise vbObjectError + 1005, "modPersonalOutlookTools.PT_V6ApplyRow", "Attachment bytes are no longer verified in retained later mail; kept."
    End If
    ' Real chain rows still need a verified newer keeper. Subject-only rows require an explicit tick instead.
    If Not model("keepers").Exists(CStr(row("group"))) Then Err.Raise vbObjectError + 1006, "modPersonalOutlookTools.PT_V6ApplyRow", "No retained newer message; kept."
    Dim verifiedNewer As Boolean, verifiedCopy As Boolean, token As Variant, parentID As Variant, oldIndex As String, newIndex As String ' Require live keeper evidence for both linked and subject-only choices.
    For Each keeper In model("keepers")(CStr(row("group")))
        PT_V6ValidateRow keeper, retained
        If CBool(row("exactCopy")) And CStr(keeper("copyClass")) = CStr(row("copyClass")) Then
            If PT_ExactMessageCopy(item, retained) Then verifiedCopy = True ' Recheck bytes/content at action time; a keeper or candidate may have gained information since the preview.
        End If ' Recheck retained evidence before any move/delete, including subject-only selections.
        If PT_ItemDate(retained, False) > PT_ItemDate(item, False) Then verifiedNewer = True
        For Each token In keeper("replyIDs")
            For Each parentID In row("messageIDs")
                If CStr(token) = CStr(parentID) Then verifiedNewer = True ' A proven descendant can have an earlier remote timestamp.
            Next parentID
        Next token
        oldIndex = CStr(row("threadIndex")): newIndex = CStr(keeper("threadIndex"))
        If Len(oldIndex) >= 44 And Len(newIndex) > Len(oldIndex) Then
            If Left$(newIndex, Len(oldIndex)) = oldIndex Then verifiedNewer = True
        End If
    Next keeper
    If CBool(row("exactCopy")) And Not verifiedCopy Then Err.Raise vbObjectError + 1009, "modPersonalOutlookTools.PT_V6ApplyRow", "No unchanged retained exact copy could be verified; kept."
    If Not verifiedNewer Then Err.Raise vbObjectError + 1007, "modPersonalOutlookTools.PT_V6ApplyRow", "No verified retained newer reply or message; kept."
    If Not destination Is Nothing Then
        ' A message already in the destination needs no action, including one already in Deleted Items.
        If item.Parent.EntryID = destination.EntryID And item.Parent.StoreID = destination.StoreID Then Exit Function
        Set moved = item.Move(destination)
        If moved.Parent.EntryID <> destination.EntryID Or moved.Parent.StoreID <> destination.StoreID Then Err.Raise 5, , "Outlook did not verify the destination."
        PT_V6ApplyRow = True
        Exit Function
    End If
    Set info = model("folders")(CStr(row("folderKey")))
    If CBool(info("permanent")) Then
        If Not PT_PermanentHere(item.Parent) Then Err.Raise vbObjectError + 1008, "modPersonalOutlookTools.PT_V6ApplyRow", "Item is no longer in Deleted Items; kept."
        item.Delete
    Else
        Set moved = item.Move(info("destination"))
    End If
    PT_V6ApplyRow = True
End Function

' Apply only checked eligible rows across all pages and collect failures without processing them twice.
Public Function PT_ApplyChainReview(ByVal model As Object, ByRef failures As String, Optional ByVal destination As Outlook.Folder = Nothing) As Long
    Dim row As Object, info As Object, problem As String, changed As Boolean
    If CBool(model("cancelled")) Then Exit Function
    If Not destination Is Nothing Then
        PT_CheckFolder destination
        If destination.DefaultItemType <> olMailItem Then Err.Raise 5, , "Choose a destination mail folder."
    End If
    For Each row In model("rows")
        Set info = model("folders")(CStr(row("folderKey")))
        If CBool(info("include")) And CBool(row("wantDelete")) And PT_ChainRowEligible(row, CBool(model("keepFiles"))) Then
            On Error Resume Next
            Err.Clear
            changed = PT_V6ApplyRow(row, model, destination)
            problem = PT_ErrorText("PT_ApplyChainReview", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_ApplyChainReview")
            If Err.Number = 0 Then
                If changed Then PT_ApplyChainReview = PT_ApplyChainReview + 1
            Else
                failures = failures & vbCrLf & CStr(row("record")(4)) & ": " & problem
            End If
            On Error GoTo 0
        End If
    Next row
End Function

' Capture one starting email and retain its modeless search-and-review window.
Public Sub Mail_CleanEmailChains()
    Dim selected As Collection
    On Error GoTo Failed
    If bulkRunning Then Exit Sub
    If Not chainReviewPanel Is Nothing Then
        If chainReviewPanel.Visible Then Err.Raise 5, , "Close the current chain-cleanup window before starting another."
        Set chainReviewPanel = Nothing
    End If
    Set selected = PT_SelectedMessages()
    If selected.Count <> 1 Then Err.Raise 5, , "Select one individual email, then run Clean email chains."
    Set chainReviewPanel = New frmPersonalOutlook
    chainReviewPanel.PrepareChainReview selected
    chainReviewPanel.Show vbModeless
    Exit Sub
Failed:
    PT_ReportError "Clean selected email chain", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.Mail_CleanEmailChains"
End Sub

' Settings belong to this Windows user and Outlook profile. Store and folder IDs, not
' display names, identify the exact configured locations. Missing IDs fail closed.
Private Function PT_SettingsSection() As String
    Static profileSection As String
    ' Native timer ticks and many registry reads must not repeatedly dereference
    ' an Outlook session proxy just to discover the same profile name.
    If Len(profileSection) = 0 Then profileSection = "Outlook - " & MailApp().Session.CurrentProfileName
    PT_SettingsSection = profileSection
End Function

' Read this Windows user's setting in the current Outlook profile, using the supplied fallback when absent.
Public Function PT_ReadSetting(ByVal key As String, Optional ByVal fallback As String = "") As String
    PT_ReadSetting = GetSetting(PT_SETTINGS_APP, PT_SettingsSection(), key, fallback)
End Function

' Persist one setting under the existing Windows-user and Outlook-profile location.
Public Sub PT_WriteSetting(ByVal key As String, ByVal value As String)
    SaveSetting PT_SETTINGS_APP, PT_SettingsSection(), key, value
End Sub

' Load the last valid deletion age while retaining compatibility with earlier saved settings.
Public Function PT_LastAgeDays() As Long
    Dim value As String
    value = PT_ReadSetting("LastDeleteDays", "90")
    PT_LastAgeDays = 90
    If Len(value) > 0 And Len(value) <= 5 Then
        If Not value Like "*[!0-9]*" Then
            If CLng(value) <= 36500 Then PT_LastAgeDays = CLng(value)
        End If
    End If
End Function

' Store a validated age only after the user has selected it.
Public Sub PT_RememberAgeDays(ByVal days As Long)
    If days < 0 Or days > 36500 Then Err.Raise vbObjectError + 1020, "modPersonalOutlookTools.PT_RememberAgeDays", "Enter a whole number of days from 0 to 36500."
    PT_WriteSetting "LastDeleteDays", CStr(days)
End Sub

' Called once from ThisOutlookSession.Application_Startup. No chooser or success popup.


' This is the same age rule used by the manual delete macro. The selected source is
' required to be Deleted Items itself; there is no traversal of its subfolders.

' Quit cannot be cancelled. Skip/X means skip cleanup and let Outlook continue closing.
' A crash, forced process termination or disabled VBA cannot run this event.


' Capture the original error before reporting it. Generic COM descriptions alone
' hide the useful error number and operation that actually failed.
Public Function PT_ErrorText(ByVal operation As String, ByVal number As Long, ByVal description As String, Optional ByVal origin As String = "", Optional ByVal codeLocation As String = "") As String
    If number = 0 And Len(description) = 0 Then Exit Function
    If Len(Trim$(description)) = 0 Then description = "Outlook did not provide an error description."
    PT_ErrorText = "Action / step: " & operation
    If Len(codeLocation) > 0 Then PT_ErrorText = PT_ErrorText & vbCrLf & "Reported by: " & codeLocation
    PT_ErrorText = PT_ErrorText & vbCrLf & "Details: " & description & vbCrLf & "Error " & CStr(number) & " (0x" & Right$("00000000" & Hex$(number), 8) & ")"
    If Len(origin) > 0 Then PT_ErrorText = PT_ErrorText & vbCrLf & "Original source: " & origin
    PT_ErrorText = PT_ErrorText & vbCrLf & "Time: " & Format$(Now, "yyyy-mm-dd hh:nn:ss") & " | Outlook package: 2026-11-23"
End Function

' Format an operation's original error number, description and code location for the report window.
Public Sub PT_ReportError(ByVal operation As String, ByVal number As Long, ByVal description As String, Optional ByVal origin As String = "", Optional ByVal codeLocation As String = "")
    Dim detail As String, panel As frmPersonalOutlook
    detail = PT_ErrorText(operation, number, description, origin, codeLocation)
    On Error Resume Next
    PT_WriteSetting "LastError", Left$(detail, 60000)
    On Error GoTo NativeFallback
    Set panel = New frmPersonalOutlook
    panel.PrepareReadOnlyReport detail, True
    panel.Caption = operation
    panel.Show vbModal
    Unload panel
    Exit Sub
NativeFallback:
    ' If the Forms component itself cannot open, the native fallback still preserves
    ' the original details instead of reporting a second error from the reporter.
    MsgBox detail, vbExclamation, operation
End Sub

' Keep the complete diagnostic text in a scrollable window with copying support.
Public Sub PT_ShowReport(ByVal title As String, ByVal text As String, Optional ByVal modal As Boolean = False)
    Dim panel As frmPersonalOutlook
    Set panel = New frmPersonalOutlook
    panel.PrepareReadOnlyReport text, False
    panel.Caption = title
    If modal Then
        panel.Show vbModal
        Unload panel
    Else
        panel.Show vbModeless
    End If
End Sub

' Check the store's actual root and the MAPI type. Search-folder IDs provide an extra
' positive check if that property is unavailable. Absence from GetSearchFolders does
' not prove a normal folder: Outlook omits inactive search folders from that list.
Public Function PT_FolderKind(ByVal folder As Outlook.Folder) As Long
    Dim root As Outlook.Folder, search As Outlook.Folder, searches As Outlook.Folders
    Dim kind As Long, number As Long, description As String, origin As String, detail As String
    If folder Is Nothing Then Err.Raise vbObjectError + 1120, "modPersonalOutlookTools.PT_FolderKind", "Choose a folder first."
    On Error GoTo Failed
    ' Outlook exposes the user-visible store root (often the IPM subtree), which can
    ' itself report PR_FOLDER_TYPE = 1. Compare its ID before trusting that property.
    Set root = folder.Store.GetRootFolder
    If folder.EntryID = root.EntryID Then PT_FolderKind = 0: Exit Function
    On Error Resume Next
    Err.Clear
    kind = CLng(folder.PropertyAccessor.GetProperty("http://schemas.microsoft.com/mapi/proptag/0x36010003"))
    number = Err.Number: description = Err.Description: origin = Err.Source
    On Error GoTo 0
    If number = 0 And kind >= 0 And kind <= 2 Then PT_FolderKind = kind: Exit Function
    On Error GoTo Failed
    Set searches = folder.Store.GetSearchFolders
    For Each search In searches
        If search.EntryID = folder.EntryID Then PT_FolderKind = 2: Exit Function
    Next search
    Err.Raise vbObjectError + 1121, "Folder type check", "Outlook could not verify that this is a normal physical folder. It has been skipped. " & PT_ErrorText("Folder-property details", number, description, origin, "modPersonalOutlookTools.PT_FolderKind")
Failed:
    detail = PT_ErrorText("Cannot establish whether this is a normal folder", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_FolderKind")
    If number <> 0 Then detail = detail & vbCrLf & PT_ErrorText("Original folder-property failure", number, description, origin, "modPersonalOutlookTools.PT_FolderKind")
    Err.Raise vbObjectError + 1121, "Folder type check", detail
End Function

' Reject a Search Folder or mailbox heading when an operation requires a physical destination.
Public Sub PT_CheckFolder(ByVal folder As Outlook.Folder)
    Dim kind As Long
    kind = PT_FolderKind(folder)
    If kind = 2 Then Err.Raise vbObjectError + 965, "modPersonalOutlookTools.PT_CheckFolder", "Choose an actual folder, not a Search Folder."
    If kind = 0 Then Err.Raise vbObjectError + 966, "modPersonalOutlookTools.PT_CheckFolder", "Choose a folder beneath the mailbox/data-file heading."
End Sub

' Parse RFC-style message-id tokens without the optional VBScript RegExp component.
' Subjects are never used as a chain key. Preserve the case-sensitive ID left side.
Private Function PT_V6MessageIDs(ByVal text As String) As Collection
    Dim ids As New Collection, first As Long, last As Long, nested As Long, at As Long, token As String, n As Long, valid As Boolean
    first = InStr(1, text, "<", vbBinaryCompare)
    Do While first > 0
        last = InStr(first + 1, text, ">", vbBinaryCompare)
        If last = 0 Then Exit Do
        nested = InStr(first + 1, text, "<", vbBinaryCompare)
        If nested > 0 And nested < last Then
            first = nested
        Else
            token = Mid$(text, first + 1, last - first - 1)
            at = InStrRev(token, "@", -1, vbBinaryCompare)
            valid = (at > 1 And at < Len(token))
            For n = 1 To Len(token)
                If AscW(Mid$(token, n, 1)) >= 0 And AscW(Mid$(token, n, 1)) <= 32 Then valid = False: Exit For
            Next n
            If valid Then ids.Add "<" & Left$(token, at) & LCase$(Mid$(token, at + 1)) & ">"
            first = InStr(last + 1, text, "<", vbBinaryCompare)
        End If
    Loop
    Set PT_V6MessageIDs = ids
End Function

' Scan permitted physical mail folders, use table metadata where possible, and report incomplete coverage.
Private Sub PT_V6Collect(ByVal folder As Outlook.Folder, ByVal model As Object, ByVal envelopes As Collection, ByVal parents As Object, ByVal visited As Object, ByVal panel As frmPersonalOutlook, ByVal depth As Long, Optional ByVal descend As Boolean = True)
    Dim key As String, kind As Long, table As Outlook.Table, row As Outlook.Row, child As Outlook.Folder
    Dim envelope As Object, tokens As Collection, column As Variant, strong As Boolean, count As Long
    Dim label As String, stage As String, storeID As String, entryID As String, fallback As Boolean, item As Object
    Dim index As String, messageID As String, references As String, replyTo As String, problem As String, filter As String, dateText As String, allowed As Boolean
    Dim batch As Variant, rowIndex As Long, fields As Variant, field As Variant
    Dim accessor As Outlook.PropertyAccessor, ipcClass As String, useItem As Boolean, lastRow As Long
    Dim subject As String, mailRow As Boolean, requiredFallback As Boolean, added As Long
    label = "A folder": stage = "Read folder identity"
    On Error GoTo FolderFailed
    If depth > 100 Or CBool(model("cancelled")) Then Exit Sub
    storeID = folder.StoreID: key = storeID & "|" & folder.EntryID
    If visited.Exists(key) Then
        If CBool(visited(key)) Or Not descend Then Exit Sub
        visited(key) = True
        GoTo Children
    End If
    visited.Add key, descend
    ' Cache a plain string before touching risky provider operations. Error handlers
    ' must never ask the already-failed folder object for another property.
    label = folder.FolderPath
    stage = "Check folder type": kind = PT_FolderKind(folder)
    If kind = 2 Then Exit Sub
    If Not PT_V6Progress(model, panel, "Locating: " & label & " | " & CStr(envelopes.Count) & " messages indexed") Then Exit Sub
    stage = "Read folder item type"
    allowed = True

    If kind = 1 And folder.DefaultItemType = olMailItem And allowed Then
        If CDate(model("cutoff")) > 0 Then
            dateText = Format$(CDate(model("cutoff")), "ddddd h:nn AMPM")
            filter = "[ReceivedTime] >= '" & dateText & "' OR [SentOn] >= '" & dateText & "' OR [CreationTime] >= '" & dateText & "'"
        End If
        stage = "Open date-filtered message table": Set table = folder.GetTable(filter, olUserItems)
        ' Add EntryID first, under the folder error handler. Other providers
        ' may omit an optional column; never interpret a shifted array offset.
        Set accessor = folder.PropertyAccessor
        table.Columns.RemoveAll: table.Columns.Add "EntryID"
        fields = Array("MessageClass", "Subject", PT_V6_TAG & "0x00710102", PT_V6_TAG & "0x1035001F", PT_V6_TAG & "0x1039001F", PT_V6_TAG & "0x1042001F")
        For Each field In fields
            On Error Resume Next
            Err.Clear: table.Columns.Add CStr(field)
            If Err.Number <> 0 Then
                fallback = True
                If added < 2 Then requiredFallback = True
                On Error GoTo FolderFailed
                Exit For
            End If
            On Error GoTo FolderFailed
            added = added + 1
        Next field
        Do Until table.EndOfTable
            stage = "Read message metadata in batches"
            batch = table.GetArray(128)
            lastRow = TableBatchLastRow(batch)
            If lastRow < 0 Then
                If Not table.EndOfTable Then Err.Raise 5, , "Outlook could not return the next batch of messages."
                Exit Do
            End If
            For rowIndex = 0 To lastRow
            entryID = CStr(batch(0, rowIndex)): strong = False: subject = "": Set item = Nothing
            useItem = requiredFallback
            If Not useItem Then
                ipcClass = BatchText(batch(1, rowIndex))
                useItem = (Len(ipcClass) = 0)
            End If
            If useItem Then
                On Error Resume Next
                Err.Clear: Set item = MailApp().Session.GetItemFromID(entryID, storeID)
                problem = Err.Description
                On Error GoTo FolderFailed
                If item Is Nothing Then
                    model("warnings") = CStr(model("warnings")) & vbCrLf & "Skipped an unavailable email in " & label & ". " & problem
                    GoTo NextEnvelope
                End If
                mailRow = TypeOf item Is Outlook.MailItem
            Else
                mailRow = (LCase$(Left$(ipcClass, 8)) = "ipm.note")
                subject = BatchText(batch(2, rowIndex))
            End If
            If mailRow Then
                index = "": messageID = "": references = "": replyTo = ""
                If Not fallback Then
                    If IsArray(batch(3, rowIndex)) Then index = accessor.BinaryToString(batch(3, rowIndex))
                    messageID = BatchText(batch(4, rowIndex)): references = BatchText(batch(5, rowIndex))
                    replyTo = BatchText(batch(6, rowIndex))
                End If
                On Error Resume Next
                Err.Clear
                ' Outlook tables can truncate long strings. Re-read a full item when
                ' a metadata field reaches the documented table string limit.
                If useItem Or fallback Or Len(index) >= 510 Or Len(messageID) >= 255 Or Len(references) >= 255 Or Len(replyTo) >= 255 Or Len(subject) >= 255 Then
                    If item Is Nothing Then Set item = MailApp().Session.GetItemFromID(entryID, storeID)
                    Set tokens = PT_V6MailTokens(item, strong)
                    subject = item.Subject
                Else
                    Set tokens = PT_V6Tokens(index, messageID, references, replyTo, storeID & entryID, strong)
                End If
                problem = ""
                If Err.Number <> 0 Then problem = PT_ErrorText("Read chain metadata in " & label, Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_V6Collect")
                On Error GoTo FolderFailed
                If Len(problem) = 0 Then
                    Set envelope = PT_V6Dict()
                    envelope.Add "folder", folder: envelope.Add "entry", entryID: envelope.Add "store", storeID
                    envelope.Add "tokens", tokens: envelope.Add "strong", strong
                    envelope.Add "subject", subject
                    envelopes.Add envelope
                    PT_V6Join parents, tokens
                Else
                    model("warnings") = CStr(model("warnings")) & vbCrLf & problem
                End If
                Set item = Nothing: Set tokens = Nothing
            End If
NextEnvelope:
            count = count + 1
            If count Mod 100 = 0 Then
                If Not PT_V6Progress(model, panel, "Locating: " & label & " | " & CStr(envelopes.Count) & " messages indexed") Then Exit Sub
            End If
            Next rowIndex
        Loop
    End If
Children:
    If Not descend Then Exit Sub
    On Error GoTo ChildrenFailed
    For Each child In folder.Folders
        PT_V6Collect child, model, envelopes, parents, visited, panel, depth + 1
        If CBool(model("cancelled")) Then Exit Sub
    Next child
    Exit Sub
FolderFailed:
    model("warnings") = CStr(model("warnings")) & vbCrLf & PT_ErrorText(stage & " - " & label, Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_V6Collect")
    Resume Children
ChildrenFailed:
    model("warnings") = CStr(model("warnings")) & vbCrLf & PT_ErrorText("Read subfolders of " & label, Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_V6Collect")
End Sub

' Folder rules are read from one complete registry slot. Saving writes the inactive
' slot first and switches one pointer last, so a failed save leaves the old rules intact.
Private Function PT_RulesSection(ByVal slot As String) As String
    PT_RulesSection = PT_SettingsSection() & " - Folder rules " & slot
End Function

' Create a disabled rule with all expected fields so Cancel can discard it cleanly.
Public Function PT_NewFolderRule(Optional ByVal storedID As String = "") As Object
    Dim rule As Object, sources As New Collection
    Set rule = PT_V6Dict()
    If Len(storedID) = 0 Then storedID = WorkflowID()
    rule.Add "id", storedID: rule.Add "fault", "": rule.Add "alsoRun", False
    rule.Add "seenFault", ""
    rule.Add "name", "New rule": rule.Add "event", "close": rule.Add "action", "move"
    rule.Add "days", 0&: rule.Add "enabled", False
    rule.Add "category", "": rule.Add "note", "": rule.Add "attachment", ""
    rule.Add "sources", sources: rule.Add "destination", Nothing
    Set PT_NewFolderRule = rule
End Function

' Record exact physical-folder and store IDs instead of relying on a possibly duplicated display name.
Public Function PT_FolderReference(ByVal folder As Outlook.Folder) As Object
    Dim ref As Object
    PT_CheckFolder folder
    Set ref = PT_V6Dict()
    ref.Add "entry", folder.EntryID: ref.Add "store", folder.StoreID
    ref.Add "label", folder.Store.DisplayName & " - " & folder.FolderPath
    Set PT_FolderReference = ref
End Function

' Reopen the exact saved folder and reject missing or mismatched references.
Public Function PT_ResolveFolderReference(ByVal ref As Object) As Outlook.Folder
    If ref Is Nothing Then Err.Raise vbObjectError + 1100, "modPersonalOutlookTools.PT_ResolveFolderReference", "Choose a folder first."
    If Len(CStr(ref("entry"))) = 0 Or Len(CStr(ref("store"))) = 0 Then Err.Raise vbObjectError + 1101, "modPersonalOutlookTools.PT_ResolveFolderReference", "A saved folder ID is missing. Choose the folder again."
    Set PT_ResolveFolderReference = MailApp().Session.GetFolderFromID(CStr(ref("entry")), CStr(ref("store")))
End Function

' Combine store and folder identity for deduplication across rule sources.
Private Function PT_ReferenceKey(ByVal ref As Object) As String
    PT_ReferenceKey = CStr(ref("store")) & "|" & CStr(ref("entry"))
End Function

' Read one stored folder reference from a complete rule-settings slot.
Private Function PT_LoadRuleRef(ByVal section As String, ByVal prefix As String) As Object
    Dim ref As Object, entry As String, store As String
    entry = GetSetting(PT_SETTINGS_APP, section, prefix & "Entry", "")
    store = GetSetting(PT_SETTINGS_APP, section, prefix & "Store", "")
    If Len(entry) = 0 And Len(store) = 0 Then Exit Function
    Set ref = PT_V6Dict()
    ref.Add "entry", entry: ref.Add "store", store
    ref.Add "label", GetSetting(PT_SETTINGS_APP, section, prefix & "Label", "Saved folder")
    Set PT_LoadRuleRef = ref
End Function

' Write one complete folder reference to the inactive settings slot.
Private Sub PT_SaveRuleRef(ByVal section As String, ByVal prefix As String, ByVal ref As Object)
    If ref Is Nothing Then
        SaveSetting PT_SETTINGS_APP, section, prefix & "Entry", ""
        SaveSetting PT_SETTINGS_APP, section, prefix & "Store", ""
        SaveSetting PT_SETTINGS_APP, section, prefix & "Label", ""
    Else
        SaveSetting PT_SETTINGS_APP, section, prefix & "Entry", CStr(ref("entry"))
        SaveSetting PT_SETTINGS_APP, section, prefix & "Store", CStr(ref("store"))
        SaveSetting PT_SETTINGS_APP, section, prefix & "Label", CStr(ref("label"))
    End If
End Sub

' Validate a bounded whole-number setting before using it for loops or age limits.
Private Function PT_SettingInteger(ByVal text As String, ByVal maximum As Long) As Long
    If Len(text) = 0 Or Len(text) > 6 Then Err.Raise vbObjectError + 1102, "modPersonalOutlookTools.PT_SettingInteger", "Invalid saved rule number. Open Configure folder rules."
    If text Like "*[!0-9]*" Then Err.Raise vbObjectError + 1102, "modPersonalOutlookTools.PT_SettingInteger", "Invalid saved rule number. Open Configure folder rules."
    If CLng(text) > maximum Then Err.Raise vbObjectError + 1102, "modPersonalOutlookTools.PT_SettingInteger", "Saved rule number is outside its allowed range."
    PT_SettingInteger = CLng(text)
End Function

' Read the active complete rule set and supply fields required by older stored rules.
Public Function PT_LoadFolderRules() As Collection
    Dim rules As New Collection, rule As Object, ref As Object, sources As Collection
    Dim slot As String, section As String, prefix As String, count As Long, n As Long, j As Long, flag As String
    slot = PT_ReadSetting("ActiveRuleSlot", "")
    If Len(slot) = 0 Then Set PT_LoadFolderRules = rules: Exit Function
    If slot <> "0" And slot <> "1" Then Err.Raise vbObjectError + 1103, "modPersonalOutlookTools.PT_LoadFolderRules", "The saved rule set is invalid. Nothing was run."
    section = PT_RulesSection(slot)
    If GetSetting(PT_SETTINGS_APP, section, "Complete", "0") <> "1" Then Err.Raise vbObjectError + 1104, "modPersonalOutlookTools.PT_LoadFolderRules", "The saved rule set is incomplete. Nothing was run."
    count = PT_SettingInteger(GetSetting(PT_SETTINGS_APP, section, "Count", ""), 200)
    For n = 1 To count
        prefix = "R" & CStr(n) & "_"
        Set rule = PT_NewFolderRule(GetSetting(PT_SETTINGS_APP, section, prefix & "ID", "legacy-" & n))
        rule("name") = GetSetting(PT_SETTINGS_APP, section, prefix & "Name", "Rule " & CStr(n))
        rule("event") = GetSetting(PT_SETTINGS_APP, section, prefix & "Event", "")
        rule("alsoRun") = (GetSetting(PT_SETTINGS_APP, section, prefix & "AlsoRun", IIf(rule("event") = "open" Or rule("event") = "close", "1", "0")) = "1")
        rule("action") = GetSetting(PT_SETTINGS_APP, section, prefix & "Action", "")
        rule("category") = GetSetting(PT_SETTINGS_APP, section, prefix & "Category", "")
        rule("note") = GetSetting(PT_SETTINGS_APP, section, prefix & "Note", "")
        rule("attachment") = GetSetting(PT_SETTINGS_APP, section, prefix & "Attachment", "")
        rule("days") = PT_SettingInteger(GetSetting(PT_SETTINGS_APP, section, prefix & "Days", ""), 36500)
        flag = GetSetting(PT_SETTINGS_APP, section, prefix & "Enabled", "")
        If flag <> "0" And flag <> "1" Then Err.Raise vbObjectError + 1105, "modPersonalOutlookTools.PT_LoadFolderRules", "A saved rule has an invalid enabled flag."
        rule("enabled") = (flag = "1")
        If rule("event") <> "open" And rule("event") <> "close" And rule("event") <> "receive" And rule("event") <> "run" And rule("event") <> "manual" Then Err.Raise vbObjectError + 1106, "modPersonalOutlookTools.PT_LoadFolderRules", "A saved rule has an invalid event."
        If Not PT_ValidRuleAction(CStr(rule("action"))) Then Err.Raise vbObjectError + 1107, "modPersonalOutlookTools.PT_LoadFolderRules", "A saved rule has an invalid action."
        Set sources = rule("sources")
        For j = 1 To PT_SettingInteger(GetSetting(PT_SETTINGS_APP, section, prefix & "Sources", ""), 100)
            Set ref = PT_LoadRuleRef(section, prefix & "S" & CStr(j) & "_")
            If ref Is Nothing Then Err.Raise vbObjectError + 1108, "modPersonalOutlookTools.PT_LoadFolderRules", "A saved source folder is incomplete."
            sources.Add ref
        Next j
        Set rule("destination") = PT_LoadRuleRef(section, prefix & "D_")
        rule("fault") = GetSetting(PT_SETTINGS_APP, section, prefix & "Fault", "")
        rule("seenFault") = GetSetting(PT_SETTINGS_APP, section, prefix & "SeenFault", "")
        ObserveRuleFault rule, PT_ReadSetting("RuleFault_" & rule("id"), "")
        If Len(CStr(rule("fault"))) = 0 Then rule("fault") = RuleProblem(rule)
        If Len(CStr(rule("fault"))) Then rule("enabled") = False
        rules.Add rule
    Next n
    Set PT_LoadFolderRules = rules
End Function

' Validate the editable settings without reading item contents or changing any folder.
Public Sub PT_ValidateFolderRule(ByVal rule As Object, Optional ByVal resolve As Boolean = False)
    Dim ref As Object, destination As Object, folder As Outlook.Folder
    If Len(Trim$(CStr(rule("name")))) = 0 Then Err.Raise vbObjectError + 1109, "modPersonalOutlookTools.PT_ValidateFolderRule", "Give each rule a name."
    If rule("event") <> "open" And rule("event") <> "close" And rule("event") <> "receive" And rule("event") <> "run" And rule("event") <> "manual" Then Err.Raise vbObjectError + 1106, "modPersonalOutlookTools.PT_ValidateFolderRule", "Choose On open, On close, New delivery, RunRules macro or Run from setup."
    If Not PT_ValidRuleAction(CStr(rule("action"))) Then Err.Raise vbObjectError + 1107, "modPersonalOutlookTools.PT_ValidateFolderRule", "Choose Move, Delete, Mark read, Mark unread, Categorise, Add note or Attach file."
    If CLng(rule("days")) < 0 Or CLng(rule("days")) > 36500 Then Err.Raise vbObjectError + 1110, "modPersonalOutlookTools.PT_ValidateFolderRule", "Enter whole days from 0 to 36500. Zero means all items, including future-dated items."
    If rule("event") = "receive" And CLng(rule("days")) <> 0 Then Err.Raise 5, , "New-delivery rules use 0 days: only the newly delivered message is processed."
    If Not CBool(rule("enabled")) Then Exit Sub
    If rule("sources").Count = 0 Then Err.Raise vbObjectError + 1111, "modPersonalOutlookTools.PT_ValidateFolderRule", "Add at least one source folder, or disable this rule."
    If rule("action") = "category" Then
        If Len(Trim$(CStr(rule("category")))) = 0 Then Err.Raise 5, "modPersonalOutlookTools.PT_ValidateFolderRule", "Choose at least one category."
    ElseIf rule("action") = "attachment" Then
        If Not CreateObject("Scripting.FileSystemObject").FileExists(CStr(rule("attachment"))) Then Err.Raise 5, , "Choose an existing file for this attachment rule."
    ElseIf rule("action") = "note" Then
        If Len(CStr(rule("note"))) = 0 Then Err.Raise 5, "modPersonalOutlookTools.PT_ValidateFolderRule", "Choose a saved note template."
        If Len(Dir$(PT_RuleNotePath(CStr(rule("note"))))) = 0 Then Err.Raise 5, "modPersonalOutlookTools.PT_ValidateFolderRule", "The selected note template is missing. Create it with Edit rule note template."
    End If
    Set destination = rule("destination")
    If CStr(rule("action")) = "move" Then
        If destination Is Nothing Then Err.Raise vbObjectError + 1112, "modPersonalOutlookTools.PT_ValidateFolderRule", "Choose a destination for this move rule."
        If resolve Then Set folder = PT_ResolveFolderReference(destination): PT_CheckFolder folder
    End If
    For Each ref In rule("sources")
        If CStr(rule("action")) = "move" Then
            If PT_ReferenceKey(ref) = PT_ReferenceKey(destination) Then Err.Raise vbObjectError + 1113, "modPersonalOutlookTools.PT_ValidateFolderRule", "A move destination must differ from every source folder in that rule."
        End If
        If resolve Then Set folder = PT_ResolveFolderReference(ref): PT_CheckFolder folder
    Next ref
End Sub

' Write an inactive complete rule set before switching its active pointer.
Public Sub PT_SaveFolderRules(ByVal rules As Collection)
    Dim rule As Object, ref As Object, slot As String, section As String, prefix As String, n As Long, j As Long
    Dim issue As String
    If rules.Count > 200 Then Err.Raise vbObjectError + 1114, "modPersonalOutlookTools.PT_SaveFolderRules", "The rule limit is 200."
    For Each rule In rules
        ObserveRuleFault rule, PT_ReadSetting("RuleFault_" & rule("id"), "")
        issue = RuleProblem(rule, True)
        If Len(issue) Then rule("enabled") = False: rule("fault") = issue
        PT_ValidateFolderRule rule
        If rule("sources").Count > 100 Then Err.Raise vbObjectError + 1115, "modPersonalOutlookTools.PT_SaveFolderRules", "A rule can contain up to 100 source folders."
    Next rule
    If PT_ReadSetting("ActiveRuleSlot", "") = "0" Then slot = "1" Else slot = "0"
    section = PT_RulesSection(slot)
    SaveSetting PT_SETTINGS_APP, section, "Complete", "0"
    SaveSetting PT_SETTINGS_APP, section, "Count", CStr(rules.Count)
    For Each rule In rules
        n = n + 1: prefix = "R" & CStr(n) & "_"
        SaveSetting PT_SETTINGS_APP, section, prefix & "ID", CStr(rule("id"))
        SaveSetting PT_SETTINGS_APP, section, prefix & "Fault", CStr(rule("fault"))
        SaveSetting PT_SETTINGS_APP, section, prefix & "SeenFault", CStr(rule("seenFault"))
        SaveSetting PT_SETTINGS_APP, section, prefix & "AlsoRun", IIf(rule("alsoRun"), "1", "0")
        SaveSetting PT_SETTINGS_APP, section, prefix & "Name", CStr(rule("name"))
        SaveSetting PT_SETTINGS_APP, section, prefix & "Event", CStr(rule("event"))
        SaveSetting PT_SETTINGS_APP, section, prefix & "Action", CStr(rule("action"))
        SaveSetting PT_SETTINGS_APP, section, prefix & "Category", CStr(rule("category"))
        SaveSetting PT_SETTINGS_APP, section, prefix & "Note", CStr(rule("note"))
        SaveSetting PT_SETTINGS_APP, section, prefix & "Attachment", CStr(rule("attachment"))
        SaveSetting PT_SETTINGS_APP, section, prefix & "Days", CStr(rule("days"))
        SaveSetting PT_SETTINGS_APP, section, prefix & "Enabled", IIf(CBool(rule("enabled")), "1", "0")
        SaveSetting PT_SETTINGS_APP, section, prefix & "Sources", CStr(rule("sources").Count)
        j = 0
        For Each ref In rule("sources")
            j = j + 1: PT_SaveRuleRef section, prefix & "S" & CStr(j) & "_", ref
        Next ref
        PT_SaveRuleRef section, prefix & "D_", rule("destination")
    Next rule
    SaveSetting PT_SETTINGS_APP, section, "Generation", WorkflowID()
    SaveSetting PT_SETTINGS_APP, section, "Complete", "1"
    Set cachedArrivalRules = Nothing
    PT_WriteSetting "ActiveRuleSlot", slot ' This final write activates only the complete new configuration.
End Sub

' Edit a detached set of rules so Cancel leaves the saved configuration intact.
Public Sub Settings_ConfigureFolderRules()
    Dim panel As frmPersonalOutlook
    On Error GoTo Failed
    Set panel = New frmPersonalOutlook
    panel.PrepareRulesHome PT_LoadFolderRules()
    panel.Show vbModal
    Unload panel
    Exit Sub
Failed:
    PT_ReportError "Configure folder rules", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.Settings_ConfigureFolderRules" 
End Sub

' Capture each physical source once before executing any rule. Therefore an item moved
' into another source during this pass cannot be picked up again by a later rule.
Public Function PT_CaptureFolderRecords(ByVal folder As Outlook.Folder, ByRef failures As String, Optional ByVal panel As frmPersonalOutlook = Nothing) As Collection
    Dim records As New Collection, table As Outlook.Table, row As Outlook.Row, item As Object
    Dim sid As String, fid As String, label As String, when As Date, kind As String, dates As Boolean, preferSent As Boolean
    Dim entry As String, record As Variant, number As Long, description As String, source As String
    On Error GoTo Failed
    label = "Source folder": PT_CheckFolder folder
    label = folder.FolderPath: sid = folder.StoreID: fid = folder.EntryID
    preferSent = PT_IsSentFolder(folder)
    Set table = folder.GetTable("", olUserItems)
    ' Optional date columns are not supported by every provider. Use complete items
    ' when these cannot be added; do not turn a provider limitation into an opaque error.
    On Error Resume Next
    Err.Clear
    dates = True
    table.Columns.Add "ReceivedTime"
    If Err.Number <> 0 Then dates = False
    Err.Clear: table.Columns.Add "SentOn"
    If Err.Number <> 0 Then dates = False
    Err.Clear
    On Error GoTo Failed
    Do Until table.EndOfTable
        Set row = table.GetNextRow
        entry = CStr(row("EntryID"))
        On Error Resume Next
        Err.Clear
        If dates Then
            kind = CStr(row("MessageClass")): when = 0
            If LCase$(Left$(kind, 8)) = "ipm.note" Or LCase$(Left$(kind, 8)) = "ipm.post" Then
                If preferSent Then when = PT_RowDate(row, "SentOn")
                If when = 0 Then when = PT_RowDate(row, "ReceivedTime")
                If when = 0 Then when = PT_RowDate(row, "SentOn")
            End If
            If when = 0 Then when = PT_RowDate(row, "CreationTime")
            record = Array(entry, sid, fid, CDate(row("LastModificationTime")), CStr(row("Subject")), kind, when, "")
        Else
            Set item = Nothing
            Set item = MailApp().Session.GetItemFromID(entry, sid)
            record = PT_Record(item, PT_ItemDate(item, preferSent))
            If CStr(record(2)) <> fid Then Err.Raise vbObjectError + 1122, "modPersonalOutlookTools.PT_CaptureFolderRecords", "Item moved while the folder was being read."
        End If
        number = Err.Number: description = Err.Description: source = Err.Source
        On Error GoTo Failed
        If number = 0 Then
            records.Add record
        Else
            failures = failures & vbCrLf & PT_ErrorText("Read item in " & label, number, description, source, "modPersonalOutlookTools.PT_CaptureFolderRecords")
        End If
        If records.Count Mod 25 = 0 Then
            If Not PT_RulesProgress(panel, "Reading " & label & " | " & records.Count & " items", 0, 0) Then
                Set PT_CaptureFolderRecords = New Collection: Exit Function
            End If
            DoEvents
        End If
    Loop
    Set PT_CaptureFolderRecords = records
    Exit Function
Failed:
    failures = failures & vbCrLf & PT_ErrorText("Read " & label, Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_CaptureFolderRecords")
    ' An incomplete folder snapshot is discarded, avoiding a misleading partial rule run.
    Set PT_CaptureFolderRecords = New Collection
End Function

' Evaluate a rule against the captured age date, including the explicit zero-day all-items choice.
Private Function PT_RuleMatches(ByVal rule As Object, ByVal record As Variant, ByVal nowValue As Date) As Boolean
    If CLng(rule("days")) = 0 Then
        PT_RuleMatches = True ' Explicit all-items mode: no date restriction, including future/unknown dates.
    ElseIf CDate(record(6)) > 0 Then
        PT_RuleMatches = (CDate(record(6)) < DateAdd("d", -CLng(rule("days")), nowValue))
    End If
End Function

' Revalidate one captured item, apply the configured action, then refresh its record for later rules.
Private Sub PT_ApplyFolderRule(ByVal rule As Object, ByRef record As Variant, ByVal referenceTime As Date)
    Dim item As Object, moved As Object, destination As Outlook.Folder, currentDate As Date
    Dim stepName As String, failure As String, number As Long
    On Error GoTo Failed
    stepName = "Reload the captured item and check it is unchanged"
    Set item = PT_ReloadRecord(record)
    stepName = "Recheck the item's age"
    If CLng(rule("days")) > 0 Then
        currentDate = PT_ItemDate(item, PT_IsSentFolder(item.Parent))
        If currentDate = 0 Or currentDate >= DateAdd("d", -CLng(rule("days")), referenceTime) Then Err.Raise vbObjectError + 1123, "modPersonalOutlookTools.PT_ApplyFolderRule", "Item no longer meets the age rule."
    End If
    Select Case CStr(rule("action"))
        Case "move"
            stepName = "Resolve the move destination"
            Set destination = PT_ResolveFolderReference(rule("destination"))
            PT_CheckFolder destination
            stepName = "Move the item"
            Set moved = item.Move(destination)
        Case "delete"
            stepName = "Resolve this mailbox's Deleted Items folder"
            Set destination = item.Parent.Store.GetDefaultFolder(olFolderDeletedItems)
            stepName = "Delete or move the item into Deleted Items"
            If PT_PermanentHere(item.Parent) Then item.Delete Else Set moved = item.Move(destination)
        Case "read", "unread"
            stepName = "Set and save the read state"
            If Not TypeOf item Is Outlook.MailItem And Not TypeOf item Is Outlook.PostItem Then Err.Raise 5, "modPersonalOutlookTools.PT_ApplyFolderRule", "Read/unread actions support messages and posts only."
            item.UnRead = (rule("action") = "unread")
            item.Save
        Case "category"
            stepName = "Merge and save the categories"
            item.Categories = PT_MergedCategories(CStr(item.Categories), CStr(rule("category")))
            item.Save
        Case "attachment"
            stepName = "Attach and save the chosen file": PT_AttachRuleFile item, CStr(rule("attachment"))
        Case "note"
            stepName = "Attach and save the selected reusable note"
            PT_AttachRuleNote item, CStr(rule("note"))
        Case Else
            Err.Raise 5, "modPersonalOutlookTools.PT_ApplyFolderRule", "Unknown rule action."
    End Select
    stepName = "Refresh the saved item record for subsequent rules"
    If rule("action") <> "move" And rule("action") <> "delete" Then record = PT_Record(item, CDate(record(6)))
    Exit Sub
Failed:
    number = Err.Number
    failure = PT_ErrorText(stepName, number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_ApplyFolderRule")
    Err.Raise number, "modPersonalOutlookTools.PT_ApplyFolderRule", failure
End Sub

' Non-moving actions can accumulate in priority order. A move/delete claims the item;
' any failure also claims it, so deletion cannot become a fallback for a failed action.
Public Function PT_RunFolderRules(ByVal rules As Collection, ByVal eventName As String, ByVal actionFilter As String, ByVal previewOnly As Boolean, ByVal nowValue As Date, ByRef failures As String, Optional ByVal panel As frmPersonalOutlook = Nothing) As String
    Dim snapshots As Object, claimed As Object, latest As Object, rule As Object, ref As Object, folder As Outlook.Folder
    Dim records As Collection, record As Variant, key As String, itemKey As String, report As String
    Dim matched As Long, changed As Long, n As Long, number As Long, description As String, origin As String
    Dim completed As Double, total As Double, cancelled As Boolean
    Dim skipped As Object
    Set skipped = PT_V6Dict()
    Dim issue As String, beforeFailures As Long, sourceProblems As Object
    Set sourceProblems = PT_V6Dict()
    Set snapshots = PT_V6Dict(): Set claimed = PT_V6Dict(): Set latest = PT_V6Dict()
    If eventName = "receive" Then
        If Not previewOnly Then Err.Raise 5, , "Arrival rules run only for genuine new-delivery events, never against old folder contents."
        PT_RunFolderRules = "NEW-DELIVERY RULES: only a newly received email in an exact selected folder is processed. Moving old mail into the folder does not run these rules. Age is not used. Existing folder contents are unchanged by this preview."
        Exit Function
    End If
    If eventName <> "open" And eventName <> "close" And eventName <> "run" And eventName <> "selected" And eventName <> "manual" Then Err.Raise 5, , "Unknown rule event."
    If actionFilter <> "" And actionFilter <> "move" And actionFilter <> "delete" Then Err.Raise 5, , "Unknown rule action filter."
    For Each rule In rules
        If ScheduledFor(rule, eventName) And (actionFilter = "" Or CStr(rule("action")) = actionFilter) Then
            issue = RuleProblem(rule, True)
            If Len(issue) Then
                failures = failures & vbCrLf & rule("name") & " - " & issue
                If Not previewOnly Then RuleOutcome rule, issue, True
                skipped(rule("id")) = True
                GoTo NextScanRule
            End If
            For Each ref In rule("sources")
                key = PT_ReferenceKey(ref)
                If Not PT_RulesProgress(panel, "Reading source folders for " & CStr(rule("name")) & vbCrLf & CStr(ref("label")), 0, 0) Then GoTo Cancelled
                If Not snapshots.Exists(key) Then
                    Set folder = Nothing: Set records = New Collection
                    On Error Resume Next
                    Err.Clear: Set folder = PT_ResolveFolderReference(ref)
                    number = Err.Number: description = Err.Description: origin = Err.Source
                    On Error GoTo 0
                    beforeFailures = Len(failures)
                    If number = 0 Then
                        Set records = PT_CaptureFolderRecords(folder, failures, panel)
                    Else
                        failures = failures & vbCrLf & PT_ErrorText("Open source " & CStr(ref("label")), number, description, origin, "modPersonalOutlookTools.PT_RunFolderRules")
                    End If
                    If Len(failures) > beforeFailures Then sourceProblems(key) = Mid$(failures, beforeFailures + 1)
                    snapshots.Add key, records
                End If
                If Not panel Is Nothing Then
                    If panel.CancelRequested Then GoTo Cancelled
                End If
                If sourceProblems.Exists(key) Then
                    If Not previewOnly Then RuleOutcome rule, CStr(sourceProblems(key)), True
                    skipped(rule("id")) = True
                GoTo NextScanRule
                End If
                total = total + snapshots(key).Count
            Next ref
        End If
NextScanRule:
    Next rule
    For Each rule In rules
        n = n + 1
        If Not skipped.Exists(rule("id")) And ScheduledFor(rule, eventName) And (actionFilter = "" Or CStr(rule("action")) = actionFilter) Then
            matched = 0: changed = 0: issue = ""
            If Not PT_RulesProgress(panel, "Rule " & n & " of " & rules.Count & ": " & CStr(rule("name")), completed, total) Then GoTo Cancelled
            For Each ref In rule("sources")
                Set records = snapshots(PT_ReferenceKey(ref))
                For Each record In records
                    itemKey = CStr(record(1)) & "|" & CStr(record(0))
                    If Not claimed.Exists(itemKey) And PT_RuleMatches(rule, record, nowValue) Then
                        If rule("action") = "move" Or rule("action") = "delete" Then claimed.Add itemKey, True
                        matched = matched + 1
                        If latest.Exists(itemKey) Then record = latest(itemKey)
                        If Not previewOnly Then
                            On Error Resume Next
                            Err.Clear: PT_ApplyFolderRule rule, record, nowValue
                            number = Err.Number: description = Err.Description: origin = Err.Source
                            On Error GoTo 0
                            If number = 0 Then
                                changed = changed + 1: latest(itemKey) = record
                            Else
                                issue = description
                                If Not claimed.Exists(itemKey) Then claimed.Add itemKey, True
                                failures = failures & vbCrLf & PT_ErrorText("Rule " & n & " - " & CStr(rule("name")) & " | " & CStr(ref("label")) & " | " & CStr(record(4)), number, description, origin, "modPersonalOutlookTools.PT_RunFolderRules")
                            End If
                        End If
                    End If
                    If Len(issue) Then Exit For
                    completed = completed + 1
                    If completed Mod 25 = 0 Or completed = total Then
                        If Not PT_RulesProgress(panel, CStr(rule("name")) & " | " & matched & " matched, " & changed & " completed" & vbCrLf & CStr(ref("label")), completed, total) Then GoTo Cancelled
                    End If
                Next record
                If Len(issue) Then Exit For
            Next ref
            If Not previewOnly Then
                If Len(issue) Then
                    RuleOutcome rule, "Stopped after " & changed & " completed. " & issue, True
                Else
                    RuleOutcome rule, changed & " completed, " & matched & " matched."
                End If
            End If
            report = report & n & ". " & CStr(rule("name")) & " | " & CStr(rule("action")) & " | " & matched & " matched"
            If Not previewOnly Then report = report & " | " & changed & " completed"
            report = report & vbCrLf
        End If
    Next rule
    GoTo Finished
Cancelled:
    cancelled = True
    If Not previewOnly And Not rule Is Nothing Then RuleOutcome rule, "Stopped by the user; " & changed & " action(s) completed in the current pass."
    report = report & "Stopped during rule " & n & ". Completed actions remain applied." & vbCrLf
Finished:
    If Len(report) = 0 Then report = "No enabled rules for this event/action."
    PT_RunFolderRules = "Rules for Outlook " & eventName & " | " & Format$(nowValue, "yyyy-mm-dd hh:nn:ss") & vbCrLf & _
        IIf(cancelled, "STOPPED: remaining work was not run.", IIf(previewOnly, "PREVIEW: no items changed.", "Completed pass; actions accumulate until a move/delete or failure.")) & vbCrLf & vbCrLf & report
End Function

' Run or preview the enabled configuration with one bulk-operation guard and an appropriate progress window.
Private Sub PT_RunConfiguredRules(ByVal eventName As String, ByVal actionFilter As String, ByVal automatic As Boolean)
    Dim rules As Collection, report As String, failures As String, panel As frmPersonalOutlook
    Dim number As Long, description As String, origin As String
    On Error GoTo Failed
    If automationBusy Or bulkRunning Then Exit Sub
    automationBusy = True
    If Not automatic Then
        Set panel = New frmPersonalOutlook: panel.PrepareRulesProgress: panel.Show vbModeless
        panel.ReportRuleProgress "Loading your saved folder rules...", 0, 0
    End If
    Set rules = PT_LoadFolderRules()
    report = PT_RunFolderRules(rules, eventName, actionFilter, False, Now, failures, panel)
    PT_WriteSetting "LastRuleRun", Left$(report & vbCrLf & failures, 60000)
    If Not panel Is Nothing Then Unload panel
    automationBusy = False
    If Not automatic And Len(failures) = 0 Then PT_ShowReport "Run rules", report
    If Len(failures) > 0 Then
        If automatic And eventName = "close" Then
            MsgBox Left$(failures, 2500) & vbCrLf & "Full details: Double-click the rule in Configure folder rules for its last run.", vbExclamation, "Some folder rules could not complete"
        Else
            PT_ShowReport "Some folder rules could not complete", report & vbCrLf & failures
        End If
    End If
    Exit Sub
Failed:
    number = Err.Number: description = Err.Description: origin = Err.Source
    If Not panel Is Nothing Then Unload panel
    automationBusy = False
    PT_ReportError "Run " & eventName & " folder rules", number, description, origin, "modPersonalOutlookTools.PT_RunConfiguredRules"
End Sub

' One toolbar command runs all enabled rules once, in the saved order.
Public Sub Mail_RunRules()
    PT_RunConfiguredRules "run", "", False
End Sub

' Run enabled opening rules and connect notifications and saved Search Folder views once per session.
Public Sub PT_OutlookStartup(ByVal app As Outlook.Application)
    If startupHandled Then Exit Sub
    startupHandled = True
    StartTaskMonitoring app
    PT_AlertsStart app ' Attach monitoring before any configured startup cleanup can run.
    PT_RunConfiguredRules "open", "", True
    PT_StartSavedSearches app ' Refresh only the custom Search Folder views created by this package.
End Sub

' Release event listeners and timers before running the enabled closing rules once.
Public Sub PT_OutlookQuit(ByVal app As Outlook.Application)
    If shutdownHandled Then Exit Sub
    shutdownHandled = True
    If Not searchFolderEvents Is Nothing Then searchFolderEvents.Disconnect ' Unhook events before releasing the manager.
    Set searchFolderEvents = Nothing ' Release the navigation and AdvancedSearch listeners on exit.
    ReleaseTaskWatch True
    PT_AlertsStop False
    PT_RunConfiguredRules "close", "", True
End Sub

' Queue WM_CLOSE for the verified tracked inspector; never close an arbitrary active window.
Private Sub PT_QueueCompletedNoteClose()
    Dim inspector As Outlook.Inspector, other As Outlook.Inspector, caption As String, className As String
    Dim stepName As String, failure As String, number As Long
#If VBA7 Then
    Dim hwnd As LongPtr
#Else
    Dim hwnd As Long
#End If
    On Error GoTo Failed
    If pendingNoteEditor Is Nothing Or pendingNoteMode <> "completed" Then Exit Sub
    stepName = "Verify the private token on the saved note editor"
    Set inspector = pendingNoteEditor.GetInspector
    If Not PT_IsPendingInspector(inspector) Then Err.Raise 5, "modPersonalOutlookTools.PT_QueueCompletedNoteClose", "The note was saved, but its editor could not be identified for closing. Close that note with X."
    ' Verify a unique inspector and a unique native Outlook window with its exact
    ' caption. This does not depend on the foreground app or steal keyboard focus.
    stepName = "Check the saved note has a unique inspector caption"
    caption = inspector.Caption: className = "rctrl_renwnd32"
    For Each other In MailApp().Inspectors
        If StrComp(other.Caption, caption, vbTextCompare) = 0 Then
            If Not PT_IsPendingInspector(other) Then Err.Raise 5, "modPersonalOutlookTools.PT_QueueCompletedNoteClose", "The note was saved, but another message window has the same title. Close the saved note with X."
        End If
    Next other
    stepName = "Find the unique native Outlook window for the tracked note"
    hwnd = FindWindowExW(0, 0, StrPtr(className), StrPtr(caption))
    If hwnd = 0 Then Err.Raise 5, "modPersonalOutlookTools.PT_QueueCompletedNoteClose", "The note was saved. Its Outlook window could not be found by its verified title; close the saved note with X."
    If FindWindowExW(0, hwnd, StrPtr(className), StrPtr(caption)) <> 0 Then Err.Raise 5, "modPersonalOutlookTools.PT_QueueCompletedNoteClose", "The note was saved, but its window title is not unique. Close the saved note with X."
    stepName = "Queue the verified note window to close after Send returns"
    If PostMessageW(hwnd, &H10, 0, 0) = 0 Then Err.Raise 5, "modPersonalOutlookTools.PT_QueueCompletedNoteClose", "The note was saved, but Windows could not queue its close. Close the saved note with X."
    ' No DoEvents or further Outlook calls here: return to the Send event immediately.
    Exit Sub
Failed:
    number = Err.Number
    failure = PT_ErrorText("Note saved locally; automatic close | " & stepName, number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_QueueCompletedNoteClose")
    Err.Raise number, "modPersonalOutlookTools.PT_QueueCompletedNoteClose", failure
End Sub

' Resolve a reusable note name to the package's per-user template folder.
Public Function PT_RuleNotePath(ByVal name As String) As String
    Dim fso As Object, folder As String
    name = Trim$(name)
    If Len(name) = 0 Or Len(name) > 80 Or name <> PT_SafeFileName(name) Or name = "." Or name = ".." Then _
        Err.Raise 5, "modPersonalOutlookTools.PT_RuleNotePath", "Use a note name of 1-80 characters, without filename punctuation."
    Set fso = CreateObject("Scripting.FileSystemObject")
    folder = fso.BuildPath(fso.GetParentFolderName(PT_SummaryTemplatePath()), "RuleNotes")
    If Not fso.FolderExists(folder) Then fso.CreateFolder folder
    PT_RuleNotePath = fso.BuildPath(folder, name & ".msg")
End Function

' List the reusable note templates available for an Add note rule.
Public Function PT_RuleNoteNames() As Collection
    Dim names As New Collection, path As String, file As Object, fso As Object
    Set fso = CreateObject("Scripting.FileSystemObject")
    path = fso.GetParentFolderName(PT_RuleNotePath("Default note"))
    For Each file In fso.GetFolder(path).Files
        If LCase$(fso.GetExtensionName(file.Name)) = "msg" And LCase$(Right$(file.Name, 13)) <> ".previous.msg" Then _
            names.Add fso.GetBaseName(file.Name)
    Next file
    Set PT_RuleNoteNames = names
End Function

' Multiple defaults, each edited in the same rich editor as ordinary attached notes.
Public Sub Settings_EditRuleNoteTemplate()
    Dim name As String, path As String
    On Error GoTo Failed
    PT_RequireNoPendingNote
    Dim panel As New frmPersonalOutlook, native As Boolean, result As Long
    Dim store As Outlook.Store, existing As Outlook.Category
    panel.PrepareTemplateManager PT_RuleNoteNames()
    panel.Show vbModal
    name = panel.TemplateName: native = panel.NativeTemplate: result = panel.Result
    Unload panel
    If result = 0 Then Exit Sub
    If result = 2 Then
        path = PT_RuleNotePath(name)
        If Len(Dir$(path)) Then Kill path
        Exit Sub
    End If
    If native Then
        If Len(name) > 120 Or InStr(name, PT_CategorySeparator()) Then Err.Raise 5, , "Use a single category name of up to 120 characters."
        Set store = PT_CurrentOutlookFolder().Store
        If Not PT_StoreSupportsCategories(store) Then Err.Raise 5, , "This mailbox cannot store Outlook categories. Create a custom note template instead."
        On Error Resume Next: Set existing = store.Categories.Item(name): On Error GoTo Failed
        If existing Is Nothing Then Set existing = store.Categories.Add(name)
        Exit Sub
    End If
    path = PT_RuleNotePath(name)
    If Len(Dir$(path)) > 0 Then
        Set pendingNoteEditor = PT_OpenNoteEditor(path)
    Else
        Set pendingNoteEditor = MailApp().CreateItem(olMailItem)
        pendingNoteEditor.BodyFormat = olFormatHTML
        pendingNoteEditor.Subject = name
        pendingNoteEditor.Display
        pendingNoteEditor.HTMLBody = "<html><body><p>Write your reusable note here.</p></body></html>"
    End If
    pendingRuleNotePath = path
    pendingNoteMode = "rule-template"
    PT_MarkPendingEditor
    PT_WatchPendingNote
    Exit Sub
Failed:
    PT_ReportError "Edit rule note template", Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.Settings_EditRuleNoteTemplate" 
End Sub

' Attach a reusable rich note only when that same saved version is absent.
Private Sub PT_AttachRuleNote(ByVal item As Object, ByVal name As String, Optional ByVal persist As Boolean = True)
    Const tag As String = "http://schemas.microsoft.com/mapi/string/{00020329-0000-0000-C000-000000000046}/PTRuleNoteVersion"
    Dim file As Object, attachment As Outlook.Attachment, path As String, signature As String, previous As String
    If Not TypeOf item Is Outlook.MailItem Then Err.Raise 5, "modPersonalOutlookTools.PT_AttachRuleNote", "Attached rule notes support email messages only."
    path = PT_RuleNotePath(name)
    Set file = CreateObject("Scripting.FileSystemObject").GetFile(path)
    signature = LCase$(name) & "|" & CStr(file.Size) & "|" & Format$(file.DateLastModified, "yyyymmddhhnnss")
    For Each attachment In item.Attachments
        previous = ""
        On Error Resume Next
        previous = CStr(attachment.PropertyAccessor.GetProperty(tag))
        On Error GoTo 0
        If previous = signature Then Exit Sub
    Next attachment
    Set attachment = item.Attachments.Add(path, olByValue)
    attachment.PropertyAccessor.SetProperty tag, signature
    If persist Then item.Save
End Sub

' Validate a stored rule action against the supported action codes.
Public Function PT_ValidRuleAction(ByVal action As String) As Boolean
    PT_ValidRuleAction = (PT_RuleActionIndex(action) >= 0)
End Function
' Translate a stored action code into the corresponding setup-list position.
Public Function PT_RuleActionIndex(ByVal action As String) As Long
    Dim values As Variant, n As Long
    values = Array("move", "delete", "read", "unread", "category", "note", "attachment")
    PT_RuleActionIndex = -1
    For n = 0 To UBound(values)
        If values(n) = action Then PT_RuleActionIndex = n: Exit Function
    Next n
End Function
' Translate a setup-list position back into a persistent action code.
Public Function PT_RuleActionCode(ByVal index As Long) As String
    Dim values As Variant
    values = Array("move", "delete", "read", "unread", "category", "note", "attachment")
    If index < 0 Or index > UBound(values) Then Exit Function
    PT_RuleActionCode = CStr(values(index))
End Function

' Add requested categories while retaining the item's existing categories.
Public Function PT_MergedCategories(ByVal existing As String, ByVal additions As String) As String
    Dim separator As String, token As Variant, seen As Object, values As New Collection, text As String
    separator = ","
    On Error Resume Next
    separator = CStr(CreateObject("WScript.Shell").RegRead("HKCU\Control Panel\International\sList"))
    On Error GoTo 0
    If Len(separator) = 0 Then separator = ","
    Set seen = CreateObject("Scripting.Dictionary"): seen.CompareMode = vbTextCompare
    For Each token In Split(existing & separator & additions, separator)
        text = Trim$(CStr(token))
        If Len(text) > 0 Then
            If Not seen.Exists(text) Then
                seen.Add text, True
                If Len(PT_MergedCategories) > 0 Then PT_MergedCategories = PT_MergedCategories & separator & " "
                PT_MergedCategories = PT_MergedCategories & text
            End If
        End If
    Next token
End Function

' Outlook workflow refinements - 15 November 2026, revision 2.
Public Function PT_CurrentOutlookFolder() As Outlook.Folder
    Dim window As Object, item As Object
    Set window = MailApp().ActiveWindow
    If TypeOf window Is Outlook.Explorer Then
        Set PT_CurrentOutlookFolder = window.CurrentFolder
    ElseIf TypeOf window Is Outlook.Inspector Then
        Set item = window.CurrentItem
        If TypeOf item.Parent Is Outlook.Folder Then Set PT_CurrentOutlookFolder = item.Parent
    End If
End Function

' Parse a real English DD/MMM/YYYY date without relying on the computer's date order.
Public Function PT_ParseDeleteDate(ByVal text As String) As Date
    Dim parts As Variant, months As Variant, n As Long, monthNumber As Long, dayNumber As Long, yearNumber As Long, value As Date
    parts = Split(Trim$(text), "/")
    If UBound(parts) <> 2 Then GoTo Invalid
    If Len(parts(0)) <> 2 Or Len(parts(1)) <> 3 Or Len(parts(2)) <> 4 Then GoTo Invalid
    If CStr(parts(0)) Like "*[!0-9]*" Or CStr(parts(2)) Like "*[!0-9]*" Then GoTo Invalid
    months = Split("jan feb mar apr may jun jul aug sep oct nov dec", " ")
    For n = 0 To 11
        If LCase$(parts(1)) = months(n) Then monthNumber = n + 1
    Next n
    If monthNumber = 0 Then GoTo Invalid
    dayNumber = CLng(parts(0)): yearNumber = CLng(parts(2))
    If dayNumber < 1 Or dayNumber > 31 Or yearNumber < 1900 Or yearNumber > 4499 Then GoTo Invalid
    value = DateSerial(yearNumber, monthNumber, dayNumber)
    If Day(value) <> dayNumber Or Month(value) <> monthNumber Or Year(value) <> yearNumber Then GoTo Invalid
    PT_ParseDeleteDate = value: Exit Function
Invalid:
    Err.Raise 5, "modPersonalOutlookTools.PT_ParseDeleteDate", "Enter a real date as DD/MMM/YYYY, for example 15/Nov/2026."
End Function

' Remember valid search choices and release the matching modeless review instance.
Public Sub PT_CloseChainReview(ByVal panel As frmPersonalOutlook)
    panel.RememberChainChoices
    panel.ReleaseReviewRows
    If Not chainReviewPanel Is Nothing Then
        If chainReviewPanel Is panel Then Set chainReviewPanel = Nothing
    End If
    Unload panel
End Sub

' Choose an optional move destination, then apply the captured review once.
Public Sub PT_CommitChainReview(ByVal panel As frmPersonalOutlook, Optional ByVal moveChecked As Boolean = False)
    Dim model As Object, failures As String, destination As Outlook.Folder, completed As Long
    On Error GoTo Failed
    If bulkRunning Or panel.ChainReview Is Nothing Then Exit Sub
    Set model = panel.ChainReview
    bulkRunning = True ' Hold the review stable while the native folder picker is open.
    If moveChecked Then
        Set destination = PT_PickOutlookFolder()
        If destination Is Nothing Then
            bulkRunning = False ' Picker cancellation leaves all ticks available in the review.
            Exit Sub
        End If
        PT_CheckFolder destination
        If destination.DefaultItemType <> olMailItem Then Err.Raise 5, , "Choose a destination mail folder."
    End If
    PT_CloseChainReview panel
    completed = PT_ApplyChainReview(model, failures, destination)
    bulkRunning = False
    If Len(failures) > 0 Then
        PT_ShowReport "Some reviewed emails were kept", completed & " completed." & vbCrLf & failures
    End If
    Exit Sub
Failed:
    bulkRunning = False
    PT_ReportError IIf(moveChecked, "Move reviewed emails", "Delete reviewed emails"), Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_CommitChainReview"
End Sub

' Share the chain-search busy state with the other bulk macro entry points.
Public Sub PT_SetChainSearchBusy(ByVal value As Boolean)
    bulkRunning = value
End Sub

' Format a date using English month names for the matching unambiguous date parser.
Public Function PT_DeleteDateText(ByVal value As Date) As String
    Dim months As Variant
    months = Split("Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec", " ")
    PT_DeleteDateText = Format$(Day(value), "00") & "/" & months(Month(value) - 1) & "/" & Format$(Year(value), "0000")
End Function

' Snapshot items strictly before the chosen calendar cutoff for later count-first deletion.
Public Function PT_OldItemDatePlan(ByVal folder As Outlook.Folder, ByVal cutoff As Date) As Object
    Dim plan As Object, records As New Collection, snapshot As Collection, record As Variant, failures As String
    If Not PT_UsableDate(cutoff) Then Err.Raise 5, , "Choose a valid cutoff date."
    PT_CheckFolder folder
    Set plan = PT_NewDeletionPlan(folder, "age")
    plan.Add "cutoff", DateValue(cutoff): plan.Add "allItems", False
    plan.Add "preferSent", PT_IsSentFolder(folder)
    Set snapshot = PT_CaptureFolderRecords(folder, failures)
    For Each record In snapshot
        If CDate(record(6)) > 0 And CDate(record(6)) < DateValue(cutoff) Then records.Add record
    Next record
    plan.Add "items", records: plan.Add "captureFailures", failures
    Set PT_OldItemDatePlan = plan
End Function

' Default a new review to 90 days, attachment protection and the starting email's mailbox.
Public Function PT_NewChainSearchSettings(ByVal selected As Outlook.MailItem) As Object
    Dim settings As Object, refs As New Collection, ref As Object
    Set settings = PT_V6Dict()
    settings.Add "allTime", False: settings.Add "days", 90&: settings.Add "keepFiles", True
    settings.Add "locations", refs
    Set ref = PT_ChainSearchReference(selected.Parent.Store.GetRootFolder, True, True)
    refs.Add ref
    Set PT_NewChainSearchSettings = settings
End Function

' Represent a mailbox or physical mail folder with exact IDs and recursion choices.
Public Function PT_ChainSearchReference(ByVal folder As Outlook.Folder, ByVal include As Boolean, ByVal recursive As Boolean) As Object
    Dim ref As Object, kind As Long
    kind = PT_FolderKind(folder)
    If kind = 2 Then Err.Raise 5, , "Choose a physical folder or mailbox, not a Search Folder."
    If kind <> 0 And folder.DefaultItemType <> olMailItem Then Err.Raise 5, , "Choose a mail folder."
    Set ref = PT_V6Dict()
    ref.Add "entry", folder.EntryID: ref.Add "store", folder.StoreID
    ref.Add "storeName", folder.Store.DisplayName ' A saved Search Folder can use a short mailbox suffix.
    ref.Add "label", folder.Store.DisplayName & " - " & folder.FolderPath
    ref.Add "include", include: ref.Add "recursive", (recursive Or kind = 0)
    Set PT_ChainSearchReference = ref
End Function

' Reject invalid or excessively large numbers in stored chain-search settings.
Private Function PT_ChainSavedCount(ByVal text As String, ByVal maximum As Long) As Long
    If Len(text) = 0 Or Len(text) > 5 Then GoTo Invalid
    If text Like "*[!0-9]*" Then GoTo Invalid
    PT_ChainSavedCount = CLng(text)
    If PT_ChainSavedCount <= maximum Then Exit Function
Invalid:
    Err.Raise 5, , "Saved chain-search settings are invalid."
End Function

' Restore the active complete search scope and range while supporting earlier settings.
Public Function PT_LoadChainSearchSettings(ByVal selected As Outlook.MailItem) As Object
    Dim settings As Object, refs As New Collection, ref As Object, slot As String, p As String, n As Long, count As Long
    Set settings = PT_NewChainSearchSettings(selected)
    slot = PT_ReadSetting("ChainSearchActiveSlot", "")
    If Len(slot) = 0 Then Set PT_LoadChainSearchSettings = settings: Exit Function
    If slot <> "0" And slot <> "1" Then Err.Raise 5, , "Saved chain-search settings are invalid."
    p = "ChainSearch" & slot & "_"
    If PT_ReadSetting(p & "Complete", "0") <> "1" Then Err.Raise 5, , "Saved chain-search settings are incomplete."
    settings("allTime") = (PT_ReadSetting(p & "AllTime", "0") = "1")
    settings("days") = PT_ChainSavedCount(PT_ReadSetting(p & "Days", "90"), 36500)
    settings("keepFiles") = (PT_ReadSetting(p & "KeepFiles", "1") = "1")
    count = PT_ChainSavedCount(PT_ReadSetting(p & "Count", "0"), 100)
    For n = 1 To count
        Set ref = PT_V6Dict()
        ref.Add "entry", PT_ReadSetting(p & n & "Entry", "")
        ref.Add "store", PT_ReadSetting(p & n & "Store", "")
        ref.Add "label", PT_ReadSetting(p & n & "Label", "Saved folder")
        ref.Add "include", True ' Every visible saved location is now searched; legacy exclusion switches no longer hide rules.
        ref.Add "recursive", (PT_ReadSetting(p & n & "Recursive", "0") = "1")
        If Len(ref("entry")) = 0 Or Len(ref("store")) = 0 Then Err.Raise 5, , "A saved search folder is incomplete. Remove it and choose it again."
        refs.Add ref
    Next n
    Set settings("locations") = refs
    Set PT_LoadChainSearchSettings = settings
End Function

' Validate the chosen scope and switch to a newly written complete search-settings slot.
Public Sub PT_SaveChainSearchSettings(ByVal settings As Object)
    Dim ref As Object, slot As String, p As String, n As Long, includes As Long
    If CLng(settings("days")) < 0 Or CLng(settings("days")) > 36500 Then Err.Raise 5, , "Use 0 for all time or 1 to 36500 days."
    If settings("locations").Count > 100 Then Err.Raise 5, , "Use up to 100 search locations."
    For Each ref In settings("locations")
        If Len(ref("entry")) = 0 Or Len(ref("store")) = 0 Then Err.Raise 5, , "Choose the incomplete search location again."
        ref("include") = True: includes = includes + 1 ' Keep the saved compatibility field consistent with the visible list.
    Next ref
    ' An empty list can be saved after removing its final location; Locate validates that at least one location exists.
    If PT_ReadSetting("ChainSearchActiveSlot", "") = "0" Then slot = "1" Else slot = "0"
    p = "ChainSearch" & slot & "_": PT_WriteSetting p & "Complete", "0"
    PT_WriteSetting p & "AllTime", IIf(settings("allTime"), "1", "0")
    PT_WriteSetting p & "Days", CStr(settings("days"))
    PT_WriteSetting p & "KeepFiles", IIf(settings("keepFiles"), "1", "0")
    PT_WriteSetting p & "Count", CStr(settings("locations").Count)
    For Each ref In settings("locations")
        n = n + 1
        PT_WriteSetting p & n & "Entry", CStr(ref("entry")): PT_WriteSetting p & n & "Store", CStr(ref("store"))
        PT_WriteSetting p & n & "Label", CStr(ref("label"))
        PT_WriteSetting p & n & "Include", "1"
        PT_WriteSetting p & n & "Recursive", IIf(ref("recursive"), "1", "0")
    Next ref
    PT_WriteSetting p & "Complete", "1": PT_WriteSetting "ChainSearchActiveSlot", slot
End Sub

' Resolve included roots and retain warnings for locations that are unavailable.
Public Function PT_ChainSearchRoots(ByVal settings As Object, ByRef warnings As String) As Collection
    Dim roots As New Collection, ref As Object, folder As Outlook.Folder
    If settings("locations").Count = 0 Then Err.Raise 5, , "Add a mailbox or folder before locating emails."
    For Each ref In settings("locations")
        Set folder = Nothing
        On Error Resume Next
        Err.Clear: Set folder = PT_ResolveFolderReference(ref)
        If Err.Number <> 0 Then warnings = warnings & vbCrLf & PT_ErrorText("Open search location " & ref("label"), Err.Number, Err.Description, Err.Source, "modPersonalOutlookTools.PT_ChainSearchRoots")
        On Error GoTo 0
        If Not folder Is Nothing Then roots.Add folder
    Next ref
    Set PT_ChainSearchRoots = roots
End Function
' Apply the most specific include or exclude rule to a folder, respecting recursion.
Public Function PT_ChainFolderAllowed(ByVal folder As Outlook.Folder, ByVal settings As Object) As Boolean
    Dim current As Outlook.Folder, ref As Object, depth As Long
    For Each ref In settings("locations")
        If StrComp(folder.StoreID, CStr(ref("store")), vbTextCompare) = 0 Then
            Set current = folder: depth = 0
            Do
                If StrComp(current.EntryID, CStr(ref("entry")), vbTextCompare) = 0 Then
                    If depth = 0 Or CBool(ref("recursive")) Then PT_ChainFolderAllowed = True: Exit Function
                    Exit Do
                End If
                If depth >= 100 Or Not TypeOf current.Parent Is Outlook.Folder Then Exit Do
                Set current = current.Parent: depth = depth + 1
            Loop
        End If
    Next ref
End Function
' Open the selected review row in a normal Outlook message window.
Public Sub PT_OpenChainReviewEmail(ByVal row As Object)
    Dim record As Variant, item As Object
    record = row("record")
    Set item = MailApp().Session.GetItemFromID(CStr(record(0)), CStr(record(1)))
    If Not TypeOf item Is Outlook.MailItem Then Err.Raise 5, , "The selected item is no longer an email. Locate again."
    item.Display
End Sub

' Refresh a supplied progress form and read its cancellation request between operations.
Private Function PT_RulesProgress(ByVal panel As frmPersonalOutlook, ByVal detail As String, ByVal completed As Double, ByVal total As Double) As Boolean
    PT_RulesProgress = True
    If panel Is Nothing Then Exit Function
    panel.ReportRuleProgress detail, completed, total
    PT_RulesProgress = Not panel.CancelRequested
End Function

' Read a positive whole-day count without interpreting decimals, exponents or local date text.
Public Function PT_ReadSearchDays(ByVal value As String) As Long
    value = Trim$(value) ' Permit incidental spaces around the user's number.
    If Len(value) = 0 Or Len(value) > 5 Or value Like "*[!0-9]*" Then GoTo Invalid
    PT_ReadSearchDays = CLng(value) ' At most five digits fit safely in a Long.
    If PT_ReadSearchDays >= 0 And PT_ReadSearchDays <= 36500 Then Exit Function
Invalid:
    Err.Raise 5, , "Enter 0 for all dates or a whole number up to 36500."
End Function

' Remove common leading reply and forward prefixes, normalise case and collapse repeated spaces.
Private Function PT_NormaliseSubject(ByVal subject As String) As String
    Dim prefixAt As Long, prefix As String
    subject = LCase$(Trim$(Replace(Replace(subject, vbTab, " "), ChrW$(160), " ")))
    Do ' Strip repeated common Outlook reply/forward prefixes only at the start.
        prefixAt = InStr(1, subject, ":", vbBinaryCompare)
        If prefixAt = 0 Or prefixAt > 4 Then Exit Do
        prefix = Trim$(Left$(subject, prefixAt - 1))
        If prefix <> "re" And prefix <> "fw" And prefix <> "fwd" Then Exit Do
        subject = Trim$(Mid$(subject, prefixAt + 1))
    Loop
    Do While InStr(subject, "  ") > 0
        subject = Replace(subject, "  ", " ") ' Treat repeated whitespace as one separator.
    Loop
    PT_NormaliseSubject = subject
End Function

' Collect distinct punctuation-separated words for the optional similar-subject comparison.
Private Function PT_SubjectWords(ByVal subject As String) As Object
    Dim words As Object, marks As Variant, token As Variant
    Set words = PT_V6Dict() ' Distinct words stop repeated text from inflating the overlap.
    For Each marks In Array("-", "_", ".", ",", ":", ";", "!", "?", "(", ")", "[", "]", "/", "\", ChrW$(8211), ChrW$(8212))
        subject = Replace(subject, CStr(marks), " ") ' Ignore punctuation in the similar-subject mode.
    Next marks
    For Each token In Split(subject, " ")
        If Len(CStr(token)) > 0 Then words(CStr(token)) = True
    Next token
    Set PT_SubjectWords = words
End Function

' Apply exact normalised matching or the documented two-word and 75-percent similarity rule.
Public Function PT_ChainSubjectMatches(ByVal seed As String, ByVal candidate As String, ByVal matchMode As Long) As Boolean
    Dim leftWords As Object, rightWords As Object, word As Variant, overlapCount As Long
    If matchMode < 1 Or matchMode > 2 Then Exit Function ' Linked chain alone uses reply metadata.
    seed = PT_NormaliseSubject(seed)
    candidate = PT_NormaliseSubject(candidate)
    If Len(seed) = 0 Or Len(candidate) = 0 Then Exit Function
    If seed = candidate Then
        PT_ChainSubjectMatches = True ' Same subject matches after case, spacing and reply-prefix normalisation.
        Exit Function
    End If
    If matchMode <> 2 Then Exit Function
    Set leftWords = PT_SubjectWords(seed)
    Set rightWords = PT_SubjectWords(candidate)
    For Each word In leftWords.Keys
        If rightWords.Exists(CStr(word)) Then overlapCount = overlapCount + 1
    Next word
    ' Count at least two shared words and a 75 percent overlap across both subjects.
    PT_ChainSubjectMatches = (overlapCount >= 2 And 8 * overlapCount >= 3 * (leftWords.Count + rightWords.Count))
End Function

' Connect saved-search events once and allow a later manual attempt if Outlook is unavailable.
Private Sub PT_StartSavedSearches(ByVal app As Outlook.Application)
    ' Joining folder navigation is independent of the existing mail alerts and startup rules.
    If Not searchFolderEvents Is Nothing Then Exit Sub
    On Error GoTo Unavailable
    Set searchFolderEvents = New clsPersonalSearchFolderEvents
    searchFolderEvents.Connect app
    Exit Sub
Unavailable:
    Set searchFolderEvents = Nothing ' A later manual Create Search Folder will retry on demand.
End Sub

' Collect approved search criteria, save per-mailbox Search Folders, and report partial provider failures.
' Open the general saved-search wizard, retaining all four filter choices.


Private Sub PT_SearchFolderWizard(ByVal defaultMode As Long, Optional ByVal defaultName As String = "")
    Dim panel As frmPersonalOutlook, startAt As Outlook.Folder, folders As Collection, created As Collection
    Dim folder As Outlook.Folder, warnings As String, report As String
    Dim number As Long, description As String, origin As String, pin As Boolean, pinWarning As String
    On Error GoTo Failed
    If bulkRunning Then Exit Sub
    Set startAt = PT_CurrentOutlookFolder() ' Capture the context before a form or picker changes focus.
    Set panel = New frmPersonalOutlook
    panel.PrepareSavedSearch startAt
    panel.Controls("savedSearchTitle").Text = defaultName
    panel.Show vbModal
    If panel.Result <> 1 Then Unload panel: Exit Sub
    Set folders = panel.SavedSearchScope ' Keep the selected folder identities after closing the form.
    pin = panel.SavedSearchFavorite
    bulkRunning = True
    Set created = PT_SaveSearchFolders(folders, panel.SavedSearchName, panel.SavedSearchMode, panel.SavedSearchDays, panel.SavedSearchChildren, warnings)
    Unload panel
    bulkRunning = False
    For Each folder In created
        If pin Then
            pinWarning = ""
            If Not PT_AddSearchFolderFavorite(folder, pinWarning) Then warnings = warnings & vbCrLf & pinWarning
        End If
        report = report & vbCrLf & folder.Name & " | " & folder.Store.DisplayName
    Next folder
    If created.Count > 0 Then report = "Open the Search Folder in Favorites or under Search Folders in each chosen mailbox. Outlook saves a separate search within each mailbox. Open its saved view for the location-specific results." & vbCrLf & report
    If Len(warnings) > 0 Then report = report & vbCrLf & warnings
    PT_ShowReport IIf(created.Count > 0, "Search Folders saved", "No Search Folder saved"), report, True
    Exit Sub
Failed:
    bulkRunning = False
    number = Err.Number: description = Err.Description: origin = Err.Source
    On Error Resume Next
    If Not panel Is Nothing Then Unload panel ' Release hidden controls after a provider failure.
    On Error GoTo 0
    PT_ReportError "Create Outlook Search Folder", number, description, origin, "modPersonalOutlookTools.Settings_CreateUnreadOrRecentSearchFolder"
End Sub

' Validate criteria, group locations by store, and give each mailbox its own saved Search Folder.
Public Function PT_SaveSearchFolders(ByVal selected As Collection, ByVal title As String, ByVal filterMode As Long, _
    ByVal days As Long, ByVal children As Boolean, ByRef warnings As String) As Collection

    Dim buckets As Object, locations As Collection, created As New Collection, existing As Object
    Dim ref As Object, folder As Outlook.Folder, key As Variant, label As String, suffix As String
    Set buckets = PT_V6Dict() ' AdvancedSearch accepts one store per saved search.
    title = Trim$(title)
    If Len(title) = 0 Or Len(title) > 120 Then Err.Raise 5, , "Enter a Search Folder name of up to 120 characters."
    If filterMode < 0 Or filterMode > 3 Then Err.Raise 5, , "Choose unread mail, recent mail, or a combination."
    If filterMode <> 0 Then days = PT_ReadSearchDays(CStr(days))
    If selected.Count = 0 Then Err.Raise 5, , "Add at least one folder or mailbox."
    PT_StartSavedSearches MailApp()
    If searchFolderEvents Is Nothing Then Err.Raise 5, , "Outlook's search events could not be connected."

    For Each ref In selected
        key = CStr(ref("store"))
        If Not buckets.Exists(key) Then
            Set locations = New Collection
            buckets.Add key, locations
        End If
        buckets(key).Add ref
    Next ref

    Set existing = PT_V6Dict() ' Distinguish names even when two stores have the same display name.
    existing.CompareMode = vbTextCompare
    For Each key In buckets.Keys
        Set locations = buckets(key)
        Set ref = locations(1)
        label = title
        If buckets.Count > 1 Then label = title & " (" & Left$(Replace(Replace(CStr(ref("storeName")), "\", "-"), "/", "-"), 75) & ")"
        If existing.Exists(label) Then
            suffix = " - " & CStr(existing.Count + 1)
            label = Left$(label, 200 - Len(suffix)) & suffix
        End If
        existing.Add label, True
        SaveMailboxWindows locations, label, created, warnings
    Next key
    Set PT_SaveSearchFolders = created
End Function

' Save one store's search and persist the recipe for its rolling date-filtered view.


' Quote a full folder path for Outlook's comma-separated AdvancedSearch scope syntax.
Private Function PT_SearchScopePath(ByVal folder As Outlook.Folder) As String
    ' Outlook requires each full path in single quotes, even when only one folder is selected.
    PT_SearchScopePath = "'" & Replace(folder.FolderPath, "'", "''") & "'"
End Function

' Build a validated mail-only DASL predicate and convert the received-date cutoff to UTC.
Public Function PT_SearchFilter(ByVal accessor As Outlook.PropertyAccessor, ByVal filterMode As Long, ByVal days As Long, ByVal atTime As Date) As String
    Dim mailOnly As String, unread As String, recent As String, cutoff As Date
    ' Validate saved settings before replacing a view. An empty filter would expose every item.
    If filterMode < 0 Or filterMode > 3 Then Err.Raise 5, , "The saved Search Folder filter is invalid."
    If filterMode <> 0 Then days = PT_ReadSearchDays(CStr(days))
    mailOnly = "(""" & PT_V6_TAG & "0x001A001F""" & " = 'IPM.Note' OR """ & PT_V6_TAG & "0x001A001F""" & " LIKE 'IPM.Note.%')"
    unread = """urn:schemas:httpmail:read"" = 0"
    If filterMode <> 0 Then
        cutoff = accessor.LocalTimeToUTC(DateAdd("d", -days, atTime)) ' Outlook DASL compares against UTC.
        recent = """urn:schemas:httpmail:datereceived"" >= '" & Format$(cutoff, "ddddd h:nn AMPM") & "'"
    End If
    Select Case filterMode
        Case 0: PT_SearchFilter = mailOnly & " AND (" & unread & ")"
        Case 1: PT_SearchFilter = mailOnly & " AND (" & recent & ")"
        Case 2: PT_SearchFilter = mailOnly & " AND (" & unread & " AND " & recent & ")"
        Case 3: PT_SearchFilter = mailOnly & " AND (" & unread & " OR " & recent & ")"
    End Select
End Function

' Refresh only a recorded Search Folder's view and restore its missing view when necessary.
Public Sub PT_RefreshSearchFolderView(ByVal browser As Outlook.Explorer)
    Dim folder As Outlook.Folder, view As Outlook.View, activeView As Outlook.View, config As Variant, value As String, filter As String
    On Error GoTo Inaccessible
    Set folder = browser.CurrentFolder
    value = PT_ReadSetting(PT_SEARCH_KEY & folder.EntryID, "")
    If Len(value) = 0 Then Exit Sub ' Leave all folders not created here alone.
    If Left$(value, 1) = "<" Then
        filter = SavedLocationFilter(folder, value)
        GoTo ApplyFilter
    End If
    config = Split(value, "|")
    If UBound(config) <> 2 Then Exit Sub
    If CStr(config(2)) <> folder.StoreID Then Exit Sub
    filter = PT_SearchFilter(folder.PropertyAccessor, CLng(config(0)), PT_ReadSearchDays(CStr(config(1))), Now)
ApplyFilter:
    On Error Resume Next: Set view = folder.Views.Item(PT_SEARCH_VIEW): On Error GoTo Inaccessible
    If view Is Nothing Then
        ' Recover the folder-specific view when Outlook or the user removed its previous copy.
        Set view = folder.Views.Add(PT_SEARCH_VIEW, olTableView, olViewSaveOptionThisFolderOnlyMe)
    End If
    If view.Filter <> filter Then
        view.Filter = filter ' Update the date without deleting or recreating the underlying Outlook folder.
        view.Save
        view.Apply
    Else
        Set activeView = browser.CurrentView
        If activeView.Name <> view.Name Then view.Apply ' Select this folder's saved view on entry.
    End If
    Exit Sub
Inaccessible:
    Dim why As String
    why = Err.Description
    On Error Resume Next
    If Len(value) Then
        If PT_ReadSetting("SearchViewIssue_" & folder.EntryID, "") <> why Then
            PT_WriteSetting "SearchViewIssue_" & folder.EntryID, why
            MsgBox "The saved location filter could not be refreshed. Check that the source folders are available or recreate the Search Folder." & vbCrLf & why, vbInformation, "Unread or recent mail"
        End If
    End If
    Debug.Print "Search Folder view: " & Err.Number & " " & Err.Description ' Navigation still works if a provider/view is unavailable.
End Sub

' Save the approved private reminder task before flagging the exact captured emails.
Public Sub Mail_FollowUp()
    Dim selected As Collection, panel As frmPersonalOutlook, folder As Outlook.Folder, detail As String
    Dim current As Collection, active As Object
    If bulkRunning Then Exit Sub
    On Error GoTo Failed
    Set current = PT_SelectedItems()
    If current.Count = 1 Then
        Set active = current(1)
        If TypeOf active Is Outlook.TaskItem Then
            OpenLinkedEmail active
            Exit Sub
        End If
    End If
    Set selected = PT_SelectedMessages()
    If selected.Count = 0 Then MsgBox "Choose one or more received or sent emails.", vbInformation, "Follow Up": Exit Sub
    bulkRunning = True: Set folder = MailApp().Session.GetDefaultFolder(olFolderTasks)
    Set panel = New frmPersonalOutlook
    panel.PrepareFollowUp selected.Count, DateAdd("d", 7, Date) + TimeSerial(10, 0, 0), OpenTaskChoices(folder)
    panel.Show vbModal
    If panel.Result = 1 Then SaveLinkedFollowUp selected, panel
Finished:
    If Not panel Is Nothing Then Unload panel
    bulkRunning = False
    If Len(detail) Then MsgBox detail, vbInformation, "Follow Up"
    Exit Sub
Failed:
    detail = Err.Description: Resume Finished
End Sub

' Combine an explicitly formatted calendar date and 24-hour time in the user's local timezone.
Public Function PT_ParseFollowUpDue(ByVal dayText As String, ByVal timeText As String) As Date
    Dim parts As Variant, d As Long, m As Long, y As Long, value As Date, h As Long, minutes As Long
    dayText = Trim$(dayText): timeText = Trim$(timeText)
    If Not dayText Like "##/##/####" Then GoTo BadDate
    parts = Split(dayText, "/"): d = CLng(parts(0)): m = CLng(parts(1)): y = CLng(parts(2))
    If y < 1900 Or y > 4499 Or m < 1 Or m > 12 Or d < 1 Or d > 31 Then GoTo BadDate
    value = DateSerial(y, m, d): If Day(value) <> d Then GoTo BadDate
    If Not timeText Like "##:##" Then GoTo BadTime
    h = CLng(Left$(timeText, 2)): minutes = CLng(Right$(timeText, 2))
    If h > 23 Or minutes > 59 Then GoTo BadTime
    PT_ParseFollowUpDue = value + TimeSerial(h, minutes, 0): Exit Function
BadDate:
    Err.Raise 5, , "Enter a real date as DD/MM/YYYY, for example 07/12/2026."
BadTime:
    Err.Raise 5, , "Enter a 24-hour time as HH:MM, for example 14:15."
End Function

' Validate the destination before creating and saving the user's private task and reminder settings.


' Reopen captured emails and add flags while preserving existing active flag settings.


' Compare complete message content before treating separately delivered copies as duplicates.
' Sender and subject must match; recipient changes do not split an otherwise identical message.
' Unverified sender/body/attachment content always remains separate; no message is saved by this comparison.
Public Function PT_ExactMessageCopy(ByVal first As Outlook.MailItem, ByVal second As Outlook.MailItem, Optional ByRef detail As String = "") As Boolean
    Dim sender As String, otherSender As String, index As Long, temp As String
    Dim leftAttachment As Outlook.Attachment, rightAttachment As Outlook.Attachment
    Dim leftRTF() As Byte, rightRTF() As Byte, length As Long
    On Error GoTo CouldNotCompare
    detail = ""
    If Not first.Sent Or Not second.Sent Or Not first.Saved Or Not second.Saved Then Exit Function
    If PT_NormaliseSubject(first.Subject) <> PT_NormaliseSubject(second.Subject) Then Exit Function
    sender = PT_V6Address(first.Sender): otherSender = PT_V6Address(second.Sender)
    If Len(sender) = 0 Then sender = LCase$(Trim$(first.SenderEmailAddress))
    If Len(otherSender) = 0 Then otherSender = LCase$(Trim$(second.SenderEmailAddress))
    If InStr(sender, "@") < 2 Or sender <> otherSender Then Exit Function
    If first.BodyFormat <> second.BodyFormat Or first.Attachments.Count <> second.Attachments.Count Then Exit Function
    If StrComp(first.Body, second.Body, vbBinaryCompare) <> 0 Then Exit Function
    If first.BodyFormat = olFormatHTML Then
        If StrComp(first.HTMLBody, second.HTMLBody, vbBinaryCompare) <> 0 Then Exit Function ' Added HTML content is information even if a plain-text preview looks unchanged.
    ElseIf first.BodyFormat = olFormatRichText Then
        leftRTF = first.RTFBody: rightRTF = second.RTFBody
        length = UBound(leftRTF) - LBound(leftRTF) + 1
        If UBound(rightRTF) - LBound(rightRTF) + 1 <> length Then Exit Function
        If RtlCompareMemory(leftRTF(LBound(leftRTF)), rightRTF(LBound(rightRTF)), length) <> length Then Exit Function
    End If
    For index = 1 To first.Attachments.Count
        Set leftAttachment = first.Attachments(index): Set rightAttachment = second.Attachments(index)
        If leftAttachment.Type <> olByValue Or rightAttachment.Type <> olByValue Then
            detail = "An embedded or linked attachment could not be verified as an exact duplicate."
            GoTo Finished ' Keep unverified copies; an attachment name or size alone is not evidence of identical content.
        End If
        If StrComp(leftAttachment.FileName, rightAttachment.FileName, vbBinaryCompare) <> 0 Or leftAttachment.Size <> rightAttachment.Size Then GoTo Finished
        If Len(temp) = 0 Then temp = PT_CreateTempFolder()
        leftAttachment.SaveAsFile temp & "\left.bin": rightAttachment.SaveAsFile temp & "\right.bin"
        If Not PT_FilesEqual(temp & "\left.bin", temp & "\right.bin") Then GoTo Finished
        Kill temp & "\left.bin": Kill temp & "\right.bin" ' Reuse the temporary names for the next pair without retaining verification files.
    Next index
    PT_ExactMessageCopy = True
Finished:
    If Len(temp) > 0 Then PT_CleanTemp temp
    Exit Function
CouldNotCompare:
    detail = "Exact-copy verification was skipped: " & Err.Description
    Resume Finished
End Function

' Join verified exact copies of the selected email even when a system assigns fresh message IDs.
' Compare candidates in coarse subject/body-length buckets, then verify full content and attachment bytes.
' The bucket only avoids unnecessary comparisons; it never proves a duplicate on its own.
Private Sub PT_JoinExactCopies(ByVal selected As Collection, ByVal envelopes As Collection, ByVal parents As Object, ByVal model As Object, ByVal panel As frmPersonalOutlook, ByVal allChains As Boolean)
    Dim proof As Object, buckets As Object, subjects As Object, seed As Outlook.MailItem, candidate As Outlook.MailItem
    Dim envelope As Object, tokens As Collection, strong As Boolean, count As Long, subject As String
    Set proof = PT_V6Dict(): model.Add "exactCopies", proof
    Set buckets = PT_V6Dict(): Set subjects = PT_V6Dict() ' Restrict selected-chain comparisons to its subjects; Find All checks the full requested scope.
    If Not selected Is Nothing Then
        For Each seed In selected
            subject = PT_NormaliseSubject(seed.Subject): subjects(subject) = True
            Set tokens = PT_V6MailTokens(seed, strong)
            PT_RegisterExactCopy seed, tokens, buckets, proof, parents, model
        Next seed
    End If
    For Each envelope In envelopes
        subject = PT_NormaliseSubject(CStr(envelope("subject")))
        If allChains Or subjects.Exists(subject) Then
            Set candidate = Nothing
            On Error Resume Next
            Set candidate = MailApp().Session.GetItemFromID(CStr(envelope("entry")), CStr(envelope("store")))
            On Error GoTo 0
            If Not candidate Is Nothing Then
                Set tokens = envelope("tokens")
                PT_RegisterExactCopy candidate, tokens, buckets, proof, parents, model
            End If
        End If
        count = count + 1
        If count Mod 100 = 0 Then
            If Not PT_V6Progress(model, panel, "Checking exact copies: " & count & " / " & envelopes.Count) Then Exit Sub
        End If
    Next envelope
End Sub

' Keep one representative for each verified content class, including repeated system deliveries with fresh IDs.
Private Sub PT_RegisterExactCopy(ByVal mail As Outlook.MailItem, ByVal tokens As Collection, ByVal buckets As Object, ByVal proof As Object, ByVal parents As Object, ByVal model As Object)
    Dim bucket As String, key As String, otherKey As String, representatives As Collection, representative As Object
    Dim first As Outlook.MailItem, detail As String, leftRoot As String, rightRoot As String
    On Error GoTo Failed
    If Not mail.Sent Or Not mail.Saved Then Exit Sub
    key = mail.Parent.StoreID & "|" & mail.EntryID
    bucket = PT_NormaliseSubject(mail.Subject) & "|" & Len(mail.Body) & "|" & mail.Attachments.Count
    If Not buckets.Exists(bucket) Then Set representatives = New Collection: buckets.Add bucket, representatives
    Set representatives = buckets(bucket) ' Only complete-content verification can merge a candidate into one of these classes.
    For Each representative In representatives
        Set first = representative("mail"): otherKey = CStr(representative("key"))
        If key = otherKey Then Exit Sub
        If PT_ExactMessageCopy(first, mail, detail) Then
            leftRoot = PT_V6Find(parents, CStr(representative("tokens")(1)))
            rightRoot = PT_V6Find(parents, CStr(tokens(1)))
            If leftRoot <> rightRoot Then parents(rightRoot) = leftRoot
            proof(otherKey) = otherKey: proof(key) = otherKey
            Exit Sub
        ElseIf Len(detail) > 0 Then
            model("warnings") = CStr(model("warnings")) & vbCrLf & detail
        End If
    Next representative
    Set representative = PT_V6Dict()
    representative.Add "mail", mail: representative.Add "tokens", tokens: representative.Add "key", key
    representatives.Add representative
    Exit Sub
Failed:
    model("warnings") = CStr(model("warnings")) & vbCrLf & "Kept an unverified copy: " & Err.Description
End Sub


' Keep one collection per metadata key while supporting duplicate deliveries with the same message ID.
Private Sub PT_AddChainIndex(ByVal index As Object, ByVal key As String, ByVal row As Object)
    Dim entries As Collection
    If Len(key) = 0 Then Exit Sub
    If Not index.Exists(key) Then Set entries = New Collection: index.Add key, entries
    index(key).Add row
End Sub

' Protect chronological newest messages and every terminal reply branch, irrespective of changed To/Cc lists.
Private Sub PT_ProtectChainTips(ByVal model As Object)
    Dim rows As Collection, row As Object, child As Object, parent As Object, key As Variant, token As Variant
    Dim groupParents As Object, newest As Object, ids As Object, indexes As Object, keepers As Object
    Dim tokens As Collection, references As Collection, index As String, prefix As String, length As Long, group As String
    Dim messageIDs As Collection, leaves As Collection, copyNewest As Object, copyClass As String
    Set rows = model("rows"): Set groupParents = PT_V6Dict(): Set newest = PT_V6Dict()
    Set ids = PT_V6Dict(): Set indexes = PT_V6Dict(): Set keepers = PT_V6Dict(): Set copyNewest = PT_V6Dict()
    For Each row In rows
        Set tokens = New Collection: tokens.Add "R:" & CStr(row("component"))
        If CLng(model("match")) > 0 Then tokens.Add "S:" & PT_NormaliseSubject(CStr(row("record")(4)))
        PT_V6Join groupParents, tokens ' Subject matching is an explicit user choice; linked mode does not merge unrelated subjects.
    Next row
    For Each row In rows
        group = PT_V6Find(groupParents, "R:" & CStr(row("component")))
        row("group") = group: row("latest") = False
        row.Add "hasDescendant", False
        copyClass = CStr(row("copyClass"))
        If Len(copyClass) > 0 Then
            If Not copyNewest.Exists(copyClass) Then copyNewest.Add copyClass, CDate(0)
            If CDate(row("record")(6)) > CDate(copyNewest(copyClass)) Then copyNewest(copyClass) = CDate(row("record")(6))
        End If
        If Not newest.Exists(group) Then newest.Add group, CDate(0)
        If CDate(row("record")(6)) > CDate(newest(group)) Then newest(group) = CDate(row("record")(6))
        For Each token In row("messageIDs"): PT_AddChainIndex ids, group & "|" & CStr(token), row: Next token
        PT_AddChainIndex indexes, group & "|" & CStr(row("threadIndex")), row
    Next row
    For Each child In rows ' Mark every referenced ancestor, so terminal branches can be protected independently of their receipt order.
        group = CStr(child("group"))
        For Each token In child("replyIDs")
            key = group & "|" & CStr(token)
            If ids.Exists(key) Then
                For Each parent In ids(key)
                    If Not parent Is child Then parent("hasDescendant") = True
                Next parent
            End If
        Next token
        index = CStr(child("threadIndex"))
        For length = 44 To Len(index) - 10 Step 10
            key = group & "|" & Left$(index, length)
            If indexes.Exists(key) Then
                For Each parent In indexes(key): parent("hasDescendant") = True: Next parent
            End If
        Next length
    Next child
    For Each row In rows ' Build the protected keeper list only after all reply relationships are known.
        group = CStr(row("group"))
        If CDate(row("record")(6)) = CDate(newest(group)) Then
            row("latest") = True
            If Len(row("reason")) = 0 Then row("reason") = "Kept: newest message (including ties)"
        ElseIf CBool(row("exactCopy")) Then
            If CDate(row("record")(6)) = CDate(copyNewest(CStr(row("copyClass")))) Then
                row("latest") = True ' Keep one newest representative of each content class, even beside a newer, different reply branch.
                If Len(row("reason")) = 0 Then row("reason") = "Kept: newest copy of this complete message"
            End If
        ElseIf Not CBool(row("subjectOnly")) And CBool(row("hasReplyParent")) And Not CBool(row("hasDescendant")) Then
            row("latest") = True ' A terminal reply can contain unique information even when a different branch arrived later.
            If Len(row("reason")) = 0 Then row("reason") = "Kept: latest reply on this branch"
        End If
        If CBool(row("latest")) Then
            If Not keepers.Exists(group) Then Set leaves = New Collection: keepers.Add group, leaves
            keepers(group).Add row
            row("wantDelete") = False
        End If
    Next row
    Set model("keepers") = keepers
End Sub

' Capture the existing Explorer and its pane state without changing its selected messages.
Private Function PT_CaptureExplorerUI() As Object
    Dim state As Object, explorer As Outlook.Explorer
    Set state = CreateObject("Scripting.Dictionary")
    On Error Resume Next ' An Inspector-only session may have no Explorer or navigation pane.
    Set explorer = MailApp().ActiveExplorer
    If Not explorer Is Nothing Then
        state.Add "explorer", explorer
        Err.Clear
        state.Add "collapsed", explorer.NavigationPane.IsCollapsed
    End If
    state.Add "owner", GetAncestor(GetActiveWindow(), 3) ' Capture the root owner before any temporary UserForm is unloaded.
    On Error GoTo 0
    Set PT_CaptureExplorerUI = state
End Function

' Restore the previous pane setting and repaint after Outlook saves changed attachments.
' Selection is never cleared/rebuilt, and no folder/view is switched as a refresh workaround.
Private Sub PT_RestoreExplorerUI(ByVal state As Object)
    Dim explorer As Outlook.Explorer
    On Error Resume Next ' Window cleanup must never hide the result of an attachment operation.
    If state Is Nothing Then Exit Sub
    If state.Exists("explorer") And state.Exists("collapsed") Then
        Set explorer = state("explorer")
        If explorer.NavigationPane.IsCollapsed <> CBool(state("collapsed")) Then explorer.NavigationPane.IsCollapsed = CBool(state("collapsed"))
    End If
    If state.Exists("owner") Then
        If IsWindow(state("owner")) <> 0 Then RedrawWindow state("owner"), 0, 0, &H581 ' Invalidate/frame/all children/update now, preserving Outlook's selection and layout.
    End If
    On Error GoTo 0
End Sub

' Build a small self-contained blue/pink/white/pink/blue gradient; no downloaded image or permanent asset is needed.
Public Function PT_TransNoticePicture() As Object
    Static cached As Object
    Dim bytes() As Byte, width As Long, height As Long, stride As Long, total As Long
    Dim x As Long, y As Long, p As Long, band As Long, t As Double, colours As Variant
    Dim r As Long, g As Long, b As Long, a As Variant, z As Variant, folder As String, path As String, handle As Integer
    Dim number As Long, description As String
    If Not cached Is Nothing Then Set PT_TransNoticePicture = cached: Exit Function
    On Error GoTo Failed
    width = 384: height = 420: stride = ((width * 3 + 3) \ 4) * 4: total = 54 + stride * height
    ReDim bytes(0 To total - 1)
    bytes(0) = 66: bytes(1) = 77 ' Windows BMP file and 24-bit RGB information headers.
    PT_BitmapLong bytes, 2, total: PT_BitmapLong bytes, 10, 54: PT_BitmapLong bytes, 14, 40
    PT_BitmapLong bytes, 18, width: PT_BitmapLong bytes, 22, height
    bytes(26) = 1: bytes(28) = 24: PT_BitmapLong bytes, 34, stride * height
    colours = Array(Array(219, 236, 245), Array(244, 228, 235), Array(251, 249, 250), Array(244, 228, 235), Array(219, 236, 245))
    For y = 0 To height - 1
        t = CDbl(y) / (height - 1) * 4: band = Fix(t)
        If band > 3 Then band = 3
        t = t - band: t = (t + t * t * (3 - 2 * t)) / 2 ' Smooth the joins between the five trans-flag colours.
        a = colours(band): z = colours(band + 1)
        r = CLng(a(0) * (1 - t) + z(0) * t): g = CLng(a(1) * (1 - t) + z(1) * t): b = CLng(a(2) * (1 - t) + z(2) * t)
        For x = 0 To width - 1
            p = 54 + y * stride + x * 3
            bytes(p) = b: bytes(p + 1) = g: bytes(p + 2) = r
        Next x
    Next y
    folder = PT_CreateTempFolder(): path = folder & "\notice.bmp"
    handle = FreeFile: Open path For Binary Access Write As #handle: Put #handle, , bytes: Close #handle: handle = 0
    Set cached = LoadPicture(path) ' StdPicture owns the image after the temporary file is removed.
    PT_CleanTemp folder
    Set PT_TransNoticePicture = cached
    Exit Function
Failed:
    number = Err.Number: description = Err.Description
    On Error Resume Next
    If handle <> 0 Then Close #handle
    If Len(folder) > 0 Then PT_CleanTemp folder
    On Error GoTo 0
    Err.Raise number, "modPersonalOutlookTools.PT_TransNoticePicture", description
End Function

' Write little-endian positive DWORDs without depending on Office pointer width.
Private Sub PT_BitmapLong(ByRef bytes() As Byte, ByVal offset As Long, ByVal value As Long)
    Dim i As Long
    For i = 0 To 3: bytes(offset + i) = value Mod 256: value = value \ 256: Next i
End Sub

' Offer real Outlook categories or portable category-note attachments for the captured selection.
Public Sub Mail_CategoriseEmails()
    OrganiseSelection False
End Sub

' Combine the selected stores' native category names with names previously chosen in this macro.
Public Function PT_CategoryChoices(ByVal mails As Collection) As Collection
    Dim names As New Collection, seen As Object, stores As Object, mail As Outlook.MailItem, category As Outlook.Category
    Dim key As String, name As String, count As Long, i As Long, saved As String
    Set seen = PT_V6Dict(): seen.CompareMode = vbTextCompare: Set stores = PT_V6Dict()
    For Each mail In mails
        key = mail.Parent.StoreID
        If Not stores.Exists(key) Then
            stores.Add key, True
            On Error Resume Next ' A provider such as IMAP may omit the native category collection.
            For Each category In mail.Parent.Store.Categories
                name = category.Name
                If Not seen.Exists(name) Then seen.Add name, True: names.Add name
            Next category
            On Error GoTo 0
        End If
    Next mail
    saved = PT_ReadSetting("CategoryChoiceCount", "0")
    If Len(saved) <= 4 And Not saved Like "*[!0-9]*" And Len(saved) > 0 Then count = CLng(saved)
    If count > 5000 Then count = 0
    For i = 1 To count
        name = PT_ReadSetting("CategoryChoice" & i, "")
        If Len(name) > 0 Then If Not seen.Exists(name) Then seen.Add name, True: names.Add name
    Next i
    Set PT_CategoryChoices = names
End Function

' Remember a successful choice without creating files or changing the user's native master category list.


' Apply the chosen category to each unchanged saved item, retaining existing categories and collecting failures.


' Read the same delimiter Outlook uses for its Categories string.
Private Function PT_CategorySeparator() As String
    On Error Resume Next
    PT_CategorySeparator = CStr(CreateObject("WScript.Shell").RegRead("HKCU\Control Panel\International\sList"))
    If Len(PT_CategorySeparator) = 0 Then PT_CategorySeparator = ","
End Function

' Attach a named Unicode text category once; the attachment marker makes repeated assignment idempotent.
Private Sub PT_AttachCategoryNote(ByVal mail As Outlook.MailItem, ByVal name As String, Optional ByVal persist As Boolean = True)
    Const marker As String = "http://schemas.microsoft.com/mapi/string/{00020329-0000-0000-C000-000000000046}/PT_CategoryNote"
    Dim attachment As Outlook.Attachment, previous As String, folder As String, path As String, stream As Object
    Dim number As Long, description As String
    On Error GoTo Failed
    For Each attachment In mail.Attachments
        previous = ""
        On Error Resume Next: previous = CStr(attachment.PropertyAccessor.GetProperty(marker)): On Error GoTo Failed
        If StrComp(previous, name, vbTextCompare) = 0 Then Exit Sub
    Next attachment
    folder = PT_CreateTempFolder(): path = folder & "\Category - " & PT_SafeFileName(name) & ".txt"
    Set stream = CreateObject("Scripting.FileSystemObject").CreateTextFile(path, True, True)
    stream.Write "Category: " & name & vbCrLf: stream.Close: Set stream = Nothing
    Set attachment = mail.Attachments.Add(path, olByValue)
    attachment.PropertyAccessor.SetProperty marker, name
    If persist Then mail.Save
    PT_CleanTemp folder
    Exit Sub
Failed:
    number = Err.Number: description = Err.Description
    On Error Resume Next
    If Not stream Is Nothing Then stream.Close
    If Len(folder) > 0 Then PT_CleanTemp folder
    On Error GoTo 0
    Err.Raise number, "modPersonalOutlookTools.PT_AttachCategoryNote", description
End Sub

' Only the genuine delivery event enters this dispatcher. Folder ItemAdd events deliberately do not call it.
Public Sub PT_HandleNewMail(ByVal entryIDs As String)
    Dim id As Variant, item As Object, rules As Collection, number As Long, description As String, notify As Boolean
    ' A broken folder-rule setting must not suppress an independent notification.
    On Error Resume Next
    Err.Clear: Set rules = ArrivalRuleSnapshot()
    If Err.Number <> 0 Then
        number = Err.Number: description = Err.Description
        PT_WriteSetting "LastArrivalRuleRun", PT_ErrorText("Load arrival rules", number, description, "", "modPersonalOutlookTools.PT_HandleNewMail")
    End If
    On Error GoTo Failed
    notify = HasNotificationWatch()
    If rules Is Nothing Then Set rules = New Collection
    If rules.Count = 0 And Not notify Then Exit Sub
    For Each id In Split(entryIDs, ",")
        Set item = PT_ResolveMailEntry(CStr(id))
        If Not item Is Nothing Then
            If TypeOf item Is Outlook.MailItem Then
                If notify Then PT_AlertArrived item
                If rules.Count > 0 Then PT_ApplyArrivalRules item, rules
            End If
        End If
    Next id
    Exit Sub
Failed:
    number = Err.Number: description = Err.Description
    On Error Resume Next
    PT_WriteSetting "LastArrivalRuleRun", PT_ErrorText("New delivery rules", number, description, "", "modPersonalOutlookTools.PT_HandleNewMail")
End Sub

' Apply enabled receive rules to this delivered object only, never to a scan of old folder contents.
' The original parent folder is captured once. A later move cannot cause the item to match a different source rule.
Public Sub PT_ApplyArrivalRules(ByVal mail As Outlook.MailItem, ByVal rules As Collection)
    Dim rule As Object, ref As Object, source As String, key As String, record As Variant, matched As Boolean
    Dim number As Long, description As String, changed As Long
    On Error GoTo Failed
    If Not mail.Sent Or Not mail.Saved Then Exit Sub
    If PT_IsSentFolder(mail.Parent) Then Exit Sub
    source = mail.Parent.StoreID & "|" & mail.Parent.EntryID
    For Each rule In rules
        If CBool(rule("enabled")) And CStr(rule("event")) = "receive" Then
            matched = False
            For Each ref In rule("sources")
                If PT_ReferenceKey(ref) = source Then matched = True: Exit For
            Next ref
            If matched Then
                ObserveRuleFault rule, PT_ReadSetting("RuleFault_" & rule("id"), "")
                matched = CBool(rule("enabled"))
            End If
            If matched Then
                If Len(key) = 0 Then
                    ' Track only matching deliveries, before a save can re-enter the event.
                    If arrivalSeen Is Nothing Then Set arrivalSeen = PT_V6Dict()
                    key = PT_ArrivalObjectKey(mail)
                    If arrivalSeen.Exists(key) Then Exit Sub
                    arrivalSeen.Add key, True
                    record = PT_Record(mail)
                End If
                PT_ValidateFolderRule rule
                PT_ApplyFolderRule rule, record, Now
                changed = changed + 1: RuleOutcome rule, "New delivery handled."
                If CStr(rule("action")) = "move" Or CStr(rule("action")) = "delete" Then Exit For
            End If
        End If
    Next rule
    If changed > 0 Then PT_WriteSetting "LastArrivalRuleRun", Format$(Now, "yyyy-mm-dd hh:nn:ss") & " | new delivery: " & changed & " rule action(s) completed."
    Exit Sub
Failed:
    number = Err.Number: description = Err.Description
    If Not rule Is Nothing Then RuleOutcome rule, description, True
    PT_WriteSetting "LastArrivalRuleRun", PT_ErrorText("New delivery rule", number, description, "", "modPersonalOutlookTools.PT_ApplyArrivalRules")
End Sub

' PR_RECORD_KEY distinguishes physical deliveries, and normally survives a move within the same store.
Private Function PT_ArrivalObjectKey(ByVal mail As Outlook.MailItem) As String
    Dim id As String
    On Error Resume Next
    id = mail.PropertyAccessor.BinaryToString(mail.PropertyAccessor.GetProperty(PT_V6_TAG & "0x0FF90102"))
    On Error GoTo 0
    If Len(id) = 0 Then id = mail.EntryID
    If Len(id) = 0 Then Err.Raise 5, , "The received email has no saved identifier."
    PT_ArrivalObjectKey = mail.Parent.StoreID & "|" & id
End Function

' Attach the selected file once if identical bytes are already present; never replace another attachment.
Private Sub PT_AttachRuleFile(ByVal item As Object, ByVal path As String)
    Dim file As Object, attachment As Outlook.Attachment, folder As String, same As Boolean, number As Long, description As String
    On Error GoTo Failed
    Set file = CreateObject("Scripting.FileSystemObject").GetFile(path)
    For Each attachment In item.Attachments
        If attachment.Type = olByValue And StrComp(attachment.FileName, file.Name, vbTextCompare) = 0 Then
            folder = PT_CreateTempFolder(): attachment.SaveAsFile folder & "\compare.bin"
            same = PT_FilesEqual(path, folder & "\compare.bin"): PT_CleanTemp folder: folder = ""
            If same Then Exit Sub
        End If
    Next attachment
    item.Attachments.Add path, olByValue: item.Save
    Exit Sub
Failed:
    number = Err.Number: description = Err.Description
    If Len(folder) > 0 Then PT_CleanTemp folder
    Err.Raise number, "modPersonalOutlookTools.PT_AttachRuleFile", description
End Sub

' Allow an older file-bearing email only when every ordinary file survives byte-for-byte in protected later mail.
' Check again at action time: a keeper's attachment could have changed after the preview.
Public Function PT_ChainFilesRetained(ByVal row As Object, ByVal model As Object) As Boolean
    Dim original As Outlook.MailItem, retained As Outlook.MailItem, keeper As Object
    Dim attachment As Outlook.Attachment, candidate As Outlook.Attachment, folder As String, html As String
    Dim found As Boolean, files As Long, originalPath As String, candidatePath As String
    On Error GoTo Finished
    If Not model("keepers").Exists(CStr(row("group"))) Then Exit Function
    PT_V6ValidateRow row, original
    If original.BodyFormat = olFormatHTML Then html = original.HTMLBody
    folder = PT_CreateTempFolder(): originalPath = folder & "\source.bin": candidatePath = folder & "\keeper.bin"
    For Each attachment In original.Attachments
        If PT_IsFileAttachment(attachment, html) Then
            files = files + 1: found = False
            If attachment.Type <> olByValue Then GoTo Finished ' Embedded/linked payloads stay protected unless ordinary bytes can be verified.
            attachment.SaveAsFile originalPath
            For Each keeper In model("keepers")(CStr(row("group")))
                If CDate(keeper("record")(6)) > CDate(row("record")(6)) Then
                    PT_V6ValidateRow keeper, retained
                    For Each candidate In retained.Attachments
                        If candidate.Type = olByValue And candidate.Size = attachment.Size And StrComp(candidate.FileName, attachment.FileName, vbTextCompare) = 0 Then
                            candidate.SaveAsFile candidatePath
                            found = PT_FilesEqual(originalPath, candidatePath)
                            Kill candidatePath
                            If found Then Exit For
                        End If
                    Next candidate
                End If
                If found Then Exit For
            Next keeper
            Kill originalPath
            If Not found Then GoTo Finished
        End If
    Next attachment
    PT_ChainFilesRetained = (files > 0)
Finished:
    If Len(folder) > 0 Then PT_CleanTemp folder ' The helper owns only this unique temporary directory.
End Function

' Record verified coverage for the review; unmatched and unverified files remain protected by default.
Private Sub PT_VerifyChainFileCoverage(ByVal model As Object, ByVal panel As frmPersonalOutlook)
    Dim row As Object, n As Long
    For Each row In model("rows")
        row.Add "filesRetained", False
        If CLng(row("files")) > 0 And Not CBool(row("latest")) Then row("filesRetained") = PT_ChainFilesRetained(row, model)
        n = n + 1
        If n Mod 10 = 0 Then
            If Not PT_V6Progress(model, panel, "Verifying retained attachments: " & n & " / " & model("rows").Count) Then Exit Sub
        End If
    Next row
End Sub

' Clearly named shortcut for the requested unread OR received-within-X-days saved folder.
Public Sub Settings_CreateUnreadOrRecentSearchFolder()
    PT_SearchFolderWizard 3, "Unread or recent mail"
End Sub

' Add a saved Search Folder to Mail Favorites without altering mail or creating a physical duplicate.
Public Function PT_AddSearchFolderFavorite(ByVal folder As Outlook.Folder, ByRef warning As String) As Boolean
    Dim explorer As Outlook.Explorer, module As Outlook.MailModule, group As Outlook.NavigationGroup, entry As Outlook.NavigationFolder
    On Error GoTo Failed
    Set explorer = MailApp().ActiveExplorer
    If explorer Is Nothing Then Err.Raise 5, , "Open the main Outlook Mail window to add a Favorite."
    Set module = explorer.NavigationPane.Modules.GetNavigationModule(olModuleMail)
    Set group = module.NavigationGroups.GetDefaultNavigationGroup(olFavoriteFoldersGroup)
    For Each entry In group.NavigationFolders
        If entry.Folder.EntryID = folder.EntryID And entry.Folder.StoreID = folder.StoreID Then PT_AddSearchFolderFavorite = True: Exit Function
    Next entry
    group.NavigationFolders.Add folder
    PT_AddSearchFolderFavorite = True
    Exit Function
Failed:
    warning = "The Search Folder was saved under " & folder.Store.DisplayName & ", but could not be added to Favorites: " & Err.Description
End Function

' IMAP does not support native categories; avoid its provider redirecting a new master category into a different store.
Private Function PT_StoreSupportsCategories(ByVal store As Outlook.Store) As Boolean
    Dim account As Outlook.Account, delivery As Outlook.Store
    PT_StoreSupportsCategories = True
    For Each account In MailApp().Session.Accounts
        Set delivery = Nothing
        On Error Resume Next: Set delivery = account.DeliveryStore: On Error GoTo 0
        If Not delivery Is Nothing Then
            If delivery.StoreID = store.StoreID And account.AccountType = olImap Then PT_StoreSupportsCategories = False: Exit Function
        End If
    Next account
End Function

' NewMailEx supplies only an EntryID; probe explicit stores when the default-store lookup cannot resolve it.
Public Function PT_ResolveMailEntry(ByVal entry As String) As Object
    Dim store As Outlook.Store, item As Object
    On Error Resume Next
    Set item = MailApp().Session.GetItemFromID(entry)
    If item Is Nothing Then
        For Each store In MailApp().Session.Stores
            Set item = MailApp().Session.GetItemFromID(entry, store.StoreID)
            If Not item Is Nothing Then Exit For
        Next store
    End If
    On Error GoTo 0
    Set PT_ResolveMailEntry = item
End Function


' A reading-pane item can carry a stale Saved flag. Reopen the stored message
' by both IDs before deciding whether there are edits to settle. Never save or
' discard a visible editor implicitly. A brand-new draft has no stored version.
Public Function EditableItem(ByVal selected As Object) As Object
    Dim item As Object, openItem As Object, window As Outlook.Inspector, explorer As Outlook.Explorer
    Dim entry As String, store As String, choice As VbMsgBoxResult, discardWindow As Outlook.Inspector
    entry = selected.EntryID
    If Len(entry) = 0 Then Set EditableItem = selected: Exit Function
    store = selected.Parent.StoreID
    For Each window In MailApp().Inspectors
        Set openItem = window.CurrentItem
        If SameStoredItem(openItem, entry, store) Then
            Set item = openItem
            Exit For
        End If
    Next window
    If item Is Nothing Then
        For Each explorer In MailApp().Explorers
            Set openItem = Nothing
            On Error Resume Next
            Set openItem = explorer.ActiveInlineResponse
            On Error GoTo 0
            If SameStoredItem(openItem, entry, store) Then
                Set item = openItem
                Exit For
            End If
        Next explorer
    End If
    If item Is Nothing Then Set item = MailApp().Session.GetItemFromID(entry, store)
    If Not item.Saved Then
        choice = MsgBox("Outlook reports pending changes to """ & PT_ItemLabel(item) & """." & vbCrLf & vbCrLf & _
            "Yes - save those changes and continue." & vbCrLf & _
            "No - discard those changes and use the stored message." & vbCrLf & _
            "Cancel - skip this item and keep its edits.", vbYesNoCancel Or vbQuestion Or vbDefaultButton3, "Use this email")
        Select Case choice
            Case vbYes: item.Save
            Case vbNo
                ' Discard through the Inspector even when the stale item originated in the reading pane.
                Set discardWindow = item.GetInspector: discardWindow.Close olDiscard: Set discardWindow = Nothing
            Case Else: Err.Raise 5, "Use this email", "Skipped at your request."
        End Select
        Set item = Nothing
        Set item = MailApp().Session.GetItemFromID(entry, store)
    End If
    Set EditableItem = item
End Function

Private Function SameStoredItem(ByVal item As Object, ByVal entry As String, ByVal store As String) As Boolean
    On Error Resume Next
    If item Is Nothing Then Exit Function
    SameStoredItem = (Len(entry) > 0 And StrComp(item.EntryID, entry, vbTextCompare) = 0 And StrComp(item.Parent.StoreID, store, vbTextCompare) = 0)
End Function

' Keep origin as a separate key. A native category and a template can share a name.
Public Function CategoryRows(ByVal items As Collection) As Collection
    Dim rows As New Collection, stores As Object, seen As Object, item As Object
    Dim key As Variant, name As Variant, cat As Outlook.Category, store As Outlook.Store
    Dim emptySelection As New Collection, nativeNames As Object
    Set stores = PT_V6Dict(): Set seen = PT_V6Dict(): seen.CompareMode = vbTextCompare
    For Each item In items
        Set store = item.Parent.Store
        If Not stores.Exists(store.StoreID) Then stores.Add store.StoreID, store
    Next item
    If stores.Count = 0 Then
        Set store = MailApp().Session.DefaultStore
        stores.Add store.StoreID, store
    End If
    For Each key In stores.Keys
        Set store = stores(key)
        On Error Resume Next
        For Each cat In store.Categories
            If Not seen.Exists(cat.Name) Then seen.Add cat.Name, True: rows.Add Array(cat.Name, "Outlook category")
        Next cat
        On Error GoTo 0
    Next key
    Set nativeNames = seen: Set seen = PT_V6Dict(): seen.CompareMode = vbTextCompare
    For Each name In PT_RuleNoteNames()
        rows.Add Array(CStr(name), "Custom note template"): seen.Add CStr(name), True
    Next name
    For Each name In PT_CategoryChoices(emptySelection)
        If Not seen.Exists(CStr(name)) And Not nativeNames.Exists(CStr(name)) Then rows.Add Array(CStr(name), "Custom text label")
    Next name
    Set CategoryRows = rows
End Function

Private Sub AssignNativeCategory(ByVal item As Object, ByVal name As String)
    Dim store As Outlook.Store, category As Outlook.Category
    Set store = item.Parent.Store
    If Not PT_StoreSupportsCategories(store) Then Err.Raise 5, , "This mailbox does not support Outlook categories. Choose a custom note instead."
    On Error Resume Next
    Set category = store.Categories.Item(name)
    On Error GoTo 0
    If category Is Nothing Then Set category = store.Categories.Add(name)
    item.Categories = PT_MergedCategories(CStr(item.Categories), name)
End Sub

Private Sub ApplyChoices(ByVal item As Object, ByVal choices As Collection, ByVal readChoice As Long)
    Dim row As Variant, changed As Boolean
    ' Validate mail-only choices before touching read state or categories.
    For Each row In choices
        If CStr(row(1)) <> "Outlook category" And Not TypeOf item Is Outlook.MailItem Then Err.Raise 5, , "Custom category notes can be attached only to an email."
    Next row
    Dim originalCategories As String, originalUnread As Boolean, originalFiles As Long
    Dim hasNative As Boolean, hasFiles As Boolean, number As Long, detail As String
    For Each row In choices
        If row(1) = "Outlook category" Then hasNative = True Else hasFiles = True
    Next row
    If hasNative Then originalCategories = CStr(item.Categories)
    If readChoice > 0 Then originalUnread = CBool(item.UnRead)
    If hasFiles Then originalFiles = item.Attachments.Count
    On Error GoTo RollBack
    If readChoice > 0 Then item.UnRead = (readChoice = 2): changed = True
    For Each row In choices
        Select Case CStr(row(1))
            Case "Outlook category": AssignNativeCategory item, CStr(row(0)): changed = True
            Case "Custom note template": PT_AttachRuleNote item, CStr(row(0)), False: changed = True
            Case "Custom text label": PT_AttachCategoryNote item, CStr(row(0)), False: changed = True
        End Select
    Next row
    If changed And Len(item.EntryID) > 0 Then item.Save
    Exit Sub
RollBack:
    number = Err.Number: detail = Err.Description
    On Error Resume Next
    If hasNative Then item.Categories = originalCategories
    If readChoice > 0 Then item.UnRead = originalUnread
    If hasFiles Then
        Do While item.Attachments.Count > originalFiles
            Err.Clear: item.Attachments.Remove item.Attachments.Count
            If Err.Number <> 0 Then Exit Do
        Loop
    End If
    On Error GoTo 0
    Err.Raise number, "Apply choices", detail
End Sub

Private Function ApplyItemAction(ByVal original As Object, ByVal panel As frmPersonalOutlook) As String
    Dim target As Object, copy As Object, filing As Boolean, destination As Outlook.Folder
    Dim detail As String, committed As Boolean, same As Boolean, copyID As String, fromFolder As Outlook.Folder
    On Error GoTo Failed
    If panel.FilingAction = 2 Then
        If Len(original.EntryID) = 0 Then Err.Raise 5, , "Save this new draft before copying it. Its edits have been kept."
        Set target = MailApp().Session.GetItemFromID(original.EntryID, original.Parent.StoreID)
        If Not target.Saved Then Err.Raise 5, , "The stored copy still has pending edits. Save the original when ready and try again."
    Else
        Set target = EditableItem(original)
    End If
    If panel.FilingAction > 0 Then
        Set destination = panel.ChosenFolder
        same = (target.Parent.EntryID = destination.EntryID And target.Parent.StoreID = destination.StoreID)
        If panel.FilingAction = 2 Then
            Set fromFolder = target.Parent: Set copy = target.Copy
            copyID = copy.EntryID
            If Len(copyID) = 0 Or copyID = original.EntryID Then Err.Raise 5, , "Outlook could not confirm a separate copy."
            SeparateWorkflowCopy copy: Set target = copy
            If Not same Then Set target = copy.Move(destination)
            committed = True
        ElseIf Not same Then
            Set target = target.Move(destination)
            committed = True
        End If
    End If
    ApplyChoices target, panel.PickedCategories, panel.ReadChoice
    Exit Function
Failed:
    detail = Err.Description
    If committed Then detail = "Filed in " & destination.FolderPath & ". Remaining changes were incomplete. " & detail
    ' Only the temporary copy created by this attempt may be removed if its move failed.
    If Not copy Is Nothing And Not committed Then
        On Error Resume Next
        Dim confirmed As Object
        Err.Clear
        If Len(copyID) > 0 And copyID <> original.EntryID Then Set confirmed = MailApp().Session.GetItemFromID(copyID, fromFolder.StoreID)
        If Not confirmed Is Nothing Then
            If confirmed.Parent.EntryID = fromFolder.EntryID Then confirmed.Delete
        End If
        If Err.Number <> 0 Or confirmed Is Nothing Then detail = detail & " Check the source and destination before copying again."
    End If
    ApplyItemAction = detail
End Function

Private Sub OrganiseSelection(ByVal filing As Boolean)
    Dim selected As Collection, item As Object, panel As frmPersonalOutlook
    Dim count As Long, detail As String, failures As String
    If bulkRunning Then Exit Sub
    On Error GoTo Failed
    If filing Then Set selected = PT_SelectedItems() Else Set selected = PT_SelectedMessages()
    If selected.Count = 0 Then MsgBox "Select an email or open it first.", vbInformation, "Organise selection": Exit Sub
    bulkRunning = True
    Set panel = New frmPersonalOutlook
    panel.PrepareOrganise selected.Count, CategoryRows(selected), filing
    panel.Show vbModal
    If panel.Result = 1 Then
        For Each item In selected
            detail = ApplyItemAction(item, panel)
            If Len(detail) Then failures = failures & vbCrLf & PT_ItemLabel(item) & " - " & detail Else count = count + 1
        Next item
    End If
Finished:
    If Not panel Is Nothing Then Unload panel
    bulkRunning = False
    If Len(failures) Then PT_ShowReport "Organise selection", count & " of " & selected.Count & " completed." & vbCrLf & failures
    Exit Sub
Failed:
    MsgBox Err.Description, vbExclamation, "Organise selection"
    Resume Finished
End Sub

' The copy picker stays modeless so the user can select or open a different email.
Private Sub StartCopyPicker(ByVal selected As Collection)
    If Not attachmentPicker Is Nothing Then
        If attachmentPicker.Visible Then Exit Sub
        Set attachmentPicker = Nothing
    End If
    Set attachmentPicker = New frmPersonalOutlook
    attachmentPicker.PrepareCopyPicker Nothing, selected
    attachmentPicker.Show vbModeless
End Sub

Public Sub PickCopyDestination(ByVal source As Outlook.MailItem)
    Dim emptySelection As New Collection
    Set attachmentPicker = New frmPersonalOutlook
    attachmentPicker.PrepareCopyPicker source, emptySelection
    attachmentPicker.Show vbModeless
End Sub

Public Function CopyMailFiles(ByVal source As Outlook.MailItem, ByVal target As Outlook.MailItem) As Long
    Dim folder As String, files As New Collection, entry As Variant, originals As Collection
    Dim number As Long, detail As String
    If source Is target Then Err.Raise 5, , "Choose a different destination email."
    If Len(source.EntryID) Then
        If SameStoredItem(target, source.EntryID, source.Parent.StoreID) Then Err.Raise 5, , "Choose a different destination email."
    End If
    On Error GoTo Failed
    PT_CheckReplySource source
    folder = PT_CreateTempFolder()
    Set originals = PT_SnapshotFileAttachments(source, folder)
    For Each entry In originals: files.Add CStr(entry(2)): Next entry
    If files.Count > 0 Then PT_AddFilesToOne target, files
    CopyMailFiles = files.Count
Finished:
    If Len(folder) Then PT_CleanTemp folder
    If number <> 0 Then Err.Raise number, "Copy attachments", detail
    Exit Function
Failed:
    number = Err.Number: detail = Err.Description
    Resume Finished
End Function


Private Function BatchText(ByVal value As Variant) As String
    If IsError(value) Or IsNull(value) Or IsEmpty(value) Then Exit Function
    BatchText = CStr(value)
End Function

Private Function ScanDescendants(ByVal folder As Outlook.Folder, ByVal options As Object) As Boolean
    Dim ref As Object
    If options Is Nothing Then ScanDescendants = True: Exit Function
    For Each ref In options("locations")
        If ref("store") = folder.StoreID And ref("entry") = folder.EntryID Then
            ScanDescendants = CBool(ref("recursive")): Exit Function
        End If
    Next ref
End Function


Public Function WorkflowID() As String
    Dim bytes(0 To 15) As Byte, n As Long
    If CoCreateGuid(bytes(0)) <> 0 Then Err.Raise 5, , "Windows could not allocate a stable identifier."
    For n = 0 To 15: WorkflowID = WorkflowID & Right$("0" & Hex$(bytes(n)), 2): Next n
End Function

Public Function RuleEventLabel(ByVal code As String) As String
    Select Case code
        Case "open": RuleEventLabel = "On Outlook open"
        Case "close": RuleEventLabel = "On Outlook close"
        Case "receive": RuleEventLabel = "New email arrives"
        Case "run": RuleEventLabel = "RunRules macro"
        Case "manual": RuleEventLabel = "Run from setup"
    End Select
End Function

Public Function CloneFolderRule(ByVal original As Object) As Object
    Dim rule As Object, key As Variant, ref As Object
    Set rule = PT_NewFolderRule(CStr(original("id")))
    For Each key In original.Keys
        Select Case CStr(key)
            Case "sources"
                For Each ref In original(key): rule(key).Add ref: Next ref
            Case "destination": Set rule(key) = original(key)
            Case Else: rule(key) = original(key)
        End Select
    Next key
    Set CloneFolderRule = rule
End Function

Public Function RuleProblem(ByVal rule As Object, Optional ByVal resolve As Boolean = False) As String
    On Error GoTo Invalid
    PT_ValidateFolderRule rule, resolve
    Exit Function
Invalid:
    RuleProblem = Err.Description
End Function

Private Sub RuleOutcome(ByVal rule As Object, ByVal description As String, Optional ByVal fault As Boolean = False)
    If fault Then
        Set cachedArrivalRules = Nothing
        rule("enabled") = False: rule("fault") = description
        rule("seenFault") = WorkflowID() & vbLf & Left$(description, 3000)
        PT_WriteSetting "RuleFault_" & rule("id"), CStr(rule("seenFault"))
    End If
    PT_WriteSetting "RuleHistory_" & rule("id"), Format$(Now, "dd/mm/yyyy hh:nn:ss") & vbCrLf & Left$(description, 5000)
End Sub

Private Function ScheduledFor(ByVal rule As Object, ByVal eventName As String) As Boolean
    If Not rule("enabled") Then Exit Function
    ScheduledFor = (eventName = "selected" Or rule("event") = eventName)
    If eventName = "run" Then ScheduledFor = (rule("event") = "run" Or CBool(rule("alsoRun")))
End Function

Public Function RunOneFolderRule(ByVal rule As Object, ByVal previewOnly As Boolean) As String
    Dim rules As New Collection, failures As String, issue As String
    If automationBusy Or bulkRunning Then RunOneFolderRule = "Another mailbox operation is running.": Exit Function
    On Error GoTo Failed
    automationBusy = True
    ObserveRuleFault rule, PT_ReadSetting("RuleFault_" & rule("id"), "")
    If Not CBool(rule("enabled")) Then
        RunOneFolderRule = "This rule is off. " & CStr(rule("fault")): GoTo Finished
    End If
    rules.Add rule
    issue = RuleProblem(rule, True)
    If Len(issue) Then Err.Raise 5, , issue
    RunOneFolderRule = PT_RunFolderRules(rules, "selected", "", previewOnly, Now, failures) & vbCrLf & failures
Finished:
    automationBusy = False: Exit Function
Failed:
    RunOneFolderRule = Err.Description
    If Not previewOnly Then RuleOutcome rule, RunOneFolderRule, True
    Resume Finished
End Function


' The saved Search Folder supplies the union of possible matches. Its table view
' can then use Outlook's In Folder column, which exists only in search results,
' to apply an independent rolling window to each location without changing mail.
Private Function JoinedWindow(ByVal first As Long, ByVal second As Long) As Long
    If first = 0 Or second = 0 Then Exit Function
    If first > second Then JoinedWindow = first Else JoinedWindow = second
End Function

Private Sub ExpandSearchPath(ByVal folder As Outlook.Folder, ByVal days As Long, ByVal recursive As Boolean, ByVal paths As Object, ByVal depths As Object)
    Dim child As Outlook.Folder, key As String, kind As Long, previous As Long
    kind = PT_FolderKind(folder)
    If kind = 2 Then Exit Sub
    key = PT_SearchScopePath(folder)
    If kind = 1 And folder.DefaultItemType = olMailItem Then
        If paths.Exists(key) Then previous = CLng(paths(key)(1)) Else previous = days
        paths(key) = Array(folder.Name, JoinedWindow(previous, days), folder.EntryID)
    End If
    If Not recursive Then Exit Sub
    ' Only a previously recursive rule covering at least the same date range
    ' can prune this subtree. A direct parent rule must not widen its children.
    If depths.Exists(key) Then
        If JoinedWindow(CLng(depths(key)), days) = CLng(depths(key)) Then Exit Sub
        depths(key) = JoinedWindow(CLng(depths(key)), days)
    Else
        depths.Add key, days
    End If
    For Each child In folder.Folders
        ExpandSearchPath child, days, True, paths, depths
    Next child
End Sub

Private Function LocationsForSearch(ByVal locations As Collection) As Object
    Dim paths As Object, depths As Object, ref As Object, folder As Outlook.Folder, child As Outlook.Folder
    Set paths = PT_V6Dict(): Set depths = PT_V6Dict()
    For Each ref In locations
        Set folder = PT_ResolveFolderReference(ref)
        If PT_FolderKind(folder) = 0 Then
            For Each child In folder.Folders
                ExpandSearchPath child, CLng(ref("days")), CBool(ref("recursive")), paths, depths
            Next child
        Else
            ExpandSearchPath folder, CLng(ref("days")), CBool(ref("recursive")), paths, depths
        End If
    Next ref
    Set LocationsForSearch = paths
End Function

Private Function WindowFilter(ByVal accessor As Outlook.PropertyAccessor, ByVal days As Long, ByVal instant As Date) As String
    If days = 0 Then
        WindowFilter = "(""" & PT_V6_TAG & "0x001A001F"" = 'IPM.Note' OR """ & PT_V6_TAG & "0x001A001F"" LIKE 'IPM.Note.%')"
    ElseIf days < 0 Then
        WindowFilter = PT_SearchFilter(accessor, 0, 0, instant)
    Else
        WindowFilter = PT_SearchFilter(accessor, 3, days, instant)
    End If
End Function

Private Function MakeSearchPlan(ByVal paths As Object, ByRef mixed As Boolean, ByRef widest As Long, ByRef ambiguous As Boolean) As Object
    Dim names As Object, path As Variant, row As Variant, n As Long, first As Long
    Set names = PT_V6Dict(): names.CompareMode = vbTextCompare: widest = -1
    For Each path In paths.Keys
        row = paths(path)
        If n = 0 Then first = CLng(row(1))
        If first <> CLng(row(1)) Then mixed = True
        If names.Exists(CStr(row(0))) Then
            If CLng(names(row(0))) <> CLng(row(1)) Then ambiguous = True
        End If
        names(CStr(row(0))) = CLng(row(1))
        widest = JoinedWindow(widest, CLng(row(1))): n = n + 1
    Next path
    Set MakeSearchPlan = names
End Function

Private Function BuildLocationView(ByVal names As Object, ByVal accessor As Outlook.PropertyAccessor, ByVal instant As Date) As String
    Dim key As Variant, clause As String, sql As String
    For Each key In names.Keys
        clause = "(""" & PT_V6_TAG & "0x0E05001F"" = '" & Replace(CStr(key), "'", "''") & "' AND " & WindowFilter(accessor, CLng(names(key)), instant) & ")"
        If Len(sql) Then sql = sql & " OR "
        sql = sql & clause
    Next key
    BuildLocationView = sql
End Function

Private Function SaveWindowFolder(ByVal store As Outlook.Store, ByVal paths As Object, ByVal title As String, ByRef warnings As String, Optional ByVal nativeScope As String = "") As Outlook.Folder
    Dim names As Object, widest As Long, mixed As Boolean, ambiguous As Boolean
    Dim saved As Outlook.Folder, existing As Outlook.Folder, view As Outlook.View, filter As String
    Dim xml As Object, root As Object, node As Object, key As Variant, row As Variant, stage As String
    On Error GoTo Failed
    Set names = MakeSearchPlan(paths, mixed, widest, ambiguous)
    If ambiguous Then Err.Raise 5, , "Two identically named folders require different windows."
    stage = "Check the Search Folder name"
    For Each existing In store.GetSearchFolders
        If StrComp(existing.Name, title, vbTextCompare) = 0 Then Err.Raise 5, , "That name already exists in this mailbox."
    Next existing
    stage = "Create native Search Folder"
    Dim scope As String, recursive As Boolean
    recursive = (Len(nativeScope) > 0)
    If recursive Then scope = nativeScope Else scope = Join(paths.Keys, ",")
    Set saved = searchFolderEvents.SaveSearch(scope, WindowFilter(store.GetRootFolder.PropertyAccessor, widest, Now), recursive, title)
    If saved.StoreID <> store.StoreID Then Err.Raise 5, , "Outlook returned a folder in a different mailbox."
    stage = "Save location-specific view"
    Set xml = CreateObject("MSXML2.DOMDocument.6.0")
    Set root = xml.createElement("search"): xml.appendChild root
    root.setAttribute "store", store.StoreID: root.setAttribute "wide", CStr(widest)
    root.setAttribute "mixed", IIf(mixed, "1", "0")
    ' Uniform criteria can be refreshed using only the store and day window.
    If mixed Then
        For Each key In paths.Keys
            row = paths(key): Set node = xml.createElement("location")
            node.setAttribute "id", CStr(row(2)): node.setAttribute "days", CStr(row(1))
            root.appendChild node
        Next key
    End If
    If mixed Then filter = BuildLocationView(names, saved.PropertyAccessor, Now) Else filter = WindowFilter(saved.PropertyAccessor, widest, Now)
    Set view = saved.Views.Add(PT_SEARCH_VIEW, olTableView, olViewSaveOptionThisFolderOnlyMe)
    view.Filter = filter: view.Save
    PT_WriteSetting PT_SEARCH_KEY & saved.EntryID, xml.XML
    Set SaveWindowFolder = saved
    Exit Function
Failed:
    warnings = warnings & vbCrLf & title & " - " & stage & ": " & Err.Description
    If Not saved Is Nothing Then
        ' Only remove the just-created virtual folder if its rules could not be installed.
        On Error Resume Next: saved.Delete
        If Err.Number <> 0 Then warnings = warnings & vbCrLf & "The unfinished Search Folder may still be present."
    End If
End Function

Private Sub SaveMailboxWindows(ByVal locations As Collection, ByVal title As String, ByVal created As Collection, ByRef warnings As String)
    Dim paths As Object, names As Object, groups As Object, group As Object, key As Variant, row As Variant
    Dim store As Outlook.Store, folder As Outlook.Folder, widest As Long, mixed As Boolean, ambiguous As Boolean, suffix As String
    On Error GoTo Failed
    Dim recursive As Boolean, nativeScope As String
    Set paths = UniformSearchPaths(locations, recursive)
    If paths Is Nothing Then
        Set paths = LocationsForSearch(locations)
    ElseIf recursive And paths.Count > 0 Then
        nativeScope = Join(paths.Keys, ",")
    End If
    If paths.Count = 0 Then Err.Raise 5, , "No physical mail folders in this selection."
    Set store = PT_ResolveFolderReference(locations(1)).Store
    Set names = MakeSearchPlan(paths, mixed, widest, ambiguous)
    If Not ambiguous Then
        Set folder = SaveWindowFolder(store, paths, title, warnings, nativeScope)
        If Not folder Is Nothing Then created.Add folder
        Exit Sub
    End If
    ' The native search-results column contains a display name, not a full path.
    ' Separate windows rather than silently mixing two unrelated "Projects" folders.
    Set groups = PT_V6Dict()
    For Each key In paths.Keys
        row = paths(key)
        If Not groups.Exists(CStr(row(1))) Then
            Set group = PT_V6Dict(): groups.Add CStr(row(1)), group
        End If
        Set group = groups(CStr(row(1))): group(key) = row
    Next key
    warnings = warnings & vbCrLf & "Same-named folders with different windows were split by criteria in " & store.DisplayName & "."
    For Each key In groups.Keys
        suffix = IIf(CLng(key) = 0, "all mail", IIf(CLng(key) < 0, "unread", key & " days or unread"))
        Set folder = SaveWindowFolder(store, groups(key), Left$(title, 170) & " (" & suffix & ")", warnings)
        If Not folder Is Nothing Then created.Add folder
    Next key
    Exit Sub
Failed:
    warnings = warnings & vbCrLf & title & " - " & Err.Description
End Sub

Private Function SavedLocationFilter(ByVal folder As Outlook.Folder, ByVal xmlText As String) As String
    Dim xml As Object, root As Object, node As Object, names As Object, physical As Outlook.Folder
    Dim name As String, days As Long
    Set xml = CreateObject("MSXML2.DOMDocument.6.0")
    If Not xml.LoadXML(xmlText) Then Err.Raise 5, , "Could not read the saved Search Folder rules."
    Set root = xml.documentElement
    If root.getAttribute("store") <> folder.StoreID Then Err.Raise 5, , "This view belongs to another mailbox."
    If root.getAttribute("mixed") = "0" Then SavedLocationFilter = WindowFilter(folder.PropertyAccessor, CLng(root.getAttribute("wide")), Now): Exit Function
    Set names = PT_V6Dict(): names.CompareMode = vbTextCompare
    For Each node In root.childNodes
        Set physical = Nothing
        On Error Resume Next
        Set physical = MailApp().Session.GetFolderFromID(CStr(node.getAttribute("id")), folder.StoreID)
        On Error GoTo 0
        If Not physical Is Nothing Then
            name = physical.Name: days = CLng(node.getAttribute("days"))
            If names.Exists(name) Then
                If CLng(names(name)) <> days Then Err.Raise 5, , "Two folders now have the same name and different windows. Recreate the Search Folder to split their rules."
            End If
            names(name) = days
        End If
    Next node
    If names.Count = 0 Then Err.Raise 5, , "No saved source folder is accessible."
    SavedLocationFilter = BuildLocationView(names, folder.PropertyAccessor, Now)
End Function


Private Function UniformSearchPaths(ByVal locations As Collection, ByRef recursive As Boolean) As Object
    Dim paths As Object, ref As Object, folder As Outlook.Folder, child As Outlook.Folder, days As Long
    Set ref = locations(1): days = CLng(ref("days")): recursive = CBool(ref("recursive"))
    For Each ref In locations
        If CLng(ref("days")) <> days Or CBool(ref("recursive")) <> recursive Then Exit Function
    Next ref
    Set paths = PT_V6Dict()
    For Each ref In locations
        Set folder = PT_ResolveFolderReference(ref)
        If PT_FolderKind(folder) = 0 Then
            For Each child In folder.Folders
                If PT_FolderKind(child) = 1 Then
                    If recursive Or child.DefaultItemType = olMailItem Then paths(PT_SearchScopePath(child)) = Array(child.Name, days, child.EntryID)
                End If
            Next child
        Else
            paths(PT_SearchScopePath(folder)) = Array(folder.Name, days, folder.EntryID)
        End If
    Next ref
    Set UniformSearchPaths = paths
End Function


Public Sub ReleaseAttachmentPicker(ByVal panel As frmPersonalOutlook)
    If attachmentPicker Is panel Then Set attachmentPicker = Nothing
End Sub


Private Function ClaimReplyFile(ByVal byName As Object, ByVal fileName As String, ByVal used As Object, ByVal paths As Object, ByVal original As Variant, ByVal draft As Outlook.MailItem, ByVal folder As String) As Boolean
    Dim bucket As Collection, candidateIndex As Variant, key As String, path As String
    If Not byName.Exists(fileName) Then Exit Function
    Set bucket = byName(fileName)
    For Each candidateIndex In bucket
        key = CStr(candidateIndex)
        If Not used.Exists(key) Then
            If Not paths.Exists(key) Then
                path = folder & "\candidate-" & key & ".bin"
                draft.Attachments(CLng(candidateIndex)).SaveAsFile path
                paths.Add key, path
            End If
            If PT_AttachmentFilesEqual(CStr(original(2)), CStr(paths(key)), CBool(original(3))) Then
                used.Add key, True
                ClaimReplyFile = True
                Exit Function
            End If
        End If
    Next candidateIndex
End Function


Private Sub ObserveRuleFault(ByVal rule As Object, ByVal recorded As String)
    Dim separator As Long, detail As String
    If recorded = CStr(rule("seenFault")) Then Exit Sub
    rule("seenFault") = recorded
    If Len(recorded) = 0 Then Exit Sub
    ' The first release saved just the description. New faults have a generation
    ' so a second failure with the same wording also takes precedence over stale edits.
    detail = recorded: separator = InStr(recorded, vbLf)
    If separator = 33 Then
        If Not Left$(recorded, 32) Like "*[!0-9A-Fa-f]*" Then detail = Mid$(recorded, separator + 1)
    End If
    rule("fault") = detail: rule("enabled") = False
End Sub


Private Function ArrivalRuleSnapshot() As Collection
    Dim slot As String, version As String, rule As Object, allRules As Collection, active As New Collection
    slot = PT_ReadSetting("ActiveRuleSlot", "")
    version = slot
    If slot = "0" Or slot = "1" Then version = slot & "|" & GetSetting(PT_SETTINGS_APP, PT_RulesSection(slot), "Generation", "")
    If Not cachedArrivalRules Is Nothing Then
        If cachedArrivalGeneration = version Then Set ArrivalRuleSnapshot = cachedArrivalRules: Exit Function
    End If
    Set allRules = PT_LoadFolderRules()
    For Each rule In allRules
        If rule("event") = "receive" And CBool(rule("enabled")) Then active.Add rule
    Next rule
    Set cachedArrivalRules = active: cachedArrivalGeneration = version
    Set ArrivalRuleSnapshot = active
End Function


Public Function TableBatchLastRow(ByRef records As Variant) As Long
    ' GetArray can return an empty array if the final row moves or disappears.
    ' Its second dimension indexes rows. Handle the unallocated dimension locally.
    On Error GoTo EmptyBatch
    TableBatchLastRow = UBound(records, 2)
    Exit Function
EmptyBatch:
    TableBatchLastRow = -1
End Function
