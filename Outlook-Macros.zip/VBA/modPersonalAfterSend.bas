Attribute VB_Name = "modPersonalAfterSend"
Option Explicit
Option Private Module

' Only a random ticket is placed on the draft. Original message IDs, the task,
' and filing decisions belong to this Outlook profile and never enter its body.
Private Const TICKET As String = "http://schemas.microsoft.com/mapi/string/{8C5D3443-2CB1-46D6-8E43-60B5D2756E05}/ResponseTicket"
Private Const LEDGER As String = "ReplyFollowUpWorkV1"
Private book As Object, listeners As Object
Private knownEmpty As Boolean
Private wakeAt As Double, presenting As Boolean, preparing As Outlook.MailItem

Private Function CurrentTick() As Double
    CurrentTick = Fix((CDbl(Now) - CDbl(#1/1/2000#)) * 86400# + 0.5)
End Function

Private Function FieldText(ByVal node As Object, ByVal key As String) As String
    Dim field As Object
    Set field = node.getAttributeNode(key)
    If Not field Is Nothing Then FieldText = CStr(field.Value)
End Function

Private Sub LoadBook()
    Dim xml As Object, raw As String
    If Not book Is Nothing Then Exit Sub
    Set xml = CreateObject("MSXML2.DOMDocument.6.0"): xml.async = False
    raw = PT_ReadSetting(LEDGER, "<responses/>")
    If Len(raw) = 0 Then raw = "<responses/>"
    If Not xml.LoadXML(raw) Then Err.Raise 5, , "The saved Reply & Follow Up list could not be read."
    If xml.documentElement.nodeName <> "responses" Then Err.Raise 5, , "The saved Reply & Follow Up list has an unexpected format."
    Set listeners = CreateObject("Scripting.Dictionary"): Set book = xml
End Sub

Private Function FindJob(ByVal id As String) As Object
    If Len(id) <> 32 Then Exit Function
    If id Like "*[!0-9A-F]*" Then Exit Function
    Set FindJob = book.documentElement.selectSingleNode("job[@id='" & id & "']")
End Function

Private Function TicketOn(ByVal mail As Outlook.MailItem) As String
    On Error Resume Next
    TicketOn = UCase$(CStr(mail.PropertyAccessor.GetProperty(TICKET)))
End Function

Private Sub PersistBook()
    If book.documentElement.childNodes.length = 0 Then
        PT_WriteSetting LEDGER, "": knownEmpty = True
    Else
        PT_WriteSetting LEDGER, book.XML: knownEmpty = False
    End If
End Sub

Private Function TracksSentFolder(ByVal state As String) As Boolean
    TracksSentFolder = (state = "waiting" Or state = "listening")
End Function

Private Sub RecalculateWake()
    Dim job As Object, due As Double
    wakeAt = 0
    For Each job In book.documentElement.childNodes
        Select Case FieldText(job, "stage")
            Case "waiting", "ready", "filing", "listening"
                If FieldText(job, "stage") = "listening" And Val(FieldText(job, "due")) = 0 Then GoTo NextJob
                due = Val(FieldText(job, "due"))
                If due < 1 Then due = 1
                If wakeAt = 0 Or due < wakeAt Then wakeAt = due
        End Select
NextJob:
    Next job
End Sub

Private Sub PruneListeners()
    Dim wanted As Object, job As Object, scope As Object, key As Variant
    Set wanted = CreateObject("Scripting.Dictionary")
    For Each job In book.documentElement.childNodes
        If TracksSentFolder(FieldText(job, "stage")) Then
            For Each scope In job.selectNodes("folder")
                wanted(FieldText(scope, "store") & "|" & FieldText(scope, "entry")) = True
            Next scope
        End If
    Next job
    For Each key In listeners.Keys
        If Not wanted.Exists(key) Then listeners.Remove key
    Next key
End Sub

Private Sub CommitStage(ByVal job As Object, ByVal stage As String)
    job.setAttribute "stage", stage: job.setAttribute "due", "1"
    PersistBook
    RecalculateWake
End Sub

Private Sub ForgetJob(ByVal job As Object)
    book.documentElement.removeChild job
    PersistBook
    RecalculateWake
    PruneListeners
End Sub

Public Function ResponseDue() As Boolean
    If Not presenting And wakeAt > 0 Then ResponseDue = (wakeAt <= CurrentTick())
End Function

Public Function ResponseDelay() As Long
    Dim seconds As Double
    If wakeAt = 0 Or presenting Then Exit Function
    seconds = wakeAt - CurrentTick()
    If seconds < 1 Then seconds = 1
    If seconds > 600 Then seconds = 600
    ResponseDelay = CLng(seconds * 1000)
End Function

Public Sub RestoreResponses(Optional ByVal unused As Boolean = False)
    Dim job As Object, state As String
    If book Is Nothing Then
        If Len(PT_ReadSetting(LEDGER, "")) = 0 Then knownEmpty = True: Exit Sub
    End If
    LoadBook
    ' Reattach only folders belonging to a send that was actually attempted.
    ' Closed unsent drafts remain dormant until Outlook raises ItemSend for them.
    For Each job In book.documentElement.childNodes
        state = FieldText(job, "stage")
        If TracksSentFolder(state) Then ResetProbe job
    Next job
    RecalculateWake
End Sub

Private Sub ResetProbe(ByVal job As Object)
    job.setAttribute "stage", "waiting": job.setAttribute "due", "1"
    job.setAttribute "cursor", "0": job.setAttribute "round", "0"
End Sub

Public Sub CloseResponseSession(Optional ByVal unused As Boolean = False)
    knownEmpty = False: wakeAt = 0: Set listeners = Nothing: Set book = Nothing: Set preparing = Nothing
End Sub

Public Sub HoldResponseDraft(ByVal mail As Outlook.MailItem)
    Set preparing = mail
End Sub

Public Sub RegisterResponseDraft(ByVal mail As Outlook.MailItem, ByVal source As Outlook.MailItem, ByVal action As Long)
    Dim id As String, job As Object
    LoadBook
    id = WorkflowID(): Set job = book.createElement("job")
    job.setAttribute "id", id: job.setAttribute "stage", "draft"
    job.setAttribute "created", Format$(Now, "dd/mm/yyyy hh:nn")
    job.setAttribute "title", Left$(mail.Subject, 180): job.setAttribute "action", CStr(action)
    If action <> 4 Then
        job.setAttribute "sourceInternet", InternetID(source)
        job.setAttribute "source", source.EntryID: job.setAttribute "sourceStore", source.Parent.StoreID
    End If
    ' A new message tracks only its own draft and sent copy.
    On Error Resume Next
    mail.PropertyAccessor.SetProperty TICKET, id
    On Error GoTo 0
    mail.DeleteAfterSubmit = False: mail.Save
    job.setAttribute "draft", mail.EntryID: job.setAttribute "draftStore", mail.Parent.StoreID
    book.documentElement.appendChild job
    On Error GoTo Unstored
    PersistBook
    Exit Sub
Unstored:
    Dim detail As String
    detail = Err.Description
    On Error Resume Next
    book.documentElement.removeChild job
    On Error GoTo 0
    Err.Raise 5, "Register response", detail
End Sub

Private Sub AddFolder(ByVal job As Object, ByVal folder As Outlook.Folder)
    Dim scope As Object, entry As String, store As String
    If folder Is Nothing Then Exit Sub
    entry = folder.EntryID: store = folder.StoreID
    For Each scope In job.selectNodes("folder")
        If FieldText(scope, "entry") = entry And FieldText(scope, "store") = store Then Exit Sub
    Next scope
    Set scope = book.createElement("folder")
    scope.setAttribute "entry", entry: scope.setAttribute "store", store: job.appendChild scope
End Sub

Private Function InternetID(ByVal mail As Outlook.MailItem) As String
    On Error Resume Next
    InternetID = CStr(mail.PropertyAccessor.GetProperty("http://schemas.microsoft.com/mapi/proptag/0x1035001F"))
    If Len(InternetID) = 0 Then InternetID = CStr(mail.PropertyAccessor.GetProperty("http://schemas.microsoft.com/mapi/proptag/0x1035001E"))
End Function

Private Sub QueueStore(ByVal job As Object, ByVal storeID As String, Optional ByVal delegate As Boolean = False)
    Dim scope As Object
    If Len(storeID) = 0 Then Exit Sub
    For Each scope In job.selectNodes("place")
        If FieldText(scope, "name") = storeID And FieldText(scope, "shared") = CStr(Abs(CLng(delegate))) Then Exit Sub
    Next scope
    Set scope = book.createElement("place"): scope.setAttribute "name", storeID
    scope.setAttribute "shared", CStr(Abs(CLng(delegate))): job.appendChild scope
End Sub

Private Sub CaptureSentFolders(ByVal job As Object, ByVal mail As Outlook.MailItem)
    Dim account As Outlook.Account, old As Object, location As Outlook.Folder
    Dim oldLocations As Object, n As Long
    Set oldLocations = job.selectNodes("folder|place")
    For n = oldLocations.length - 1 To 0 Step -1
        Set old = oldLocations.Item(n): job.removeChild old
    Next n
    ' Snapshot the final account/overrides at Send. The timer resolves each
    ' store or delegate separately, without an address-book lookup inside Send.
    On Error Resume Next
    Set location = mail.SaveSentMessageFolder: AddFolder job, location
    Set account = mail.SendUsingAccount
    If Not account Is Nothing Then QueueStore job, account.DeliveryStore.StoreID
    QueueStore job, mail.Parent.StoreID
    QueueStore job, FieldText(job, "sourceStore")
    QueueStore job, Application.Session.DefaultStore.StoreID
    QueueStore job, mail.SentOnBehalfOfName, True
End Sub

Private Sub ResolvePlace(ByVal job As Object, ByVal place As Object)
    Dim store As Outlook.Store, delegate As Outlook.Recipient, inbox As Outlook.Folder
    If FieldText(place, "shared") = "1" Then
        Set delegate = Application.Session.CreateRecipient(FieldText(place, "name"))
        If Not delegate.Resolve Then Exit Sub
        ' GetSharedDefaultFolder supports Inbox. Resolve Sent Items via its Store.
        Set inbox = Application.Session.GetSharedDefaultFolder(delegate, olFolderInbox)
        Set store = inbox.Store
    Else
        Set store = Application.Session.GetStoreFromID(FieldText(place, "name"))
    End If
    AddFolder job, store.GetDefaultFolder(olFolderSentMail)
    place.setAttribute "resolved", "1"
End Sub

Public Function SentCopyIdentity(ByVal marker As String, ByVal sentID As String, ByVal expectedMarker As String, ByVal expectedID As String) As Boolean
    If Len(marker) Then
        SentCopyIdentity = (StrComp(marker, expectedMarker, vbBinaryCompare) = 0)
    ElseIf Len(sentID) And Len(expectedID) Then
        SentCopyIdentity = (StrComp(sentID, expectedID, vbBinaryCompare) = 0)
    End If
End Function

Private Function InternetMatch(ByVal mail As Outlook.MailItem) As Object
    Dim internet As String, job As Object, candidate As Object
    internet = InternetID(mail): If Len(internet) = 0 Then Exit Function
    For Each job In book.documentElement.childNodes
        If TracksSentFolder(FieldText(job, "stage")) Then
            If SentCopyIdentity("", internet, FieldText(job, "id"), FieldText(job, "internet")) Then
                If Not candidate Is Nothing Then Exit Function
                Set candidate = job
            End If
        End If
    Next job
    Set InternetMatch = candidate
End Function

Public Sub ResponseSubmitting(ByVal item As Object, ByRef cancelSend As Boolean)
    Dim mail As Outlook.MailItem, job As Object, id As String, problem As String, before As Object, originalJob As Object, registered As Boolean
    On Error GoTo Failed
    If cancelSend Or Not TypeOf item Is Outlook.MailItem Then Exit Sub
    Set mail = item
    If Not preparing Is Nothing Then
        If mail Is preparing Then cancelSend = True: Exit Sub
        If Len(mail.EntryID) > 0 Then
            If mail.EntryID = preparing.EntryID And mail.Parent.StoreID = preparing.Parent.StoreID Then cancelSend = True: Exit Sub
        End If
    End If
    If knownEmpty Then Exit Sub
    id = TicketOn(mail)
    LoadBook
    If Len(id) Then
        Set job = FindJob(id)
    Else
        ' Some stores strip a named property when a saved draft synchronises.
        ' The original draft and store IDs are still an exact local identity.
        Set job = JobForDraft(mail)
        If Not job Is Nothing Then
            id = FieldText(job, "id")
            On Error Resume Next
            mail.PropertyAccessor.SetProperty TICKET, id
            On Error GoTo Failed
        End If
    End If
    If job Is Nothing Then Exit Sub
    If Not (FieldText(job, "stage") = "draft" Or TracksSentFolder(FieldText(job, "stage"))) Then Exit Sub
    Set originalJob = job: Set before = job.cloneNode(True)
    If mail.EntryID <> FieldText(job, "draft") Or mail.Parent.StoreID <> FieldText(job, "draftStore") Then
        ' Copies may inherit a tracking tag. Never let a different draft take
        ' over a pending workflow merely because it contains the same property.
        Dim answer As Long, fork As Object
        answer = MsgBox("This draft was copied or moved after it was prepared. Yes tracks this draft separately. No sends it as ordinary mail. Cancel keeps it open.", vbQuestion + vbYesNoCancel + vbDefaultButton3, "Confirm draft identity")
        If answer = vbCancel Then cancelSend = True: Exit Sub
        If answer = vbNo Then mail.PropertyAccessor.DeleteProperty TICKET: mail.Save: Exit Sub
        Set fork = book.createElement("job")
        Dim key As Variant
        For Each key In Array("source", "sourceStore", "sourceInternet", "action")
            fork.setAttribute CStr(key), FieldText(job, CStr(key))
        Next key
        id = WorkflowID(): fork.setAttribute "id", id: fork.setAttribute "created", Format$(Now, "dd/mm/yyyy hh:nn")
        Set job = fork: book.documentElement.appendChild job
        mail.PropertyAccessor.SetProperty TICKET, id: mail.Save
    End If
    Dim internet As String
    internet = InternetID(mail)
    If internet = FieldText(job, "sourceInternet") Then internet = ""
    job.setAttribute "internet", internet: job.setAttribute "startTick", Format$(CurrentTick(), "0")
    If mail.DeleteAfterSubmit Then mail.DeleteAfterSubmit = False
    CaptureSentFolders job, mail
    job.setAttribute "draft", mail.EntryID: job.setAttribute "draftStore", mail.Parent.StoreID
    job.setAttribute "title", Left$(mail.Subject, 180): job.setAttribute "sentTry", Format$(Now, "dd/mm/yyyy hh:nn")
    Dim deadline As Date
    On Error Resume Next
    deadline = mail.DeferredDeliveryTime
    On Error GoTo Failed
    Dim endTick As Double
    endTick = CurrentTick() + 86400#
    If Year(deadline) >= 2000 And Year(deadline) < 4000 Then
        If deadline > Now Then endTick = Fix((CDbl(deadline) - CDbl(#1/1/2000#)) * 86400#) + 86400#
    End If
    job.setAttribute "retryUntil", Format$(endTick, "0")
    ResetProbe job
    PersistBook
    registered = True
    RecalculateWake
    RequestOutlookWork 150
    Exit Sub
Failed:
    problem = Err.Description
    If Len(id) Then
        cancelSend = True
        If Not registered And Not before Is Nothing Then
            On Error Resume Next
            If Not job Is originalJob Then
                book.documentElement.removeChild job
                mail.PropertyAccessor.SetProperty TICKET, FieldText(originalJob, "id"): mail.Save
            Else
                book.documentElement.replaceChild before, originalJob
            End If
            RecalculateWake
            On Error GoTo 0
        End If
        MsgBox "Outlook kept the draft because its follow-up could not be registered. " & problem, vbInformation, "Reply & Follow Up"
    End If
End Sub

Private Function StoredResponse(ByVal entry As String, ByVal store As String) As Outlook.MailItem
    Dim item As Object
    If Len(entry) = 0 Or Len(store) = 0 Then Exit Function
    On Error Resume Next
    Set item = Application.Session.GetItemFromID(entry, store)
    If TypeOf item Is Outlook.MailItem Then Set StoredResponse = item
End Function

Private Function InSentScope(ByVal job As Object, ByVal folder As Outlook.Folder) As Boolean
    Dim scope As Object
    For Each scope In job.selectNodes("folder")
        If FieldText(scope, "entry") = folder.EntryID And FieldText(scope, "store") = folder.StoreID Then InSentScope = True: Exit Function
    Next scope
End Function

Private Sub RecordSent(ByVal job As Object, ByVal mail As Outlook.MailItem)
    job.setAttribute "sent", mail.EntryID: job.setAttribute "sentStore", mail.Parent.StoreID
    job.setAttribute "title", Left$(mail.Subject, 180)
    CommitStage job, "ready"
    RequestOutlookWork 150
End Sub

Public Sub ObserveResponseCopy(ByVal item As Object)
    Dim job As Object, id As String, mail As Outlook.MailItem
    On Error GoTo Failed
    If book Is Nothing Or Not TypeOf item Is Outlook.MailItem Then Exit Sub
    Set mail = item: If Not mail.Sent Or Len(mail.EntryID) = 0 Then Exit Sub
    id = TicketOn(mail)
    If Len(id) Then Set job = FindJob(id) Else Set job = InternetMatch(mail)
    If job Is Nothing Then Exit Sub
    If Not TracksSentFolder(FieldText(job, "stage")) Then Exit Sub
    If mail.EntryID = FieldText(job, "source") And mail.Parent.StoreID = FieldText(job, "sourceStore") Then Exit Sub
    If InSentScope(job, mail.Parent) Then RecordSent job, mail
    Exit Sub
Failed:
    PT_AlertLog "Could not confirm a sent follow-up copy. The pending check will retry. " & Err.Description
End Sub

Private Sub ProbeOneFolder(ByVal job As Object, ByVal scope As Object)
    Dim folder As Outlook.Folder, table As Outlook.Table, row As Outlook.Row, item As Outlook.MailItem
    Dim key As String, watcher As clsPersonalFolderWatcher, filter As String, entry As String, store As String
    entry = FieldText(scope, "entry"): store = FieldText(scope, "store"): key = store & "|" & entry
    Set folder = Application.Session.GetFolderFromID(entry, store)
    If Not listeners.Exists(key) Then
        Set watcher = New clsPersonalFolderWatcher: watcher.WatchSentCopies folder
        listeners.Add key, watcher
    End If
    ' Bulk delivery and a very fast send can precede ItemAdd. Query the exact
    ' ticket in this one folder. No subject matching or mailbox-wide traversal.
    filter = Chr$(34) & TICKET & Chr$(34) & " = '" & FieldText(job, "id") & "'"
    Dim internet As String
    internet = FieldText(job, "internet")
    If Len(internet) Then filter = filter & " OR " & Chr$(34) & "urn:schemas:mailheader:message-id" & Chr$(34) & " = '" & Replace(internet, "'", "''") & "'"
    On Error Resume Next
    Set table = folder.GetTable(ScopedSentQuery(folder, job, filter), olUserItems)
    On Error GoTo 0
    If table Is Nothing And Len(internet) Then
        filter = Chr$(34) & "urn:schemas:mailheader:message-id" & Chr$(34) & " = '" & Replace(internet, "'", "''") & "'"
        Set table = folder.GetTable(ScopedSentQuery(folder, job, filter), olUserItems)
    End If
    If table Is Nothing Then Exit Sub
    If table.EndOfTable Then Exit Sub
    Set row = table.GetNextRow
    Set item = StoredResponse(CStr(row("EntryID")), store)
    If Not item Is Nothing Then ObserveResponseCopy item
End Sub

Private Sub ProbeResponse(ByVal job As Object)
    Dim scopes As Object, i As Long, pass As Long, number As Long, scope As Object, key As String
    Dim place As Object
    Set scopes = job.selectNodes("folder"): i = CLng(Val(FieldText(job, "cursor")))
    If i < scopes.length Then
        Set scope = scopes.Item(i): job.setAttribute "cursor", CStr(i + 1)
        On Error Resume Next
        Err.Clear: ProbeOneFolder job, scope: number = Err.Number
        On Error GoTo 0
        If number = &H80010007 Or number = &H80010108 Or number = &H80040115 Then
            key = FieldText(scope, "store") & "|" & FieldText(scope, "entry")
            If listeners.Exists(key) Then listeners.Remove key
        End If
        Exit Sub
    End If
    For Each place In job.selectNodes("place")
        If FieldText(place, "resolved") <> "1" And FieldText(place, "pass") <> FieldText(job, "round") Then
            place.setAttribute "pass", FieldText(job, "round")
            On Error Resume Next
            ResolvePlace job, place
            On Error GoTo 0
            Exit Sub
        End If
    Next place
    pass = CLng(Val(FieldText(job, "round"))) + 1
    job.setAttribute "cursor", "0": job.setAttribute "round", CStr(pass)
    If pass >= 5 Then
        ' Waiting offline or a cancelled Send must never open a reminder.
        ' Keep ItemAdd and use sparse exact checks until a day after the expected send.
        job.setAttribute "stage", "listening"
        If CurrentTick() < Val(FieldText(job, "retryUntil")) Then
            job.setAttribute "due", Format$(CurrentTick() + 600, "0")
        Else
            job.setAttribute "due", "0"
        End If
        PersistBook
    Else
        job.setAttribute "due", Format$(CurrentTick() + Choose(pass, 3, 12, 45, 120), "0")
    End If
End Sub

Public Function ResponseWork() As String
    Dim job As Object, state As String, nowTick As Double
    On Error GoTo Failed
    If presenting Or book Is Nothing Then Exit Function
    nowTick = CurrentTick()
    For Each job In book.documentElement.childNodes
        state = FieldText(job, "stage")
        If Val(FieldText(job, "due")) <= nowTick Then
            Select Case state
                Case "listening"
                    If Val(FieldText(job, "due")) > 0 Then
                        job.setAttribute "stage", "waiting": job.setAttribute "cursor", "0"
                        job.setAttribute "round", CStr(CLng(Val(FieldText(job, "round"))) + 1)
                        ResponseWork = "Find saved sent copy": Exit For
                    End If
                Case "waiting"
                    ResponseWork = "Find saved sent copy": ProbeResponse job: Exit For
                Case "ready", "filing"
                    If ResponseWindowReady() Then
                        ResponseWork = "Choose sent follow-up"
                        PresentResponse job
                    Else
                        job.setAttribute "due", Format$(nowTick + 3, "0")
                    End If
                    Exit For
            End Select
        End If
    Next job
    RecalculateWake
    PruneListeners
    Exit Function
Failed:
    Dim detail As String
    detail = Err.Description: On Error Resume Next
    If Not job Is Nothing Then job.setAttribute "due", Format$(CurrentTick() + 45, "0")
    RecalculateWake
    PT_AlertLog "Reply & Follow Up is pending. " & detail
End Function

Public Function RemoveResponseTag(ByVal mail As Outlook.MailItem) As Boolean
    If Len(TicketOn(mail)) = 0 Then Exit Function
    mail.PropertyAccessor.DeleteProperty TICKET: RemoveResponseTag = True
End Function


Public Function ResponseJobs() As Collection
    Dim rows As New Collection, job As Object, state As String, label As String
    LoadBook
    For Each job In book.documentElement.childNodes
        state = FieldText(job, "stage")
        Select Case state
            Case "draft": label = "Draft"
            Case "waiting", "listening": label = "Waiting for sent copy"
            Case "filing": label = "Ready to file"
            Case "applying": label = "Check earlier filing"
            Case "saving": label = "Check earlier task"
            Case "missing": label = "Choose sent copy"
            Case Else: label = "Ready for reminder"
        End Select
        rows.Add Array(FieldText(job, "id"), FieldText(job, "title"), FieldText(job, "created"), label)
    Next job
    Set ResponseJobs = rows
End Function

Private Function OpenSent(ByVal job As Object) As Outlook.MailItem
    Dim mail As Outlook.MailItem
    Set mail = StoredResponse(FieldText(job, "sent"), FieldText(job, "sentStore"))
    If mail Is Nothing Then Exit Function
    Dim marker As String
    marker = TicketOn(mail)
    If Len(marker) Then
        If marker <> FieldText(job, "id") Then Exit Function
    End If
    If mail.Sent And ResponseMailAvailable(mail) Then Set OpenSent = mail
End Function

Private Function OpenSource(ByVal job As Object) As Outlook.MailItem
    Dim mail As Outlook.MailItem
    Set mail = StoredResponse(FieldText(job, "source"), FieldText(job, "sourceStore"))
    If mail Is Nothing Then Exit Function
    If mail.Sent And ResponseMailAvailable(mail) Then Set OpenSource = mail
End Function

Public Sub ManageResponses(ByVal selected As Outlook.MailItem)
    Dim panel As frmPersonalOutlook, job As Object, choice As Long, rows As Collection, state As String
    Dim mail As Outlook.MailItem, token As String, stage As String, confirmation As String
    On Error GoTo Failed
    Set rows = ResponseJobs(): If rows.Count = 0 Then Exit Sub
    Set panel = New frmPersonalOutlook: panel.PrepareResponseList rows: panel.Show vbModal
    choice = panel.Result
    If choice > 0 Then Set job = FindJob(panel.ResponseID)
    Unload panel: If job Is Nothing Then Exit Sub
    If choice = 2 Then
        If MsgBox("Stop tracking this workflow and keep its emails and any saved task?", vbQuestion + vbYesNo + vbDefaultButton2, "Reply & Follow Up") = vbYes Then ForgetJob job
        Exit Sub
    End If
    state = FieldText(job, "stage")
    If state = "saving" Then
        ' A crash can separate a successful Outlook save from our registry
        ' checkpoint. Search the task's receipt before offering another save.
        If RecoverResponseTask(job) Then state = "filing"
        If state = "saving" Then
            If MsgBox("Outlook closed during the earlier task save. Check Tasks first. Continue to the reminder screen and select an existing task if it was saved?", vbQuestion + vbYesNo + vbDefaultButton2, "Check earlier task") <> vbYes Then Exit Sub
            CommitStage job, "ready": state = "ready"
        End If
    ElseIf state = "applying" Then
        If MsgBox("Filing was interrupted. Check the listed messages first. Continue to filing to finish the remaining choices?", vbQuestion + vbYesNo + vbDefaultButton2, "Check earlier filing") <> vbYes Then Exit Sub
        CommitStage job, "filing": state = "filing"
    End If
    Set mail = OpenSent(job)
    If mail Is Nothing Then
        If selected Is Nothing Then GoTo NeedCopy
        If Not selected.Sent Or Not ResponseMailAvailable(selected) Then GoTo NeedCopy
        token = TicketOn(selected)
        If Len(token) > 0 And token <> FieldText(job, "id") Then GoTo NeedCopy
        If selected.EntryID = FieldText(job, "source") And selected.Parent.StoreID = FieldText(job, "sourceStore") Then GoTo NeedCopy
        If state = "draft" Then
            ' No send event was recorded. Require both the original ticket and
            ' a Sent Items location before an explicit recovery is allowed.
            Dim defaultSent As Outlook.Folder
            Set defaultSent = selected.Parent.Store.GetDefaultFolder(olFolderSentMail)
            If token <> FieldText(job, "id") Or selected.Parent.EntryID <> defaultSent.EntryID Then GoTo NeedCopy
        ElseIf Len(token) = 0 Then
            If Not InSentScope(job, selected.Parent) Then
                If Not SentCopyIdentity("", InternetID(selected), FieldText(job, "id"), FieldText(job, "internet")) Then GoTo NeedCopy
            End If
        End If
        confirmation = "Use this sent email for the pending workflow?" & vbCrLf & selected.Subject & vbCrLf & selected.Parent.FolderPath & vbCrLf & "Sent " & Format$(selected.SentOn, "dd/mm/yyyy hh:nn") & vbCrLf & "Workflow: " & FieldText(job, "title")
        If MsgBox(confirmation, vbQuestion + vbYesNo + vbDefaultButton2, "Confirm sent copy") <> vbYes Then Exit Sub
        job.setAttribute "sent", selected.EntryID: job.setAttribute "sentStore", selected.Parent.StoreID
    End If
    stage = "ready"
    If state = "filing" Or FieldText(job, "afterReminder") = "1" Then stage = "filing"
    CommitStage job, stage
    PresentResponse job
    Exit Sub
NeedCopy:
    MsgBox "Select the actual sent email in its Sent Items or configured sent-copy folder, then open Pending follow-ups again. A draft that is still in the Outbox will continue when Outlook sends it.", vbInformation, "Reply & Follow Up"
    Exit Sub
Failed:
    MsgBox Err.Description, vbInformation, "Reply & Follow Up"
End Sub

Private Sub PresentResponse(ByVal job As Object)
    Dim mail As Outlook.MailItem, source As Outlook.MailItem, targets As New Collection
    Dim panel As frmPersonalOutlook, taskFolder As Outlook.Folder, id As String, explain As String, detail As String
    Dim stage As String, savedID As String, savedStore As String, problem As String, critical As Boolean
    If presenting Then Exit Sub
    presenting = True
    On Error GoTo Failed
    DeferNotificationCards
    id = FieldText(job, "id"): stage = FieldText(job, "stage")
    Set mail = OpenSent(job)
    If mail Is Nothing Then
        CommitStage job, "missing"
        MsgBox "The sent copy has moved or its mailbox is unavailable. Select that sent email and choose Pending follow-ups in Reply & Follow Up.", vbInformation, "Reply & Follow Up"
        GoTo Finished
    End If
    Set source = OpenSource(job): targets.Add mail
    If Not source Is Nothing Then targets.Add source
    If source Is Nothing And Len(FieldText(job, "source")) Then explain = "The original email is unavailable. Only the sent copy is included."
    If stage = "ready" Then
        Set taskFolder = Application.Session.GetDefaultFolder(olFolderTasks)
        Set panel = New frmPersonalOutlook
        panel.PrepareSentReminder targets.Count, OpenTaskChoices(taskFolder), mail.Subject, explain
        panel.Show vbModal
        If panel.Result = 1 Then
            job.setAttribute "targetTask", panel.ExistingTaskID: job.setAttribute "targetStore", taskFolder.StoreID
            CommitStage job, "saving": critical = True
            SaveLinkedFollowUp targets, panel, savedID, savedStore, id
            If Len(savedID) = 0 Then
                If Not RecoverResponseTask(job) Then GoTo Finished
            Else
                job.setAttribute "task", savedID: job.setAttribute "taskStore", savedStore
            End If
        End If
        Unload panel: Set panel = Nothing
        job.setAttribute "afterReminder", "1": CommitStage job, "filing": critical = False
    End If
    ' Resolve again after the reminder dialog. The user may have moved or
    ' deleted a message during the exchange, or an Outlook rule may have run.
    Set mail = OpenSent(job): Set source = OpenSource(job)
    If mail Is Nothing Then CommitStage job, "missing": GoTo Finished
    Set targets = New Collection: targets.Add mail
    If Not source Is Nothing Then targets.Add source
    Set panel = New frmPersonalOutlook
    Dim subject As String
    If Not source Is Nothing Then
        subject = source.Subject
    ElseIf Len(FieldText(job, "source")) Then
        explain = "The original email is unavailable. Filing applies only to the sent copy."
    End If
    panel.PrepareResponseFiling CategoryRows(targets), mail.Subject, subject, Not source Is Nothing, id, explain, FieldText(job, "sentDone") = "1", FieldText(job, "sourceDone") = "1"
    panel.Show vbModal
    If panel.Result = 1 Then
        CommitStage job, "applying": critical = True
        If panel.FileSent Then detail = FileResponseItem(job, mail, "sent", panel)
        If panel.FileSource And Not source Is Nothing Then
            problem = FileResponseItem(job, source, "source", panel)
            If Len(problem) Then detail = detail & vbCrLf & problem
        End If
        If Len(Trim$(detail)) Then
            PT_ShowReport "Reply & Follow Up", "The send and any saved task are complete. Check the filing result and use Pending follow-ups to finish." & vbCrLf & detail
            GoTo Finished
        End If
    End If
    ForgetJob job
Finished:
    On Error Resume Next
    If Not panel Is Nothing Then Unload panel
    ReleaseNotificationCards
    presenting = False: RecalculateWake
    Exit Sub
Failed:
    detail = Err.Description
    On Error Resume Next
    If Not critical Then
        If stage = "filing" Or FieldText(job, "afterReminder") = "1" Then CommitStage job, "applying" Else CommitStage job, "missing"
    End If
    MsgBox "Your message was sent. The workflow is available under Pending follow-ups. " & detail, vbInformation, "Reply & Follow Up"
    Resume Finished
End Sub

Private Function FileResponseItem(ByVal job As Object, ByVal mail As Outlook.MailItem, ByVal role As String, ByVal panel As frmPersonalOutlook) As String
    Dim filed As Object, oldEntry As String, oldStore As String, detail As String, problem As String
    On Error GoTo Failed
    oldEntry = mail.EntryID: oldStore = mail.Parent.StoreID
    detail = ApplyResponseChoices(mail, panel, filed)
    If Not filed Is Nothing Then
        job.setAttribute role, filed.EntryID: job.setAttribute role & "Store", filed.Parent.StoreID
        PersistBook
        If Len(FieldText(job, "task")) Then UpdateFiledTaskLink FieldText(job, "task"), FieldText(job, "taskStore"), oldEntry, oldStore, filed
    End If
    If Len(detail) Then Err.Raise 5, , detail
    job.setAttribute role & "Done", "1": PersistBook
    Exit Function
Failed:
    problem = Err.Description: FileResponseItem = IIf(role = "sent", "Sent email", "Original email") & " - " & problem
End Function

Private Function RecoverResponseTask(ByVal job As Object) As Boolean
    Dim found As Outlook.TaskItem
    Set found = TaskForResponse(FieldText(job, "id"), FieldText(job, "targetTask"), FieldText(job, "targetStore"))
    If found Is Nothing Then Exit Function
    job.setAttribute "task", found.EntryID: job.setAttribute "taskStore", found.Parent.StoreID
    job.setAttribute "afterReminder", "1": CommitStage job, "filing"
    RecoverResponseTask = True
End Function

Private Function ScopedSentQuery(ByVal folder As Outlook.Folder, ByVal job As Object, ByVal criteria As String) As String
    Dim start As Double, utc As Date
    ScopedSentQuery = "@SQL=" & criteria
    start = Val(FieldText(job, "startTick")): If start <= 0 Then Exit Function
    On Error GoTo NoDate
    utc = folder.PropertyAccessor.LocalTimeToUTC(CDate(CDbl(#1/1/2000#) + (start - 300#) / 86400#))
    ScopedSentQuery = "@SQL=(" & criteria & ") AND " & Chr$(34) & "http://schemas.microsoft.com/mapi/proptag/0x00390040" & Chr$(34) & " >= '" & Format$(utc, "ddddd h:nn AMPM") & "'"
NoDate:
End Function

Private Function JobForDraft(ByVal mail As Outlook.MailItem) As Object
    Dim job As Object, found As Object, entry As String, store As String, stage As String
    entry = mail.EntryID: If Len(entry) = 0 Then Exit Function
    store = mail.Parent.StoreID
    For Each job In book.documentElement.childNodes
        stage = FieldText(job, "stage")
        If stage = "draft" Or TracksSentFolder(stage) Then
            If FieldText(job, "draft") = entry And FieldText(job, "draftStore") = store Then
                If Not found Is Nothing Then Exit Function
                Set found = job
            End If
        End If
    Next job
    Set JobForDraft = found
End Function
