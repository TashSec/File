VERSION 1.0 CLASS
BEGIN
  MultiUse = -1
END
Attribute VB_Name = "clsPersonalSearchFolderEvents"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit ' Require declarations for the event handler and Outlook object names.

' Paste this into a blank class module named clsPersonalSearchFolderEvents.
' The application instance waits for its own AdvancedSearch events. A small instance
' per Explorer refreshes only the saved views that belong to this macro.

#If VBA7 Then
Private Declare PtrSafe Sub SearchWait Lib "kernel32" Alias "Sleep" (ByVal milliseconds As Long)
#Else
Private Declare Sub SearchWait Lib "kernel32" Alias "Sleep" (ByVal milliseconds As Long)
#End If

Private WithEvents outlookHost As Outlook.Application ' Route the application's search-complete event.
Private WithEvents openWindows As Outlook.Explorers ' Observe Outlook windows opened after startup.
Private WithEvents browser As Outlook.Explorer ' Follow navigation in one window instance.
Private listeners As Collection ' Retain the per-window instances while this owner is alive.
Private pendingTag As String ' Only the active search owned by this class can complete its wait.
Private done As Boolean ' Set by Outlook when that search finishes.
Private serial As Long ' Distinguish consecutive saves in the same second.
Private lastViewAt As Date
Private refreshing As Boolean ' A view Apply may raise another navigation event.

' Attach the application's search-complete and new-window events and register existing Explorers.
Public Sub Connect(ByVal host As Outlook.Application)
    Dim window As Outlook.Explorer
    Set outlookHost = host ' Keep the explicit Outlook Application supplied by the macro.
    Set openWindows = host.Explorers
    Set listeners = New Collection
    For Each window In openWindows
        Attach window ' Include windows Outlook already opened before the startup hook.
    Next window
End Sub

' Unhook every event source before its VBA project or Outlook Explorer can be destroyed.
Public Sub Disconnect()
    Dim listener As clsPersonalSearchFolderEvents
    On Error Resume Next ' Continue releasing the other sources if Outlook already closed one window.
    If Not listeners Is Nothing Then
        For Each listener In listeners
            listener.Disconnect ' Each child releases its own Explorer event interface.
        Next listener
    End If
    Set listeners = Nothing
    Set browser = Nothing
    Set openWindows = Nothing
    Set outlookHost = Nothing
    pendingTag = ""
    refreshing = False
    On Error GoTo 0
End Sub

' Retain a view-refresh listener for the newly opened Outlook Explorer.
Private Sub openWindows_NewExplorer(ByVal Explorer As Outlook.Explorer)
    Attach Explorer ' Each Explorer has its own current folder and view state.
End Sub

' Prune closed Explorer listeners and retain a fresh listener for the supplied window.
Private Sub Attach(ByVal window As Outlook.Explorer)
    Dim listener As clsPersonalSearchFolderEvents, index As Long
    For index = listeners.Count To 1 Step -1
        Set listener = listeners(index)
        If Not listener.HasWindow Then listeners.Remove index ' Release closed window instances.
    Next index
    Set listener = New clsPersonalSearchFolderEvents
    listener.ConnectWindow window
    listeners.Add listener
End Sub

' Watch folder navigation in this Explorer and refresh its current recorded Search Folder.
Public Sub ConnectWindow(ByVal window As Outlook.Explorer)
    Set browser = window ' Bind FolderSwitch, even in a secondary Outlook window.
    RefreshView ' Handle a Search Folder that was already selected.
End Sub

' Let the owning event manager release listeners whose Outlook windows have closed.
Public Property Get HasWindow() As Boolean
    HasWindow = Not browser Is Nothing ' The owner can prune this listener after Close.
End Property

' Refresh a recorded recent-mail view after navigating to its Search Folder.
Private Sub browser_FolderSwitch()
    RefreshView ' Recalculate the recent cutoff whenever the user enters the folder.
End Sub

' Refresh the date cutoff when returning to the Outlook window.
Private Sub browser_Activate()
    If lastViewAt > 0 Then
        If DateDiff("s", lastViewAt, Now) < 60 Then Exit Sub
    End If
    RefreshView ' Also refresh when the user returns to this Outlook window.
End Sub

' Release the closed Explorer so its listener can be pruned.
Private Sub browser_Close()
    Set browser = Nothing ' Release the Outlook Explorer reference immediately.
End Sub

' Guard against nested view events and always clear the guard on return.
Private Sub RefreshView()
    If refreshing Or browser Is Nothing Then Exit Sub
    On Error GoTo Finished ' Always clear the guard, including an unexpected Outlook event failure.
    refreshing = True: lastViewAt = Now
    ApplyLinkedFlagView browser
    PT_RefreshSearchFolderView browser ' The module checks this folder's recorded identity first.
Finished:
    refreshing = False
End Sub

' Wait for this search's completion, then ask Outlook to save it as a folder with a bounded provider timeout.
Public Function SaveSearch(ByVal scope As String, ByVal filter As String, ByVal children As Boolean, ByVal title As String) As Outlook.Folder
    Dim search As Outlook.Search, deadline As Date, number As Long, origin As String, description As String
    If Len(pendingTag) > 0 Then Err.Raise 5, , "A Search Folder is already being created."
    On Error GoTo Failed
    serial = serial + 1
    pendingTag = "PT_Search_" & Format$(Now, "yyyymmddhhnnss") & "_" & CStr(serial)
    done = False ' Establish the tag before Outlook can raise a completion event.
    Set search = outlookHost.AdvancedSearch(scope, filter, children, pendingTag)
    If Not search.IsSynchronous Then
        deadline = DateAdd("n", 3, Now) ' Bound the wait when a provider is slow or unavailable.
        Do Until done
            DoEvents ' Allow Outlook to deliver AdvancedSearchComplete.
            If Not done And Now >= deadline Then Err.Raise 5, , "Outlook did not complete this search within three minutes. Try a smaller scope or check the mailbox connection."
            If Not done Then SearchWait 20 ' Yield briefly so the wait does not spin at full CPU.
        Loop
    End If
    Set SaveSearch = search.Save(title) ' Ask Outlook to place the completed search in its folder list.
    pendingTag = ""
    Exit Function
Failed:
    number = Err.Number: origin = Err.Source: description = Err.Description
    pendingTag = "" ' Disregard any late completion after a failure.
    On Error Resume Next
    If Not search Is Nothing Then search.Stop
    On Error GoTo 0
    Err.Raise number, origin, description
End Function

' Accept only the completion event whose tag identifies this manager's pending search.
Private Sub outlookHost_AdvancedSearchComplete(ByVal SearchObject As Outlook.Search)
    If Len(pendingTag) > 0 And SearchObject.Tag = pendingTag Then done = True
End Sub
