Attribute VB_Name = "BulkTableUpdater"
Option Explicit

' Bulk Table Updater 1.0
' Import this standard module into the workbook that contains your tables.
' Add the companion event code to ThisWorkbook, then run BTU_SetupSheet.
' No references, add-ins, Windows API declarations or external files are required.

Private Const FIRST_COL As Long = 3
Private Const MARKER_ROW As Long = 5
Private Const HEADER_ROW As Long = 6
Private Const FIRST_ROW As Long = 7
Private Const COUNT_COL As Long = 2
Private Const CONTROL_NAME As String = "_BTU_Control"
Private Const STATUS_CELL As String = "B3"
Private Const ANY_TOKEN As String = "[ANY]"
Private Const CLEAR_TOKEN As String = "[CLEAR]"
Private mBusy As Boolean

Public Sub BTU_SetupSheet()
    Dim ws As Worksheet, message As String
    On Error GoTo Failed
    Set ws = ActiveControlSheet(False)
    If BTU_SetupCore(ws, message) Then
        MsgBox message, vbInformation, "Bulk Table Updater"
    Else
        MsgBox message, vbExclamation, "Bulk Table Updater"
    End If
    Exit Sub
Failed:
    MsgBox Err.Description, vbExclamation, "Bulk Table Updater"
End Sub

Public Sub BTU_RefreshCounts()
    BTU_RefreshAll True
End Sub

Public Sub BTU_ApplyUpdates()
    Dim ws As Worksheet, message As String
    On Error GoTo Failed
    Set ws = ActiveControlSheet(True)
    If BTU_ApplyCore(ws, message) Then
        MsgBox message, vbInformation, "Bulk Table Updater"
    Else
        MsgBox message, vbExclamation, "Bulk Table Updater"
    End If
    Exit Sub
Failed:
    MsgBox Err.Description, vbExclamation, "Bulk Table Updater"
End Sub

' Public helpers accept arguments, so they do not clutter the Alt+F8 macro list.
Public Function BTU_SetupCore(ByVal ws As Worksheet, ByRef message As String) As Boolean
    Dim oldEvents As Boolean
    oldEvents = Application.EnableEvents
    On Error GoTo Failed
    If Not (ws.Parent Is ThisWorkbook) Then
        Err.Raise vbObjectError + 2100, , "Install this module in the workbook you want to update."
    End If
    If ws.ProtectContents Or ws.ProtectDrawingObjects Then
        Err.Raise vbObjectError + 2101, , "Unprotect the input sheet before running setup."
    End If
    Application.EnableEvents = False
    If Not IsControlSheet(ws) Then
        ws.Names.Add Name:="'" & Replace(ws.Name, "'", "''") & "'!" & CONTROL_NAME, _
                     RefersTo:="=TRUE", Visible:=False
    End If
    AddButton ws, "__BTU_Apply", "Apply table updates", "BTU_ApplyUpdates", 0
    AddButton ws, "__BTU_Refresh", "Refresh counts", "BTU_RefreshCounts", 164
    Application.EnableEvents = oldEvents
    BTU_RefreshAll True
    message = "Setup complete on '" & ws.Name & "'." & vbCrLf & vbCrLf & _
              "B6: target table name." & vbCrLf & _
              "Row 5: Criteria above each matching column; leave update markers blank." & vbCrLf & _
              "Row 6, C onwards: table headings." & vbCrLf & _
              "Row 7 onwards: criteria and new values." & vbCrLf & vbCrLf & _
              "Automatic counts also need the supplied ThisWorkbook event code." & vbCrLf & _
              "Read B3 for the current status."
    BTU_SetupCore = True
    Exit Function
Failed:
    message = Err.Description
    On Error Resume Next
    Application.EnableEvents = oldEvents
End Function

Public Sub BTU_RebindButtons()
    Dim ws As Worksheet, actionPrefix As String
    actionPrefix = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!"
    On Error Resume Next
    For Each ws In ThisWorkbook.Worksheets
        If IsControlSheet(ws) Then
            If ws.Shapes("__BTU_Apply").OnAction <> actionPrefix & "BTU_ApplyUpdates" Then
                ws.Shapes("__BTU_Apply").OnAction = actionPrefix & "BTU_ApplyUpdates"
            End If
            If ws.Shapes("__BTU_Refresh").OnAction <> actionPrefix & "BTU_RefreshCounts" Then
                ws.Shapes("__BTU_Refresh").OnAction = actionPrefix & "BTU_RefreshCounts"
            End If
        End If
    Next ws
End Sub

Public Sub BTU_RefreshAll(Optional ByVal RecalculateFirst As Boolean = False)
    Dim ws As Worksheet, oldEvents As Boolean
    If mBusy Then Exit Sub
    oldEvents = Application.EnableEvents
    mBusy = True
    On Error GoTo CleanUp
    Application.EnableEvents = False
    If RecalculateFirst Then Application.Calculate
    For Each ws In ThisWorkbook.Worksheets
        If IsControlSheet(ws) Then RefreshOne ws
    Next ws
CleanUp:
    On Error Resume Next
    Application.EnableEvents = oldEvents
    mBusy = False
End Sub

' Build the complete plan against one snapshot before writing any target cells.
' If a write fails, restore every cell whose write was attempted.
Public Function BTU_ApplyCore(ByVal ws As Worksheet, ByRef message As String) As Boolean
    Dim lo As ListObject, plan As Object, counts As Variant
    Dim lastRow As Long, status As String, k As Variant, item As Variant
    Dim target As Range, changed As Collection, rowSet As Object
    Dim oldValues() As Variant, oldFormulas() As Variant, wasFormula() As Boolean
    Dim oldEvents As Boolean, oldScreen As Boolean, oldFill As Boolean
    Dim oldCalc As XlCalculation, oldCancel As XlEnableCancelKey
    Dim i As Long, attempted As Long, failure As String, rollbackFailed As Boolean
    Dim settingsSaved As Boolean, activeRows As Long, noMatchRows As Long
    If mBusy Then
        message = "The updater is already running."
        Exit Function
    End If
    On Error GoTo Failed
    If Not (ws.Parent Is ThisWorkbook) Then
        Err.Raise vbObjectError + 2102, , "The input sheet must be in the workbook containing this macro."
    End If
    If Not IsControlSheet(ws) Then
        Err.Raise vbObjectError + 2103, , "Run BTU_SetupSheet on this input sheet first."
    End If
    oldEvents = Application.EnableEvents
    oldScreen = Application.ScreenUpdating
    oldCalc = Application.Calculation
    oldFill = Application.AutoCorrect.AutoFillFormulasInLists
    oldCancel = Application.EnableCancelKey
    settingsSaved = True
    mBusy = True
    Application.EnableEvents = False
    Application.EnableCancelKey = xlErrorHandler
    Application.Calculate
    If Not BuildPlan(ws, True, lo, counts, lastRow, plan, status, activeRows, noMatchRows) Then
        WriteCounts ws, counts, lastRow
        SetStatus ws, status
        message = "No changes made." & vbCrLf & status
        GoTo CleanUp
    End If
    WriteCounts ws, counts, lastRow
    If lo.Parent.ProtectContents Then
        Err.Raise vbObjectError + 2104, , "The target sheet is protected. Unprotect it before applying updates."
    End If
    Set changed = New Collection
    Set rowSet = NewDictionary(vbBinaryCompare)
    For Each k In plan.Keys
        item = plan(k)
        Set target = lo.DataBodyRange.Cells(CLng(item(0)), CLng(item(1)))
        If target.HasArray Then
            Err.Raise vbObjectError + 2105, , "An update would overwrite an array formula at " & _
                      target.Address(External:=True) & ". No changes made."
        End If
        If target.HasFormula Or Not SameValue(target.Value2, item(2), False) Then
            changed.Add CStr(k)
            rowSet(CStr(item(0))) = True
        End If
    Next k
    If changed.Count = 0 Then
        message = "No table cells needed changing." & vbCrLf & _
                  CStr(noMatchRows) & " instruction row(s) matched no records."
        SetStatus ws, message
        BTU_ApplyCore = True
        GoTo CleanUp
    End If

    ReDim oldValues(1 To changed.Count)
    ReDim oldFormulas(1 To changed.Count)
    ReDim wasFormula(1 To changed.Count)
    For i = 1 To changed.Count
        item = plan(changed(i))
        Set target = lo.DataBodyRange.Cells(CLng(item(0)), CLng(item(1)))
        oldValues(i) = target.Value2
        wasFormula(i) = CBool(target.HasFormula)
        If wasFormula(i) Then oldFormulas(i) = ReadFormula(target)
    Next i

    Application.ScreenUpdating = False
    Application.Calculation = xlCalculationManual
    Application.AutoCorrect.AutoFillFormulasInLists = False
    For i = 1 To changed.Count
        item = plan(changed(i))
        Set target = lo.DataBodyRange.Cells(CLng(item(0)), CLng(item(1)))
        attempted = i
        WriteValue target, item(2)
        If target.HasFormula Or Not SameValue(target.Value2, item(2), False) Then
            Err.Raise vbObjectError + 2106, , "Excel did not retain the requested value at " & _
                      target.Address(External:=True) & "."
        End If
    Next i
    message = "Updated " & CStr(changed.Count) & " cell(s) across " & _
              CStr(rowSet.Count) & " record(s) in table '" & lo.Name & "'." & vbCrLf & _
              CStr(noMatchRows) & " instruction row(s) matched no records." & vbCrLf & _
              "Target formatting was retained. Save the workbook to keep these changes."
    BTU_ApplyCore = True
    GoTo CleanUp

Failed:
    failure = Err.Description
    On Error Resume Next
    ' Prevent a second Escape from interrupting restoration.
    If settingsSaved Then Application.EnableCancelKey = xlDisabled
    For i = attempted To 1 Step -1
        Err.Clear
        item = plan(changed(i))
        Set target = lo.DataBodyRange.Cells(CLng(item(0)), CLng(item(1)))
        If wasFormula(i) Then
            RestoreFormula target, oldFormulas(i)
        Else
            WriteValue target, oldValues(i)
        End If
        If Err.Number <> 0 Then rollbackFailed = True
    Next i
    If rollbackFailed Then
        message = "Update failed and restoration was incomplete. Do not save over your original." & _
                  vbCrLf & "Check the table against your saved copy." & vbCrLf & failure
    ElseIf attempted > 0 Then
        message = "Update failed. The attempted cell changes were restored." & vbCrLf & failure
    Else
        message = "No changes made." & vbCrLf & failure
    End If

CleanUp:
    On Error Resume Next
    If settingsSaved Then
        Application.AutoCorrect.AutoFillFormulasInLists = oldFill
        ' Recalculate while events remain disabled, then refresh every registered input sheet.
        Application.Calculation = oldCalc
        If attempted > 0 Then Application.Calculate
        Dim inputSheet As Worksheet
        For Each inputSheet In ThisWorkbook.Worksheets
            If IsControlSheet(inputSheet) Then RefreshOne inputSheet
        Next inputSheet
        SetStatus ws, message
        Application.ScreenUpdating = oldScreen
        Application.EnableCancelKey = oldCancel
        Application.EnableEvents = oldEvents
    End If
    mBusy = False
End Function

Private Function BuildPlan(ByVal ws As Worksheet, ByVal makePlan As Boolean, _
        ByRef lo As ListObject, ByRef counts As Variant, ByRef lastRow As Long, _
        ByRef plan As Object, ByRef status As String, _
        ByRef activeRows As Long, ByRef noMatchRows As Long) As Boolean
    Dim lastCol As Long, width As Long, rowCount As Long, tableRows As Long
    Dim map() As Long, isCriterion() As Boolean, included() As Boolean
    Dim headers As Variant, markers As Variant, source As Variant, data As Variant
    Dim headerMap As Object, seen As Object, indexes As Object, index As Object
    Dim matches As Collection, tableRow As Variant
    Dim r As Long, c As Long, tr As Long, criteriaCount As Long
    Dim name As String, marker As String, identity As String, mask As String, key As String
    Dim reason As String, firstProblem As String, conflict As String
    Dim active As Boolean, valid As Boolean, n As Long, v As Variant, existing As Variant
    Dim col As ListColumn, k As Variant
    On Error GoTo Failed
    Set plan = NewDictionary(vbBinaryCompare)
    lastRow = LastUsedRow(ws.Range(ws.Cells(FIRST_ROW, FIRST_COL), _
                                  ws.Cells(ws.Rows.Count, ws.Columns.Count)))
    If lastRow < FIRST_ROW Then lastRow = HEADER_ROW
    rowCount = lastRow - HEADER_ROW
    If rowCount > 0 Then ReDim counts(1 To rowCount, 1 To 1)
    lastCol = LastUsedColumn(ws.Range(ws.Cells(MARKER_ROW, FIRST_COL), _
                                     ws.Cells(ws.Rows.Count, ws.Columns.Count)))
    If lastCol < FIRST_COL Then
        status = "Add table headings in row 6, starting at C6."
        GoTo InvalidSetup
    End If
    width = lastCol - FIRST_COL + 1
    headers = ReadMatrix(ws.Range(ws.Cells(HEADER_ROW, FIRST_COL), ws.Cells(HEADER_ROW, lastCol)))
    markers = ReadMatrix(ws.Range(ws.Cells(MARKER_ROW, FIRST_COL), ws.Cells(MARKER_ROW, lastCol)))
    If rowCount > 0 Then
        source = ReadMatrix(ws.Range(ws.Cells(FIRST_ROW, FIRST_COL), ws.Cells(lastRow, lastCol)))
    End If
    v = ws.Cells(HEADER_ROW, COUNT_COL).Value2
    If IsError(v) Then
        status = "B6 contains an error. Enter the target table name."
        GoTo InvalidSetup
    End If
    name = Trim$(CStr(v))
    If Len(name) = 0 Then
        status = "Enter the target Excel table name in B6."
        GoTo InvalidSetup
    End If
    Set lo = FindTable(name)
    If lo Is Nothing Then
        status = "Table '" & name & "' was not found in this workbook. Check B6."
        GoTo InvalidSetup
    End If
    If lo.Parent Is ws Then
        status = "The target table must be on a different worksheet from this input grid."
        GoTo InvalidSetup
    End If

    Set headerMap = NewDictionary(vbTextCompare)
    For Each col In lo.ListColumns
        name = Trim$(col.Name)
        If headerMap.Exists(name) Then
            status = "The target table has ambiguous headings after trimming spaces: " & name
            GoTo InvalidSetup
        End If
        headerMap.Add name, col.Index
    Next col
    Set seen = NewDictionary(vbTextCompare)
    ReDim map(1 To width)
    ReDim isCriterion(1 To width)
    ReDim included(1 To width)
    For c = 1 To width
        If IsError(headers(1, c)) Or IsError(markers(1, c)) Then
            status = "An error appears in row 5 or 6, column " & ColumnLetter(ws, c + FIRST_COL - 1) & "."
            GoTo InvalidSetup
        End If
        name = Trim$(CStr(headers(1, c)))
        marker = Trim$(CStr(markers(1, c)))
        If Len(name) = 0 Then
            If Len(marker) > 0 Then
                status = "Add a heading at " & ws.Cells(HEADER_ROW, c + FIRST_COL - 1).Address(False, False) & "."
                GoTo InvalidSetup
            End If
            For r = 1 To rowCount
                If Not IsBlankValue(source(r, c)) Then
                    status = "Data has no heading at " & ws.Cells(FIRST_ROW + r - 1, FIRST_COL + c - 1).Address(False, False) & "."
                    GoTo InvalidSetup
                End If
            Next r
        Else
            If StrComp(marker, "Criteria", vbTextCompare) <> 0 And Len(marker) > 0 Then
                status = "Row 5 must contain Criteria or be blank. Check " & _
                         ws.Cells(MARKER_ROW, c + FIRST_COL - 1).Address(False, False) & "."
                GoTo InvalidSetup
            End If
            If Not headerMap.Exists(name) Then
                status = "Heading '" & name & "' is not in table '" & lo.Name & "'."
                GoTo InvalidSetup
            End If
            map(c) = CLng(headerMap(name))
            isCriterion(c) = (StrComp(marker, "Criteria", vbTextCompare) = 0)
            If isCriterion(c) Then criteriaCount = criteriaCount + 1
            identity = CStr(map(c)) & ":" & CStr(isCriterion(c))
            If seen.Exists(identity) Then
                status = "Heading '" & name & "' is repeated for the same role. Use it once per role."
                GoTo InvalidSetup
            End If
            seen.Add identity, True
        End If
    Next c
    If criteriaCount = 0 Then
        status = "Mark at least one column Criteria in row 5."
        GoTo InvalidSetup
    End If
    If rowCount = 0 Then
        status = "Ready. Enter criteria and update values from row 7."
        BuildPlan = True
        Exit Function
    End If
    tableRows = lo.ListRows.Count
    If tableRows > 0 Then data = ReadMatrix(lo.DataBodyRange)
    Set indexes = NewDictionary(vbBinaryCompare)
    For r = 1 To rowCount
        active = False
        valid = True
        reason = vbNullString
        For c = 1 To width
            If map(c) > 0 Then
                If Not IsBlankValue(source(r, c)) Then active = True
                If IsError(source(r, c)) Then
                    valid = False
                    reason = "Input error at " & ws.Cells(FIRST_ROW + r - 1, FIRST_COL + c - 1).Address(False, False) & "."
                End If
            End If
        Next c
        If active Then
            activeRows = activeRows + 1
            If Not valid Then
                counts(r, 1) = "Input error"
                If Len(firstProblem) = 0 Then firstProblem = reason
            Else
                ' Each wildcard pattern gets its own index. [ANY] columns are omitted.
                mask = vbNullString
                For c = 1 To width
                    included(c) = False
                    If isCriterion(c) Then
                        included(c) = Not IsToken(source(r, c), ANY_TOKEN)
                        If included(c) Then mask = mask & CStr(c) & ","
                    End If
                Next c
                If Not indexes.Exists(mask) Then
                    Set index = NewDictionary(vbTextCompare)
                    For tr = 1 To tableRows
                        key = MakeKey(data, tr, included, map, width, True, valid)
                        If valid Then
                            If Not index.Exists(key) Then
                                Set matches = New Collection
                                index.Add key, matches
                            End If
                            Set matches = index(key)
                            matches.Add tr
                        End If
                    Next tr
                    indexes.Add mask, index
                Else
                    Set index = indexes(mask)
                End If
                key = MakeKey(source, r, included, map, width, False, valid)
                n = 0
                If index.Exists(key) Then
                    Set matches = index(key)
                    For Each tableRow In matches
                        tr = CLng(tableRow)
                        ' Verify candidate values as well: numeric string keys can round.
                        If MatchesRow(data, tr, source, r, included, map, width) Then
                            n = n + 1
                            If makePlan Then
                                For c = 1 To width
                                    If map(c) > 0 And Not isCriterion(c) Then
                                        v = source(r, c)
                                        If Not IsBlankValue(v) Then
                                            If IsToken(v, CLEAR_TOKEN) Then v = Empty
                                            identity = CStr(tr) & ":" & CStr(map(c))
                                            If plan.Exists(identity) Then
                                                existing = plan(identity)
                                                If Not SameValue(existing(2), v, False) Then
                                                    If Len(conflict) = 0 Then
                                                        conflict = "Conflicting updates from input rows " & _
                                                            CStr(existing(3)) & " and " & CStr(r + FIRST_ROW - 1) & _
                                                            " to table record " & CStr(tr) & ", heading '" & _
                                                            lo.ListColumns(map(c)).Name & "'."
                                                    End If
                                                End If
                                            Else
                                                plan.Add identity, Array(tr, map(c), v, r + FIRST_ROW - 1)
                                            End If
                                        End If
                                    End If
                                Next c
                            End If
                        End If
                    Next tableRow
                End If
                counts(r, 1) = n
                If n = 0 Then noMatchRows = noMatchRows + 1
            End If
        End If
    Next r
    If Len(firstProblem) > 0 Then
        status = firstProblem & " Fix input errors before applying updates."
    ElseIf Len(conflict) > 0 Then
        status = conflict & " Resolve the conflict before applying."
    Else
        status = "Ready. " & CStr(activeRows) & " instruction row(s); " & _
                 CStr(noMatchRows) & " with no matches. Blank updates keep values; [CLEAR] empties them."
        BuildPlan = True
    End If
    Exit Function

InvalidSetup:
    For r = 1 To rowCount
        counts(r, 1) = "Setup error"
    Next r
    Exit Function
Failed:
    status = "Cannot prepare updates: " & Err.Description
    On Error Resume Next
    If rowCount > 0 Then
        ReDim counts(1 To rowCount, 1 To 1)
        For r = 1 To rowCount
            counts(r, 1) = "Setup error"
        Next r
    End If
End Function

Private Sub RefreshOne(ByVal ws As Worksheet)
    Dim lo As ListObject, counts As Variant, plan As Object
    Dim lastRow As Long, status As String, activeRows As Long, noMatchRows As Long
    Dim ready As Boolean
    On Error GoTo Failed
    ready = BuildPlan(ws, False, lo, counts, lastRow, plan, status, activeRows, noMatchRows)
    WriteCounts ws, counts, lastRow
    SetStatus ws, status
    Exit Sub
Failed:
    On Error Resume Next
    SetStatus ws, "Counts could not refresh: " & Err.Description
End Sub

Private Sub WriteCounts(ByVal ws As Worksheet, ByVal counts As Variant, ByVal lastRow As Long)
    Dim previousLast As Long, endRow As Long, n As Long, r As Long
    Dim output() As Variant, old As Variant, changed As Boolean
    Dim area As Range
    previousLast = LastUsedRow(ws.Range(ws.Cells(FIRST_ROW, COUNT_COL), ws.Cells(ws.Rows.Count, COUNT_COL)))
    endRow = lastRow
    If previousLast > endRow Then endRow = previousLast
    If endRow < FIRST_ROW Then Exit Sub
    n = endRow - FIRST_ROW + 1
    ReDim output(1 To n, 1 To 1)
    If lastRow >= FIRST_ROW Then
        For r = 1 To lastRow - FIRST_ROW + 1
            output(r, 1) = counts(r, 1)
        Next r
    End If
    Set area = ws.Range(ws.Cells(FIRST_ROW, COUNT_COL), ws.Cells(endRow, COUNT_COL))
    old = ReadMatrix(area)
    For r = 1 To n
        If Not SameValue(old(r, 1), output(r, 1), False) Then
            changed = True
            Exit For
        End If
    Next r
    If changed Then area.Value2 = output
End Sub

Private Sub SetStatus(ByVal ws As Worksheet, ByVal text As String)
    If Not SameValue(ws.Range(STATUS_CELL).Value2, text, False) Then
        ws.Range(STATUS_CELL).Value2 = text
    End If
End Sub

Private Function MakeKey(ByRef values As Variant, ByVal row As Long, _
        ByRef included() As Boolean, ByRef map() As Long, ByVal width As Long, _
        ByVal fromTable As Boolean, ByRef valid As Boolean) As String
    Dim c As Long, index As Long, v As Variant, part As String, result As String
    valid = True
    For c = 1 To width
        If included(c) Then
            If fromTable Then index = map(c) Else index = c
            v = values(row, index)
            If IsError(v) Then
                valid = False
                Exit Function
            End If
            If IsBlankValue(v) Then
                part = "Z"
            ElseIf VarType(v) = vbString Then
                part = "T" & CStr(v)
            ElseIf VarType(v) = vbBoolean Then
                part = "B" & CStr(v)
            Else
                part = "N" & CStr(v)
            End If
            result = result & CStr(Len(part)) & ":" & part
        End If
    Next c
    MakeKey = result
End Function

Private Function MatchesRow(ByRef data As Variant, ByVal tableRow As Long, _
        ByRef source As Variant, ByVal sourceRow As Long, ByRef included() As Boolean, _
        ByRef map() As Long, ByVal width As Long) As Boolean
    Dim c As Long
    For c = 1 To width
        If included(c) Then
            If Not SameValue(data(tableRow, map(c)), source(sourceRow, c), True) Then Exit Function
        End If
    Next c
    MatchesRow = True
End Function

Private Function SameValue(ByVal a As Variant, ByVal b As Variant, ByVal ignoreCase As Boolean) As Boolean
    If IsError(a) Or IsError(b) Then
        If IsError(a) And IsError(b) Then SameValue = (CStr(a) = CStr(b))
        Exit Function
    End If
    If IsBlankValue(a) Or IsBlankValue(b) Then
        SameValue = IsBlankValue(a) And IsBlankValue(b)
        Exit Function
    End If
    If VarType(a) = vbString Or VarType(b) = vbString Then
        If VarType(a) <> vbString Or VarType(b) <> vbString Then Exit Function
        If ignoreCase Then
            SameValue = (StrComp(CStr(a), CStr(b), vbTextCompare) = 0)
        Else
            SameValue = (StrComp(CStr(a), CStr(b), vbBinaryCompare) = 0)
        End If
    ElseIf VarType(a) = vbBoolean Or VarType(b) = vbBoolean Then
        If VarType(a) = vbBoolean And VarType(b) = vbBoolean Then SameValue = (a = b)
    ElseIf IsNumeric(a) And IsNumeric(b) Then
        SameValue = (CDbl(a) = CDbl(b))
    Else
        SameValue = (VarType(a) = VarType(b)) And (CStr(a) = CStr(b))
    End If
End Function

Private Function IsBlankValue(ByVal v As Variant) As Boolean
    If IsError(v) Then Exit Function
    If IsEmpty(v) Then
        IsBlankValue = True
    ElseIf VarType(v) = vbString Then
        IsBlankValue = (Len(v) = 0)
    End If
End Function

Private Function IsToken(ByVal v As Variant, ByVal token As String) As Boolean
    If VarType(v) = vbString Then IsToken = (StrComp(Trim$(v), token, vbTextCompare) = 0)
End Function

Private Sub WriteValue(ByVal cell As Range, ByVal v As Variant)
    If IsEmpty(v) Then
        cell.ClearContents
    ElseIf VarType(v) = vbString Then
        ' Preserve text exactly, including leading zeros and literal "=" strings.
        ' The prefix is Excel's text marker; it is not part of the stored value.
        cell.Value2 = "'" & CStr(v)
    Else
        cell.Value2 = v
    End If
End Sub

Private Function ReadFormula(ByVal cell As Range) As Variant
    On Error GoTo Legacy
    ReadFormula = CallByName(cell, "Formula2", VbGet)
    Exit Function
Legacy:
    Err.Clear
    ReadFormula = cell.Formula
End Function

Private Sub RestoreFormula(ByVal cell As Range, ByVal formula As Variant)
    On Error GoTo Legacy
    CallByName cell, "Formula2", VbLet, formula
    Exit Sub
Legacy:
    Err.Clear
    cell.Formula = formula
End Sub

Private Function ReadMatrix(ByVal area As Range) As Variant
    Dim a(1 To 1, 1 To 1) As Variant
    If area.Cells.CountLarge = 1 Then
        a(1, 1) = area.Value2
        ReadMatrix = a
    Else
        ReadMatrix = area.Value2
    End If
End Function

Private Function NewDictionary(ByVal compare As VbCompareMethod) As Object
    Set NewDictionary = CreateObject("Scripting.Dictionary")
    NewDictionary.CompareMode = compare
End Function

Private Function FindTable(ByVal name As String) As ListObject
    Dim ws As Worksheet, lo As ListObject
    For Each ws In ThisWorkbook.Worksheets
        For Each lo In ws.ListObjects
            If StrComp(lo.Name, name, vbTextCompare) = 0 Then
                Set FindTable = lo
                Exit Function
            End If
        Next lo
    Next ws
End Function

Private Function IsControlSheet(ByVal ws As Worksheet) As Boolean
    Dim n As Name, simpleName As String
    For Each n In ws.Names
        simpleName = Mid$(n.Name, InStrRev(n.Name, "!") + 1)
        If StrComp(simpleName, CONTROL_NAME, vbTextCompare) = 0 Then
            IsControlSheet = True
            Exit Function
        End If
    Next n
End Function

Private Function ActiveControlSheet(ByVal requireSetup As Boolean) As Worksheet
    If Not TypeOf ActiveSheet Is Worksheet Then
        Err.Raise vbObjectError + 2107, , "Select your input worksheet first."
    End If
    Dim ws As Worksheet
    Set ws = ActiveSheet
    If Not (ws.Parent Is ThisWorkbook) Then
        Err.Raise vbObjectError + 2108, , "Select an input sheet in the workbook containing this macro."
    End If
    If requireSetup And Not IsControlSheet(ws) Then
        Err.Raise vbObjectError + 2109, , "Run BTU_SetupSheet on this worksheet first."
    End If
    Set ActiveControlSheet = ws
End Function

Private Sub AddButton(ByVal ws As Worksheet, ByVal name As String, ByVal caption As String, _
                      ByVal macro As String, ByVal offset As Double)
    Dim button As Object
    On Error Resume Next
    Set button = ws.Buttons(name)
    On Error GoTo 0
    If button Is Nothing Then
        Set button = ws.Buttons.Add(ws.Range("B1").Left + offset, ws.Range("B1").Top + 2, 156, 26)
        button.Name = name
    End If
    button.Caption = caption
    button.OnAction = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & macro
    button.Placement = xlFreeFloating
End Sub

Private Function LastUsedRow(ByVal area As Range) As Long
    Dim found As Range
    Set found = area.Find(What:="*", After:=area.Cells(1, 1), LookIn:=xlFormulas, _
                         LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, _
                         MatchCase:=False, SearchFormat:=False)
    If Not found Is Nothing Then LastUsedRow = found.Row
End Function

Private Function LastUsedColumn(ByVal area As Range) As Long
    Dim found As Range
    Set found = area.Find(What:="*", After:=area.Cells(1, 1), LookIn:=xlFormulas, _
                         LookAt:=xlPart, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious, _
                         MatchCase:=False, SearchFormat:=False)
    If Not found Is Nothing Then LastUsedColumn = found.Column
End Function

Private Function ColumnLetter(ByVal ws As Worksheet, ByVal column As Long) As String
    ColumnLetter = Split(ws.Cells(1, column).Address(True, False), "$")(0)
End Function
