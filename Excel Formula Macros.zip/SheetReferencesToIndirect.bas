Attribute VB_Name = "SheetReferencesToIndirect"
Option Explicit
' Independent module. No reference to the other delivered module is required.
' Windows desktop Excel. Version 1.0, 5 November 2026.
Private Const TITLE As String = "Make worksheet references indirect"
Private Const BACKUP_TAG As String = "indirect"

Private Type IR_Edit
    Address As String
    Before As String
    After As String
    State As String
    Note As String
End Type

Public Sub MakeSheetReferencesIndirect()
    Dim picked As Range, ws As Worksheet, selectorCell As Range, source As Variant
    Dim selector As String, checkSheet As Worksheet
    On Error GoTo Failed
    Set picked = IR_PickCell("Select any cell on the worksheet to change (in the required open workbook).")
    If picked Is Nothing Then Exit Sub
    Set ws = picked.Worksheet
    source = Application.InputBox("Exact source worksheet name to replace, without quotes or !:", TITLE, Type:=2)
    If VarType(source) = vbBoolean Then Exit Sub
    If Len(CStr(source)) = 0 Then Exit Sub
    Set checkSheet = ws.Parent.Worksheets(CStr(source))
    Set selectorCell = IR_PickCell("Select ONE cell containing the replacement worksheet name, in the SAME workbook.")
    If selectorCell Is Nothing Then Exit Sub
    If selectorCell.CountLarge <> 1 Then Err.Raise 5, TITLE, "Select exactly one selector cell."
    If Not (selectorCell.Parent.Parent Is ws.Parent) Then _
        Err.Raise 5, TITLE, "The selector cell must be in the target workbook."
    If selectorCell.HasFormula Or IsError(selectorCell.Value2) Then _
        Err.Raise 5, TITLE, "Use a selector cell containing a typed worksheet name, not a formula or error."
    Set checkSheet = ws.Parent.Worksheets(CStr(selectorCell.Value2))
    selector = "'" & Replace(selectorCell.Worksheet.Name, "'", "''") & "'!" & _
               selectorCell.Address(True, True, xlA1)
    IR_Run ws, CStr(source), selector
    Exit Sub
Failed:
    MsgBox "Could not start: " & Err.Description & vbCrLf & _
        "Check the worksheet names and selector cell.", vbExclamation, TITLE
End Sub


Private Function IR_PickCell(ByVal prompt As String) As Range
    On Error Resume Next
    Set IR_PickCell = Application.InputBox(prompt, TITLE, Type:=8)
    On Error GoTo 0
End Function

Private Function IR_Read(ByVal c As Range, ByVal useF2 As Boolean) As String
    If useF2 Then
        IR_Read = CStr(CallByName(c, "Formula2", VbGet))
    Else
        IR_Read = CStr(c.Formula)
    End If
End Function

Private Sub IR_Write(ByVal c As Range, ByVal formula As String, ByVal useF2 As Boolean)
    If useF2 Then
        CallByName c, "Formula2", VbLet, formula
    Else
        c.Formula = formula
    End If
End Sub

Private Function IR_HasFormula2(ByVal c As Range) As Boolean
    Dim v As Variant
    On Error Resume Next
    v = CallByName(c, "Formula2", VbGet)
    IR_HasFormula2 = (Err.Number = 0)
    Err.Clear
    On Error GoTo 0
End Function

Private Function IR_CellRestriction(ByVal c As Range) As String
    Dim v As Variant
    If c.HasArray Then
        IR_CellRestriction = "Legacy array formula: edit the array as a unit manually."
        Exit Function
    End If
    On Error Resume Next
    v = CallByName(c, "HasSpill", VbGet)
    If Err.Number = 0 Then
        If Not IsNull(v) Then
            If CBool(v) Then IR_CellRestriction = "Spilled array: review the spill formula manually."
        End If
    End If
    Err.Clear
    On Error GoTo 0
End Function

Private Function IR_QuotedEnd(ByVal s As String, ByVal start As Long) As Long
    Dim i As Long, q As String
    q = Mid$(s, start, 1)
    i = start + 1
    Do While i <= Len(s)
        If Mid$(s, i, 1) = q Then
            If Mid$(s, i + 1, 1) = q Then
                i = i + 2
            Else
                IR_QuotedEnd = i
                Exit Function
            End If
        Else
            i = i + 1
        End If
    Loop
    Err.Raise vbObjectError + 710, TITLE, "Unclosed quotation in formula."
End Function

Private Function IR_BracketEnd(ByVal s As String, ByVal start As Long) As Long
    Dim i As Long, depth As Long, ch As String
    i = start
    Do While i <= Len(s)
        ch = Mid$(s, i, 1)
        If ch = "'" And i < Len(s) Then
            ' Apostrophe escapes special characters in structured references.
            i = i + 2
        Else
            If ch = "[" Then depth = depth + 1
            If ch = "]" Then
                depth = depth - 1
                If depth = 0 Then
                    IR_BracketEnd = i
                    Exit Function
                End If
            End If
            i = i + 1
        End If
    Loop
    Err.Raise vbObjectError + 711, TITLE, "Unclosed bracket in formula."
End Function

Private Function IR_NameChar(ByVal ch As String) As Boolean
    If Len(ch) = 0 Then Exit Function
    IR_NameChar = (ch Like "[A-Za-z0-9_.$\]")
    If AscW(ch) < 0 Or AscW(ch) > 127 Then IR_NameChar = True
End Function

Private Function IR_Quote(ByVal s As String) As String
    IR_Quote = Chr$(34) & Replace(s, Chr$(34), Chr$(34) & Chr$(34)) & Chr$(34)
End Function

Private Function IR_Backup(ByVal wb As Workbook) As String
    Dim base As String, ext As String, path As String, k As Long, p As Long
    If Len(wb.Path) = 0 Or InStr(1, wb.Path, "://", vbTextCompare) > 0 Then
        Err.Raise vbObjectError + 712, TITLE, _
            "Save the target workbook to a local or synced folder first, then run again."
    End If
    p = InStrRev(wb.Name, ".")
    If p = 0 Then Err.Raise vbObjectError + 713, TITLE, "The target needs a saved Excel filename."
    base = wb.Path & Application.PathSeparator & Left$(wb.Name, p - 1) & _
           "_before_" & BACKUP_TAG & "_" & Format$(Now, "yyyymmdd_hhnnss")
    ext = Mid$(wb.Name, p)
    path = base & ext
    Do While Len(Dir$(path)) > 0
        k = k + 1
        path = base & "_" & CStr(k) & ext
    Loop
    wb.SaveCopyAs path
    IR_Backup = path
End Function

Private Function IR_Report(ByVal ws As Worksheet, ByRef edits() As IR_Edit, _
                          ByVal n As Long) As Worksheet
    Dim report As Worksheet
    Set report = Workbooks.Add(xlWBATWorksheet).Worksheets(1)
    report.Name = "Formula changes"
    report.Cells.NumberFormat = "@"
    report.Range("A1").Value2 = TITLE
    report.Range("A2").Value2 = "Target workbook"
    report.Range("B2").Value2 = ws.Parent.FullName
    report.Range("A3").Value2 = "Target worksheet"
    report.Range("B3").Value2 = ws.Name
    report.Range("A4").Value2 = "Backup"
    report.Range("B4").Value2 = "Not applied. No backup needed yet."
    report.Range("A6:E6").Value2 = Array("Cell", "Status", "Original formula", "Proposed formula", "Details")
    report.Range("A1:E1").Merge
    report.Range("A1").Font.Size = 16
    report.Range("A1").Font.Bold = True
    report.Range("A6:E6").Font.Bold = True
    report.Range("A6:E6").Interior.Color = RGB(230, 221, 244)
    report.Columns("A").ColumnWidth = 14
    report.Columns("B").ColumnWidth = 17
    report.Columns("C:D").ColumnWidth = 65
    report.Columns("E").ColumnWidth = 55
    IR_FillReport report, edits, n
    report.Activate
    report.Range("C7").Select
    ActiveWindow.FreezePanes = True
    Set IR_Report = report
End Function

Private Sub IR_FillReport(ByVal report As Worksheet, ByRef edits() As IR_Edit, ByVal n As Long)
    Dim data() As Variant, i As Long
    If n = 0 Then
        report.Range("A7").Value2 = "No matching formulas."
        Exit Sub
    End If
    If n > report.Rows.Count - 6 Then _
        Err.Raise vbObjectError + 714, TITLE, "Too many report rows. No changes were applied."
    ReDim data(1 To n, 1 To 5)
    For i = 1 To n
        data(i, 1) = edits(i).Address
        data(i, 2) = edits(i).State
        data(i, 3) = edits(i).Before
        data(i, 4) = edits(i).After
        data(i, 5) = edits(i).Note
    Next i
    With report.Range("A7").Resize(n, 5)
        .NumberFormat = "@"
        .Value2 = data
        .VerticalAlignment = xlTop
        .WrapText = True
        .Rows.RowHeight = 60
    End With
    If report.AutoFilterMode Then report.AutoFilterMode = False
    report.Range("A6:E" & CStr(n + 6)).AutoFilter
End Sub

Private Function IR_SameValue(ByVal a As Variant, ByVal b As Variant) As Boolean
    If IsError(a) Or IsError(b) Or IsArray(a) Or IsArray(b) Then Exit Function
    If VarType(a) <> VarType(b) Then Exit Function
    IR_SameValue = (a = b)
End Function

Private Sub IR_Apply(ByVal ws As Worksheet, ByRef edits() As IR_Edit, ByVal n As Long, _
                    ByVal useF2 As Boolean, ByVal checkResult As Boolean, _
                    ByRef backupPath As String)
    Dim i As Long, j As Long, c As Range, oldValue As Variant
    Dim oldCalc As XlCalculation, oldEvents As Boolean, oldScreen As Boolean
    Dim oldFill As Boolean, settingsCaptured As Boolean
    Dim failure As String, rollbackFailures As Long
    On Error GoTo Failed
    If ws.ProtectContents Then Err.Raise vbObjectError + 715, TITLE, "The target worksheet is protected."
    If ws.Parent.ReadOnly Then Err.Raise vbObjectError + 716, TITLE, "The target workbook is read-only."
    For i = 1 To n
        If edits(i).State = "Proposed" Then
            Set c = ws.Range(edits(i).Address)
            If IR_Read(c, useF2) <> edits(i).Before Then _
                Err.Raise vbObjectError + 717, TITLE, "A source formula changed after the preview. Run again."
        End If
    Next i
    oldCalc = Application.Calculation
    oldEvents = Application.EnableEvents
    oldScreen = Application.ScreenUpdating
    oldFill = Application.AutoCorrect.AutoFillFormulasInLists
    settingsCaptured = True
    Application.EnableEvents = False
    Application.ScreenUpdating = False
    Application.Calculation = xlCalculationManual
    Application.AutoCorrect.AutoFillFormulasInLists = False
    backupPath = IR_Backup(ws.Parent)
    For i = 1 To n
        If edits(i).State = "Proposed" Then
            Set c = ws.Range(edits(i).Address)
            If checkResult Then
                c.Calculate
                oldValue = c.Value2
            End If
            If checkResult And IsError(oldValue) Then
                edits(i).State = "Skipped"
                edits(i).Note = "Existing result is an error; equivalence could not be checked."
            Else
                edits(i).State = "Writing"
                IR_Write c, edits(i).After, useF2
                If checkResult Then
                    c.Calculate
                    If Not IR_SameValue(oldValue, c.Value2) Then
                        IR_Write c, edits(i).Before, useF2
                        c.Calculate
                        edits(i).State = "Skipped"
                        edits(i).Note = "Original restored: the current result changed (or became an error)."
                    Else
                        edits(i).State = "Applied"
                        edits(i).Note = "Current scalar result matched exactly. Review future data and edge cases."
                    End If
                Else
                    edits(i).State = "Applied"
                End If
            End If
        End If
    Next i
    GoTo RestoreSettings
Failed:
    failure = Err.Description
    On Error Resume Next
    For j = n To 1 Step -1
        If edits(j).State = "Applied" Or edits(j).State = "Writing" Then
            Err.Clear
            IR_Write ws.Range(edits(j).Address), edits(j).Before, useF2
            If Err.Number = 0 Then
                edits(j).State = "Restored"
                edits(j).Note = "Run stopped; original formula restored."
            Else
                rollbackFailures = rollbackFailures + 1
                edits(j).State = "Restore failed"
                edits(j).Note = "Recover this workbook from the backup."
            End If
        End If
    Next j
    On Error GoTo 0
RestoreSettings:
    On Error Resume Next
    If settingsCaptured Then
        Application.AutoCorrect.AutoFillFormulasInLists = oldFill
        Application.Calculation = oldCalc
        Application.EnableEvents = oldEvents
        Application.ScreenUpdating = oldScreen
    End If
    On Error GoTo 0
    If Len(failure) > 0 Then
        If rollbackFailures > 0 Then failure = failure & vbCrLf & _
            CStr(rollbackFailures) & " formula(s) could not be restored. Use the backup: " & backupPath
        Err.Raise vbObjectError + 718, TITLE, failure
    End If
End Sub

Private Sub IR_Run(ByVal ws As Worksheet, ByVal source As String, ByVal selector As String)
    Dim edits() As IR_Edit, n As Long, i As Long, proposed As Long, applied As Long
    Dim report As Worksheet, useF2 As Boolean, backupPath As String, failure As String
    On Error GoTo Failed
    If ws.ProtectContents Then Err.Raise vbObjectError + 719, TITLE, "Unprotect the target worksheet first."
    useF2 = IR_HasFormula2(ws.Cells(1, 1))
    IR_Plan ws, source, selector, useF2, edits, n
    Set report = IR_Report(ws, edits, n)
    For i = 1 To n
        If edits(i).State = "Proposed" Then proposed = proposed + 1
    Next i
    If proposed = 0 Then
        MsgBox "No eligible changes. The report lists any matching formulas that were skipped.", vbInformation, TITLE
        Exit Sub
    End If
    If MsgBox(CStr(proposed) & " formula cell(s) proposed for:" & vbCrLf & _
       ws.Parent.Name & " / " & ws.Name & vbCrLf & vbCrLf & _
       "YES: back up the workbook and apply the changes." & vbCrLf & _
       "NO: leave formulas unchanged so you can review the full report." & vbCrLf & _
       "After reviewing, run the macro again to apply.", _
       vbYesNo + vbQuestion + vbDefaultButton2, TITLE) <> vbYes Then Exit Sub
    IR_Apply ws, edits, n, useF2, False, backupPath
    report.Range("B4").Value2 = backupPath
    IR_FillReport report, edits, n
    For i = 1 To n
        If edits(i).State = "Applied" Then applied = applied + 1
    Next i
    MsgBox CStr(applied) & " formula cell(s) changed. See the report for any skips." & _
        vbCrLf & "Backup: " & backupPath & vbCrLf & _
        "Review the workbook, then save it. Normal Excel Undo is not available.", vbInformation, TITLE
    Exit Sub
Failed:
    failure = Err.Description
    On Error Resume Next
    If Not report Is Nothing Then
        If Len(backupPath) > 0 Then report.Range("B4").Value2 = backupPath
        IR_FillReport report, edits, n
    End If
    On Error GoTo 0
    MsgBox "Stopped: " & failure, vbExclamation, TITLE
End Sub

Private Sub IR_Plan(ByVal ws As Worksheet, ByVal source As String, ByVal selector As String, _
                   ByVal useF2 As Boolean, ByRef edits() As IR_Edit, ByRef n As Long)
    Dim formulas As Range, c As Range, before As String, after As String
    Dim hits As Long, why As String
    n = 0
    On Error Resume Next
    Set formulas = ws.UsedRange.SpecialCells(xlCellTypeFormulas)
    On Error GoTo 0
    If formulas Is Nothing Then Exit Sub
    ReDim edits(1 To CLng(formulas.CountLarge))
    For Each c In formulas.Cells
        before = IR_Read(c, useF2)
        hits = 0
        why = vbNullString
        after = IR_Transform(before, source, selector, ws, hits, why, c)
        If hits > 0 Then
            n = n + 1
            edits(n).Address = c.Address(False, False)
            edits(n).Before = before
            edits(n).After = after
            If Len(why) = 0 Then why = IR_CellRestriction(c)
            If Len(after) > 8192 Then why = "The proposed formula exceeds Excel's 8,192-character limit."
            If Len(why) > 0 Then
                edits(n).State = "Skipped"
                edits(n).Note = why
            Else
                edits(n).State = "Proposed"
                edits(n).Note = CStr(hits) & " replacement(s)."
            End If
        End If
    Next c
End Sub

Private Function IR_Transform(ByVal s As String, ByVal source As String, ByVal selector As String, _
                              ByVal ws As Worksheet, ByRef hits As Long, ByRef why As String, _
                              Optional ByVal contextCell As Range = Nothing) As String
    Dim i As Long, j As Long, k As Long, e As Long, ch As String, name As String
    Dim out As String, address As String, prev As String, matched As Boolean
    On Error GoTo Failed
    i = 1
    Do While i <= Len(s)
        ch = Mid$(s, i, 1)
        If ch = Chr$(34) Then
            j = IR_QuotedEnd(s, i)
            out = out & Mid$(s, i, j - i + 1)
            i = j + 1
        ElseIf ch = "[" Then
            j = IR_BracketEnd(s, i)
            out = out & Mid$(s, i, j - i + 1)
            i = j + 1
        ElseIf ch = "'" Or IR_NameChar(ch) Then
            If ch = "'" Then
                j = IR_QuotedEnd(s, i) + 1
                name = Replace(Mid$(s, i + 1, j - i - 2), "''", "'")
            Else
                j = i + 1
                Do While IR_NameChar(Mid$(s, j, 1))
                    j = j + 1
                Loop
                name = Mid$(s, i, j - i)
            End If
            prev = vbNullString
            If i > 1 Then prev = Mid$(s, i - 1, 1)
            matched = (StrComp(name, source, vbTextCompare) = 0 And Mid$(s, j, 1) = "!")
            If prev = "]" Or prev = ":" Or prev = "!" Then matched = False
            If matched Then
                hits = hits + 1
                address = IR_Address(s, j + 1, e)
                If Len(address) = 0 Then
                    why = "Target reference is not a supported A1 cell/range (names, spills and constructed ranges need review)."
                    IR_Transform = s
                    Exit Function
                End If
                out = out & "INDIRECT(" & IR_Quote("'") & "&SUBSTITUTE(" & selector & "," & _
                      IR_Quote("'") & "," & IR_Quote("''") & ")&" & IR_Quote("'!" & address) & ")"
                i = e + 1
            Else
                out = out & Mid$(s, i, j - i)
                i = j
            End If
        Else
            out = out & ch
            i = i + 1
        End If
    Loop
    IR_Transform = out
    Exit Function
Failed:
    why = "Formula needs manual review: " & Err.Description
    IR_Transform = s
End Function

Private Function IR_Address(ByVal s As String, ByVal start As Long, ByRef finish As Long) As String
    Dim p As Long, firstKind As Long, secondKind As Long, ch As String, nextNonSpace As Long
    p = start
    firstKind = IR_AddressPart(s, p)
    If firstKind = 0 Then Exit Function
    If Mid$(s, p, 1) = ":" Then
        p = p + 1
        secondKind = IR_AddressPart(s, p)
        If firstKind <> secondKind Or secondKind = 0 Then Exit Function
    ElseIf firstKind <> 3 Then
        Exit Function
    End If
    ch = Mid$(s, p, 1)
    If IR_NameChar(ch) Or ch = "#" Or ch = "[" Or ch = "!" Or ch = ":" Or ch = "(" Then Exit Function
    nextNonSpace = p
    Do While Mid$(s, nextNonSpace, 1) = " "
        nextNonSpace = nextNonSpace + 1
    Loop
    If Mid$(s, nextNonSpace, 1) = ":" Then Exit Function
    finish = p - 1
    IR_Address = Mid$(s, start, p - start)
End Function

Private Function IR_AddressPart(ByVal s As String, ByRef p As Long) As Long
    ' 1 = column, 2 = row, 3 = cell; zero = unsupported.
    Dim col As Long, row As Double, letters As Long, digits As Long, ch As String
    If Mid$(s, p, 1) = "$" Then p = p + 1
    Do
        ch = UCase$(Mid$(s, p, 1))
        If Len(ch) = 0 Then Exit Do
        If ch < "A" Or ch > "Z" Then Exit Do
        letters = letters + 1
        If letters > 3 Then Exit Function
        col = col * 26 + Asc(ch) - 64
        p = p + 1
    Loop
    If col > 16384 Then Exit Function
    If letters > 0 And Mid$(s, p, 1) = "$" Then p = p + 1
    If Mid$(s, p, 1) = "0" Then Exit Function
    Do
        ch = Mid$(s, p, 1)
        If Len(ch) = 0 Then Exit Do
        If ch < "0" Or ch > "9" Then Exit Do
        digits = digits + 1
        row = row * 10 + CLng(ch)
        If row > 1048576 Then Exit Function
        p = p + 1
    Loop
    If letters > 0 Then
        If digits > 0 Then IR_AddressPart = 3 Else IR_AddressPart = 1
    ElseIf digits > 0 Then
        IR_AddressPart = 2
    End If
End Function
