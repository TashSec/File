Attribute VB_Name = "IfFunctionsToIfs"
Option Explicit
' Independent module. No reference to the other delivered module is required.
' Windows desktop Excel. Version 1.0, 5 November 2026.
Private Const TITLE As String = "Convert SUMIF, COUNTIF and AVERAGEIF"
Private Const BACKUP_TAG As String = "ifs"

Private Type CF_Edit
    Address As String
    Before As String
    After As String
    State As String
    Note As String
End Type

Public Sub ConvertIfFunctionsToIfs()
    Dim picked As Range
    Set picked = CF_PickCell("Select any cell on the worksheet to change (in the required open workbook).")
    If picked Is Nothing Then Exit Sub
    CF_Run picked.Worksheet, vbNullString, vbNullString
End Sub


Private Function CF_PickCell(ByVal prompt As String) As Range
    On Error Resume Next
    Set CF_PickCell = Application.InputBox(prompt, TITLE, Type:=8)
    On Error GoTo 0
End Function

Private Function CF_Read(ByVal c As Range, ByVal useF2 As Boolean) As String
    If useF2 Then
        CF_Read = CStr(CallByName(c, "Formula2", VbGet))
    Else
        CF_Read = CStr(c.Formula)
    End If
End Function

Private Sub CF_Write(ByVal c As Range, ByVal formula As String, ByVal useF2 As Boolean)
    If useF2 Then
        CallByName c, "Formula2", VbLet, formula
    Else
        c.Formula = formula
    End If
End Sub

Private Function CF_HasFormula2(ByVal c As Range) As Boolean
    Dim v As Variant
    On Error Resume Next
    v = CallByName(c, "Formula2", VbGet)
    CF_HasFormula2 = (Err.Number = 0)
    Err.Clear
    On Error GoTo 0
End Function

Private Function CF_CellRestriction(ByVal c As Range) As String
    Dim v As Variant
    If c.HasArray Then
        CF_CellRestriction = "Legacy array formula: edit the array as a unit manually."
        Exit Function
    End If
    On Error Resume Next
    v = CallByName(c, "HasSpill", VbGet)
    If Err.Number = 0 Then
        If Not IsNull(v) Then
            If CBool(v) Then CF_CellRestriction = "Spilled array: review the spill formula manually."
        End If
    End If
    Err.Clear
    On Error GoTo 0
End Function

Private Function CF_QuotedEnd(ByVal s As String, ByVal start As Long) As Long
    Dim i As Long, q As String
    q = Mid$(s, start, 1)
    i = start + 1
    Do While i <= Len(s)
        If Mid$(s, i, 1) = q Then
            If Mid$(s, i + 1, 1) = q Then
                i = i + 2
            Else
                CF_QuotedEnd = i
                Exit Function
            End If
        Else
            i = i + 1
        End If
    Loop
    Err.Raise vbObjectError + 710, TITLE, "Unclosed quotation in formula."
End Function

Private Function CF_BracketEnd(ByVal s As String, ByVal start As Long) As Long
    Dim i As Long, depth As Long, ch As String
    i = start
    Do While i <= Len(s)
        ch = Mid$(s, i, 1)
        If ch = "'" And i < Len(s) Then
            ' Apostrophe escapes special characters in structured references.
            i = i + 2
        Else
            If ch = "[" Then depth = depth + 1
            If ch = "]" Then
                depth = depth - 1
                If depth = 0 Then
                    CF_BracketEnd = i
                    Exit Function
                End If
            End If
            i = i + 1
        End If
    Loop
    Err.Raise vbObjectError + 711, TITLE, "Unclosed bracket in formula."
End Function

Private Function CF_NameChar(ByVal ch As String) As Boolean
    If Len(ch) = 0 Then Exit Function
    CF_NameChar = (ch Like "[A-Za-z0-9_.$\]")
    If AscW(ch) < 0 Or AscW(ch) > 127 Then CF_NameChar = True
End Function

Private Function CF_Quote(ByVal s As String) As String
    CF_Quote = Chr$(34) & Replace(s, Chr$(34), Chr$(34) & Chr$(34)) & Chr$(34)
End Function

Private Function CF_Backup(ByVal wb As Workbook) As String
    Dim base As String, ext As String, path As String, k As Long, p As Long
    If Len(wb.Path) = 0 Or InStr(1, wb.Path, "://", vbTextCompare) > 0 Then
        Err.Raise vbObjectError + 712, TITLE, _
            "Save the target workbook to a local or synced folder first, then run again."
    End If
    p = InStrRev(wb.Name, ".")
    If p = 0 Then Err.Raise vbObjectError + 713, TITLE, "The target needs a saved Excel filename."
    base = wb.Path & Application.PathSeparator & Left$(wb.Name, p - 1) & _
           "_before_" & BACKUP_TAG & "_" & Format$(Now, "yyyymmdd_hhnnss")
    ext = Mid$(wb.Name, p)
    path = base & ext
    Do While Len(Dir$(path)) > 0
        k = k + 1
        path = base & "_" & CStr(k) & ext
    Loop
    wb.SaveCopyAs path
    CF_Backup = path
End Function

Private Function CF_Report(ByVal ws As Worksheet, ByRef edits() As CF_Edit, _
                          ByVal n As Long) As Worksheet
    Dim report As Worksheet
    Set report = Workbooks.Add(xlWBATWorksheet).Worksheets(1)
    report.Name = "Formula changes"
    report.Cells.NumberFormat = "@"
    report.Range("A1").Value2 = TITLE
    report.Range("A2").Value2 = "Target workbook"
    report.Range("B2").Value2 = ws.Parent.FullName
    report.Range("A3").Value2 = "Target worksheet"
    report.Range("B3").Value2 = ws.Name
    report.Range("A4").Value2 = "Backup"
    report.Range("B4").Value2 = "Not applied. No backup needed yet."
    report.Range("A6:E6").Value2 = Array("Cell", "Status", "Original formula", "Proposed formula", "Details")
    report.Range("A1:E1").Merge
    report.Range("A1").Font.Size = 16
    report.Range("A1").Font.Bold = True
    report.Range("A6:E6").Font.Bold = True
    report.Range("A6:E6").Interior.Color = RGB(230, 221, 244)
    report.Columns("A").ColumnWidth = 14
    report.Columns("B").ColumnWidth = 17
    report.Columns("C:D").ColumnWidth = 65
    report.Columns("E").ColumnWidth = 55
    CF_FillReport report, edits, n
    report.Activate
    report.Range("C7").Select
    ActiveWindow.FreezePanes = True
    Set CF_Report = report
End Function

Private Sub CF_FillReport(ByVal report As Worksheet, ByRef edits() As CF_Edit, ByVal n As Long)
    Dim data() As Variant, i As Long
    If n = 0 Then
        report.Range("A7").Value2 = "No matching formulas."
        Exit Sub
    End If
    If n > report.Rows.Count - 6 Then _
        Err.Raise vbObjectError + 714, TITLE, "Too many report rows. No changes were applied."
    ReDim data(1 To n, 1 To 5)
    For i = 1 To n
        data(i, 1) = edits(i).Address
        data(i, 2) = edits(i).State
        data(i, 3) = edits(i).Before
        data(i, 4) = edits(i).After
        data(i, 5) = edits(i).Note
    Next i
    With report.Range("A7").Resize(n, 5)
        .NumberFormat = "@"
        .Value2 = data
        .VerticalAlignment = xlTop
        .WrapText = True
        .Rows.RowHeight = 60
    End With
    If report.AutoFilterMode Then report.AutoFilterMode = False
    report.Range("A6:E" & CStr(n + 6)).AutoFilter
End Sub

Private Function CF_SameValue(ByVal a As Variant, ByVal b As Variant) As Boolean
    If IsError(a) Or IsError(b) Or IsArray(a) Or IsArray(b) Then Exit Function
    If VarType(a) <> VarType(b) Then Exit Function
    CF_SameValue = (a = b)
End Function

Private Sub CF_Apply(ByVal ws As Worksheet, ByRef edits() As CF_Edit, ByVal n As Long, _
                    ByVal useF2 As Boolean, ByVal checkResult As Boolean, _
                    ByRef backupPath As String)
    Dim i As Long, j As Long, c As Range, oldValue As Variant
    Dim oldCalc As XlCalculation, oldEvents As Boolean, oldScreen As Boolean
    Dim oldFill As Boolean, settingsCaptured As Boolean
    Dim failure As String, rollbackFailures As Long
    On Error GoTo Failed
    If ws.ProtectContents Then Err.Raise vbObjectError + 715, TITLE, "The target worksheet is protected."
    If ws.Parent.ReadOnly Then Err.Raise vbObjectError + 716, TITLE, "The target workbook is read-only."
    For i = 1 To n
        If edits(i).State = "Proposed" Then
            Set c = ws.Range(edits(i).Address)
            If CF_Read(c, useF2) <> edits(i).Before Then _
                Err.Raise vbObjectError + 717, TITLE, "A source formula changed after the preview. Run again."
        End If
    Next i
    oldCalc = Application.Calculation
    oldEvents = Application.EnableEvents
    oldScreen = Application.ScreenUpdating
    oldFill = Application.AutoCorrect.AutoFillFormulasInLists
    settingsCaptured = True
    Application.EnableEvents = False
    Application.ScreenUpdating = False
    Application.Calculation = xlCalculationManual
    Application.AutoCorrect.AutoFillFormulasInLists = False
    backupPath = CF_Backup(ws.Parent)
    For i = 1 To n
        If edits(i).State = "Proposed" Then
            Set c = ws.Range(edits(i).Address)
            If checkResult Then
                c.Calculate
                oldValue = c.Value2
            End If
            If checkResult And IsError(oldValue) Then
                edits(i).State = "Skipped"
                edits(i).Note = "Existing result is an error; equivalence could not be checked."
            Else
                edits(i).State = "Writing"
                CF_Write c, edits(i).After, useF2
                If checkResult Then
                    c.Calculate
                    If Not CF_SameValue(oldValue, c.Value2) Then
                        CF_Write c, edits(i).Before, useF2
                        c.Calculate
                        edits(i).State = "Skipped"
                        edits(i).Note = "Original restored: the current result changed (or became an error)."
                    Else
                        edits(i).State = "Applied"
                        edits(i).Note = "Current scalar result matched exactly. Review future data and edge cases."
                    End If
                Else
                    edits(i).State = "Applied"
                End If
            End If
        End If
    Next i
    GoTo RestoreSettings
Failed:
    failure = Err.Description
    On Error Resume Next
    For j = n To 1 Step -1
        If edits(j).State = "Applied" Or edits(j).State = "Writing" Then
            Err.Clear
            CF_Write ws.Range(edits(j).Address), edits(j).Before, useF2
            If Err.Number = 0 Then
                edits(j).State = "Restored"
                edits(j).Note = "Run stopped; original formula restored."
            Else
                rollbackFailures = rollbackFailures + 1
                edits(j).State = "Restore failed"
                edits(j).Note = "Recover this workbook from the backup."
            End If
        End If
    Next j
    On Error GoTo 0
RestoreSettings:
    On Error Resume Next
    If settingsCaptured Then
        Application.AutoCorrect.AutoFillFormulasInLists = oldFill
        Application.Calculation = oldCalc
        Application.EnableEvents = oldEvents
        Application.ScreenUpdating = oldScreen
    End If
    On Error GoTo 0
    If Len(failure) > 0 Then
        If rollbackFailures > 0 Then failure = failure & vbCrLf & _
            CStr(rollbackFailures) & " formula(s) could not be restored. Use the backup: " & backupPath
        Err.Raise vbObjectError + 718, TITLE, failure
    End If
End Sub

Private Sub CF_Run(ByVal ws As Worksheet, ByVal source As String, ByVal selector As String)
    Dim edits() As CF_Edit, n As Long, i As Long, proposed As Long, applied As Long
    Dim report As Worksheet, useF2 As Boolean, backupPath As String, failure As String
    On Error GoTo Failed
    If ws.ProtectContents Then Err.Raise vbObjectError + 719, TITLE, "Unprotect the target worksheet first."
    useF2 = CF_HasFormula2(ws.Cells(1, 1))
    CF_Plan ws, source, selector, useF2, edits, n
    Set report = CF_Report(ws, edits, n)
    For i = 1 To n
        If edits(i).State = "Proposed" Then proposed = proposed + 1
    Next i
    If proposed = 0 Then
        MsgBox "No eligible changes. The report lists any matching formulas that were skipped.", vbInformation, TITLE
        Exit Sub
    End If
    If MsgBox(CStr(proposed) & " formula cell(s) proposed for:" & vbCrLf & _
       ws.Parent.Name & " / " & ws.Name & vbCrLf & vbCrLf & _
       "YES: back up the workbook and apply the changes." & vbCrLf & _
       "NO: leave formulas unchanged so you can review the full report." & vbCrLf & _
       "After reviewing, run the macro again to apply.", _
       vbYesNo + vbQuestion + vbDefaultButton2, TITLE) <> vbYes Then Exit Sub
    CF_Apply ws, edits, n, useF2, True, backupPath
    report.Range("B4").Value2 = backupPath
    CF_FillReport report, edits, n
    For i = 1 To n
        If edits(i).State = "Applied" Then applied = applied + 1
    Next i
    MsgBox CStr(applied) & " formula cell(s) changed. See the report for any skips." & _
        vbCrLf & "Backup: " & backupPath & vbCrLf & _
        "Review the workbook, then save it. Normal Excel Undo is not available.", vbInformation, TITLE
    Exit Sub
Failed:
    failure = Err.Description
    On Error Resume Next
    If Not report Is Nothing Then
        If Len(backupPath) > 0 Then report.Range("B4").Value2 = backupPath
        CF_FillReport report, edits, n
    End If
    On Error GoTo 0
    MsgBox "Stopped: " & failure, vbExclamation, TITLE
End Sub

Private Sub CF_Plan(ByVal ws As Worksheet, ByVal source As String, ByVal selector As String, _
                   ByVal useF2 As Boolean, ByRef edits() As CF_Edit, ByRef n As Long)
    Dim formulas As Range, c As Range, before As String, after As String
    Dim hits As Long, why As String
    n = 0
    On Error Resume Next
    Set formulas = ws.UsedRange.SpecialCells(xlCellTypeFormulas)
    On Error GoTo 0
    If formulas Is Nothing Then Exit Sub
    ReDim edits(1 To CLng(formulas.CountLarge))
    For Each c In formulas.Cells
        before = CF_Read(c, useF2)
        hits = 0
        why = vbNullString
        after = CF_Transform(before, source, selector, ws, hits, why, c)
        If hits > 0 Then
            n = n + 1
            edits(n).Address = c.Address(False, False)
            edits(n).Before = before
            edits(n).After = after
            If Len(why) = 0 Then why = CF_CellRestriction(c)
            If Len(after) > 8192 Then why = "The proposed formula exceeds Excel's 8,192-character limit."
            If Len(why) > 0 Then
                edits(n).State = "Skipped"
                edits(n).Note = why
            Else
                edits(n).State = "Proposed"
                edits(n).Note = CStr(hits) & " replacement(s)."
            End If
        End If
    Next c
End Sub

Private Function CF_Transform(ByVal s As String, ByVal unused1 As String, ByVal unused2 As String, _
                              ByVal ws As Worksheet, ByRef hits As Long, ByRef why As String, _
                              Optional ByVal contextCell As Range = Nothing) As String
    On Error GoTo Failed
    CF_Transform = CF_Rewrite(s, ws, hits, why, 0, contextCell)
    If Len(why) > 0 Then CF_Transform = s
    Exit Function
Failed:
    why = "Formula needs manual review: " & Err.Description
    CF_Transform = s
End Function

Private Function CF_Rewrite(ByVal s As String, ByVal ws As Worksheet, ByRef hits As Long, _
                            ByRef why As String, ByVal depth As Long, ByVal contextCell As Range) As String
    Dim i As Long, j As Long, k As Long, closeAt As Long, a As Long
    Dim ch As String, token As String, out As String, name As String, prev As String
    Dim args As Collection, parts() As String, dataRange As String, rangeWhy As String
    If depth > 64 Then Err.Raise 5, TITLE, "Nesting exceeds the supported limit."
    i = 1
    Do While i <= Len(s)
        ch = Mid$(s, i, 1)
        If ch = Chr$(34) Or ch = "'" Or ch = "[" Then
            If ch = "[" Then j = CF_BracketEnd(s, i) Else j = CF_QuotedEnd(s, i)
            out = out & Mid$(s, i, j - i + 1)
            i = j + 1
        ElseIf CF_NameChar(ch) Then
            j = i + 1
            Do While CF_NameChar(Mid$(s, j, 1))
                j = j + 1
            Loop
            token = Mid$(s, i, j - i)
            name = UCase$(token)
            k = j
            Do While Mid$(s, k, 1) = " "
                k = k + 1
            Loop
            prev = vbNullString
            If i > 1 Then prev = Mid$(s, i - 1, 1)
            If Mid$(s, k, 1) = "(" And (name = "LET" Or name = "LAMBDA") Then _
                why = "LET/LAMBDA scope requires manual review."
            If Mid$(s, k, 1) = "(" And prev <> "!" And _
                (name = "SUMIF" Or name = "COUNTIF" Or name = "AVERAGEIF") Then
                hits = hits + 1
                closeAt = CF_CloseParen(s, k)
                Set args = CF_Arguments(Mid$(s, k + 1, closeAt - k - 1))
                ReDim parts(1 To args.Count)
                For a = 1 To args.Count
                    parts(a) = CF_Rewrite(CStr(args(a)), ws, hits, why, depth + 1, contextCell)
                    If Len(Trim$(parts(a))) = 0 Then why = "An explicitly empty argument requires manual review."
                Next a
                If name = "COUNTIF" And args.Count = 2 Then
                    out = out & "COUNTIFS(" & parts(1) & "," & parts(2) & ")"
                ElseIf (name = "SUMIF" Or name = "AVERAGEIF") And (args.Count = 2 Or args.Count = 3) Then
                    dataRange = parts(1)
                    If args.Count = 3 Then dataRange = parts(3)
                    rangeWhy = CF_RangeCheck(ws, parts(1), dataRange, contextCell)
                    If Len(rangeWhy) > 0 Then why = rangeWhy
                    out = out & name & "S(" & dataRange & "," & parts(1) & "," & parts(2) & ")"
                Else
                    why = "Unexpected argument count."
                    out = out & Mid$(s, i, closeAt - i + 1)
                End If
                i = closeAt + 1
            Else
                out = out & token
                i = j
            End If
        Else
            out = out & ch
            i = i + 1
        End If
    Loop
    CF_Rewrite = out
End Function

Private Function CF_CloseParen(ByVal s As String, ByVal start As Long) As Long
    Dim i As Long, depth As Long, ch As String
    i = start
    Do While i <= Len(s)
        ch = Mid$(s, i, 1)
        Select Case ch
            Case Chr$(34), "'": i = CF_QuotedEnd(s, i)
            Case "[": i = CF_BracketEnd(s, i)
            Case "(": depth = depth + 1
            Case ")"
                depth = depth - 1
                If depth = 0 Then
                    CF_CloseParen = i
                    Exit Function
                End If
        End Select
        i = i + 1
    Loop
    Err.Raise 5, TITLE, "Unclosed function call."
End Function

Private Function CF_Arguments(ByVal s As String) As Collection
    Dim result As New Collection, i As Long, start As Long, paren As Long, brace As Long, ch As String
    i = 1
    start = 1
    Do While i <= Len(s)
        ch = Mid$(s, i, 1)
        Select Case ch
            Case Chr$(34), "'": i = CF_QuotedEnd(s, i)
            Case "[": i = CF_BracketEnd(s, i)
            Case "(": paren = paren + 1
            Case ")": paren = paren - 1
            Case "{": brace = brace + 1
            Case "}": brace = brace - 1
            Case ","
                If paren = 0 And brace = 0 Then
                    result.Add Mid$(s, start, i - start)
                    start = i + 1
                End If
        End Select
        i = i + 1
    Loop
    result.Add Mid$(s, start)
    Set CF_Arguments = result
End Function

Private Function CF_RangeCheck(ByVal ws As Worksheet, ByVal criteriaRange As String, _
                               ByVal dataRange As String, ByVal contextCell As Range) As String
    Dim rows1 As Long, cols1 As Long, areas1 As Long
    Dim rows2 As Long, cols2 As Long, areas2 As Long, table As ListObject
    If Not contextCell Is Nothing Then
        On Error Resume Next
        Set table = contextCell.ListObject
        On Error GoTo 0
        If Not table Is Nothing Then
            ' Formula2 may omit the table name inside its own calculated column.
            If Left$(Trim$(criteriaRange), 1) = "[" Then criteriaRange = table.Name & Trim$(criteriaRange)
            If Left$(Trim$(dataRange), 1) = "[" Then dataRange = table.Name & Trim$(dataRange)
        End If
    End If
    ' Evaluate in the target worksheet, never the active report worksheet.
    ' Excel's Evaluate has a 255-character expression limit.
    If Len(criteriaRange) > 245 Or Len(dataRange) > 245 Then
        CF_RangeCheck = "A range expression is too long to validate reliably."
        Exit Function
    End If
    If Not CF_Dimensions(ws, criteriaRange, rows1, cols1, areas1) Or _
       Not CF_Dimensions(ws, dataRange, rows2, cols2, areas2) Then
        CF_RangeCheck = "Could not resolve both ranges; review local names, arrays, links or dynamic references."
    ElseIf areas1 <> 1 Or areas2 <> 1 Then
        CF_RangeCheck = "Multiple-area range requires manual review."
    ElseIf rows1 <> rows2 Or cols1 <> cols2 Then
        CF_RangeCheck = "Range sizes differ. IFS requires matching row and column counts."
    End If
End Function

Private Function CF_Dimensions(ByVal ws As Worksheet, ByVal expression As String, _
                               ByRef rows As Long, ByRef cols As Long, ByRef areas As Long) As Boolean
    Dim isReference As Variant, arguments As Collection, refText As Variant, a1Style As Variant
    Dim trimmed As String
    On Error GoTo NotResolved
    trimmed = Trim$(expression)
    If UCase$(Left$(trimmed, 9)) = "INDIRECT(" Then
        If CF_CloseParen(trimmed, 9) = Len(trimmed) Then
            Set arguments = CF_Arguments(Mid$(trimmed, 10, Len(trimmed) - 10))
            If arguments.Count < 1 Or arguments.Count > 2 Then Exit Function
            If arguments.Count = 2 Then
                a1Style = ws.Evaluate(CStr(arguments(2)))
                If IsError(a1Style) Then Exit Function
                If Not CBool(a1Style) Then Exit Function
            End If
            refText = ws.Evaluate(CStr(arguments(1)))
            If IsError(refText) Or IsArray(refText) Then Exit Function
            If VarType(refText) <> vbString Then Exit Function
            expression = "(" & CStr(refText) & ")"
        End If
    End If
    If Len(expression) > 245 Then Exit Function
    ' Evaluate may return VALUES for INDIRECT/INDEX, even though Excel treats
    ' their results as references inside a worksheet formula. Ask Excel for
    ' reference status and dimensions instead of relying on a COM Range object.
    isReference = ws.Evaluate("ISREF(" & expression & ")")
    If IsError(isReference) Then Exit Function
    If VarType(isReference) <> vbBoolean Then Exit Function
    If Not CBool(isReference) Then Exit Function
    rows = CLng(ws.Evaluate("ROWS(" & expression & ")"))
    cols = CLng(ws.Evaluate("COLUMNS(" & expression & ")"))
    areas = CLng(ws.Evaluate("AREAS(" & expression & ")"))
    CF_Dimensions = (rows > 0 And cols > 0 And areas > 0)
NotResolved:
End Function
